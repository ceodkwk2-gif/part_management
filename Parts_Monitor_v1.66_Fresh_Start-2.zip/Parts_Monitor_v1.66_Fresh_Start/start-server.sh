#!/bin/sh
# macOS/Linux support launcher. Run: sh start-server.sh
set -eu
PARTS_ROOT=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
cd "$PARTS_ROOT/app"
if [ -x "$PWD/runtime/node" ]; then
  PARTS_NODE="$PWD/runtime/node"
elif command -v node >/dev/null 2>&1; then
  PARTS_NODE=$(command -v node)
else
  printf '%s\n' 'Node.js not found. Ask support to install an approved Node.js 22 or 24 on this server PC only.' 'See START_HERE.html. No installation is needed on viewer PCs.'
  exit 1
fi
if ! "$PARTS_NODE" -e "process.exit(Number(process.versions.node.split('.')[0])>=18?0:1)"; then
  printf '%s\n' 'Node.js 18+ is required. Use an approved Node.js 22 or 24 for a new installation.'
  exit 1
fi
printf '%s\n' 'Starting Parts Monitor. Keep this window open while the team uses the dashboard.'
exec "$PARTS_NODE" server.cjs --open
