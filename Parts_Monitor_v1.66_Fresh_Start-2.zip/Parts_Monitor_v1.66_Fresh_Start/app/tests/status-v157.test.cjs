'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const S=require('../src/supply-stages'),A=require('../src/action-requests'),Share=require('../src/share-dialog');
const row=(center,patch={})=>({id:center+'|TEST-000001',part:'TEST-000001',name:'Sample part',center,needed:7,stock:0,shortage:7,open:20,india:0,hq:100,proposed:0,target:1,...patch});
const po=(patch={})=>({part:'TEST-000001',po:'000001',item:'10',poDate:'2026-10-01',ordered:5,eta:'2026-11-28',pending:null,documentPending:0,documentedQty:5,stage:'supply-documents',...patch});
function input(rows=[row('CTDI')],pos=[po()]){return {asof:'2026-10-12',week:'2026-10-12',rows,siel:{available:true,sourceDate:'2026-10-19',rows:pos},pos:[],products:[],sourceDates:[],trend:[]};}
test('SIEL placed qty covers only its reported amount; neither Delivery nor ETA marks receipt',()=>{
 for(const eta of ['2026-01-01','2026-11-28',null]){
  const rows=[{...row('CTDI'),siel:[po({eta})]}],before=JSON.stringify(rows),result=S.classify(rows,{available:true}).get(rows[0].id);
  assert.deepEqual(result.map(a=>[a.code,a.quantity]),[['HQ',5],['INDIA_ORDER',2]]);assert.equal(JSON.stringify(rows),before);
 }
});
test('one status row retains mixed states and PO quantities without request / reply columns',()=>{
 const m=A.build(input());assert.equal(m.rows.length,1);assert.equal(m.columns.length,12);assert.equal(m.rows[0].hqPo,5);assert.equal(m.rows[0].eta,'2026-11-28 / 5');assert.match(m.rows[0].status,/본사 → 법인 입고 대기 5/);assert.match(m.rows[0].status,/법인 → 본사 추가 PO 필요 2/);
 assert(!m.columns.some(c=>/reply|action|quantity|id|basis|dates/.test(c.key)));const csv=Share.csv(Share.normalize(m));assert.equal(csv.split('\r\n')[0].split(',').length,12);assert(!/공급문서|요청|회신|자료 확인 필요/.test(csv));
});
test('HQ export deduplicates shared orders and stock across centers while aggregating demand',()=>{
 const d=input([row('CTDI'),row('Flex')],[po({ordered:20}),po({po:'000002',ordered:4,eta:'2026-12-01'})]);
 const m=A.build(d,{recipient:'HQ'});assert.equal(m.rows.length,1);assert.equal(m.rows[0].hq,100);assert.equal(m.rows[0].hqPo,24);assert.equal(m.rows[0].shortage,14);assert.match(m.rows[0].status,/본사 → 법인 입고 대기 14$/);assert.equal(m.rows[0].eta,'2026-11-28 / 20\n2026-12-01 / 4');
 const partial=A.build(input([row('CTDI'),row('Flex')],[po()]),{recipient:'HQ'});assert.equal(partial.rows.length,1);assert.equal(partial.rows[0].hqPo,5);assert.match(partial.rows[0].status,/센터별 배정 없음/);
});
test('missing SIEL and dates remain explicit, and filtered status exports keep all selected rows',()=>{
 const unknown=input([row('CTDI',{shortage:null,needed:null,stock:null})]);assert.match(A.build(unknown,{kind:'ALL',rowIds:[unknown.rows[0].id]}).rows[0].status,/센터 재고·수리 필요량 미확인/);
 const d=input();d.siel={available:false,rows:[]};const m=A.build(d);assert.equal(m.rows[0].hqPo,'미확인');assert.equal(m.rows[0].eta,'—');assert.match(m.rows[0].status,/SIEL PO Report 미제공/);
 const s=input([row('CTDI'),row('Flex')],[po({ordered:20,eta:null})]);assert.equal(A.build(s,{center:'Flex'}).rows.length,1);assert.equal(A.build(s,{rowIds:[]}).rows.length,0);assert.equal(A.build(s,{rowIds:[s.rows[0].id]}).rows[0].eta,'도착 예정일 미정 / 20');
});

test('shortage export includes the selected part buffer gap without adding unrelated buffer-only parts',()=>{
 const d=input([row('CTDI',{proposed:12,target:35}),row('Flex',{id:'Flex|TEST-000002',part:'TEST-000002',shortage:0,proposed:9,target:9})]);
 const selected=A.build(d,{kind:'SHORTAGE',rowIds:[d.rows[0].id]});assert.equal(selected.rows.length,1);assert.match(selected.rows[0].status,/수리센터 → 법인 추가 PO 필요 12/);assert.match(selected.rows[0].status,/수리 0 \+ 보유 12/);
 assert.equal(A.build(d).rows.length,2);
});

test('part detail and progress records share the same partial PO status as downloads',()=>{
 const d=input();d.tasks=[{rowId:d.rows[0].id,kind:'HQ',textKo:'예전 조치 지시문',textEn:'Legacy action instruction'}];
 for(const language of ['ko','en']){
  const expected=A.build(d,{language}).rows[0].status.split('\n');
  for(const html of [require('../src/part-trace').render({data:d,part:'TEST-000001',language}),require('../src/workflow').render({data:d,language})]){
   for(const status of expected)assert(html.includes(status));
   assert(!/공급 문서|문서 미작성|자동 조치|예전 조치 지시문|Legacy action instruction/.test(html));
  }
 }
});
