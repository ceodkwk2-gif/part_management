'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),Data=require('../src/stage-data'),Dash=require('../src/stage-dashboard'),Exports=require('../src/action-requests');
const row={id:'CTDI|TEST-001',part:'TEST-001',center:'CTDI',needed:0,stock:2,target:15,open:20,proposed:0,shortage:0,waitingCovered:true,india:0,hq:970,pos:[],siel:[{po:'P',item:'10',part:'TEST-001',ordered:50,eta:'2027-01-28',status:'Buyer I/R'}],sourceDates:{hq:'2026-10-06'},sourceWeeks:{}};
test('HQ stock and PO review flag never changes quantities or source ETA and requires an actual supply gap',()=>{
 const before=JSON.stringify(row);assert.deepEqual(Data.reviewFlags(row).map(f=>f.code),['HQ_STOCK_ETA']);assert.equal(JSON.stringify(row),before);
 for(const patch of [{hq:0},{hq:null},{open:0},{india:13},{india:null},{stock:15},{siel:[]}])assert.equal(Data.reviewFlags({...row,...patch}).length,0,JSON.stringify(patch));
 assert.equal(Data.reviewFlags({...row,siel:[{...row.siel[0],eta:null}]}).at(-1).hasMissingEta,true);
});
test('PO with a missing ETA is explicitly unset, while no PO is not presented as an unset ETA',()=>{
 const d={asof:'2026-10-12',rows:[row],products:[],sourceDates:[],siel:{available:true,sourceDate:'2026-10-19',rows:[...row.siel,{...row.siel[0],po:'P2',eta:null,ordered:5}]}};
 for(const language of ['ko','en']){const m=Exports.build(d,{rowIds:[row.id],kind:'ALL',language});assert(!JSON.stringify(m).includes('Buyer I/R'));assert.match(m.rows[0].eta,/2027-01-28 \/ 50/);assert.match(m.rows[0].eta,language==='ko'?/도착 예정일 미정 \/ 5/:/Arrival date not set \/ 5/);}
 assert.equal(Exports.build({...d,siel:{available:true,rows:[]}},{rowIds:[row.id],kind:'ALL'}).rows[0].eta,'—');
});
test('detail checks identify affected fields, calculation impact and exact WIP provenance without modifying data',()=>{
 const d={asof:'2026-10-12',rows:[{...row,avg:null,target:null,proposed:null,avgReason:'대시보드 누락 — 사용량 이력 보완 필요'}],sourceDates:[{type:'dashboard',center:'CTDI',file:'inventory.xlsx',sheet:'Parts'}],issues:{unresolvedProducts:[{center:'CTDI',required:'TRUNCATED',source:'wip.xlsx',sheet:'InHouse',row:42}]},siel:{available:true,rows:row.siel}};
 const before=JSON.stringify(d),checks=Data.quantityChecks(d);assert.equal(checks.length,2);assert.deepEqual(checks[0].missing,['보유 목표','추가 PO']);assert.equal(checks[1].row,42);assert.equal(Data.quantityChecks(d,'Flex').length,0);
 const html=Dash.checksHTML(d);assert.match(html,/inventory.xlsx/);assert.match(html,/wip.xlsx \/ InHouse \/ 42행/);assert.match(html,/제품 대수 유지/);assert.equal(JSON.stringify(d),before);
});
