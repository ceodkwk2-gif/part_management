'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const C=require('../src/core.js'),S=require('../src/summary-data.js'),X=require('../vendor/xlsx.full.min.js');
const date='2026-10-12',headers=['Final Status','Required Part','Serial No','RMA No','Physical Receipt Date'];
function wip(center,sheets){const w=X.utils.book_new();for(const [name,rows]of Object.entries(sheets))X.utils.book_append_sheet(w,X.utils.aoa_to_sheet([headers,...rows]),name);return C.importWorkbook(w,'Synthetic_'+center+'_12102026.xlsx',X,{center}).sources;}
function item(sn,part,n,status='Waiting for Component'){return [status,part+' #'+n,sn,'R'+sn,'09/01/2026'];}
function stock(center,parts){return {type:'dashboard',center,date,file:'Synthetic.xlsx',usageMonths:['2026-09'],rows:parts.map(part=>({part,stock:0,po:0,usage:{'2026-09':1}}))};}
test('restored independent Flex demand adds 201 units across 20 rows and 15 distinct codes after five overlaps',()=>{
 const ctdi=Array.from({length:32},(_,i)=>'TEST-'+String(i+1).padStart(6,'0'));
 const flex=[...ctdi.slice(0,5),...Array.from({length:15},(_,i)=>'TEST-'+String(i+101).padStart(6,'0'))];
 const quantities=[10,4,4,1,1,1,1,1,1,60,55,16,14,13,8,5,2,2,1,1];
 const rows=flex.map((p,i)=>item('F'+i,p,quantities[i]));
 const done=Array.from({length:4},(_,i)=>item('D'+i,'0',0,'For Test'));
 const flexSource=wip('Flex',{Inhouse:[...rows,...done],'FAN-Inhouse':done.map(r=>['Repairable',...r.slice(1)])});
 const state=C.empty();state.sources=[stock('CTDI',ctdi),stock('Flex',flex),...flexSource,...wip('CTDI',{WIP_Jio:ctdi.map((p,i)=>item('C'+i,p,i===31?39:15)),WIP_Airtel:[],WIP_Vi:[]})];
 const saved=JSON.stringify(state),result=C.calculate(state,date),short=result.parts.filter(r=>r.shortage>0),f=short.filter(r=>r.center==='Flex'),c=short.filter(r=>r.center==='CTDI');
 assert.equal(flexSource[0].duplicateDetails.length,4);assert.equal(flexSource[0].wipImportComplete,false);
 assert.deepEqual([f.length,f.reduce((n,r)=>n+r.shortage,0)],[20,201]);
 assert.deepEqual([c.length,c.reduce((n,r)=>n+r.shortage,0)],[32,504]);
 assert.deepEqual([new Set(short.map(r=>r.part)).size,short.reduce((n,r)=>n+r.shortage,0)],[47,705]);
 assert.equal(f.filter(r=>c.some(x=>x.part===r.part)).length,5);assert.equal(JSON.stringify(state),saved);
});
test('known repair shortage remains visible when monthly use is unknown; unparsed old products mark only supported partial totals',()=>{
 const calculated={parts:[{center:'Flex',part:'명판',needed:8,stock:0,shortage:8,target:null,open:0,proposed:null}],used:[{type:'dashboard',center:'Flex'},{type:'wip',center:'Flex',operator:'Jio',rows:[]}],wip:[{center:'Flex',key:'bad',required:'unclear',age:60,tokens:{parts:{},unparsed:'unclear'}}]};
 const q=S.quantityCoverage(calculated,'Flex');assert.equal(q.shortage.unknownRows,0);assert.equal(q.order.unknownRows,1);assert.equal(q.shortage.partial,true);assert.equal(q.products.partial,false);assert.equal(q.overdue.partial,true);assert.deepEqual(q.order.reasons,['월 사용량 이력 미확인']);
 const next=S.quantityCoverage({...calculated,wip:[]},'Flex');assert.notEqual(q.shortage.signature,next.shortage.signature);assert.equal(next.shortage.partial,false);assert.equal(next.order.partial,true);
});
