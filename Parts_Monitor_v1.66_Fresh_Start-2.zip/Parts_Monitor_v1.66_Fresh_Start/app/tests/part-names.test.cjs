'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),Names=require('../src/part-names.js');
const name=(description,part='ZZZZ-123456')=>Names.extractName(description,part).name;
const source=(type,center,rows)=>({type,center,file:type+'-'+center+'.xlsx',sheet:'Parts',date:'2026-01-15',rows});
const row=(part,description,line=2)=>({part,description,row:line});
test('specification delimiters retain the explicit component family',()=>{
 assert.equal(name('R-CHIP;2.2Kohm,1%,TP'),'R-CHIP');
 assert.equal(name('CONNECTOR-BACK PANEL;3P,BLACK'),'CONNECTOR-BACK PANEL');
 assert.equal(name('OSCILLATOR-CLOCK,50MHz,3.3V'),'OSCILLATOR-CLOCK');
});
test('known compact families normalize without guessing from material codes',()=>{
 assert.equal(name('R CHIP 300 OHM'),'R-CHIP');
 assert.equal(name('RCHIP 2KOHM'),'R-CHIP');
 assert.equal(name('FET-SILICONMODEL123,N,40V'),'FET-SILICON');
 assert.equal(name('IC_DC_DC CONVERTER MODEL123,LQFN'),'IC-DC/DC CONVERTER');
 assert.equal(name('IC-DDR4SDRAM;FBGA'),'IC-DDR4 SDRAM');
 assert.equal(name('R-CHIP ARRAY;10Kohm'),'R-CHIP ARRAY');
 assert.equal(name('THERMAL PAD SOFT;12x12'),'THERMAL PAD SOFT');
});
test('generic nameplate and thermal pad are material names',()=>{
 assert.equal(name('Serial# Plate'),'명판');
 assert.equal(name('THERMALPAD12.5X12.5X3'),'THERMAL PAD');
 assert.equal(Names.resolve(null,'Name plate').partName,'명판');
 assert.equal(Names.resolve(null,'THERMAL PAD').partName,'THERMAL PAD');
});
test('functional distinctions and slash notation survive shortening',()=>{
 assert.equal(name('COVER-FRONT PANEL ASSY;BLACK'),'COVER-FRONT PANEL ASSY');
 assert.equal(name('COVER-BOTTOM SHIELD CAN;AL'),'COVER-BOTTOM SHIELD CAN');
 assert.equal(name('IC-IF/RF AMP;MODEL123'),'IC-IF/RF AMP');
 assert.equal(name('JACK-MODULAR'),'JACK-MODULAR');
 assert.equal(name('FREQ-ISOLATOR'),'FREQ-ISOLATOR');
 assert.equal(name('ASSY-MODELX1'),'ASSY-MODELX1');
 assert.equal(name('FAN_C4_ASSY_VendorA(MODEL123'),'FAN C4 ASSY VendorA');
 assert.equal(name('FAN C4 CONTROL BOARD(MODEL123)'),'FAN C4 CONTROL BOARD');
});
test('repeated own code and obvious trailing specs are removed, not names',()=>{
 assert.equal(name('REAR HOUSING GUARD (ZZZZ- 123456)'),'REAR HOUSING GUARD');
 assert.equal(name('CONNECTOR-BACK PANEL 3P'),'CONNECTOR-BACK PANEL');
 assert.equal(name('LOWER PLATE 10x20mm'),'LOWER PLATE');
 assert.equal(name('COVER-MODEL1 BOTTOM PC'),'COVER-MODEL1 BOTTOM PC');
});
test('no meaningful name is invented from empty, numeric, specification or opaque code',()=>{
 for(const description of ['',null,'-',123,'50MHz','ZZZZ-123456'])assert.equal(name(description),Names.MISSING);
 assert.equal(name('MODEL123','MODEL123'),Names.MISSING);
 assert.equal(name('DUST CAP','DUST CAP'),'DUST CAP');
 assert.equal(name('RDU LOCK SCREW','RDU LOCK SCREW'),'RDU LOCK SCREW');
 assert.equal(name('Barrel Oring','BARREL ORING'),'Barrel Oring');
 assert.equal(name('Taper Needle TEST-14G','TAPER NEEDLE TEST-14G'),'Taper Needle TEST-14G');
});
test('local dashboard takes precedence, global name is deterministic',()=>{
 const sources=[source('dashboard','Flex',[row('PART1','COVER-TOP;A')]),source('dashboard','CTDI',[row('PART1','COVER-FRONT;B')]),source('india','',[row('PART1','COVER-INVENTORY;C')])];
 const index=Names.buildNameIndex(sources);
 assert.equal(Names.resolve(index,'part1','Flex').partName,'COVER-TOP');
 assert.equal(Names.resolve(index,'PART1','CTDI').partName,'COVER-FRONT');
 assert.equal(Names.resolve(index,'PART1').partName,'COVER-FRONT');
});
test('missing local name falls back to other dashboard then inventory then PO',()=>{
 const index=Names.buildNameIndex([
  source('dashboard','Flex',[row('PART1',''),row('PART2','PART2'),row('PART3',''),row('PART4','')]),
  source('dashboard','CTDI',[row('PART1','FAN ASSY')]),source('india','',[row('PART2','FUSE-SURFACE MOUNT;3A')]),
  source('hq','',[row('PART3','CONNECTOR-SOCKET;4P')]),source('po','Flex',[row('PART4','CABLE-POWER;1M')])]);
 for(const [part,expected,type] of [['PART1','FAN ASSY','dashboard'],['PART2','FUSE-SURFACE MOUNT','india'],['PART3','CONNECTOR-SOCKET','hq'],['PART4','CABLE-POWER','po']]){
  assert.equal(Names.resolve(index,part,'Flex').partName,expected);assert.equal(Names.resolve(index,part,'Flex').source.type,type);
 }
});
test('topmost duplicate source row controls the description, even when blank',()=>{
 const index=Names.buildNameIndex([source('dashboard','Flex',[row('PART1','LOWER COVER',9),row('PART1','',2)]),source('india','',[row('PART1','FALLBACK COVER',3)])]);
 assert.equal(Names.resolve(index,'PART1','Flex').partName,'FALLBACK COVER');
 assert.equal(Names.resolve(index,'PART1','Flex').source.type,'india');
});
test('raw text and provenance remain available without source mutation',()=>{
 const sources=[source('dashboard','Flex',[{...row('PART1','R-CHIP; 10Kohm, 1%',7),sheet:'Alternate'}])],before=JSON.stringify(sources),index=Names.buildNameIndex(sources),record=Names.resolve(index,'PART1','Flex');
 assert.equal(JSON.stringify(sources),before);assert.equal(record.rawDescription,'R-CHIP; 10Kohm, 1%');
 assert.deepEqual(record.source,{type:'dashboard',center:'Flex',file:'dashboard-Flex.xlsx',sheet:'Alternate',row:7,date:'2026-01-15'});
 assert.deepEqual(Names.resolve(JSON.parse(JSON.stringify(index)),'PART1','Flex'),record);
});
test('unprovided and WIP product descriptions cannot become component names',()=>{
 const index=Names.buildNameIndex([source('wip','Flex',[row('PART1','PRODUCT NAME')])]);
 assert.equal(Names.resolve(index,'PART1','Flex').partName,Names.MISSING);
 assert.equal(Names.resolve(index,'ZZZZ-123456').source,null);
});
test('material keys do not change or merge merely because names match',()=>{
 const index=Names.buildNameIndex([source('dashboard','Flex',[row('ZZZZ-123456','Name plate'),row('YYYY-654321','Name plate'),row('__proto__','COVER')])]);
 assert.equal(Object.keys(index.byPart).length,3);assert.equal(Names.resolve(index,'ZZZZ-123456').part,'ZZZZ-123456');
 assert.equal(Names.resolve(index,'YYYY-654321').part,'YYYY-654321');assert.equal(Names.resolve(index,'__proto__').partName,'COVER');
});
