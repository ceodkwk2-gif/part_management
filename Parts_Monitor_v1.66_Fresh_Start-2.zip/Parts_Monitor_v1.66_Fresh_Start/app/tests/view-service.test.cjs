'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const fs=require('node:fs'),os=require('node:os'),path=require('node:path');
const C=require('../src/core'),R=require('../src/reporting'),S=require('../src/summary-data'),{createViewService}=require('../server/view-service.cjs');
const part='1000-000001',other='1000-000002';
const key=ref=>JSON.stringify([ref.key,ref.revision]);
const row=(sn='S1',parts={[part]:1},extra={})=>({key:sn+'|R1',sn,rma:'R1',receipt:'2026-08-01',status:'Waiting for Component',required:Object.keys(parts).join(','),tokens:{parts,unparsed:''},row:2,...extra});
function source(date,rows=[row()],extra={}){return {type:'wip',center:'Flex',operator:'Jio',date,file:'Synthetic.xlsx',sheet:'Inhouse',duplicates:[],wipImportComplete:true,statuses:{UNRELATED:'Repaired',...Object.fromEntries(rows.map(row=>[row.key,row.status]))},rows,...extra};}
function fakeStore(initial){
 let state=R.normalizeState(initial),revision=1;const reads={reports:[],sources:[]};
 function entries(){return [...new Map([...state.sources,...Object.values(state.reportingSourceArchive||{})].map(source=>[key({key:C.sourceKey(source),revision:source.reportingRevision}),{key:C.sourceKey(source),revision:source.reportingRevision,source}])).values()];}
 return {reads,set(next){state=R.normalizeState(next);revision++;},state:()=>state,
 compactManifest(){const index=entries().map(({source,...entry})=>{const {rows,statuses,...meta}=source;return {...entry,hash:entry.revision,meta:{...meta,rowCount:rows.length}};});const {sources,reportingSourceArchive,...metadata}=state;return {revision,updatedAt:'NOW'+revision,state:metadata,sourceIndex:index,currentSourceRefs:sources.map(source=>({key:C.sourceKey(source),revision:source.reportingRevision})),archiveSourceRefs:Object.fromEntries(Object.entries(reportingSourceArchive||{}).map(([k,source])=>[k,{key:C.sourceKey(source),revision:source.reportingRevision}]))};},
 readSources(refs){reads.sources.push(refs.length);const index=new Map(entries().map(entry=>[key(entry),entry.source]));return refs.map(ref=>index.get(key(ref))).filter(Boolean);},
 readReportState(id){reads.reports.push(id);const report=R.reports(state).find(report=>report.id===id),resolved=R.reportState(state,id);return {...resolved,reportingWeeks:[report],reportingSourceArchive:{},selectedReportingWeek:id};}
 };
}
function makeState(){let state=R.normalizeState({...C.empty(),sources:[source('2026-09-28',[row('A'),row('B')])]});state=R.applySources(state,[source('2026-10-05',[row('A',{[part]:2,[other]:1}),row('C')],{statuses:{'A|R1':'Waiting for Component','B|R1':'Repaired','C|R1':'Waiting for Module',UNRELATED:'Complete'}})],'2026-10-05');return state;}

test('view contract matches full-state calculations and trace using only scoped source reads',()=>{
 const state=makeState(),before=JSON.stringify(state),store=fakeStore(state),service=createViewService({store}),view=service.getView(),expected=S.build(state);
 for(const field of ['rows','tasks','products','pos','metricsByCenter','overdue','trend','supplierEvidenceStatus'])assert.deepEqual(view[field],expected[field],field);
 assert.equal(JSON.stringify(state),before);assert(store.reads.sources.every(count=>count===1));assert.equal(service.diagnostics().cachedWeeks,2);assert(!JSON.stringify(service.getManifest()).includes('UNRELATED'));assert(!('sources' in service.getManifest().state));
});
test('notes-only revision reuses view/history/trace; settings reuse trace but recalculate metrics',()=>{
 const store=fakeStore(makeState()),service=createViewService({store});service.getView();const first=service.diagnostics();store.set({...store.state(),notes:{a:'operator note'}});service.invalidate({operation:'notes'});const notesView=service.getView();assert.equal(notesView.revision,2);assert.equal(service.diagnostics().viewBuilds,first.viewBuilds);assert.equal(service.diagnostics().traceBuilds,first.traceBuilds);assert.equal(service.diagnostics().weekBuilds,first.weekBuilds);
 store.set({...store.state(),settings:{...store.state().settings,targetMonths:2}});service.getView();assert.equal(service.diagnostics().traceBuilds,first.traceBuilds);assert.equal(service.diagnostics().weekBuilds,first.weekBuilds+2);assert.equal(service.diagnostics().viewBuilds,first.viewBuilds+1);
});
test('appending a report builds only its weekly metrics and keeps past results',()=>{
 const store=fakeStore(makeState()),service=createViewService({store}),before=service.getView(),counts=service.diagnostics();store.set(R.applySources(store.state(),[source('2026-10-12',[row('A'),row('D')])],'2026-10-12'));const after=service.getView();assert.equal(service.diagnostics().weekBuilds,counts.weekBuilds+1);assert.deepEqual(after.trend.slice(0,2),before.trend);assert.equal(after.trend.length,3);assert.equal(after.trend[2].observedWaitingChanges.Flex.notListedProducts,1);assert.equal(after.trend[2].observedWaitingChanges.Flex.newProducts,1);
});
test('same-week corrections update trace and only affected metric points',()=>{
 const store=fakeStore(makeState()),service=createViewService({store});service.getView();const before=service.diagnostics();store.set(R.applySources(store.state(),[source('2026-10-05',[row('A',{[other]:3})])],'2026-10-05'));const view=service.getView(),expected=S.build(store.state());assert.equal(service.diagnostics().weekBuilds,before.weekBuilds+1);assert.deepEqual(view.products,expected.products);assert.deepEqual(view.trend,expected.trend);assert.equal(view.products[0].parts[0].baseline,false);
});
test('explicit past view never receives future traces or waiting changes',()=>{
 const store=fakeStore(makeState()),service=createViewService({store}),view=service.getView({reportId:'2026-09-28'}),expected=S.build(store.state(),{reportId:'2026-09-28'});assert.deepEqual(view.products,expected.products);assert.equal(view.trend.length,1);assert.equal(view.products.length,2);assert.throws(()=>service.getView({reportId:'2026-11-01'}),/저장된/);
});
test('retained stale WIP is not added as another observation or fresh trend',()=>{
 const base=R.normalizeState({...C.empty(),sources:[source('2026-09-28')]}),state=R.applySources(base,[],'2026-10-05'),store=fakeStore(state),view=createViewService({store}).getView();assert.equal(view.products[0].parts[0].observations,1);assert.equal(view.trend.at(-1).metricsByCenter.Flex.wip,null);assert.equal(view.overdue.freshByCenter.Flex,false);
});
test('empty store and deliberate cache reset preserve empty contract',()=>{
 const store=fakeStore(C.empty()),service=createViewService({store}),view=service.getView();assert.equal(view.dataAvailable,false);assert.equal(view.revision,1);service.invalidate({force:true});assert.equal(service.diagnostics().cachedWeeks,0);service.close();
});
test('derived disk cache survives restart, invalidates changed input, and recovers from corrupt cache',()=>{
 const cacheDir=fs.mkdtempSync(path.join(os.tmpdir(),'parts-view-cache-'));
 try{
  const store=fakeStore(makeState()),first=createViewService({store,cacheDir}),expected=first.getView();first.close();
  const restarted=createViewService({store,cacheDir}),same=restarted.getView();assert.deepEqual(JSON.parse(JSON.stringify(same)),JSON.parse(JSON.stringify(expected)));assert.equal(restarted.diagnostics().viewBuilds,0);assert.equal(restarted.diagnostics().diskHits,1);
  store.set(R.applySources(store.state(),[source('2026-10-12',[row('A')])],'2026-10-12'));const next=restarted.getView();assert.equal(restarted.diagnostics().weekBuilds,1);assert.equal(next.trend.length,3);
  restarted.close();fs.writeFileSync(path.join(cacheDir,'view-latest.json.gz'),'corrupt');const recovered=createViewService({store,cacheDir});assert.equal(recovered.getView().week,'2026-10-12');assert.equal(recovered.diagnostics().viewBuilds,1);assert.equal(recovered.diagnostics().weekBuilds,0);assert.equal(recovered.diagnostics().traceBuilds,0);
  recovered.invalidate({force:true});assert.equal(fs.readdirSync(cacheDir).length,0);recovered.close();
 }finally{fs.rmSync(cacheDir,{recursive:true,force:true});}
});
test('status projection keeps whitespace-normalized SN/RMA evidence for earlier nonwaiting observations',()=>{
 let state=R.normalizeState({...C.empty(),sources:[source('2026-09-28',[],{statuses:{' s1 | r1 ':'Repaired',UNRELATED:'Complete'}})]});state=R.applySources(state,[source('2026-10-05',[row()])],'2026-10-05');const view=createViewService({store:fakeStore(state)}).getView(),expected=S.build(state);assert.deepEqual(view.products,expected.products);assert.equal(view.products[0].parts[0].priorWithoutDate,'2026-09-28');
});
