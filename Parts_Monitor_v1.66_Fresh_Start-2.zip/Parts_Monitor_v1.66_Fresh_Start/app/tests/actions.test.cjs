'use strict';
// Invented values only. These tests do not load an operational export.
const test=require('node:test');
const assert=require('node:assert/strict');
const Core=require('../src/core.js');
const Actions=require('../src/actions.js');
const PART='TEST-000001',OTHER='TEST-000002',DATE='2024-08-12';
const MONTHS=['2024-02','2024-03','2024-04','2024-05','2024-06','2024-07'];
function row(overrides={}){
 const r={center:'Flex',part:PART,stock:10,needed:2,avg:4,target:4,open:0,detailPending:null,
  india:10,hq:20,issues:[],needBasis:'dashboard',...overrides};
 if(!Object.hasOwn(overrides,'shortage'))r.shortage=r.stock!=null&&r.needed!=null?Math.max(0,r.needed-r.stock):null;
 if(!Object.hasOwn(overrides,'proposed'))r.proposed=[r.stock,r.needed,r.target,r.open].every(v=>typeof v==='number')?Math.max(0,r.needed+r.target-r.stock-r.open):null;
 return r;
}
function project(parts,risks=[],extra={}){return Actions.fromResults({parts,wip:[],warnings:[],...extra},{allRows:risks},{asof:DATE})}
function group(result,code){return result.groups.find(g=>g.code===code)}
test('empty input has five zero groups and no invented part or action',()=>{
 const r=project([]);assert.equal(r.groups.length,5);assert.equal(r.counts.allParts,0);assert.equal(r.metrics.shortage.value,0);assert.equal(r.tasks.order.partCount,0);
});
test('current physical shortage remains urgent with ample existing PO',()=>{
 const r=project([row({stock:1,needed:3,open:10,india:0,hq:0})]),p=r.rows[0];
 assert.equal(p.category,'SUPPLY_NOW');assert.equal(p.shortage.value,2);assert.equal(p.proposed.value,0);
 assert.equal(r.tasks.poFollowup.partCount,1);assert.match(p.nextAction,/부족 2개/);assert.match(p.nextAction,/긴급 입고 필요/);assert.match(p.nextAction,/공급 진행 확인 필요/);assert.doesNotMatch(p.nextAction,/조달 필요|추가 발주/);
});
test('additional PO needed is separate from current shortage and existing open PO',()=>{
 const r=project([row({stock:2,needed:2,open:1})]);
 assert.equal(r.rows[0].category,'ORDER');assert.equal(r.tasks.order.quantity.value,3);assert.equal(r.tasks.supply.partCount,0);
});
test('pending covering target gap requires arrival followup but no new PO',()=>{
 const r=project([row({stock:3,needed:2,open:3})]);
 assert.equal(r.rows[0].category,'WAIT_PO');assert.equal(r.metrics.proposed.value,0);assert.equal(group(r,'WAIT_PO').metrics.open.value,3);
});
test('receipt-only category uses strict after-repair reserve boundary and complete sufficient PO evidence',()=>{
 const qualifies=row({stock:3,needed:2,target:4,open:3});
 assert.equal(Core.waitingCovered(qualifies),true);
 const boundary=row({stock:6,needed:2,target:4,open:2});
 const insufficient=row({stock:3,needed:2,target:4,open:2});
 for(const candidate of [boundary,insufficient,row({stock:0,needed:0,target:0,open:2}),row({stock:3,needed:0,target:4,open:0})]){
  const r=project([candidate]);assert.equal(Core.waitingCovered(candidate),false);assert.equal(r.tasks.waitingCovered.partCount,0);
  assert.notEqual(r.members[0].category,'WAIT_PO');assert.equal(group(r,'WAIT_PO').partCount,0);
 }
 // Do not trust a stale proposed=0 if the physical and pending quantities fail coverage.
 assert.equal(Core.waitingCovered({...insufficient,proposed:0}),false);
 for(const field of ['stock','needed','target','open','proposed']){
  for(const value of [null,undefined,NaN,Infinity,-1]){
   const candidate={...qualifies,[field]:value},r=project([candidate]);
   assert.equal(Core.waitingCovered(candidate),false,field+'='+value);assert.equal(r.tasks.waitingCovered.partCount,0);
   assert.notEqual(r.members[0].category,'WAIT_PO');
  }
 }
});
test('task rows and metrics include only qualifying centers when one shared code needs different actions',()=>{
 const waiting=row({stock:1,needed:0,target:2,open:1});
 const ordering=row({center:'CTDI',stock:0,needed:2,target:2,open:1});
 const before=JSON.stringify([waiting,ordering]),r=project([waiting,ordering]);
 const wait=r.tasks.waitingCovered,order=r.tasks.order,supply=r.tasks.supply;
 assert.equal(wait.partCount,1);assert.equal(order.partCount,1);assert.equal(supply.partCount,1);
 assert.deepEqual(wait.rows[0].centers,['Flex']);assert.deepEqual(wait.rows[0].members.map(m=>m.center),['Flex']);
 assert.deepEqual(wait.members.map(m=>m.center),['Flex']);assert.equal(wait.rows[0].proposed.value,0);assert.equal(wait.rows[0].shortage.value,0);
 assert.equal(wait.rows[0].open.value,1);assert.equal(wait.quantity.value,1);assert.equal(wait.rows[0].category,'WAIT_PO');
 assert.deepEqual(order.rows[0].centers,['CTDI']);assert.equal(order.rows[0].proposed.value,3);assert.equal(order.quantity.value,3);
 assert.deepEqual(supply.rows[0].centers,['CTDI']);assert.equal(supply.quantity.value,2);
 assert.equal(r.allRows[0].members.length,2,'Full inventory keeps both center facts');
 assert.equal(JSON.stringify([waiting,ordering]),before,'Task projection never changes original quantities');
});
test('waiting task never includes a stock-sufficient or unknown other-center row',()=>{
 const waiting=row({stock:0,needed:0,target:1,open:1});
 for(const other of [row({center:'CTDI'}),row({center:'CTDI',stock:null})]){
  const r=project([waiting,other]),task=r.tasks.waitingCovered;
  assert.equal(task.partCount,1);assert.equal(task.quantity.value,1);assert.equal(task.rows[0].proposed.value,0);
  assert.deepEqual(task.rows[0].centers,['Flex']);assert.deepEqual(task.rows[0].dataFields,[]);
  assert.deepEqual(group(r,'WAIT_PO').rows[0].centers,['Flex']);assert.equal(group(r,'WAIT_PO').metrics.open.value,1);
  assert.equal(r.allRows[0].members.length,2);
 }
});
test('stock at or above target still waits when repairs use reserve that existing PO replenishes',()=>{
 for(const quantities of [{stock:10,needed:8,target:10,open:8},{stock:20,needed:15,target:10,open:5},{stock:0,needed:0,target:10,open:10}]){
  const input=row(quantities),before=JSON.stringify(input),r=project([input]),part=r.members[0],exclusive=Actions.exclusiveStatus(r);
  assert.equal(part.proposed,0);assert.equal(part.shortage,0);assert.equal(part.waitingCovered,true);
  assert.equal(part.category,'WAIT_PO');assert.equal(exclusive.byPart[PART],'WAIT_PO');
  assert.equal(r.tasks.waitingCovered.partCount,1);assert.equal(r.tasks.poFollowup.partCount,1);
  assert.equal(exclusive.tasks.waitingCovered.quantity.value,quantities.open);
  assert.equal(JSON.stringify(input),before,'Classification does not consume stock or change source quantities');
  assert.match(part.nextAction,/기존 PO 입고 필요/);assert.doesNotMatch(part.nextAction,/정상|모두 충족/);
 }
});
test('physical stock covering repairs and full reserve is excluded even with an open PO',()=>{
 const r=project([row({stock:25,needed:15,target:10,open:5})]),part=r.members[0],exclusive=Actions.exclusiveStatus(r);
 assert.equal(part.proposed,0);assert.equal(part.shortage,0);assert.equal(part.waitingCovered,false);
 assert.equal(part.category,'READY');assert.equal(exclusive.byPart[PART],'READY');
 assert.equal(r.tasks.waitingCovered.partCount,0);assert.equal(exclusive.tasks.waitingCovered.partCount,0);
 assert.equal(r.tasks.poFollowup.partCount,0);
});
test('sufficient physical stock stays ready even with positive PO and PO-detail mismatch',()=>{
 const r=project([row({open:4,detailPending:3,issues:['PO 잔량 불일치','상세 PO 미매칭']})]);
 assert.equal(r.rows[0].category,'READY');assert.equal(r.tasks.poFollowup.partCount,0);assert.equal(r.rows[0].hasDataIssues,true);
 assert.deepEqual(r.rows[0].members[0].issues,['PO 잔량 불일치','상세 PO 미매칭']);assert.doesNotMatch(r.rows[0].nextAction,/원본|데이터|자료|보완/);
});
test('urgent parts keep both supply and additional-order quantities',()=>{
 const r=project([row({stock:1,needed:3,open:1})]);
 assert.equal(r.counts.SUPPLY_NOW,1);assert.equal(r.counts.ORDER,0);assert.equal(r.tasks.order.partCount,1);
 assert.equal(group(r,'SUPPLY_NOW').metrics.proposed.value,5);assert.equal(r.tasks.order.quantity.value,5);
 assert.match(r.rows[0].nextAction,/부족 2개/);assert.match(r.rows[0].nextAction,/추가 발주 5개 필요/);
});
test('unknown fields remain unassessed and alert-only without turning quantity into zero',()=>{
 const r=project([row({stock:null})]);
 assert.equal(r.rows[0].category,'UNASSESSED');assert.equal(r.metrics.shortage.value,null);assert.equal(r.metrics.shortage.knownSubtotal,0);
 assert.equal(r.metrics.shortage.unknownCount,1);assert.ok(r.rows[0].dataFields.includes('stock'));
});
test('known urgent shortage takes priority over incomplete order calculation',()=>{
 const r=project([row({stock:1,needed:3,target:null,avg:null})]);
 assert.equal(r.rows[0].category,'SUPPLY_NOW');assert.equal(r.metrics.shortage.value,2);assert.equal(r.metrics.proposed.value,null);
 assert.equal(group(r,'SUPPLY_NOW').metrics.proposed.unknownCount,1);assert.doesNotMatch(r.rows[0].nextAction,/보완|데이터|자료/);
});
test('unknown quantity count distinguishes unique materials from unknown center rows',()=>{
 const r=project([row({stock:null}),row({center:'CTDI',stock:null})]);
 assert.equal(r.metrics.proposed.unknownCount,2);assert.equal(r.metrics.proposed.unknownPartCount,1);assert.equal(r.counts.unassessedParts,1);
});
test('one normalized material across centers has one primary group and preserves both tasks',()=>{
 const r=project([row({part:' test-000001 ',stock:0,needed:2,open:2}),row({center:'CTDI',stock:2,needed:2,open:0})]);
 assert.equal(r.counts.allParts,1);assert.equal(r.counts.activeParts,1);assert.equal(r.counts.SUPPLY_NOW,1);assert.equal(r.counts.ORDER,0);
 assert.equal(r.rows[0].members.length,2);assert.equal(r.rows[0].proposed.value,8);assert.equal(r.tasks.order.partCount,1);
 assert.equal(r.centers.find(c=>c.center==='CTDI').counts.ORDER,1);assert.equal(r.centers.find(c=>c.center==='Flex').counts.SUPPLY_NOW,1);
});
test('resolved duplicate alone never makes an idle part actionable and remains in Alert',()=>{
 const idle=row({stock:2,needed:0,avg:0,target:0});
 const r=project([idle,row({...idle,part:OTHER,issues:['센터 중복코드']})]);
 assert.equal(r.counts.inactiveParts,2);assert.equal(r.counts.READY,0);assert.equal(r.counts.activeParts,0);
 assert.equal(r.dataAlerts.partCount,1);assert.equal(r.dataAlerts.rows[0].part,OTHER);assert.equal(r.tasks.data,undefined);
});
test('zero historic use still requires action for an actual current shortage',()=>{
 const r=project([row({stock:0,needed:2,avg:0,target:0})]);
 assert.equal(r.counts.SUPPLY_NOW,1);assert.equal(r.counts.inactiveParts,0);assert.equal(r.tasks.order.quantity.value,2);
});
test('part inactive at one center but active at another is counted active only once',()=>{
 const r=project([row({stock:0,needed:0,avg:0,target:0}),row({center:'CTDI'})]);
 assert.equal(r.counts.activeParts,1);assert.equal(r.counts.inactiveParts,0);assert.equal(r.counts.READY,1);
 assert.equal(r.centers.find(c=>c.center==='Flex').counts.inactiveParts,1);
});
test('past ETD remains independent PO followup even with sufficient stock',()=>{
 const p=row({open:1});const risk={...p,reasonCodes:['ETD_BEFORE_REPORT'],evidence:{targetGap:0}};
 const r=project([p],[risk]);assert.equal(r.counts.PO_SCHEDULE,1);assert.equal(r.tasks.poFollowup.partCount,1);assert.equal(r.tasks.waitingCovered.partCount,0);
 assert.match(r.rows[0].nextAction,/출발예정일·진행 상태 확인 필요/);assert.equal(r.arrivalPredictionAvailable,false);
});
test('unknown ETD by itself does not put sufficient stock into followup or count receipt',()=>{
 const p=row({open:3});const r=project([p],[{...p,reasonCodes:[],evidence:{targetGap:0,poRows:[{pending:3,etd:null}]}}]);
 assert.equal(r.counts.READY,1);assert.equal(r.metrics.open.value,3);assert.equal(r.rows[0].members[0].stock,10);
});
test('unparsed WIP warns once without assigning missing quantity to every known part',()=>{
 const r=project([row({needBasis:'wip'}),row({part:OTHER,needBasis:'wip'})],[],{wip:[{center:'Flex',tokens:{parts:{},unparsed:'unknown'}}]});
 assert.equal(r.counts.READY,2);assert.equal(r.unresolvedWipProducts,1);assert.equal(r.unresolvedAffectsCurrent,true);
 assert.ok(r.warnings.some(w=>w.includes('전체 조치 없음으로 판단하지 않습니다')));
});
test('approved source values and input objects are not mutated or reallocated',()=>{
 const p=row({open:0,detailPending:8,stock:3});const input={parts:[p],wip:[],warnings:[]},risk={allRows:[{...p,reasonCodes:['PO_SCHEDULE'],evidence:{targetGap:3}}]};
 const before=JSON.stringify({input,risk});const r=Actions.fromResults(input,risk);
 assert.equal(r.rows[0].category,'ORDER');assert.equal(r.rows[0].proposed.value,3);assert.equal(r.rows[0].members[0].india,10);
 assert.equal(JSON.stringify({input,risk}),before);assert.equal(r.allocationConfirmed,false);
});
test('operational groups plus unassessed rows reconcile without a DATA work category',()=>{
 const values=[row({stock:0}),row({part:'TEST-000002',stock:2}),row({part:'TEST-000003',stock:null}),
  row({part:'TEST-000004',stock:2,open:4}),row({part:'TEST-000005'}),row({part:'TEST-000006',needed:0,avg:0,target:0})];
 const r=project(values);assert.equal(r.groups.reduce((n,g)=>n+g.partCount,0)+r.counts.unassessedParts,r.counts.activeParts);
 assert.equal(r.counts.activeParts+r.counts.inactiveParts,r.counts.allParts);assert.deepEqual(r.groups.map(g=>g.partCount),[1,1,1,0,1]);assert.ok(!r.groups.some(g=>g.code==='DATA'));
});
function source(type,center,rows,extra={}){
 const s={type,center,operator:'',date:DATE,file:'synthetic.xlsx',sheet:'Synthetic',rows,...extra};s.id=Core.sourceKey(s);return s;
}
test('after-repair waiting classification preserves core shortage and additional-order quantities',()=>{
 const cases=[
  {part:'TEST-000010',stock:20,hold:15,po:5,shortage:0,proposed:0,status:'WAIT_PO'},
  {part:'TEST-000011',stock:0,hold:0,po:10,shortage:0,proposed:0,status:'WAIT_PO'},
  {part:'TEST-000012',stock:25,hold:15,po:5,shortage:0,proposed:0,status:'READY'},
  {part:'TEST-000013',stock:20,hold:25,po:15,shortage:5,proposed:0,status:'SUPPLY_NOW'},
  {part:'TEST-000014',stock:20,hold:15,po:4,shortage:0,proposed:1,status:'ORDER'},
  {part:'TEST-000015',stock:20,hold:25,po:4,shortage:5,proposed:11,status:'SUPPLY_NOW'}
 ];
 const state=Core.empty();state.sources=[source('dashboard','Flex',cases.map((item,i)=>({
  part:item.part,stock:item.stock,hold:item.hold,po:item.po,row:i+2,usage:Object.fromEntries(MONTHS.map(month=>[month,10]))
 })),{usageMonths:MONTHS,holdDate:DATE})];
 const before=JSON.stringify(state),calculated=Core.calculate(state,DATE,'Flex'),summary=Actions.fromResults(calculated,{allRows:[]}),exclusive=Actions.exclusiveStatus(summary);
 for(const expected of cases){
  const actual=calculated.parts.find(p=>p.part===expected.part);
  assert.deepEqual([actual.stock,actual.needed,actual.target,actual.open,actual.shortage,actual.proposed],
   [expected.stock,expected.hold,10,expected.po,expected.shortage,expected.proposed],expected.part);
  assert.equal(actual.currentOrderNeed+actual.futureOrderNeed,expected.proposed);
  assert.equal(exclusive.byPart[expected.part],expected.status);
  if(expected.status==='WAIT_PO')assert.equal(actual.action,'기존 PO 입고 대기');
  if(expected.status==='ORDER')assert.equal(actual.action,'추가 발주 필요');
  if(expected.shortage>0)assert.match(actual.action,/공급|긴급 입고/,'Open PO does not release a physical shortage');
 }
 assert.equal(JSON.stringify(state),before,'Core classification does not alter the imported state');
});
test('evaluate respects center and operator selection without assigning shared stock to an operator',()=>{
 const s=Core.empty();const dashboard=(center,part)=>source('dashboard',center,[{part,stock:10,hold:3,po:0,row:2,
  usage:Object.fromEntries(MONTHS.map(m=>[m,4]))}],{usageMonths:MONTHS,holdDate:DATE});
 s.sources=[dashboard('CTDI',PART),dashboard('Flex',OTHER),source('wip','CTDI',[
  {key:'test-a',row:2,tokens:{parts:{[PART]:1},unparsed:''}}],{operator:'Jio',duplicates:[]}),
 source('wip','CTDI',[{key:'test-b',row:2,tokens:{parts:{[PART]:2},unparsed:''}}],{operator:'Airtel',duplicates:[]}),
 source('wip','CTDI',[],{operator:'Vi',duplicates:[]})];
 const r=Actions.evaluate(s,DATE,'CTDI','Jio');assert.equal(r.counts.allParts,1);assert.equal(r.rows[0].part,PART);
 assert.equal(r.rows[0].members[0].selected,1);assert.equal(r.rows[0].members[0].needed,3);assert.equal(r.rows[0].members[0].stock,10);
 assert.equal(r.center,'CTDI');assert.equal(r.operator,'Jio');
});
test('registered scope counts dashboard codes once and does not add upstream or PO-only codes',()=>{
 const upstream='TEST-000090',unlisted='TEST-000091';
 const used=[source('dashboard','Flex',[{part:PART,row:2,stock:4},{part:PART,row:9,stock:100},{part:OTHER,row:3,stock:2}]),
  source('dashboard','CTDI',[{part:PART,row:2,stock:8},{part:'TEST-000003',row:3,stock:1}]),
  source('hq','',[{part:upstream,qty:90}]),source('po','Flex',[{part:unlisted,pending:2}])];
 const r=project([row(),row({part:OTHER}),row({center:'CTDI'}),row({center:'CTDI',part:'TEST-000003'}),
  row({part:unlisted,stock:0,missingDashboardCode:true,avg:null,target:null})],[],{used});
 assert.equal(r.inventoryScope.complete,true);assert.equal(r.inventoryScope.registeredPartCount,3);
 assert.deepEqual(r.inventoryScope.centers.map(c=>c.registeredPartCount),[2,2]);assert.equal(r.inventoryScope.sharedPartCount,1);
 assert.equal(r.counts.allParts,4);assert.deepEqual(r.inventoryScope.outsideRegistered.parts,[unlisted]);
 assert.ok(!r.inventoryScope.registeredParts.includes(upstream));
});
test('center-list omissions remain distinct from globally unregistered codes and clear after corrected import',()=>{
 const extra='TEST-000004',state=Core.empty(),dashboard=(center,parts)=>source('dashboard',center,parts.map((part,i)=>({part,row:i+2,stock:5,hold:0,po:0,
  usage:Object.fromEntries(MONTHS.map(m=>[m,1]))})),{usageMonths:MONTHS,holdDate:DATE});
 const flex=dashboard('Flex',[PART]),ctdi=dashboard('CTDI',[PART,OTHER]);
 state.sources=[flex,ctdi,source('po','Flex',[{part:OTHER,pending:2,row:2},{part:extra,pending:1,row:3}])];
 const before=Actions.evaluate(state,DATE).inventoryScope;
 assert.equal(before.registeredPartCount,2);assert.equal(before.missingOwnDashboard.partCount,2);
 assert.equal(before.missingOwnDashboard.centerPartCount,2);assert.deepEqual(before.outsideRegistered.parts,[extra]);
 const shared=before.missingOwnDashboard.rows.find(r=>r.part===OTHER);assert.equal(shared.registeredAtOtherCenter,true);
 assert.equal(shared.origins[0].type,'po');assert.equal(shared.origins[0].row,2);
 const corrected=Core.merge(state,[dashboard('Flex',[PART,OTHER,extra])]),after=Actions.evaluate(corrected,DATE).inventoryScope;
 assert.equal(corrected.sources.length,state.sources.length);assert.equal(after.registeredPartCount,3);
 assert.equal(after.missingOwnDashboard.partCount,0);assert.equal(after.outsideRegistered.partCount,0);
});
test('operator selection keeps selected-center registered denominator while limiting action rows',()=>{
 const used=[source('dashboard','Flex',[{part:PART,row:2},{part:OTHER,row:3}]),source('dashboard','CTDI',[{part:'TEST-000003',row:2}])];
 const r=Actions.fromResults({parts:[row()],allParts:[row(),row({part:OTHER})],used,wip:[],warnings:[]},{allRows:[]},
  {center:'Flex',operator:'Synthetic-A'});
 assert.equal(r.counts.allParts,1);assert.equal(r.inventoryScope.registeredPartCount,2);
 assert.equal(r.inventoryScope.centers.length,1);assert.equal(r.inventoryScope.operatorFiltered,false);
 assert.match(r.inventoryScope.scopeLabel,/사업자 선택과 관계없이/);
});
test('missing dashboard is unconfirmed, while a supplied empty dashboard is a confirmed zero',()=>{
 const partial=project([] ,[],{used:[source('dashboard','Flex',[{part:PART,row:2}])] }).inventoryScope;
 assert.equal(partial.complete,false);assert.equal(partial.registeredPartCount,null);assert.equal(partial.knownRegisteredPartCount,1);
 assert.equal(partial.sharedPartCount,null);assert.equal(partial.centers.find(c=>c.center==='CTDI').registeredPartCount,null);
 assert.equal(partial.outsideRegistered.partCount,null);
 const empty=Actions.fromResults({parts:[],used:[source('dashboard','Flex',[])],wip:[]},{allRows:[]},{center:'Flex'}).inventoryScope;
 assert.equal(empty.complete,true);assert.equal(empty.registeredPartCount,0);assert.equal(empty.centers[0].registeredPartCount,0);
});

test('sufficient existing PO is its own subset while current physical shortage stays visible',()=>{
 const covered=row({stock:0,needed:19,target:26,open:72});
 const insufficient=row({part:OTHER,stock:0,needed:71,target:26,open:57});
 const r=project([covered,insufficient]);
 assert.equal(r.tasks.supply.partCount,2);assert.equal(r.tasks.poFollowup.partCount,2);
 assert.equal(r.tasks.waitingCovered.partCount,1);assert.equal(r.tasks.waitingCovered.rows[0].part,PART);
 assert.equal(r.tasks.waitingCovered.quantity.value,72);assert.equal(r.tasks.order.quantity.value,40);
 assert.equal(r.members.find(m=>m.part===OTHER).currentOrderNeed,14);
 assert.equal(r.members.find(m=>m.part===OTHER).futureOrderNeed,26);
 assert.equal(r.tasks.orderCurrent.partCount,1);assert.equal(r.tasks.orderBuffer.partCount,0);
});
test('current-demand and future-holding portions reconcile and tiny replenishment is retained',()=>{
 const values=[row({stock:0,needed:3,target:4,open:1}),row({part:OTHER,stock:0,needed:0,avg:1/6,target:1,open:0})];
 const r=project(values),tiny=r.members.find(m=>m.part===OTHER);
 assert.equal(r.metrics.proposed.value,7);assert.equal(r.metrics.currentOrderNeed.value,2);assert.equal(r.metrics.futureOrderNeed.value,5);
 assert.equal(r.tasks.orderCurrent.quantity.value,6);assert.equal(r.tasks.orderBuffer.quantity.value,1);
 assert.equal(tiny.lowDemandOneUnit,true);assert.equal(tiny.orderPurpose,'보유 기준 보충');assert.equal(tiny.proposed,1);
});
test('ETD history reports postponement or withdrawn date without claiming transport or arrival',()=>{
 const delayed=Core.poSchedule({oldEtd:'2024-08-10',etd:'2024-08-20',pending:2},DATE);
 assert.equal(delayed.etdChange,'POSTPONED');assert.equal(delayed.daysPostponed,10);
 assert.equal(delayed.scheduleLabel,'출발예정일 연기');assert.equal(delayed.transitConfirmed,false);assert.equal(delayed.arrivalConfirmed,false);
 const withdrawn=Core.poSchedule({oldEtd:'2024-08-10',etd:null,pending:3},DATE);
 assert.equal(withdrawn.etdChange,'WITHDRAWN');assert.equal(withdrawn.scheduleLabel,'출발예정일 삭제·미정');
 assert.equal(Core.poSchedule({etd:'2024-08-20'},DATE).etdChange,'DATED','A lone ETD has no prior-date comparison');
 assert.equal(Core.poSchedule({etd:'2024-08-20',etdHistoryAvailable:true},DATE).etdChange,'ASSIGNED');
});
test('schedule checks use source report date, ignore received lines, and stay separate from covered stock needs',()=>{
 const schedule=Core.summarizePoSchedule([
  {pending:2,oldEtd:'2024-08-05',etd:'2024-08-11'},
  {pending:0,oldEtd:'2024-08-03',etd:null},
  {pending:1,etd:'2024-08-13'}
 ],DATE);
 assert.equal(schedule.postponedRows,1);assert.equal(schedule.withdrawnRows,0);assert.equal(schedule.beforeReportRows,1);
 const r=project([row({open:3,poSchedule:schedule})]);
 assert.equal(r.tasks.schedule.partCount,1);assert.equal(r.tasks.waitingCovered.partCount,0);
 assert.equal(r.members[0].category,'PO_SCHEDULE');assert.doesNotMatch(r.members[0].nextAction,/운송 중|입고 지연|요청/);
});
test('first original row is applied to duplicate stock and consumption before actions are derived',()=>{
 const state=Core.empty();state.sources=[source('dashboard','Flex',[
  {part:PART,row:2,stock:10,hold:0,po:0,usage:Object.fromEntries(MONTHS.map(m=>[m,0]))},
  {part:PART,row:9,stock:0,hold:100,po:0,usage:Object.fromEntries(MONTHS.map(m=>[m,100]))}
 ],{usageMonths:MONTHS,holdDate:DATE})];
 const r=Actions.evaluate(state,DATE,'Flex');
 assert.equal(r.members[0].stock,10);assert.equal(r.members[0].needed,0);assert.equal(r.members[0].avg,0);
 assert.equal(r.members[0].proposed,0);assert.equal(r.members[0].selectedSourceRow,2);
 assert.deepEqual(r.members[0].ignoredSourceRows,[9]);assert.equal(r.tasks.order.partCount,0);assert.equal(r.tasks.supply.partCount,0);
 assert.equal(r.dataAlerts.partCount,1);assert.equal(r.counts.inactiveParts,1);
});

test('exclusive cards classify each part once while retaining other-centre ordering and waiting work',()=>{
 const waitPart='TEST-000003',normalPart='TEST-000004';
 const input=project([
  row({stock:0,needed:3,target:2,open:1}),
  row({center:'CTDI',stock:1,needed:0,target:2,open:0}),
  row({part:OTHER,stock:1,needed:0,target:3,open:0}),
  row({part:OTHER,center:'CTDI',stock:0,needed:0,target:3,open:3}),
  row({part:waitPart,stock:1,needed:0,target:3,open:2}),
  row({part:waitPart,center:'CTDI'}),
  row({part:normalPart})
 ]);
 const before=JSON.stringify(input),result=Actions.exclusiveStatus(input),{supply,order,waitingCovered}=result.tasks;
 assert.deepEqual(result.groups.map(group=>group.partCount),[1,1,1]);
 assert.deepEqual(result.rows.map(row=>row.part),[PART,OTHER,waitPart]);
 assert.equal(new Set(result.rows.map(row=>row.part)).size,result.counts.actionParts);
 assert.equal(supply.quantity.value,3);assert.equal(order.quantity.value,2);assert.equal(waitingCovered.quantity.value,2);
 assert.deepEqual(supply.rows[0].members.map(m=>m.statusCategory),['SUPPLY_NOW','ORDER']);
 assert.deepEqual(order.rows[0].members.map(m=>m.statusCategory),['ORDER','WAIT_PO']);
 assert.equal(order.rows[0].members.length,2,'Other-centre waiting work stays under its order parent');
 assert.equal(waitingCovered.rows[0].members.length,1,'Normal other-centre row is omitted');
 assert.equal(supply.rows[0].proposed.value,5,'Current shortage parent retains all its ordering work');
 assert.equal(supply.rows[0].members[1].parentStatus,'SUPPLY_NOW');
 assert.equal(result.byPart[PART],'SUPPLY_NOW');assert.equal(result.memberStatus['CTDI|'+PART],'ORDER');
 assert.equal(input.tasks.order.partCount,2,'Diagnostic ordering still includes the shortage part');
 assert.equal(input.tasks.waitingCovered.partCount,2,'Diagnostic waiting still includes the order parent');
 assert.equal(JSON.stringify(input),before,'Display partition never mutates source calculations or task queues');
});
test('exclusive priority is evaluated within the selected centre scope',()=>{
 const flex=row({stock:0,needed:3,target:2,open:1}),ctdi=row({center:'CTDI',stock:1,needed:0,target:2,open:0});
 const both=Actions.exclusiveStatus(project([flex,ctdi])),single=Actions.exclusiveStatus(project([ctdi]));
 assert.equal(both.counts.SUPPLY_NOW,1);assert.equal(both.counts.ORDER,0);
 assert.equal(single.counts.SUPPLY_NOW,0);assert.equal(single.counts.ORDER,1);
 assert.equal(single.tasks.order.rows[0].members[0].center,'CTDI');
});
test('new after-repair waiting members stay subordinate to shortages and orders at another center',()=>{
 const waiting=row({stock:20,needed:15,target:10,open:5});
 for(const other of [row({center:'CTDI',stock:20,needed:25,target:10,open:15}),row({center:'CTDI',stock:20,needed:15,target:10,open:4})]){
  const input=project([waiting,other]),exclusive=Actions.exclusiveStatus(input),expected=other.shortage>0?'SUPPLY_NOW':'ORDER';
  assert.equal(exclusive.byPart[PART],expected);assert.equal(exclusive.counts.WAIT_PO,0);
  assert.equal(exclusive.memberStatus['Flex|'+PART],'WAIT_PO');
  assert.equal(exclusive.rows[0].members.length,2,'Other-center waiting work remains visible under the higher-priority status');
  assert.equal(exclusive.rows[0].members.find(m=>m.center==='Flex').open,5);
  assert.equal(exclusive.rows[0].members.find(m=>m.center==='Flex').proposed,0);
  if(other.shortage>0){
   assert.equal(Core.waitingCovered(other),true,'A shortage row may have enough PO, but shortage remains its primary status');
   assert.equal(exclusive.tasks.supply.quantity.value,5);assert.equal(exclusive.tasks.order.partCount,0);
  }else assert.equal(exclusive.tasks.order.quantity.value,1);
 }
});
test('exclusive no-shortage categories require known current quantities at every selected centre',()=>{
 const knownOrder=row({stock:0,needed:0,target:2,open:0}),unknown=row({center:'CTDI',stock:null});
 const input=project([knownOrder,unknown]),result=Actions.exclusiveStatus(input);
 assert.equal(input.tasks.order.partCount,1);assert.equal(result.counts.ORDER,0);assert.equal(result.counts.WAIT_PO,0);
 assert.equal(result.counts.UNASSESSED,1);assert.equal(result.unassessed.knownOrderPartCount,1);
 assert.equal(result.unassessed.rows[0].members[0].proposed,2,'Known work remains available with the alert');
 assert.equal(result.unassessed.rows[0].members[1].stock,null);
 assert.equal(result.unassessed.rows[0].members[1].shortage,null);
 assert.match(result.dataAlerts.rows[0].classificationIssues[0],/現在|현재 부족 없음으로 판단하지 않음/);
});
test('exclusive current shortage preserves known work and warns about an unassessed other centre',()=>{
 const result=Actions.exclusiveStatus(project([row({stock:0,needed:2,open:0}),row({center:'CTDI',stock:null})]));
 assert.equal(result.counts.SUPPLY_NOW,1);assert.equal(result.counts.ORDER,0);
 assert.equal(result.tasks.supply.quantity.value,2);assert.equal(result.tasks.supply.primaryMembers.length,1);
 assert.equal(result.tasks.supply.rows[0].members.length,2);assert.equal(result.dataAlerts.partCount,1);
 assert.equal(result.tasks.supply.rows[0].currentAssessed,false);
 assert.equal(result.tasks.supply.rows[0].shortage.value,null,'All-centre total is still incomplete');
 assert.equal(result.tasks.supply.rows[0].shortage.knownSubtotal,2);
});
test('unknown other-centre ordering blocks PO-fulfilled claims but not a known replenishment task',()=>{
 const wait=row({stock:0,needed:0,target:2,open:2}),order=row({stock:0,needed:0,target:2,open:0}),unknown=row({center:'CTDI',stock:1,needed:0,open:null});
 const waiting=Actions.exclusiveStatus(project([wait,unknown])),ordering=Actions.exclusiveStatus(project([order,unknown]));
 assert.equal(waiting.counts.WAIT_PO,0);assert.equal(waiting.counts.UNASSESSED,1);assert.equal(waiting.unassessed.knownWaitingPartCount,1);
 assert.equal(ordering.counts.ORDER,1);assert.equal(ordering.tasks.order.quantity.value,2);
 assert.equal(ordering.tasks.order.rows[0].orderAssessed,false);assert.equal(ordering.dataAlerts.partCount,1);
});
test('low-use reference excludes only wholly low-use parts, retaining mixed, zero and invalid-history parts',()=>{
 const codes=['LOW-000001','MIX-000001','ZERO-000001','UNKNOWN-000001','HIGH-000001'];
 const members=codes.map(part=>row({part,stock:0,needed:0,target:1,open:0}));
 members.push(row({part:codes[1],center:'CTDI',stock:0,needed:0,target:1,open:0}));
 const low=(total,flag,valid=true)=>({valid,total,flag,threshold:2});
 const uses={'Flex|LOW-000001':low(1,true),'Flex|MIX-000001':low(2,true),'CTDI|MIX-000001':low(20,false),
  'Flex|ZERO-000001':low(0,false),'Flex|UNKNOWN-000001':low(null,false,false),'Flex|HIGH-000001':low(12,false)};
 const input=project(members),before=JSON.stringify({input,uses}),result=Actions.exclusiveStatus(input,uses),partition=result.tasks.order.lowUsage;
 assert.equal(partition.totalPartCount,5);assert.equal(partition.lowOnlyPartCount,1);assert.equal(partition.excludingLowOnlyPartCount,4);
 assert.deepEqual(partition.lowOnlyParts,[codes[0]]);assert.deepEqual(partition.mixedParts,[codes[1]]);
 assert.equal(partition.unknownUsagePartCount,1);assert.equal(partition.zeroUsagePartCount,1);
 assert.equal(result.tasks.order.partCount,5);assert.equal(result.tasks.order.quantity.value,6,'Reference count does not cancel orders');
 assert.equal(JSON.stringify({input,uses}),before);
});
test('low-use partition considers only ordering members and separately reports legacy overlapping orders',()=>{
 const input=project([
  row({stock:0,needed:2,target:1,open:0}),
  row({part:OTHER,stock:0,needed:0,target:1,open:0}),
  row({part:OTHER,center:'CTDI',stock:0,needed:0,target:3,open:3})
 ]);
 const uses={['Flex|'+PART]:{valid:true,total:1,flag:true},['Flex|'+OTHER]:{valid:true,total:2,flag:true},['CTDI|'+OTHER]:{valid:true,total:30,flag:false}};
 const result=Actions.exclusiveStatus(input,uses);
 assert.equal(result.tasks.order.lowUsage.lowOnlyPartCount,1,'High-use waiting child does not alter order-only low-use partition');
 assert.equal(result.tasks.order.lowUsage.excludingLowOnlyPartCount,0);
 assert.equal(result.legacyOrderLowUsage.totalPartCount,2);assert.equal(result.legacyOrderLowUsage.lowOnlyPartCount,2);
 assert.equal(result.tasks.order.rows[0].members.length,2);
});
test('empty exclusive projection has no fabricated work or low-use parts',()=>{
 const r=Actions.exclusiveStatus(project([]));assert.deepEqual(r.groups.map(g=>g.partCount),[0,0,0]);
 assert.equal(r.counts.actionParts,0);assert.equal(r.unassessed.partCount,0);assert.equal(r.tasks.order.quantity.value,0);
 assert.equal(r.legacyOrderLowUsage.lowOnlyPartCount,0);assert.equal(r.legacyOrderLowUsage.excludingLowOnlyPartCount,0);
});
