'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm');
const T=require('../src/share-tables.js'),I=require('../src/i18n.js'),D=require('../src/share-dialog.js'),Tat=require('../src/wip-tat.js');
require('../src/i18n-extra.js')(I);require('../src/share-i18n.js')(I);
const PART='TEST-000001';
const objects=model=>model.rows.map(row=>Object.fromEntries(model.columns.map((column,index)=>[column.key,row[index]])));
function product(age,sn,extra={}){const date='2030-09-30';return Tat.evaluate([{center:'Flex',operator:'Jio',sn,rma:'R-'+sn,receipt:new Date(Date.parse(date)-age*86400000).toISOString().slice(0,10),date,
 tokens:{parts:{[PART]:2},unparsed:''},required:PART+' #2',source:'synthetic.xlsb',sheet:'Inhouse',row:2,...extra}]).rows[0];}
test('trace CSV has one product-part row; day45 is Alert, day44 is not; baseline and zero TAT remain honest',()=>{
 const rows=[product(45,'A'),product(44,'B')],trace={firstSeenDate:'2030-09-16',firstSeenWeek:'2030-09-16',firstSeenAgeDays:0,baselinePresent:true,observationCount:2,episodeStartDate:'2030-09-16',continuityUncertain:true};
 const original=JSON.stringify(rows),model=T.wipTraceProducts({rows,part:PART,traceFor:()=>trace}),records=objects(model);
 assert.equal(records.length,2);assert.equal(records[0].alert,'45일 이상 Alert');assert.equal(records[1].alert,'45일 미만');assert.equal(records[0].firstAge,0);
 assert.equal(records[0].observation,'최초 자료부터 대기');assert.equal(records[0].continuity,'중간 관찰 공백 있음');assert.equal(records[0].needed,2);
 assert.equal(JSON.stringify(rows),original);assert.equal(model.columns.some(c=>c.key==='po'),false);assert.match(model.notes.join(' '),/실제 부품 필요 발생일이 아닙니다/);
 const en=D.normalize(model,{language:'en',translator:I});assert.doesNotMatch(en.columns.map(c=>c.label).join(' '),/[가-힣]/);assert.doesNotMatch(en.notes.join(' '),/[가-힣]/);
 for(const key of ['alert','observation','continuity'])assert.doesNotMatch(en.rows[0][model.columns.findIndex(c=>c.key===key)],/[가-힣]/);
});
test('related PO export preserves separate orders and unknown dates without repeating per-product quantities',()=>{
 const po={reportAvailable:true,sourceDate:'2030-09-30',sourceFile:'po.xlsx',rows:[{po:'A',item:'1',ordered:5,pending:3,shipped:2,poDate:'2030-09-01',poAgeDays:29,etd:'2030-10-02'},
 {po:'B',item:'1',ordered:9,pending:9,shipped:0,poDate:null,poAgeDays:null,etd:null}]};
 const model=T.wipTracePO({part:PART,center:'Flex',po}),records=objects(model);assert.equal(records.length,2);assert.equal(records[0].pending,3);assert.equal(records[1].pending,9);
 assert.equal(records[1].poAgeDays,null);assert.equal(records[1].etd,null);assert.equal(model.columns.some(c=>c.key==='sn'),false);
 const en=D.normalize(model,{language:'en',translator:I});assert.doesNotMatch(en.columns.map(c=>c.label).join(' '),/[가-힣]/);assert.doesNotMatch(en.notes.join(' '),/[가-힣]/);
 assert.match(T.wipTracePO({po:{reportAvailable:false}}).notes[0],/발주 여부를 확정하지/);
});
function functionSource(name){const source=fs.readFileSync(require.resolve('../src/app.js'),'utf8'),start=source.indexOf('function '+name+'('),end=source.indexOf('\nfunction ',start+10);assert.ok(start>=0);return source.slice(start,end<0?undefined:end);}
function drawerFixture(){
 const rows=[{...product(45,'A'),partQuantity:2},{...product(46,'B'),partQuantity:2}],group={key:'Flex|'+PART,center:'Flex',part:PART,operators:new Set(['Jio']),products:new Set(['A','B']),quantity:4,overdueProducts:1,rows};
 const balance={center:'Flex',part:PART,stock:1,india:2,hq:7,needed:11,shortage:10,open:5,proposed:7,dashboardDate:'2030-09-29',needDate:'2030-09-30'};
 const po={reportAvailable:true,sourceDate:'2030-09-30',rows:[{po:'P-1',ordered:5,shipped:0,pending:5,poDate:'2030-09-01',poAgeDays:29,etd:null}]};
 const trace={firstSeenDate:'2030-09-16',firstSeenWeek:'2030-09-16',firstSeenAgeDays:31,baselinePresent:true,continuityUncertain:false};
 const elements={},created=[];let shared;
 const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const ctx={groupedWipParts:()=>[group],result:{allParts:[balance],commonSupport:{sourceDates:{india:'2030-09-28',hq:'2030-09-22'}}},asof:'2030-09-30',
 actionMember:r=>r,operationMember:()=>({roles:['수리센터'],reasons:['센터 PO 부족']}),followupResult:{tasks:[{center:'Flex',part:PART,recipientLabel:'수리센터',text:'추가 PO 총 7개 필요'}]},
 PartsWipTrace:{relatedPO:()=>po},document:{createElement:()=>{const element={remove(){},querySelectorAll(){return []}};created.push(element);return element;},body:{append(){}},activeElement:null,addEventListener(){},removeEventListener(){},querySelectorAll:()=>[]},
 I:{translateDOM(){}},$:selector=>elements[selector]||(elements[selector]={focus(){}}),esc,num:v=>String(v),N:v=>v,tag:(t,c)=>'<b class="'+c+'">'+esc(t)+'</b>',
 sourceTextHTML:esc,operatorName:v=>v,shortName:()=>'<raw name>',wipAgeLabel:()=> '입고 45일 초과',wipProductKey:r=>r.sn,
 wipTraceEntry:()=>trace,wipAgeIssueLabel:()=>'',actionWork:()=>'',openShare:(...args)=>shared=args,
 table:(headers,records)=>'<table><thead>'+headers.map(h=>'<th>'+h+'</th>').join('')+'</thead>'+records.map(r=>'<tr>'+r.map(c=>'<td>'+(c?.html??c)+'</td>').join('')+'</tr>').join('')+'</table>'};
 vm.createContext(ctx);for(const name of ['wipTraceFirstHTML','wipTracePOHTML','wipDetail'])vm.runInContext(functionSource(name),ctx);ctx.wipDetail('Flex|'+PART);
 return {html:created[0].innerHTML,elements,shared:()=>shared,ctx};
}
test('actual WIP drawer renderer shows scoped product demand but center-wide balance, first observation, all PO evidence and actionable export',()=>{
 const f=drawerFixture();assert.match(f.html,/필요 4개/);assert.match(f.html,/센터 전체 수리 필요/);assert.match(f.html,/<td>11<\/td>/);assert.match(f.html,/최초 자료부터 대기/);
 assert.match(f.html,/45일째 Alert/);assert.match(f.html,/45일 초과/);assert.match(f.html,/P-1/);assert.match(f.html,/2030-09-01/);assert.match(f.html,/29일/);
 assert.match(f.html,/특정 제품에 배정된 주문은 확인되지/);assert.match(f.html,/본사 재고: 2030-09-22/);assert.doesNotMatch(f.html,/<raw name>/);assert.match(f.html,/&lt;raw name&gt;/);
 f.elements['#export-wip-trace'].onclick();assert.equal(f.shared()[0],'wip-trace');assert.equal(f.shared()[1].rows.length,2);assert.equal(f.shared()[1].po.rows.length,1);
});
test('45-plus alert filter does not redefine the over45 metric',()=>{
 const ctx={wipAgeFilter:'ALERT45',PartsWipTat:Tat};vm.createContext(ctx);vm.runInContext(functionSource('wipMatchesAge'),ctx);
 assert.equal(ctx.wipMatchesAge(product(45,'A')),true);assert.equal(ctx.wipMatchesAge(product(44,'B')),false);assert.equal(ctx.wipMatchesAge({...product(46,'C'),age:null}),false);
 ctx.wipAgeFilter='OVERDUE';assert.equal(ctx.wipMatchesAge(product(45,'A')),false);assert.equal(ctx.wipMatchesAge(product(46,'C')),true);
});
