'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const Trace=require('../src/part-trace.js'),Mail=require('../src/overdue-mail.js');
function fixture(){return {asof:'2026-10-12',rows:[{id:'Flex|A',part:'A',name:'Chip',center:'Flex',stock:0,india:0,hq:3,avg:1,needed:1,shortage:1,open:2,proposed:0}],products:[{id:'P1',center:'Flex',operator:'Jio',sn:'SN1',rma:'R1',receipt:'2026-08-14',date:'2026-10-12',age:59,parts:[{part:'A',quantity:1,firstDate:'2026-09-10',firstAge:27,autoFirstDate:'2026-09-28',autoFirstAge:45,manualFirstConfirmedDate:'2026-09-10',manualFirstConfirmedNote:'Historical report reviewed',firstConfirmedSource:'manual',firstConfirmedConflict:false,baseline:true,traceKey:'trace-1'}]}],pos:[],tasks:[]};}
const col=(table,key)=>table.rows.map(row=>row[table.columns.findIndex(c=>c.key===key)]);
test('manual confirmation reaches detail and export with automatic evidence and unchanged receipt TAT',()=>{
 const data=fixture(),before=JSON.stringify(data),row=Trace.buildRows({data})[0],html=Trace.render({data}),table=Trace.buildTable({data});
 assert.equal(row.firstDate,'2026-09-10');assert.equal(row.firstAge,27);assert.equal(row.observedDays,32);assert.equal(row.tat,59);assert.equal(row.autoFirstDate,'2026-09-28');assert.equal(row.traceKey,'trace-1');
 assert.match(html,/2026-09-10 · 수기 확인/);assert.match(html,/WIP 최초 관찰 2026-09-28/);assert.match(col(table,'observation')[0],/수기 확인일 적용/);assert.match(col(table,'observation')[0],/Historical report reviewed/);assert.equal(col(table,'tat')[0],59);assert.equal(col(table,'firstDate')[0],'2026-09-10');assert.equal(table.columns.length,20);assert.equal(JSON.stringify(data),before);
});
test('manual-first mail retains nine columns and uses a non-WIP-only heading',()=>{
 const data=fixture(),table=Mail.build({data}),english=Mail.build({data,language:'en'});
 assert.equal(table.columns.length,9);assert.equal(table.columns.find(c=>c.key==='first').label,'최초 부품대기 확인일');assert.match(col(table,'first')[0],/SN SN1 \/ RMA R1/);assert.match(col(table,'first')[0],/수기 확인: 2026-09-10/);assert.match(col(table,'first')[0],/WIP 최초 관찰: 2026-09-28/);assert.doesNotMatch(col(table,'first')[0],/최초 부품대기 확인일 이전부터 대기/);assert.match(col(table,'products')[0],/TAT 59일/);assert.match(col(english,'first')[0],/Manual confirmation: 2026-09-10/);assert.match(col(english,'first')[0],/WIP first observation: 2026-09-28/);
});
test('mixed automatic and manual products stay distinguishable in one part email row',()=>{
 const data=fixture();data.products.push({...data.products[0],id:'P2',sn:'SN2',rma:'R2',parts:[{part:'A',quantity:2,firstDate:'2026-09-25',firstAge:42,baseline:true}]});
 const table=Mail.build({data}),value=col(table,'first')[0];assert.equal(table.rows.length,1);assert.match(value,/WIP 관찰: 2026-09-25/);assert.match(value,/수기 확인: 2026-09-10/);assert.match(value,/최초 부품대기 확인일 이전부터 대기/);assert.match(col(table,'products')[0],/2대/);assert.match(col(table,'need')[0],/45일 초과분 필요: 3개/);
});
test('conflicting manual input is not relabelled as an automatic WIP observation',()=>{
 const data=fixture(),entry=data.products[0].parts[0];Object.assign(entry,{firstDate:'2026-10-01',firstAge:48,manualFirstConfirmedDate:'2026-10-01',firstConfirmedConflict:true,firstConfirmedIssues:['EARLIER_AUTOMATIC_OBSERVATION']});
 assert.match(Trace.observationText(Trace.buildRows({data})[0],'ko'),/수기 입력과 WIP 관찰 근거 불일치/);assert.match(col(Mail.build({data}),'first')[0],/수기 확인: 2026-10-01/);assert.match(col(Mail.build({data}),'first')[0],/WIP 최초 관찰: 2026-09-28/);
});
test('saved invalid manual date shows candidate and automatic fallback separately',()=>{
 const data=fixture(),entry=data.products[0].parts[0];Object.assign(entry,{firstDate:'2026-09-28',firstAge:45,manualFirstConfirmedDate:'2026-10-20',firstConfirmedSource:'automatic',firstConfirmedConflict:true});
 const row=Trace.buildRows({data})[0],h=Trace.render({data}),value=col(Mail.build({data,language:'en'}),'first')[0];assert.equal(row.firstDate,'2026-09-28');assert.match(h,/수기 입력일 검토 필요 2026-10-20/);assert.doesNotMatch(h,/2026-09-28 · 수기 확인/);assert.match(value,/Manual date \(review needed\): 2026-10-20/);assert.match(value,/Applied date: 2026-09-28/);
});
test('manual date never becomes fabricated automatic evidence; manual note is HTML escaped',()=>{
 const data=fixture(),entry=data.products[0].parts[0];entry.autoFirstDate=null;entry.autoFirstAge=null;entry.manualFirstConfirmedNote='<script>alert(1)</script>';
 const row=Trace.buildRows({data})[0],h=Trace.render({data});assert.equal(row.autoFirstDate,null);assert.equal(row.autoFirstAge,null);assert.match(h,/WIP 최초 관찰 미확인/);assert.match(h,/&lt;script&gt;/);assert.doesNotMatch(h,/<script>/);
});
