'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const os=require('node:os');
const crypto=require('node:crypto');
const {createStore}=require('../server/store.cjs');
const C=require('../src/core.js');
const R=require('../src/reporting.js');
const P=require('../src/pipeline.js');
const sha=bytes=>crypto.createHash('sha256').update(bytes).digest('hex');
function dashboard(date='2024-08-12',stock=1){return {type:'dashboard',center:'Flex',operator:'',date,dateLabel:date,file:'Synthetic dashboard '+date+'.xlsx',sheet:'Dashboard',holdDate:date,usageMonths:['2024-07'],rows:[{part:'TEST-000001',row:5,stock,po:0,hold:3,usage:{'2024-07':2}}]};}
function fixture(){return R.normalizeState({...C.empty(),sources:[dashboard()],notes:{'TEST-000001':'Keep this action note'},leadTimes:{'TEST-000001':{months:6}}});}
function temp(t){const directory=fs.mkdtempSync(path.join(os.tmpdir(),'parts-store-test-'));t.after(()=>fs.rmSync(directory,{recursive:true,force:true}));return directory;}
function update(state,date='2024-08-19',stock=7){return R.applySources(state,[dashboard(date,stock)],date);}
function statusError(status,code){return error=>error.status===status&&(!code||error.code===code);}

test('durable restart preserves full state, settings, notes, source revisions and original weekly values',t=>{
 const dataDir=temp(t),seed=fixture(),store=createStore({dataDir,seedState:seed});
 assert.equal(store.status().revision,0);assert.equal(store.status().reportCount,1);
 const next=update(store.read().state);next.settings.hqMonths=4;
 const saved=store.save({state:next,baseRevision:0,reportDate:'2024-08-19'});
 assert.equal(saved.revision,1);assert.deepEqual(saved.state,next);store.close();
 const restarted=createStore({dataDir,seedState:C.empty()});assert.deepEqual(restarted.read().state,next);
 assert.equal(restarted.status().reportCount,2);assert.equal(restarted.status().reportDate,'2024-08-19');
 assert.equal(C.calculate(R.reportState(restarted.read().state,'2024-08-12'),'2024-08-12').parts[0].stock,1);
 assert.equal(C.calculate(R.reportState(restarted.read().state,'2024-08-19'),'2024-08-19').parts[0].stock,7);
 const leaked=restarted.read();leaked.state.notes['TEST-000001']='Mutated';assert.equal(restarted.read().state.notes['TEST-000001'],'Keep this action note');
});

test('same-week correction replaces that report and next-week carry-forward preserves history without summing stock',t=>{
 const store=createStore({dataDir:temp(t),seedState:fixture()});
 let state=update(store.read().state);store.save({state,baseRevision:0});
 state=R.applySources(state,[dashboard('2024-08-19',9)],'2024-08-21');store.save({state,baseRevision:1});
 assert.equal(store.status().reportCount,2);assert.equal(store.status().reportDate,'2024-08-21');
 state=P.recordExistingWeek(state,'2024-08-26');store.save({state,baseRevision:2,operation:'carry-forward'});
 assert.equal(store.status().reportCount,3);assert.equal(store.status().reportDate,'2024-08-26');
 assert.equal(C.calculate(R.reportState(store.read().state,'2024-08-26'),'2024-08-26').parts[0].stock,9);
 assert.equal(store.listCommits()[0].operation,'carry-forward');assert.equal(store.listCommits().length,4);
});

test('failed pointer replacement leaves current state and committed raw index intact across restart',t=>{
 const dataDir=temp(t);let failNextPointer=false;
 const io=Object.create(fs);io.renameSync=(from,to)=>{if(failNextPointer&&to===path.join(dataDir,'current.json')){failNextPointer=false;throw Object.assign(new Error('Synthetic disk failure'),{code:'EIO'});}return fs.renameSync(from,to);};
 const store=createStore({dataDir,seedState:fixture(),fs:io}),before=store.read();
 const raw=store.addRaw({name:'Original.xlsx',bytes:Buffer.from('synthetic original bytes')});failNextPointer=true;
 assert.throws(()=>store.save({state:update(before.state),baseRevision:0,rawIds:[raw.id]}),/Synthetic disk failure/);
 assert.deepEqual(store.read(),before);assert.equal(store.listRaw().length,0);assert.throws(()=>store.readRaw(raw.id),statusError(404));
 const restarted=createStore({dataDir,seedState:C.empty()});assert.deepEqual(restarted.read(),before);assert.equal(restarted.listCommits().length,1);
 assert.ok(fs.readdirSync(path.join(dataDir,'generations')).length>1,'failed generation exists but is not selected');
 assert.equal(restarted.backupEntries().filter(entry=>entry.name.startsWith('generations/')).length,1);
 // Retrying is permitted from the original revision after the failed write.
 assert.equal(store.save({state:update(before.state),baseRevision:0,rawIds:[raw.id]}).revision,1);
});

test('optimistic revision rejects a stale browser and detects a second writer without losing the first save',t=>{
 const dataDir=temp(t),first=createStore({dataDir,seedState:fixture()}),second=createStore({dataDir,seedState:fixture()});
 const stale=second.read().state;first.save({state:update(first.read().state),baseRevision:0});
 assert.throws(()=>first.save({state:stale,baseRevision:0}),statusError(409,'REVISION_CONFLICT'));
 assert.throws(()=>second.save({state:stale,baseRevision:0}),statusError(409,'REVISION_CONFLICT'));
 assert.equal(second.read().revision,1);assert.equal(first.read().revision,1);
 assert.throws(()=>first.save({state:first.read().state}),statusError(409));
});

test('corrupt current pointer recovers only the previous committed generation, not an orphan',t=>{
 const dataDir=temp(t),store=createStore({dataDir,seedState:fixture()});
 store.save({state:update(store.read().state),baseRevision:0});
 fs.writeFileSync(path.join(dataDir,'current.json'),'broken pointer');
 fs.writeFileSync(path.join(dataDir,'generations','999999999999-00000000-0000-0000-0000-000000000000.json.gz'),'uncommitted newer-looking file');
 const restarted=createStore({dataDir,seedState:C.empty()});assert.equal(restarted.read().revision,0);assert.match(restarted.status().recoveryNotice,/직전/);assert.equal(restarted.status().reportCount,1);
 const next=update(restarted.read().state);assert.equal(restarted.save({state:next,baseRevision:0}).revision,1);
 const clean=createStore({dataDir});assert.deepEqual(clean.read().state,next);assert.equal(clean.status().recoveryNotice,undefined);
});

test('corrupt latest generation recovers previous; both broken pointers never overwrite seed',t=>{
 const dataDir=temp(t),store=createStore({dataDir,seedState:fixture()});store.save({state:update(store.read().state),baseRevision:0});
 const pointer=JSON.parse(fs.readFileSync(path.join(dataDir,'current.json'),'utf8'));
 fs.writeFileSync(path.join(dataDir,'generations',pointer.generation),'broken gzip');
 assert.equal(createStore({dataDir}).read().revision,0);
 fs.writeFileSync(path.join(dataDir,'previous.json'),'broken previous');
 const bytes=fs.readFileSync(path.join(dataDir,'current.json'));
 assert.throws(()=>createStore({dataDir,seedState:C.empty()}),statusError(503,'STORE_RECOVERY_REQUIRED'));
 assert.deepEqual(fs.readFileSync(path.join(dataDir,'current.json')),bytes);
});

test('raw storage retains exact bytes and Korean filenames, deduplicates bytes, and exposes only committed originals',t=>{
 const store=createStore({dataDir:temp(t),seedState:fixture()}),bytes=Buffer.from([0,1,2,255,22,0,99]);
 const first=store.addRaw({name:'인도 법인 재고.xlsx',bytes});assert.equal(first.sha256,sha(bytes));assert.equal(first.size,bytes.length);
 assert.equal(store.listRaw().length,0);assert.throws(()=>store.readRaw(first.id),statusError(404));
 const alias=store.addRaw({name:'재고 수정본.xlsx',bytes});assert.equal(alias.id,first.id);
 store.save({state:store.read().state,baseRevision:0,rawIds:[first.id,alias.id],reportDate:'2024-08-12'});
 const raw=store.readRaw(first.id);assert.deepEqual(raw.bytes,bytes);assert.equal(store.listRaw().length,1);assert.equal(raw.meta.uses.length,1);
 assert.deepEqual(raw.meta.names,['인도 법인 재고.xlsx','재고 수정본.xlsx']);assert.equal(raw.meta.week,'2024-08-12');
 raw.meta.name='external mutation';assert.equal(store.readRaw(first.id).meta.name,'재고 수정본.xlsx');
 for(const name of ['../x.xlsx','sub/x.xlsx','sub\\x.xlsx','..','a\u0000b.xlsx'])assert.throws(()=>store.addRaw({name,bytes}),statusError(400,'INVALID_RAW_NAME'));
 for(const id of ['../../auth.json','raw_../x','raw_'+sha(bytes)+'/../x'])assert.throws(()=>store.readRaw(id),statusError(400,'INVALID_RAW_ID'));
 assert.throws(()=>store.save({state:store.read().state,baseRevision:1,rawIds:['raw_'+'f'.repeat(64)]}),statusError(422,'RAW_NOT_STAGED'));
 assert.equal(store.read().revision,1);
});

test('bootstrap imports initial raw folder recursively exactly once and never resets existing state',t=>{
 const base=temp(t),dataDir=path.join(base,'data'),initialRawDir=path.join(base,'initial');fs.mkdirSync(path.join(initialRawDir,'Flex'),{recursive:true});
 fs.writeFileSync(path.join(initialRawDir,'Flex','WIP.xlsx'),'initial original');fs.writeFileSync(path.join(initialRawDir,'ignore.txt'),'not a workbook');
 const first=createStore({dataDir,seedState:fixture(),initialRawDir});assert.equal(first.listRaw().length,1);assert.equal(first.readRaw(first.listRaw()[0].id).bytes.toString(),'initial original');
 first.save({state:update(first.read().state),baseRevision:0});fs.writeFileSync(path.join(initialRawDir,'HQ.xlsx'),'arrived later');
 const reopened=createStore({dataDir,seedState:C.empty(),initialRawDir});assert.equal(reopened.status().reportCount,2);assert.equal(reopened.listRaw().length,1);assert.equal(reopened.read().revision,1);
});

test('ordinary update cannot remove saved report weeks or break older source references; restore is explicit',t=>{
 const store=createStore({dataDir:temp(t),seedState:fixture()}),initial=store.read().state;
 store.save({state:update(initial),baseRevision:0});
 assert.throws(()=>store.save({state:initial,baseRevision:1}),statusError(422,'HISTORY_REMOVAL_BLOCKED'));
 const broken=store.read().state;broken.reportingWeeks[0].sourceRefs[0].revision='does-not-exist';
 assert.throws(()=>store.save({state:broken,baseRevision:1}),statusError(422,'INVALID_REPORT_HISTORY'));
 assert.equal(store.read().revision,1);store.save({state:initial,baseRevision:1,operation:'restore'});assert.equal(store.status().reportCount,1);assert.equal(store.listCommits().length,3);
});

test('empty first-start state is allowed, but invalid uploads and malformed report dates never publish',t=>{
 const store=createStore({dataDir:temp(t),seedState:C.empty()});assert.equal(store.status().reportCount,0);
 assert.equal(store.save({state:fixture(),baseRevision:0}).revision,1);
 assert.throws(()=>store.save({state:C.empty(),baseRevision:1}),statusError(422,'INVALID_STATE'));
 assert.throws(()=>store.save({state:store.read().state,baseRevision:1,reportDate:'2024-02-31'}),statusError(400,'INVALID_REPORT_DATE'));
 assert.equal(store.read().revision,1);
});

test('backup entries restore every committed state and raw byte, excluding pending uploads and unrelated files',t=>{
 const dataDir=temp(t),restoreDir=temp(t),store=createStore({dataDir,seedState:fixture()});
 const raw=store.addRaw({name:'Committed.xlsx',bytes:Buffer.from('committed original')});store.save({state:update(store.read().state),baseRevision:0,rawIds:[raw.id]});
 const pending=store.addRaw({name:'Pending.xlsx',bytes:Buffer.from('uncommitted original')});fs.writeFileSync(path.join(dataDir,'auth.json'),'not included by store');
 const entries=store.backupEntries();assert.ok(entries.every(entry=>!entry.name.includes(pending.sha256)&&!entry.name.includes('auth')));
 assert.equal(entries.filter(entry=>entry.name.startsWith('generations/')).length,2);
 for(const entry of entries){const target=path.join(restoreDir,entry.name);fs.mkdirSync(path.dirname(target),{recursive:true});fs.writeFileSync(target,entry.bytes);}
 const restored=createStore({dataDir:restoreDir,seedState:C.empty()});assert.deepEqual(restored.read(),store.read());assert.deepEqual(restored.listCommits(),store.listCommits());assert.deepEqual(restored.readRaw(raw.id).bytes,Buffer.from('committed original'));assert.throws(()=>restored.readRaw(pending.id),statusError(404));
});

test('HTTP operation names import, carry and remove preserve their audit labels and history guards',t=>{
 const store=createStore({dataDir:temp(t),seedState:fixture()});
 let state=update(store.read().state);store.save({state,baseRevision:0,operation:'import'});
 state=P.recordExistingWeek(state,'2024-08-26');store.save({state,baseRevision:1,operation:'carry'});
 // Removing a source is not permission to remove an earlier report week.
 assert.throws(()=>store.save({state:fixture(),baseRevision:2,operation:'remove'}),statusError(422,'HISTORY_REMOVAL_BLOCKED'));
 store.save({state:store.read().state,baseRevision:2,operation:'remove'});
 assert.deepEqual(store.listCommits(3).map(commit=>commit.operation),['remove','carry','import']);
 assert.equal(store.status().reportCount,3);assert.equal(store.status().revision,3);
});
