'use strict';
// Synthetic quantities only. A confirmed report week is selection evidence,
// never an invented inventory measurement date or WIP observation date.
const test=require('node:test'),assert=require('node:assert/strict');
const C=require('../src/core.js'),R=require('../src/reporting.js'),P=require('../src/pipeline.js');
const PART='1000-000001',MONTHS=['2026-04','2026-05','2026-06','2026-07','2026-08','2026-09'];
function dashboard(date='2026-09-28'){
 return {type:'dashboard',center:'Flex',operator:'',date,dateLabel:date,file:'Synthetic dashboard.xlsx',sheet:'Dashboard',holdDate:date,usageMonths:MONTHS,
  rows:[{part:PART,row:2,stock:1,po:0,hold:2,usage:Object.fromEntries(MONTHS.map(month=>[month,2]))}]};
}
function inventory(date,qty=4){return {type:'india',date,dateLabel:date||'WK41',file:'Synthetic inventory.xlsx',sheet:'Stock',rows:[{part:PART,row:2,qty}]};}
function weekInventory(week,qty=4){return C.assignReportWeek(inventory(null,qty),week);}
function fixture(date='2026-09-28',qty=8){return R.normalizeState({...C.empty(),sources:[dashboard(date),...(qty==null?[]:[inventory(date,qty)])]});}
function source(state,week,type='india'){
 const sources=R.reportState(state,week).sources.filter(item=>item.type===type);
 return sources.sort((a,b)=>(C.sourceSelectionDate(a)||'').localeCompare(C.sourceSelectionDate(b)||'')).at(-1)||null;
}
function indiaQty(state,week){return C.calculate(R.reportState(state,week),R.reports(state).find(report=>report.id===week).cutoff,'Flex').parts.find(part=>part.part===PART).india;}
const reload=state=>R.normalizeState(JSON.parse(JSON.stringify(state)));

test('confirming a source week preserves unknown actual date and normalizes the reporting week',()=>{
 const original=inventory(null,12),before=JSON.stringify(original),assigned=C.assignReportWeek(original,'2026-10-07');
 assert.equal(assigned.date,null);assert.equal(assigned.reportWeek,'2026-10-05');assert.equal(assigned.datePrecision,'week');
 assert.equal(C.sourceSelectionDate(assigned),'2026-10-05');assert.equal(assigned.rows[0].qty,12);
 assert.equal(JSON.stringify(original),before);assert.throws(()=>C.assignReportWeek(original,'2026-02-31'));
 assert.throws(()=>C.assignReportWeek(original,null));
 const dated=C.assignReportWeek(inventory('2026-10-06',13),'2026-10-05');
 assert.equal(dated.date,'2026-10-06');assert.equal(C.sourceSelectionDate(dated),'2026-10-06');
});

test('pipeline uses confirmed week-only inventory without changing its date or selecting a future week',()=>{
 const state=fixture(),incoming=weekInventory('2026-10-05',12),plan=P.evaluate(state,[incoming],'2026-10-07');
 assert.equal(plan.canApply,true);assert.equal(plan.selectedSources.length,1);assert.equal(plan.selectedSources[0].date,null);
 const applied=R.applySources(state,plan.selectedSources,plan.reportDate);
 assert.equal(indiaQty(applied,'2026-10-05'),12);assert.equal(indiaQty(applied,'2026-09-28'),8);
 assert.equal(source(applied,'2026-10-05').reportWeek,'2026-10-05');assert.equal(source(applied,'2026-10-05').date,null);
 const future=P.evaluate(state,[weekInventory('2026-10-12',99)],'2026-10-07');
 assert.equal(future.canApply,false);assert.equal(future.selectedSources.length,0);
 const actualFuture=P.evaluate(state,[C.assignReportWeek(inventory('2026-10-06',99),'2026-10-05')],'2026-10-05');
 assert.equal(actualFuture.canApply,false);assert.equal(actualFuture.selectedSources.length,0);
});

test('unconfirmed inventory and undated WIP remain blocked instead of converting the report week into an observation date',()=>{
 const state=fixture(),wip={type:'wip',center:'Flex',operator:'Jio',date:null,file:'Synthetic WIP.xlsb',sheet:'Inhouse',rows:[]};
 assert.equal(P.evaluate(state,[inventory(null)],'2026-10-05').canApply,false);
 assert.throws(()=>C.assignReportWeek(wip,'2026-10-05'));
 const forged={...wip,reportWeek:'2026-10-05',datePrecision:'week',dateBasis:'user-confirmed-bundle'};
 const rejected=P.evaluate(state,[forged],'2026-10-05');
 assert.equal(rejected.canApply,false);assert.equal(rejected.selectedSources.length,0);
 assert.throws(()=>R.applySources(state,[forged],'2026-10-05'));
 assert.equal(P.validate({...state,sources:[...state.sources,forged]}).ok,false);
});

test('an actual October 6 source belongs to the October 5 reporting week when the report cutoff is October 6',()=>{
 const state=fixture(),incoming={...inventory('2026-10-06',13),type:'hq'},plan=P.evaluate(state,[incoming],'2026-10-06');
 assert.equal(plan.canApply,true);assert.equal(plan.weekId,'2026-10-05');assert.equal(plan.reportDate,'2026-10-06');
 const applied=R.applySources(state,plan.selectedSources,plan.reportDate),report=R.selectedReport(applied);
 assert.equal(report.id,'2026-10-05');assert.equal(report.cutoff,'2026-10-06');
 assert.equal(source(applied,'2026-10-05','hq').date,'2026-10-06');assert.equal(source(applied,'2026-09-28','hq'),null);
});

test('correcting an older source updates dependent later weeks but preserves earlier history and later own uploads',()=>{
 let state=fixture();
 state=R.applySources(state,[weekInventory('2026-10-05',20)],'2026-10-05');
 state=R.applySources(state,[],'2026-10-12');
 state=R.applySources(state,[inventory('2026-10-19',90)],'2026-10-19');
 state=R.applySources(state,[],'2026-10-26');
 state=R.applySources(state,[weekInventory('2026-10-05',25)],'2026-10-07');
 for(const saved of [state,reload(state)]){
  assert.equal(indiaQty(saved,'2026-09-28'),8);
  assert.equal(indiaQty(saved,'2026-10-05'),25);assert.equal(indiaQty(saved,'2026-10-12'),25);
  assert.equal(indiaQty(saved,'2026-10-19'),90);assert.equal(indiaQty(saved,'2026-10-26'),90);
  for(const report of R.reports(saved))assert.deepEqual(R.reportWarnings(saved,report.id),[]);
 }
});

test('supplementing a missing older-week slot fills dependent missing weeks and stops at a later own upload',()=>{
 let state=fixture('2026-09-28',null);
 state=R.applySources(state,[],'2026-10-05');state=R.applySources(state,[],'2026-10-12');
 state=R.applySources(state,[inventory('2026-10-19',90)],'2026-10-19');
 state=R.applySources(state,[weekInventory('2026-10-05',25)],'2026-10-07');
 assert.equal(indiaQty(state,'2026-09-28'),null);
 assert.equal(indiaQty(state,'2026-10-05'),25);assert.equal(indiaQty(state,'2026-10-12'),25);
 assert.equal(indiaQty(state,'2026-10-19'),90);
});

function cancellationFixture(){
 let state=fixture('2026-09-21',10);
 state=R.applySources(state,[inventory('2026-09-28',20)],'2026-09-28');
 state=R.applySources(state,[],'2026-10-05');
 state=R.applySources(state,[inventory('2026-10-12',30)],'2026-10-12');
 state=R.applySources(state,[],'2026-10-19');
 return state;
}

test('cancellation previews and applies the last normal earlier source only to dependent report weeks',()=>{
 let state=cancellationFixture();const removedId=source(state,'2026-09-28').id;
 const preview=R.previewRemoveSource(state,removedId,'2026-09-28');
 assert.equal(preview.source.rows[0].qty,20);assert.equal(preview.fallback.rows[0].qty,10);
 assert.deepEqual([...preview.affectedReportIds].sort(),['2026-09-28','2026-10-05']);
 state=R.removeSource(state,removedId,'2026-09-28');
 for(const saved of [state,reload(state)]){
  assert.equal(indiaQty(saved,'2026-09-21'),10);
  assert.equal(indiaQty(saved,'2026-09-28'),10);assert.equal(source(saved,'2026-09-28').date,'2026-09-21');
  assert.equal(indiaQty(saved,'2026-10-05'),10);assert.equal(source(saved,'2026-10-05').date,'2026-09-21');
  assert.equal(indiaQty(saved,'2026-10-12'),30);assert.equal(indiaQty(saved,'2026-10-19'),30);
  for(const report of R.reports(saved))assert.deepEqual(R.reportWarnings(saved,report.id),[]);
 }
});

test('reupload after cancellation restores the cancelled dependency chain, including after save and reload',()=>{
 let state=cancellationFixture();
 state=R.removeSource(state,source(state,'2026-09-28').id,'2026-09-28');state=reload(state);
 state=R.applySources(state,[inventory('2026-09-28',25)],'2026-09-30');state=reload(state);
 assert.equal(indiaQty(state,'2026-09-21'),10);
 assert.equal(indiaQty(state,'2026-09-28'),25);assert.equal(indiaQty(state,'2026-10-05'),25);
 assert.equal(indiaQty(state,'2026-10-12'),30);assert.equal(indiaQty(state,'2026-10-19'),30);
});

test('a newly recorded week inherits the normal fallback instead of resurrecting the cancelled source',()=>{
 let state=fixture('2026-09-21',10);
 state=R.applySources(state,[inventory('2026-09-28',20)],'2026-09-28');
 state=R.removeSource(state,source(state,'2026-09-28').id,'2026-09-28');state=reload(state);
 state=R.applySources(state,[],'2026-10-05');
 assert.equal(indiaQty(state,'2026-09-21'),10);
 assert.equal(indiaQty(state,'2026-09-28'),10);assert.equal(indiaQty(state,'2026-10-05'),10);
 assert.equal(source(state,'2026-10-05').date,'2026-09-21');
});

test('cancellation without an earlier eligible source leaves the slot missing in dependent and new weeks',()=>{
 let state=fixture('2026-09-21',null);
 state=R.applySources(state,[inventory('2026-09-28',20)],'2026-09-28');
 state=R.applySources(state,[],'2026-10-05');
 const id=source(state,'2026-09-28').id,preview=R.previewRemoveSource(state,id,'2026-09-28');
 assert.equal(preview.fallback,null);assert.deepEqual([...preview.affectedReportIds].sort(),['2026-09-28','2026-10-05']);
 state=R.removeSource(state,id,'2026-09-28');state=reload(state);
 state=R.applySources(state,[],'2026-10-12');
 for(const week of ['2026-09-21','2026-09-28','2026-10-05','2026-10-12']){
  assert.equal(source(state,week),null);assert.equal(indiaQty(state,week),null);
 }
});

test('cancelling an inherited source skips the same cancelled revision in earlier reports when choosing fallback',()=>{
 let state=fixture('2026-09-21',10);
 state=R.applySources(state,[inventory('2026-09-28',20)],'2026-09-28');
 state=R.applySources(state,[],'2026-10-05');state=R.applySources(state,[],'2026-10-12');
 const id=source(state,'2026-10-05').id,preview=R.previewRemoveSource(state,id,'2026-10-05');
 assert.equal(preview.source.rows[0].qty,20);assert.equal(preview.fallback.rows[0].qty,10);
 assert.deepEqual([...preview.affectedReportIds].sort(),['2026-10-05','2026-10-12']);
 state=reload(R.removeSource(state,id,'2026-10-05'));
 assert.equal(indiaQty(state,'2026-09-28'),20);
 assert.equal(indiaQty(state,'2026-10-05'),10);assert.equal(indiaQty(state,'2026-10-12'),10);
});

test('a corrected normal fallback reaches later dependent reports without changing an intervening own upload',()=>{
 let state=fixture('2026-09-21',10);
 state=R.applySources(state,[inventory('2026-09-28',20)],'2026-09-28');
 state=R.applySources(state,[],'2026-10-05');state=R.applySources(state,[],'2026-10-12');
 state=R.removeSource(state,source(state,'2026-10-05').id,'2026-10-05');
 state=R.applySources(state,[inventory('2026-09-21',11)],'2026-09-22');state=reload(state);
 assert.equal(indiaQty(state,'2026-09-21'),11);
 assert.equal(indiaQty(state,'2026-09-28'),20);
 assert.equal(indiaQty(state,'2026-10-05'),11);assert.equal(indiaQty(state,'2026-10-12'),11);
 state=R.applySources(state,[],'2026-10-19');assert.equal(indiaQty(state,'2026-10-19'),11);
});
