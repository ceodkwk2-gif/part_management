'use strict';
// Synthetic source fixtures only. Weekly uploads select snapshots; they do not
// sum successive weeks or alter stock, demand and existing order calculations.
const test=require('node:test'),assert=require('node:assert/strict');
const C=require('../src/core.js'),R=require('../src/reporting.js'),O=require('../src/operations.js'),P=require('../src/pipeline.js');
const PART='TEST-000001',DATE='2024-08-12';
const MONTHS=['2024-02','2024-03','2024-04','2024-05','2024-06','2024-07'];
function dashboard(date=DATE,stock=1,center='Flex'){
 return {type:'dashboard',center,operator:'',date,dateLabel:date,file:'Synthetic dashboard '+date+'.xlsx',sheet:'Dashboard',holdDate:date,usageMonths:MONTHS,
  rows:[{part:PART,row:5,stock,po:0,hold:3,usage:Object.fromEntries(MONTHS.map(month=>[month,2]))}]};
}
function inventory(type='india',date=DATE){return {type,date,dateLabel:date,file:'Synthetic '+type+'.xlsx',sheet:'Stock',rows:[{part:PART,row:2,qty:4}]};}
function fixture(){return R.normalizeState({...C.empty(),sources:[dashboard(),inventory(),inventory('hq')]});}
const row=(plan,key)=>plan.rows.find(item=>item.key===key);
test('next-week source selection updates quantities without summing snapshots and preserves the prior report',()=>{
 const original=fixture(),before=JSON.stringify(original),plan=P.evaluate(original,[dashboard('2024-08-19',7)],'2024-08-20');
 assert.equal(plan.canApply,true);assert.equal(plan.weekId,'2024-08-19');assert.equal(plan.rows.length,10);
 assert.equal(row(plan,'flex:dashboard').status,'new');assert.equal(row(plan,'india').status,'retained');
 assert.equal(row(plan,'ctdi:wip:Jio').status,'missing');assert.deepEqual(plan.selectedIndices,[0]);
 const next=R.applySources(original,plan.selectedSources,plan.reportDate);
 assert.equal(R.reports(next).length,2);assert.equal(C.calculate(R.reportState(next),'2024-08-20').parts[0].stock,7);
 assert.equal(C.calculate(R.reportState(next,'2024-08-12'),DATE).parts[0].stock,1);
 assert.equal(JSON.stringify(original),before);assert.equal(P.validate(next).ok,true);
});
test('same-week correction replaces the source rather than making a second report and retains older weeks',()=>{
 let state=fixture();state=R.applySources(state,[dashboard('2024-08-19',7)],'2024-08-20');
 const plan=P.evaluate(state,[dashboard('2024-08-19',9)],'2024-08-21');
 assert.equal(row(plan,'flex:dashboard').message,'같은 기준일 정정본 반영');
 state=R.applySources(state,plan.selectedSources,plan.reportDate);
 assert.equal(state.reportingWeeks.length,2);assert.equal(R.selectedReport(state).reportDate,'2024-08-21');
 assert.equal(C.calculate(R.reportState(state),'2024-08-21').parts[0].stock,9);
 assert.equal(C.calculate(R.reportState(state,'2024-08-12'),DATE).parts[0].stock,1);
});
test('past-week preview uses that saved week and future weeks inherit the latest saved report after corrections',()=>{
 let state=fixture();
 state=R.applySources(state,[dashboard(DATE,9),inventory('hq','2024-08-19')],'2024-08-20');
 const changedIndia=inventory();changedIndia.rows[0].qty=5;
 let plan=P.evaluate(state,[changedIndia],'2024-08-14');
 assert.equal(plan.canApply,true);assert.equal(row(plan,'flex:dashboard').status,'retained');
 assert.equal(row(plan,'flex:dashboard').source.rows[0].stock,1);
 state=R.applySources(state,plan.selectedSources,plan.reportDate);
 const get=(id,type)=>R.reportState(state,id).sources.find(source=>source.type===type);
 assert.equal(get('2024-08-12','dashboard').rows[0].stock,1);
 assert.equal(get('2024-08-19','dashboard').rows[0].stock,9);
 // Re-uploading the old week's existing dashboard is a no-op even though the
 // global store contains the newer report's different same-date revision.
 plan=P.evaluate(state,[dashboard(DATE,1)],'2024-08-14');
 assert.equal(row(plan,'flex:dashboard').status,'retained');assert.equal(plan.canApply,false);
 plan=P.evaluate(state,[dashboard(DATE,2)],'2024-08-15');
 state=R.applySources(state,plan.selectedSources,plan.reportDate);
 plan=P.evaluate(state,[inventory('hq','2024-08-26')],'2024-08-27');
 assert.equal(row(plan,'flex:dashboard').source.rows[0].stock,9);
 // India was inherited; the old-week correction propagates. The independently
 // uploaded dashboard above remains at its newer report's own revision.
 assert.equal(row(plan,'india').source.rows[0].qty,5);
 state=R.applySources(state,plan.selectedSources,plan.reportDate);
 assert.equal(get('2024-08-12','dashboard').rows[0].stock,2);
 assert.equal(get('2024-08-19','dashboard').rows[0].stock,9);
 assert.equal(get('2024-08-26','dashboard').rows[0].stock,9);
 assert.equal(P.validate(state).ok,true);
});
test('latest actual source date wins independently of upload order and file modification metadata',()=>{
 const older={...dashboard('2024-08-15',50),importedAt:'2099-01-01'},newer=dashboard('2024-08-19',4);
 for(const sources of [[older,newer],[newer,older]]){
  const plan=P.evaluate(fixture(),sources,'2024-08-20');assert.equal(plan.canApply,true);assert.equal(plan.selectedSources.length,1);
  assert.equal(plan.selectedSources[0].date,'2024-08-19');assert.equal(plan.selectedSources[0].rows[0].stock,4);
 }
});
test('older uploads never replace the existing newer source and exact already applied copies are no-ops',()=>{
 const state=fixture();
 const older=P.evaluate(state,[dashboard('2024-08-05',99)],'2024-08-20');
 assert.equal(row(older,'flex:dashboard').status,'retained');assert.equal(older.selectedSources.length,0);assert.equal(older.canApply,false);
 const same=P.evaluate(state,[{...dashboard(),file:'Renamed copy.xlsx',importPath:'weekly/copy.xlsx',importedAt:'2099-01-01'}],'2024-08-20');
 assert.equal(same.ok,true);assert.equal(same.canApply,false);assert.equal(row(same,'flex:dashboard').source.rows[0].stock,1);
});
test('conflicting same-date uploads require a choice and apply only that whole source',()=>{
 const sources=[dashboard('2024-08-19',4),{...dashboard('2024-08-19',9),file:'Correction.xlsx'}];
 const plan=P.evaluate(fixture(),sources,'2024-08-20');assert.equal(plan.canApply,false);assert.equal(row(plan,'flex:dashboard').status,'conflict');
 assert.equal(row(plan,'flex:dashboard').source,null);assert.equal(plan.selectedSources.length,0);
 const chosen=P.evaluate(fixture(),sources,'2024-08-20',{'flex:dashboard':'incoming:1'});
 assert.equal(chosen.canApply,true);assert.deepEqual(chosen.selectedIndices,[1]);assert.equal(chosen.selectedSources[0].rows[0].stock,9);
 assert.equal(P.evaluate(fixture(),sources,'2024-08-20',{'flex:dashboard':'incoming:99'}).canApply,false);
});
test('identical copies with different source provenance import once while original row policy is preserved',()=>{
 const source=dashboard('2024-08-19',4);source.rows.push({...source.rows[0],row:9,stock:200});
 const copy={...source,file:'Copied workbook.xlsx',sheet:'Copied sheet',importPath:'copy/path.xlsx',id:'copy',importedAt:'2099-01-01'};
 const plan=P.evaluate(fixture(),[source,copy],'2024-08-20');
 assert.equal(plan.canApply,true);assert.equal(plan.selectedSources.length,1);assert.match(plan.warnings.join(' '),/복사본 1건/);
 const state=R.applySources(fixture(),plan.selectedSources,plan.reportDate),calculated=C.calculate(R.reportState(state),'2024-08-20');
 assert.equal(calculated.parts[0].stock,4);assert.equal(calculated.parts[0].selectedSourceRow,5);assert.equal(P.validate(state).ok,true);
});
test('new missing or invalid dates block without inventing a date, but legacy undated inventory can carry',()=>{
 const state=fixture();state.sources.push({...inventory('india',null),dateLabel:'WK32'});
 for(const date of [null,'2024-02-31','08/20/2024']){
  const plan=P.evaluate(state,[inventory('india',date)],'2024-08-20');
  assert.equal(plan.canApply,false);assert.equal(row(plan,'india').status,'date_required');
  assert.equal(plan.selectedSources.length,0);
 }
 const legacy=R.normalizeState({...C.empty(),sources:[dashboard(),inventory('india',null)]});
 const carried=P.evaluate(legacy,[dashboard('2024-08-19')],'2024-08-20');
 assert.equal(carried.canApply,true);assert.equal(row(carried,'india').status,'retained');assert.equal(row(carried,'india').source.date,null);
 assert.match(carried.warnings.join(' '),/기준일 미확인/);
});
test('future sources and malformed report dates block until explicitly corrected or excluded',()=>{
 const future=P.evaluate(fixture(),[dashboard('2024-08-21')],'2024-08-20');
 assert.equal(future.canApply,false);assert.equal(row(future,'flex:dashboard').status,'future');
 const invalid=P.evaluate(fixture(),[dashboard('2024-08-19')],'2024-02-31');
 assert.equal(invalid.canApply,false);assert.equal(invalid.weekId,null);assert(invalid.errors.length);
});
test('logical slots canonicalize Flex Jio and CTDI Vodafone Idea while rejecting unknown operators',()=>{
 assert.equal(P.slotKey({type:'wip',center:'Flex',operator:'미구분'}),'flex:wip:Jio');
 assert.equal(P.slotKey({type:'wip',center:'CTDI',operator:'Vodafone Idea'}),'ctdi:wip:Vi');
 const source={type:'wip',center:'CTDI',operator:'Unknown',date:DATE,rows:[]};
 assert.equal(P.evaluate(fixture(),[source],DATE).ok,false);
 const accepted=P.evaluate(fixture(),[{...source,operator:'Vodafone Idea'}],DATE);
 assert.equal(accepted.canApply,true);assert.equal(accepted.selectedSources[0].operator,'Vi');
});
test('validation preserves unknown quantities as warnings but fails closed for negative quantities or invalid sources',()=>{
 const uncertain=R.applySources(fixture(),[dashboard(DATE,null)],DATE);
 assert.equal(P.validate(uncertain).ok,true);assert.match(P.validate(uncertain).warnings.join(' '),/계산할 수 없습니다/);
 const negative=R.applySources(fixture(),[dashboard(DATE,-1)],DATE);
 const result=P.validate(negative);assert.equal(result.ok,false);assert.match(result.errors.join(' '),/음수/);
 assert.equal(P.validate(null).ok,false);assert.equal(P.validate(C.empty()).ok,false);
 assert.equal(P.validate({...C.empty(),sources:[{type:'unrecognized',rows:[]}]}).ok,false);
});
test('validation blocks a broken calculation or action grouping instead of exporting a false success',()=>{
 const calculate=C.calculate,evaluate=O.evaluate;
 try{
  C.calculate=(...args)=>{const result=calculate(...args);result.allParts[0].shortage+=1;return result;};
  let result=P.validate(fixture());assert.equal(result.ok,false);assert.match(result.errors.join(' '),/부족 산식/);
  C.calculate=calculate;
  O.evaluate=(...args)=>({...evaluate(...args),groupTotal:999,groupingComplete:false});
  result=P.validate(fixture());assert.equal(result.ok,false);assert.match(result.errors.join(' '),/조치담당 조합 종수/);
 }finally{C.calculate=calculate;O.evaluate=evaluate;}
 const clean=P.validate(fixture());assert.equal(clean.ok,true);assert.equal(clean.summary.shortagePartKinds,clean.summary.actionGroupKinds);
});
test('explicit carry-forward records a new week without redating sources or changing prior report evidence',()=>{
 const state=fixture(),oldReport=R.selectedReport(state);
 state.notes.review='Synthetic note retained';state.partLeadTimes={[PART]:{months:6,note:'Synthetic LT'}};
 const before=JSON.stringify(state);
 const plan=P.evaluate(state,[],'2024-08-20');
 assert.equal(plan.canApply,false);assert.equal(plan.canRecordExisting,true);assert.equal(plan.recordExistingReason,'');
 const next=P.recordExistingWeek(state,'2024-08-20'),report=R.selectedReport(next);
 assert.equal(R.reports(next).length,2);assert.equal(report.reportDate,'2024-08-20');assert.equal(report.carriedForward,true);
 assert.deepEqual(report.sourceRefs,oldReport.sourceRefs);assert.deepEqual(R.reports(next)[0],oldReport);
 assert.deepEqual(next.sources,state.sources);assert.deepEqual(next.settings,state.settings);
 assert.deepEqual(next.notes,state.notes);assert.deepEqual(next.partLeadTimes,state.partLeadTimes);
 assert.equal(R.selectedReport(state).reportDate,DATE);assert.equal(JSON.stringify(state),before);
 const restored=R.normalizeState(JSON.parse(JSON.stringify(next)));
 assert.equal(R.selectedReport(restored).carriedForward,true);assert.equal(P.validate(restored).ok,true);
 const later=P.recordExistingWeek(restored,'2024-08-27');
 assert.equal(R.reports(later).length,3);assert.deepEqual(R.selectedReport(later).sourceRefs,oldReport.sourceRefs);
 assert.equal(Object.keys(later.reportingSourceArchive).length,0);
});
test('carry-forward requires an unrecorded week after the latest report and existing usable source data',()=>{
 const state=fixture();
 for(const date of [DATE,'2024-08-18','2024-08-05','2024-02-31',null]){
  assert.equal(P.evaluate(state,[],date).canRecordExisting,false);
  assert.throws(()=>P.recordExistingWeek(state,date));
 }
 const next=P.recordExistingWeek(state,'2024-08-20');
 assert.equal(P.evaluate(next,[],'2024-08-21').canRecordExisting,false);
 assert.throws(()=>P.recordExistingWeek(next,'2024-08-21'),/이미 있습니다/);
 assert.equal(P.evaluate(C.empty(),[],'2024-08-20').canRecordExisting,false);
 assert.throws(()=>P.recordExistingWeek(C.empty(),'2024-08-20'),/저장된 보고 자료/);
});
test('pending files and source-reference or quantity errors cannot be bypassed with carry-forward',()=>{
 for(const source of [dashboard(),dashboard(null),dashboard('2024-08-21'),{type:'unrecognized',date:DATE,rows:[]}]){
  assert.equal(P.evaluate(fixture(),[source],'2024-08-20').canRecordExisting,false);
 }
 const broken=fixture();broken.reportingWeeks[0].sourceRefs[0].revision='missing';
 assert.equal(P.evaluate(broken,[],'2024-08-20').canRecordExisting,false);
 assert.throws(()=>P.recordExistingWeek(broken,'2024-08-20'),/원본 버전/);
 const negative=R.applySources(fixture(),[dashboard(DATE,-1)],DATE);
 assert.throws(()=>P.recordExistingWeek(negative,'2024-08-20'),/음수/);
});
