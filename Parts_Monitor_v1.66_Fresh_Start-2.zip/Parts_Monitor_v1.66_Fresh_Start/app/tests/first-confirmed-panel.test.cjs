'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const P=require('../src/first-confirmed-panel.js');
function entry(overrides={}){return {key:'stable-key-1',part:'1205-003915',center:'Flex',operator:'Jio',sn:'SN-1',rma:'RMA-1',receipt:'2026-08-21',date:'2026-10-12',currentAgeDays:52,firstSeenDate:'2026-09-25',effectiveFirstSeenDate:'2026-09-25',manualEditable:true,...overrides};}
function fixture(rows=[entry()]){return {firstConfirmedEntries:rows,rows:[{part:'1205-003915',name:'IC-ETHERNET SWITCH'}]};}
test('manual dates panel lists stable product-part pairs and searches identities, not source row numbers',()=>{
 const rows=[entry(),entry({key:'other-part',part:'0902-002744'}),entry({key:'other-repair',rma:'RMA-2'}),entry({key:'other-center',center:'CTDI',operator:'Airtel'}),entry()];
 const m=P.buildModel({data:fixture(rows)});assert.equal(m.rows.length,4);
 assert.equal(P.buildModel({data:fixture(rows),search:'rma-2'}).rows.length,1);
 assert.equal(P.buildModel({data:fixture(rows),search:'airtel'}).rows[0].center,'CTDI');
 assert.equal(P.buildModel({data:fixture(rows),search:'0902-002744'}).rows[0].key,'other-part');
 assert.equal(P.buildModel({data:fixture(rows),search:'missing'}).rows.length,0);
});
test('manual and review views preserve total counts and paginate by record identity',()=>{
 const rows=Array.from({length:25},(_,i)=>entry({key:'K-'+i,sn:'S-'+i,currentAgeDays:i,manualFirstConfirmedDate:i%2?'2026-09-01':null,firstConfirmedConflict:i===2}));
 const model=P.buildModel({data:fixture(rows),page:2,pageSize:10});assert.equal(model.visible.length,10);assert.equal(model.pages,3);assert.equal(model.manualCount,12);assert.equal(model.conflictCount,1);
 assert.equal(P.buildModel({data:fixture(rows),mode:'MANUAL'}).rows.length,12);
 assert.equal(P.buildModel({data:fixture(rows),mode:'CONFLICT'}).rows[0].key,'K-2');
 assert.equal(P.buildModel({data:fixture(rows),page:999,pageSize:10}).page,3);
});
test('editable renderer distinguishes auto evidence, manual applied date and conflicts without redefining TAT',()=>{
 const data=fixture([entry({manualFirstConfirmedDate:'2026-09-01',manualFirstConfirmedNote:'old report row 2',effectiveFirstSeenDate:'2026-09-01',firstConfirmedSource:'manual',firstConfirmedConflict:true})]);
 const before=JSON.stringify(data),html=P.render({data});
 assert.match(html,/WIP 최초확인/);assert.match(html,/2026-09-25/);assert.match(html,/value="2026-09-01"/);assert.match(html,/수기 확인/);assert.match(html,/날짜 확인 필요/);assert.match(html,/TAT 52일/);
 assert.match(html,/min="2026-08-21"/);assert.match(html,/max="2026-10-12"/);assert.match(html,/자동으로 복귀/);assert.equal(JSON.stringify(data),before);
 assert.doesNotMatch(html,/추가 PO|발주 필요수/);
});
test('readonly result viewer exposes saved dates but cannot submit or clear them; English stays English',()=>{
 const html=P.render({data:fixture([entry({manualFirstConfirmedDate:'2026-09-01'})]),readOnly:true,language:'en'});
 assert.match(html,/results viewer/);assert.match(html,/2026-09-01/);assert.doesNotMatch(html,/data-fc-date|data-fc-save|data-fc-clear/);assert.doesNotMatch(html,/[가-힣]/);
});
test('rendering escapes untrusted part names, notes and product identity',()=>{
 const data=fixture([entry({key:'<unsafe>"key',sn:'<img src=x>',manualFirstConfirmedNote:'" onfocus="bad',manualFirstConfirmedDate:'2026-09-01'})]);data.rows[0].name='<script>bad</script>';
 const html=P.render({data});assert.doesNotMatch(html,/<img|<script|value="" onfocus=/);assert.match(html,/&lt;img/);assert.match(html,/&lt;script&gt;/);assert.match(html,/data-fc-key="&lt;unsafe&gt;&quot;key"/);
});
test('empty state explains WIP requirement and incomplete identities cannot receive manual dates',()=>{
 assert.match(P.render({data:{}}),/WIP를 반영하면/);
 const html=P.render({data:fixture([entry({manualEditable:false})])});assert.match(html,/제품 식별정보 또는 날짜 확인 필요/);assert.match(html,/data-fc-save disabled/);
 assert.ok(P.validation(entry({manualEditable:false}),'2026-09-01'));
});
test('date validation allows legitimate earlier evidence but rejects impossible bounds and oversized notes',()=>{
 const row=entry();assert.equal(P.validation(row,'2026-08-21'),'');assert.equal(P.validation(row,'2026-10-12'),'');assert.equal(P.validation(row,'2026-10-01'),'');assert.equal(P.validation(row,null),'');
 for(const date of ['', '2026-02-30','26/09/01','2026-08-20','2026-10-13'])assert.ok(P.validation(row,date),date);
 assert.ok(P.validation(row,'2026-09-01','x'.repeat(2001)));assert.equal(P.validation(row,'2026-09-01','x'.repeat(2000)),'');
});
function bindingFixture(record=entry()){
 const make=extra=>({disabled:false,value:'',textContent:'',classList:{add(){},remove(){}},...extra});
 const input=make({value:'2026-09-01'}),note=make({value:'prior weekly report'}),save=make(),clear=make(),status=make(),search=make(),mode=make({value:'ALL'}),next=make({dataset:{fcPage:'2'}});
 const elements={'[data-fc-date]':input,'[data-fc-note]':note,'.fc-row-status':status,'[data-fc-save]':save,'[data-fc-clear]':clear};
 const row={getAttribute:()=>record.key,querySelector:selector=>elements[selector]};
 const root={querySelector:selector=>({'[data-fc-search]':search,'[data-fc-mode]':mode})[selector],querySelectorAll:selector=>({'[data-fc-page]':[next],'[data-fc-key]':[row]})[selector]||[]};
 return {root,input,note,save,clear,status,search,mode,next,data:fixture([record])};
}
test('save and clear send exact server operation payloads with stable keys',async()=>{
 const row=entry({key:'["center","SN-1","RMA-1","1205-003915"]'}),f=bindingFixture(row),sent=[],saved=[];
 P.bind(f.root,{onSave:async payload=>sent.push(payload),onSaved:value=>saved.push(value)},{data:f.data});
 await f.save.onclick();assert.deepEqual(sent[0],{changes:[{key:row.key,date:'2026-09-01',note:'prior weekly report'}]});assert.match(f.status.textContent,/저장 완료/);assert.equal(saved.length,1);
 await f.clear.onclick();assert.deepEqual(sent[1],{changes:[{key:row.key,date:null,note:''}]});assert.match(f.status.textContent,/자동 관찰일로 복귀/);
});
test('failed saves preserve the typed date and note, display server error and never report success',async()=>{
 const f=bindingFixture(),error=new Error('Revision changed'),seen=[];let saved=0;
 P.bind(f.root,{onSave:async()=>{throw error},onSaved:()=>saved++,onError:e=>seen.push(e)},{data:f.data});
 await f.save.onclick();assert.equal(f.input.value,'2026-09-01');assert.equal(f.note.value,'prior weekly report');assert.equal(f.status.textContent,'Revision changed');assert.equal(saved,0);assert.deepEqual(seen,[error]);assert.equal(f.save.disabled,false);
});
test('invalid dates never submit, pending saves prevent duplicate submissions and filters reset page',async()=>{
 const f=bindingFixture();let calls=0,release;const filters=[],pages=[];
 P.bind(f.root,{onSave:()=>{calls++;return new Promise(resolve=>release=resolve)},onFilter:value=>filters.push(value),onPage:value=>pages.push(value)},{data:f.data});
 f.input.value='2026-08-20';await f.save.onclick();assert.equal(calls,0);assert.match(f.status.textContent,/입고일/);
 f.input.value='2026-09-01';const pending=f.save.onclick();assert.equal(f.input.disabled,true);await f.save.onclick();assert.equal(calls,1);release();await pending;assert.equal(f.input.disabled,false);
 f.search.value='SN-1';f.search.onchange();f.mode.value='MANUAL';f.mode.onchange();f.next.onclick();assert.deepEqual(filters,[{search:'SN-1',page:1},{mode:'MANUAL',page:1}]);assert.deepEqual(pages,[2]);
});
test('unsaved row drafts survive unrelated renders and report dirty state without submitting',()=>{
 const row=entry({manualFirstConfirmedDate:'2026-09-03',manualFirstConfirmedNote:'saved note'}),data=fixture([row]),drafts={[row.key]:{date:'2026-09-02',note:'pending note'}};
 const html=P.render({data,drafts});assert.match(html,/value="2026-09-02"/);assert.match(html,/value="pending note"/);assert.match(html,/미저장/);assert.match(html,/2026-09-25/);
 const f=bindingFixture(row),changes=[];P.bind(f.root,{onDirty:value=>changes.push(value)},{data:f.data});
 f.input.value='2026-09-02';f.note.value='pending note';f.input.oninput();assert.deepEqual(changes[0],{key:row.key,date:'2026-09-02',note:'pending note',dirty:true});assert.equal(f.status.textContent,'미저장');
 f.input.value=row.manualFirstConfirmedDate;f.note.value=row.manualFirstConfirmedNote;f.note.oninput();assert.equal(changes[1].dirty,false);assert.equal(f.status.textContent,'');
 assert.equal(data.firstConfirmedEntries[0].manualFirstConfirmedDate,'2026-09-03');
});
test('an existing manual date can be cleared when newer source dates or identity need review',async()=>{
 const row=entry({manualEditable:false,manualFirstConfirmedDate:'2026-09-01',receipt:null}),data=fixture([row]),html=P.render({data});
 assert.match(html,/data-fc-save disabled/);assert.doesNotMatch(html,/data-fc-clear disabled/);assert.equal(P.validation(row,null),'');
 const f=bindingFixture(row),sent=[];P.bind(f.root,{onSave:async payload=>sent.push(payload)},{data});await f.clear.onclick();assert.equal(sent[0].changes[0].date,null);
});
test('a retained but invalid manual record is not labelled as the applied source',()=>{
 const data=fixture([entry({manualFirstConfirmedDate:'2026-08-01',firstConfirmedSource:'automatic',effectiveFirstSeenDate:'2026-09-25',firstConfirmedConflict:true})]);
 const html=P.render({data});assert.match(html,/value="2026-08-01"/);assert.match(html,/<div class="fc-applied"><b>2026-09-25<\/b><span class="fc-badge ">자동 관찰<\/span>/);assert.doesNotMatch(html,/<span class="fc-badge fc-manual">/);assert.match(html,/data-fc-clear >/);
});
