'use strict';
// Synthetic data only: this is a projection layer, not a second inventory model.
const test=require('node:test');
const assert=require('node:assert/strict');
const Share=require('../src/share-tables.js');
const Tat=require('../src/wip-tat.js');
const PART='TEST-000001',OTHER='TEST-000002',DATE='2024-09-30';
const member=(extra={})=>({part:PART,center:'Center A',stock:0,india:8,hq:20,avg:0.5,needed:4,target:1,
 shortage:4,poOrdered:0,open:0,proposed:5,dashboardDate:'2024-09-20',needDate:DATE,poSourceDate:null,...extra});
const task=(row,recipient='CENTER',kind='ORDER',extra={})=>({id:[row.center,row.part,kind,recipient].join('|'),
 part:row.part,center:row.center,recipient,kind,row,text:'추가 PO 총 5개 필요',quantity:5,
 tat:{products:2,overdueProducts:1},sourceDates:{stock:row.dashboardDate,wip:[DATE],india:null},...extra});
const objectRows=model=>model.rows.map(row=>Object.fromEntries(model.columns.map((column,index)=>[column.key,row[index]])));
function freeze(value){if(value&&typeof value==='object'&&!Object.isFrozen(value)){Object.freeze(value);Object.values(value).forEach(freeze)}return value}
function waiting(age,index=0,extra={}){return {center:'Center A',operator:'Operator A',sn:'SYN-'+index,rma:'RMA-'+index,source:'synthetic.xlsx',sheet:'InHouse',row:index+2,
 required:PART+' #2',tokens:{parts:{[PART]:2},unparsed:''},date:DATE,
 receipt:age===null?null:new Date(Date.parse(DATE+'T00:00:00Z')-age*86400000).toISOString().slice(0,10),...extra};}

test('summary exports actual parallel recipients, a single total-order instruction and nullable evidence',()=>{
 const row=member({avg:null,target:null,poOrdered:null,proposed:null});
 const tasks=[task(row,'CENTER','ORDER',{text:'확인된 수리용 PO 4개 필요 · 보유분·총 추가 PO 미계산'}),
  task(row,'INDIA','SUPPLY',{text:'기존 PO 2개 공급 일정·출고 여부 확인',scheduleNote:'ETD 미정'}),
  task(row,'HQ','HQ_SUPPLY',{text:'법인 요청·기존 주문 기준 자재 확보 검토',quantity:null})];
 const output=Share.summary({groups:[{part:PART,members:[row]}],tasks,nameFor:()=>'<raw name>'});
 const record=objectRows(output)[0];
 assert.equal(output.taskCount,3);assert.equal(output.partCount,1);assert.equal(output.columns.length,16);
 assert.equal(record.recipients,'수리센터 / 법인 / 본사');assert.match(record.action,/ETD 미정/);
 assert.equal(record.ordered,null);assert.equal(record.avg,null);assert.equal(record.totalRequired,null);assert.equal(record.proposed,null);
 assert.equal(record.name,'<raw name>');assert.equal(output.columns.find(c=>c.key==='name').raw,true);
 const hq=objectRows(Share.summary({groups:[{part:PART,members:[row]}],tasks,recipient:'HQ'}));
 assert.equal(hq.length,1);assert.equal(hq[0].recipients,'본사');assert.doesNotMatch(hq[0].action,/추가 PO|수리용 PO/);
});

test('summary preserves other-center tasks with their own evidence and filters tasks by recipient, not owner',()=>{
 const a=member(),b=member({center:'Center B',stock:3,needed:0,target:8,proposed:2,open:3});
 const tasks=[task(a),task(a,'INDIA','SUPPLY',{text:'기존 PO 공급 확인'}),task(b,'HQ','HQ_SUPPLY',{text:'본사 확보 검토'}),
  task(member({part:OTHER}),'HQ','HQ_SUPPLY')];
 const groups=[{part:PART,members:[a]}],all=Share.summary({groups,tasks});
 assert.equal(all.taskCount,3);assert.equal(all.partCount,1);assert.equal(all.rows.length,2);
 const rows=objectRows(all);assert.equal(rows[1].center,'Center B');assert.equal(rows[1].stock,3);assert.equal(rows[1].india,null);
 assert.doesNotMatch(rows[0].action,/본사 확보 검토/);assert.match(rows[1].action,/본사 확보 검토/);
 const hq=objectRows(Share.summary({groups,tasks,recipient:'HQ'}));assert.equal(hq.length,1);assert.equal(hq[0].center,'Center B');assert.equal(hq[0].india,8);
 assert.equal(Share.summary({groups,tasks,recipient:'MISSING'}).rows.length,0);
});

test('common long-lead review appears once and never acquires an invented center PO quantity',()=>{
 const a=member(),b=member({center:'Center B'}),common=task({part:PART,center:'공통',india:8,hq:20},'HQ','LT_REVIEW',{
  text:'법인 요청·기존 구매계획 기준 장납자재 확보 검토',quantity:null});
 const output=Share.summary({groups:[{part:PART,members:[a,b]}],tasks:[common,common]});
 const rows=objectRows(output);assert.equal(output.taskCount,1);assert.equal(rows.filter(r=>r.action.includes('장납자재')).length,1);
 assert.match(rows[0].action,/\[공통 · 본사\]/);assert.equal(rows[0].india,8);assert.equal(rows[1].india,null);
 const filtered=Share.summary({groups:[{part:PART,members:[a,b]}],tasks:[common],recipient:'HQ'});
 assert.equal(filtered.rows.length,1);assert.equal(filtered.taskCount,1);
 assert.equal(objectRows(filtered)[0].center,'공통');assert.equal(objectRows(filtered)[0].stock,null);assert.equal(objectRows(filtered)[0].proposed,null);
 const noMember=objectRows(Share.summary({groups:[{part:PART,members:[]}],tasks:[common]}))[0];
 assert.equal(noMember.center,'공통');assert.equal(noMember.stock,null);assert.equal(noMember.proposed,null);assert.equal(noMember.hq,20);
});

test('projection does not mutate inputs, round calculation values or remove no-task rows in all scope',()=>{
 const row=member({avg:0.03,needed:4,target:1,proposed:5}),groups=[{part:PART,members:[row]}],tasks=[];
 freeze(groups);freeze(tasks);const before=JSON.stringify({groups,tasks});
 const output=Share.summary({groups,tasks});const record=objectRows(output)[0];
 assert.equal(record.avg,1);assert.equal(record.totalRequired,5);assert.equal(record.proposed,5);
 assert.equal(record.action,'');assert.equal(output.taskCount,0);assert.equal(output.rows.length,1);
 assert.equal(JSON.stringify({groups,tasks}),before);assert.equal(row.avg,0.03);
});

test('summary carries upstream source dates without substituting report or center dates for unknown India stock date',()=>{
 const row=member(),t=task(row,'HQ','HQ_SUPPLY',{sourceDates:{stock:'2024-09-20',india:null,hq:'2024-09-19'}});
 const output=Share.summary({groups:[{part:PART,members:[row]}],tasks:[t],sourceDates:{india:'2024-09-18',hq:'2024-09-18'}});
 const record=objectRows(output)[0];assert.match(record.sourceDates,/센터 재고: 2024-09-20/);assert.match(record.sourceDates,/법인 재고: 미확인/);
 assert.match(record.sourceDates,/본사 재고: 2024-09-19/);assert.equal(output.columns.find(c=>c.key==='proposed').label,'센터 추가 PO 필요수');
});

test('follow-up output retains one action per row and never presents task reference quantity as another order',()=>{
 const row=member({needed:4,target:2,proposed:6}),tasks=[task(row,'CENTER','ORDER',{text:'추가 PO 총 6개 필요',quantity:6}),
  task(row,'INDIA','SUPPLY',{text:'법인 보유분의 센터 공급 검토',quantity:4,scheduleNote:'ETD 미정'}),
  task(row,'HQ','HQ_SUPPLY',{text:'법인 요청·기존 주문 기준 자재 확보 검토',quantity:null})];
 const output=Share.followups({tasks});assert.equal(output.taskCount,3);assert.equal(output.partCount,1);assert.equal(output.rows.length,3);
 assert.equal(output.columns.some(c=>c.key==='quantity'),false);
 assert.match(objectRows(output)[0].action,/총 6개/);assert.doesNotMatch(objectRows(output)[1].action,/4개.*발주/);
 assert.match(objectRows(output)[1].action,/ETD 미정/);assert.match(objectRows(output)[0].sourceDates,/법인 재고: 미확인/);
 assert.equal(Share.followups({tasks,recipient:'HQ'}).rows.length,1);
});

test('WIP product request table is one row per product and preserves raw multi-part and unresolved requirements',()=>{
 const input=Tat.evaluate([
  waiting(46,1,{sheet:'FAN-Inhouse',required:PART+' #2, '+OTHER+' #3',tokens:{parts:{[PART]:2,[OTHER]:3},unparsed:''}}),
  waiting(20,2,{required:'<img src=x> #?',tokens:{parts:{},unparsed:'<img src=x> #?'}}),
  waiting(null,3,{required:PART,tokens:{parts:{[PART]:1},unparsed:''}})
 ]).rows;freeze(input);
 const output=Share.wipProducts({rows:input}),rows=objectRows(output);
 assert.equal(output.productCount,3);assert.equal(output.rows.length,3);assert.equal(output.partCount,2);assert.equal(output.unresolvedProducts,1);
 assert.equal(rows[0].required,PART+' × 2 / '+OTHER+' × 3');assert.equal(rows[0].category,'FAN');
 assert.equal(rows[1].required,'');assert.equal(rows[1].rawRequired,'<img src=x> #?');assert.equal(rows[1].unparsed,'<img src=x> #?');
 assert.equal(rows[1].source,'synthetic.xlsx');assert.equal(rows[1].row,4);assert.equal(rows[1].check,'필요 부품 확인 필요');
 assert.equal(rows[2].age,null);assert.equal(rows[2].receipt,null);assert.equal(rows[2].sourceDate,DATE);
 for(const key of ['sn','rma','fert','required','rawRequired','unparsed','source','sheet'])assert.equal(output.columns.find(c=>c.key===key).raw,true);
});

test('WIP part quantities partition 0-30 and other disjoint ages without inflating the overdue subtotal',()=>{
 const ages=[0,30,31,45,46,90,91,180,181,null],input=Tat.evaluate(ages.map((age,index)=>waiting(age,index))).rows;
 input.push(...Tat.evaluate([waiting(80,50,{tokens:{parts:{},unparsed:'unclear'},required:'unclear'})]).rows);
 const output=Share.wipParts({rows:input}),row=objectRows(output)[0];
 assert.equal(output.productCount,11);assert.equal(output.partCount,1);assert.equal(output.unitCount,20);
 assert.equal(output.unresolvedProducts,1);assert.equal(output.quantityComplete,false);
 assert.deepEqual([row.days0_30,row.days31_45,row.days46_90,row.days91_180,row.days181plus,row.unknownAge],[4,4,4,4,2,2]);
 assert.equal(row.overdue,10);assert.equal(row.quantity,20);assert.equal(row.sourceDates,DATE);
 assert.equal(row.days46_90+row.days91_180+row.days181plus,row.overdue);
 assert.equal(row.days0_30+row.days31_45+row.days46_90+row.days91_180+row.days181plus+row.unknownAge,row.quantity);
 assert.equal(output.columns.find(c=>c.key==='quantity').unit,'pieces');
});

test('WIP builders respect caller scope and empty projections retain usable headers',()=>{
 const input=Tat.evaluate([waiting(46,1),waiting(20,2,{center:'Center B',operator:'Vi'})]).rows;
 const chosen=input.filter(r=>r.center==='Center B');const parts=Share.wipParts({rows:chosen}),products=Share.wipProducts({rows:chosen});
 assert.equal(parts.rows.length,1);assert.equal(parts.productCount,1);assert.equal(objectRows(parts)[0].operator,'Vodafone Idea');
 assert.equal(parts.columns.some(c=>c.key==='unknownAge'),false);assert.equal(products.rows.length,1);
 for(const output of [Share.summary(),Share.followups(),Share.wipParts(),Share.wipProducts()]){
  assert.equal(output.rows.length,0);assert.equal(output.partCount,0);assert.ok(output.headers.length>0);
  assert.deepEqual(output.headers,output.columns.map(c=>c.label));
 }
});
