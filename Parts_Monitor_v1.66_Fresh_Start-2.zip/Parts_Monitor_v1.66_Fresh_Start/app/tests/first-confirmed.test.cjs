'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),os=require('node:os');
const C=require('../src/core.js'),R=require('../src/reporting.js'),Trace=require('../src/wip-trace.js'),First=require('../src/first-confirmed.js');
const {createStore}=require('../server/store.cjs'),{createUpdateService}=require('../server/update-service.cjs'),{createViewService}=require('../server/view-service.cjs');
const PART='1205-003915';
const row=(extra={})=>({key:'SN-1|RMA-1',sn:'SN-1',rma:'RMA-1',receipt:'2026-08-01',status:'Waiting for Component',required:PART,tokens:{parts:{[PART]:1},unparsed:''},sheet:'InHouse',row:2,...extra});
const wip=(date,rows=[row()])=>({type:'wip',center:'Flex',operator:'Jio',date,file:'WIP-'+date+'.xlsx',sheet:'InHouse',rows:rows.filter(r=>/Waiting/.test(r.status)),statuses:Object.fromEntries(rows.map(r=>[r.key,r.status])),duplicates:[],wipImportComplete:true});
function state(){let s=R.applySources(C.empty(),[wip('2026-09-21')],'2026-09-21');return R.applySources(s,[wip('2026-10-12')],'2026-10-12');}
function setup(t){const dir=fs.mkdtempSync(path.join(os.tmpdir(),'parts-first-confirmed-'));t.after(()=>fs.rmSync(dir,{recursive:true,force:true}));const store=createStore({dataDir:dir,seedState:state()}),service=createUpdateService({store});return {dir,store,service};}
const entry=s=>Trace.evaluate(s).entries[0];
test('manual first confirmation changes observation display only, preserving automatic evidence, quantities and receipt TAT',()=>{
 const s=state(),original=entry(s),key=original.key,before=JSON.stringify(s),record={date:'2026-09-03',note:'Old weekly report',updatedAt:'2026-10-22T00:00:00.000Z'};
 const result=entry({...s,manualFirstConfirmed:{[key]:record}});
 assert.equal(original.receipt,'2026-08-01');assert.equal(result.firstSeenDate,'2026-09-21');assert.equal(result.effectiveFirstSeenDate,'2026-09-03');assert.equal(result.effectiveFirstSeenAgeDays,33);
 assert.equal(result.firstConfirmedSource,'manual');assert.equal(result.firstConfirmedConflict,false);assert.equal(result.manualFirstConfirmedNote,'Old weekly report');
 assert.equal(result.currentAgeDays,original.currentAgeDays);assert.equal(result.quantity,original.quantity);assert.equal(result.actualNeedDate,null);assert.equal(result.actualArrivalDate,null);assert.equal(JSON.stringify(s),before);
});
test('later manual date retains input and clearly flags earlier automatic evidence',()=>{
 const s=state(),key=entry(s).key,result=entry({...s,manualFirstConfirmed:{[key]:{date:'2026-10-01',note:''}}});
 assert.equal(result.effectiveFirstSeenDate,'2026-10-01');assert.equal(result.firstSeenDate,'2026-09-21');assert.equal(result.firstConfirmedConflict,true);assert.deepEqual(result.firstConfirmedIssues,['EARLIER_AUTOMATIC_OBSERVATION']);
});
test('saved date is not reused before an explicit newer waiting episode or outside corrected receipt bounds',()=>{
 let s=state();const key=entry(s).key;s.manualFirstConfirmed={[key]:{date:'2026-09-03',note:''}};
 s=R.applySources(s,[wip('2026-10-19',[row({status:'Under Repair'})])],'2026-10-19');s=R.applySources(s,[wip('2026-10-26')],'2026-10-26');
 const result=entry(s);assert.equal(result.manualFirstConfirmedDate,'2026-09-03');assert.equal(result.firstConfirmedSource,'automatic');assert.equal(result.effectiveFirstSeenDate,'2026-10-26');assert(result.firstConfirmedIssues.includes('BEFORE_CONFIRMED_EPISODE_BOUNDARY'));
 const corrected=First.decorate({...entry(state()),receipt:'2026-09-10'},{[key]:{date:'2026-09-03'}});assert(corrected.firstConfirmedIssues.includes('BEFORE_RECEIPT'));assert.equal(corrected.firstConfirmedSource,'automatic');
});
test('manual identities keep center, operator, RMA and part separate and refuse anonymous rows',()=>{
 const r={...row(),center:'Flex',operator:'Jio'},key=First.identityKey(r,PART);assert.equal(key,Trace.rowKey(r,PART));
 for(const change of [{center:'CTDI'},{operator:'Airtel',center:'CTDI'},{rma:'OTHER'},{sn:'OTHER'}])assert.notEqual(First.identityKey({...r,...change},PART),key);
 assert.notEqual(First.identityKey(r,'1205-003916'),key);assert.equal(First.identityKey({center:'Flex',operator:'Jio',source:'x',row:2},PART),null);
});
test('save, restart and clear preserve source state and restore the automatic date',t=>{
 const {dir,store,service}=setup(t),before=store.read().state,key=entry(before).key;
 service.update({operation:'firstConfirmed',baseRevision:0,changes:[{key,date:'2026-09-03',note:'Checked old WIP'}]});
 const saved=store.read().state;assert.equal(saved.manualFirstConfirmed[key].date,'2026-09-03');assert(saved.manualFirstConfirmed[key].updatedAt);assert.deepEqual(saved.sources,before.sources);assert.deepEqual(saved.reportingWeeks,before.reportingWeeks);assert.deepEqual(saved.settings,before.settings);
 const restart=createStore({dataDir:dir}),restartedService=createUpdateService({store:restart});assert.equal(entry(restart.read().state).effectiveFirstSeenDate,'2026-09-03');
 restartedService.update({operation:'firstConfirmed',baseRevision:1,changes:[{key,date:null}]});assert.equal(entry(restart.read().state).effectiveFirstSeenDate,'2026-09-21');assert.equal(entry(restart.read().state).firstConfirmedSource,'automatic');assert.equal(restart.listCommits()[0].operation,'firstConfirmed');
});
test('invalid dates, identity and stale revision fail without partially saving a batch',t=>{
 const {store,service}=setup(t),key=entry(store.read().state).key;
 for(const date of ['2026-07-31','2026-10-13','2026-02-30','not-a-date'])assert.throws(()=>service.update({operation:'firstConfirmed',baseRevision:0,changes:[{key,date}]}),e=>e.status===422);
 assert.throws(()=>service.update({operation:'firstConfirmed',baseRevision:0,changes:[{key,date:'2026-09-03'},{key:'fabricated',date:'2026-09-04'}]}),e=>e.status===422);
 assert.equal(store.status().revision,0);assert.equal(store.read().state.manualFirstConfirmed,undefined);
 service.update({operation:'firstConfirmed',baseRevision:0,changes:[{key,date:'2026-09-03'}]});assert.throws(()=>service.update({operation:'firstConfirmed',baseRevision:0,changes:[{key,date:null}]}),e=>e.status===409);
});
test('record map validation rejects malformed restored metadata, and notes cannot bypass date validation',t=>{
 const {store,service}=setup(t),key=entry(store.read().state).key;
 assert.equal(First.validMap(undefined),true);assert.equal(First.validMap({[key]:{date:'2026-02-30'}}),false);assert.equal(First.validMap([]),false);
 assert.throws(()=>service.update({operation:'notes',baseRevision:0,patch:{manualFirstConfirmed:{[key]:{date:'2026-09-03'}}}}),e=>e.status===400);
 assert.throws(()=>store.saveMetadata({baseRevision:0,patch:{manualFirstConfirmed:{[key]:{date:'bad'}}}}),e=>e.code==='INVALID_FIRST_CONFIRMED');
});
test('historical report does not present a future manual date as an observation known at that WIP date',()=>{
 const s=state(),key=entry(s).key;s.manualFirstConfirmed={[key]:{date:'2026-10-01',note:''}};
 const result=Trace.evaluate(s,{reportId:'2026-09-21',asof:'2026-09-21'}).entries[0];assert.equal(result.effectiveFirstSeenDate,'2026-09-21');assert(result.firstConfirmedIssues.includes('AFTER_WIP_DATE'));assert.equal(result.manualFirstConfirmedDate,'2026-10-01');
});
test('manual save invalidates trace and view content keys but keeps weekly quantities cached',t=>{
 const {store,service}=setup(t),views=createViewService({store}),before=views.getView(),stats=views.diagnostics(),key=entry(store.read().state).key;
 service.update({operation:'firstConfirmed',baseRevision:0,changes:[{key,date:'2026-09-03',note:'Verified'}]});const after=views.getView(),next=views.diagnostics();
 assert.equal(next.traceBuilds,stats.traceBuilds+1);assert.equal(next.viewBuilds,stats.viewBuilds+1);assert.equal(next.weekBuilds,stats.weekBuilds);assert.deepEqual(after.rows,before.rows);assert.deepEqual(after.metricsByCenter,before.metricsByCenter);assert.deepEqual(after.trend,before.trend);
 // Summary projection is wired by the parent integration task.
 assert.equal(after.revision,before.revision+1);
});
