const test=require('node:test');
const assert=require('node:assert/strict');
const C=require('../src/core.js');
const R=require('../src/reporting.js');
const P=require('../src/pipeline.js');
const U=require('../src/upload-panel.js');
const source=(type,date,file,extra={})=>({type,date,dateLabel:date,file,center:type==='india'?'India':type==='hq'?'HQ':'Flex',operator:type==='wip'?'Jio':null,sheet:'Sheet1',rows:[],...extra});
const stateWith=(sources,date='2026-10-05')=>R.applySources(C.empty(),sources,date);

test('cancel one physical workbook targets all its source types and not another archive with the same filename',()=>{
 const staged=[source('dashboard','2026-10-12','combined.xlsx',{archiveName:'a.zip',importPath:'a.zip/folder/combined.xlsx'}),source('po','2026-10-12','combined.xlsx',{archiveName:'a.zip',importPath:'a.zip/folder/combined.xlsx'}),source('dashboard','2026-10-12','combined.xlsx',{archiveName:'b.zip',importPath:'b.zip/combined.xlsx',center:'CTDI'})];
 assert.deepEqual(U.stagedFileIndices(staged,U.fileKey(staged[0])),[0,1]);
 const state=stateWith(staged,'2026-10-12');
 assert.equal(U.appliedFileSourceIds(state,'2026-10-12',U.fileKey(staged[0])).length,2);
 assert.equal(U.appliedFileSourceIds(state,'2026-10-12',U.fileKey(staged[2])).length,1);
});

test('a corrupt upload keeps the previous source visible and never becomes zero inventory',()=>{
 const state=stateWith([source('india','2026-10-05','previous-stock.xlsx')]);
 const issues=[{file:'broken-stock.xlsx',message:'Invalid workbook',excluded:true}];
 const model=U.buildModel({state,reportDate:'2026-10-12',issues});
 const india=model.slots.find(row=>row.key==='india');
 assert.equal(india.source.file,'previous-stock.xlsx');assert.equal(india.reference,true);
 assert.equal(model.counts.invalid,1);assert.equal(model.canApply,false);
 const html=U.render({state,reportDate:'2026-10-12',issues});
 assert.match(html,/previous-stock\.xlsx/);assert.match(html,/broken-stock\.xlsx/);assert.match(html,/이전 정상 자료가 있으면 유지/);
 assert.doesNotMatch(html,/재고 0|0개 재고/);
});

test('cancelling a staged file retains other active file indices for the preview and apply button',()=>{
 const state=stateWith([source('hq','2026-10-05','hq.xlsx')]);
 const staged=[source('dashboard','2026-10-12','flex.xlsx'),source('india','2026-10-12','india.xlsx')];
 const stageExcluded=new Set([0]),review=P.evaluate(state,[staged[1]],'2026-10-12');
 const model=U.buildModel({state,reportDate:'2026-10-12',staged,stageExcluded,review});
 assert.equal(model.stagedFiles[0].status,'cancelled');assert.equal(model.stagedFiles[1].status,'ready');
 assert.equal(model.counts.ready,1);assert.equal(model.canApply,true);
 assert.match(U.render({state,reportDate:'2026-10-12',staged,stageExcluded,review}),/취소 되돌리기/);
});

test('week-assigned stock shows the week without inventing a measured day, while undated WIP requests its date',()=>{
 const stock=source('india',null,'WK41.xlsx',{reportWeek:'2026-10-05',datePrecision:'week'});
 const formatted=U.dates(stock);assert.equal(formatted.actual,null);assert.equal(formatted.assigned,'2026-10-05');assert.equal(formatted.label,'10/5주');assert.match(formatted.note,/실제 기준일 미확인/);
 const wip=source('wip',null,'unknown-wip.xlsb'),state=C.empty(),review=P.evaluate(state,[wip],'2026-10-12');
 const html=U.render({state,reportDate:'2026-10-12',staged:[wip],review});
 assert.match(html,/data-source-date="0"/);assert.match(html,/실제 WIP 기준일 입력 필요/);
 assert.equal(U.buildModel({state,reportDate:'2026-10-12',staged:[wip],review}).canApply,false);
});

test('selected-week applied-file list never targets a newer independent upload',()=>{
 let state=stateWith([source('india','2026-10-05','old.xlsx')]);
 state=R.applySources(state,[source('india','2026-10-12','new.xlsx')],'2026-10-12');
 const old=U.buildModel({state,reportDate:'2026-10-05'}),latest=U.buildModel({state,reportDate:'2026-10-12'});
 assert.deepEqual(old.files.map(file=>file.name),['old.xlsx']);assert.deepEqual(latest.files.map(file=>file.name),['new.xlsx']);
 assert.equal(U.appliedFileSourceIds(state,'2026-10-05',latest.files[0].key).length,0);
 assert.match(U.cancellationMessage(old,old.files[0].key),/이후에 별도로 올린 자료와 보관 원본은 유지/);
});

test('English file controls remain operational and filenames are HTML-escaped',()=>{
 const staged=[source('india','2026-10-12','bad<name>.xlsx')],state=C.empty(),review=P.evaluate(state,staged,'2026-10-12');
 const html=U.render({state,reportDate:'2026-10-12',staged,review,language:'en'});
 assert.match(html,/India stock/);assert.match(html,/id="apply-import"[^>]*>Run</);assert.match(html,/accept="\.xlsx,\.xls,\.xlsb,\.zip"/);
 assert.match(html,/data-upload-cancel-staged=/);assert.match(html,/bad&lt;name&gt;\.xlsx/);assert.doesNotMatch(html,/bad<name>/);
 assert.equal((html.match(/id="apply-import"/g)||[]).length,1);
 assert.match(html,/id="server-dropzone"/);assert.match(html,/id="report-date"/);
});

function compactFixture(){
 let state=C.empty();
 for(const day of ['2026-09-27','2026-09-28','2026-10-06','2026-10-12']){
  const india=day==='2026-10-06'?C.assignReportWeek(source('india',null,'WK41.xlsx'),'2026-10-05'):source('india',day,'India-'+day+'.xlsx');
  const incoming=[source('dashboard',day,'Flex-'+day+'.xlsx')];if(day!=='2026-10-12')incoming.push(india);
  state=R.applySources(state,incoming,day);
 }
 state.importIssuesByWeek={'2026-10-12':[{file:'WK42.xlsx',message:'File is corrupt',excluded:true}]};
 const entries=[...state.sources,...Object.values(state.reportingSourceArchive||{})],index=new Map(entries.map(item=>{
  const {rows,...meta}=item;return [JSON.stringify([item.id,item.reportingRevision]),{key:item.id,revision:item.reportingRevision,hash:'fixture',meta:{...meta,rowCount:rows.length}}];
 }));
 const {sources,reportingSourceArchive,...metadata}=state;
 return {revision:4,state:metadata,sourceIndex:[...index.values()],currentSourceRefs:sources.map(item=>({key:item.id,revision:item.reportingRevision})),archiveSourceRefs:Object.values(reportingSourceArchive||{}).map(item=>({key:item.id,revision:item.reportingRevision}))};
}

test('metadata-only manifest keeps all four weeks selectable without raw workbook rows',()=>{
 const manifest=compactFixture(),model=U.buildModel({manifest}),html=U.render({manifest});
 assert.equal(model.reportDate,'2026-10-12');assert.equal(model.mode,'browse');assert.equal(model.reports.length,4);
 assert.equal(model.nextDate,'2026-10-19');assert.equal(model.state.sources.some(item=>'rows' in item),false);
 for(const day of ['2026-09-27','2026-09-28','2026-10-06','2026-10-12'])assert.match(html,new RegExp('data-upload-week="'+day+'"'));
 assert.match(html,/data-upload-new-week="2026-10-19"/);assert.match(html,/WK41.xlsx/);assert.match(html,/WK42.xlsx/);assert.match(html,/이전 주차 참고/);
 assert.doesNotMatch(html,/id="server-dropzone"/,'browse view should show saved files, not an already-open upload form');
});

test('each metadata-only historical week resolves its original files and keeps invalid-file notices scoped',()=>{
 const manifest=compactFixture();
 for(const [day,filename] of [['2026-09-27','India-2026-09-27.xlsx'],['2026-09-28','India-2026-09-28.xlsx'],['2026-10-06','WK41.xlsx'],['2026-10-12','WK41.xlsx']]){
  const model=U.buildModel({manifest,reportDate:day}),india=model.slots.find(item=>item.key==='india');
  assert.equal(india.source.file,filename);assert.equal(india.reference,day==='2026-10-12');
  assert.equal(model.savedIssues.length,day==='2026-10-12'?1:0);
  assert.equal(U.appliedFileSourceIds(model.state,day,india.fileKey).length,1);
 }
});

test('new-week workflow defaults to the next Monday and preserves reference files until new sources apply',()=>{
 const manifest=compactFixture(),model=U.buildModel({manifest,mode:'new'}),html=U.render({manifest,mode:'new'});
 assert.equal(model.reportDate,'2026-10-19');assert.equal(model.report,null);assert.equal(model.reports.length,4);
 assert.equal(model.slots.find(item=>item.key==='india').source.file,'WK41.xlsx');
 assert.match(html,/id="report-date" type="date" value="2026-10-19"/);assert.match(html,/id="files"/);assert.match(html,/id="apply-import" disabled/);
 assert.match(html,/data-upload-browse-week="2026-10-12"/);
});

test('metadata cancellation does not fabricate raw rows or a replacement preview',()=>{
 const model=U.buildModel({manifest:compactFixture()}),before=JSON.stringify(model.state),file=model.files[0];
 const message=U.cancellationMessage(model,file.key);
 assert.match(message,/이전 정상 자료가 있으면/);assert.doesNotMatch(message,/취소 후 적용:/);
 assert.equal(JSON.stringify(model.state),before);assert.equal(model.state.sources.some(item=>'rows' in item),false);
});

test('persisted weekly diagnostics show damaged WK42 and its fallback only in the affected week',()=>{
 const manifest=compactFixture();delete manifest.state.importIssuesByWeek;
 manifest.state.importDiagnostics={weeks:[{reportWeek:'2026-10-05',excluded:[],resolved:[{file:'WK41.xlsx',reason:'DATE_UNCONFIRMED'}]},{reportWeek:'2026-10-12',excluded:[{file:'WK42.xlsx',reason:'INVALID_SOURCE_FILE',status:'open',fallback:{file:'WK41.xlsx',date:null,reportWeek:'2026-10-05',datePrecision:'week'}}]}]};
 const latest=U.render({manifest}),prior=U.render({manifest,reportDate:'2026-10-06'});
 assert.match(latest,/WK42.xlsx/);assert.match(latest,/손상되어 읽을 수 없는 파일/);assert.match(latest,/대신 사용: WK41.xlsx \(10\/5주\)/);
 assert.doesNotMatch(prior,/WK42.xlsx|DATE_UNCONFIRMED/);
});

test('metadata source resolution honors archived revision references for same-date corrections',()=>{
 const old=source('india','2026-10-05','original.xlsx'),corrected=source('india','2026-10-05','corrected.xlsx');
 let state=stateWith([old],'2026-10-05');state=R.applySources(state,[corrected],'2026-10-12');
 const metadata={...state,_metadataOnly:true,sources:state.sources.map(({rows,...rest})=>({...rest,rowCount:rows.length})),reportingSourceArchive:Object.fromEntries(Object.entries(state.reportingSourceArchive||{}).map(([key,{rows,...rest}])=>[key,{...rest,rowCount:rows.length}]))};
 assert.equal(U.buildModel({state:metadata,reportDate:'2026-10-05'}).slots.find(item=>item.key==='india').source.file,'original.xlsx');
 assert.equal(U.buildModel({state:metadata,reportDate:'2026-10-12'}).slots.find(item=>item.key==='india').source.file,'corrected.xlsx');
});

test('metadata manifest never reselects a cancelled revision retained among old source references',()=>{
 const manifest=compactFixture(),latest=manifest.state.reportingWeeks.find(item=>item.id==='2026-10-12'),wk41=manifest.sourceIndex.find(item=>item.meta.file==='WK41.xlsx'),fallback=manifest.sourceIndex.find(item=>item.meta.file==='India-2026-09-28.xlsx');
 latest.excludedSourceRefs=[{key:wk41.key,revision:wk41.revision}];latest.sourceRefs.push({key:fallback.key,revision:fallback.revision});
 const model=U.buildModel({manifest}),india=model.slots.find(item=>item.key==='india');
 assert.equal(india.source.file,'India-2026-09-28.xlsx');assert.equal(india.reference,true);
 assert.equal(model.files.some(item=>item.name==='WK41.xlsx'),false);
 assert.equal(U.appliedFileSourceIds(model.state,model.reportDate,U.fileKey(wk41.meta)).length,0);
});
