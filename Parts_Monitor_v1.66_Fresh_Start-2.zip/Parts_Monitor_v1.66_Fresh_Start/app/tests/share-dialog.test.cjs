'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const D=require('../src/share-dialog.js'),I=require('../src/i18n.js');
require('../src/i18n-extra.js')(I);require('../src/share-i18n.js')(I);
function table(){return {columns:[{key:'part',label:'부품 코드',raw:true},{key:'action',label:'필요 조치'},{key:'qty',label:'센터 재고'}],rows:[['명판','추가 PO 총 3개 필요',0],['TEST-000001','기존 PO 2개 입고 대기 (ETD 미정)',null]],notes:['빈칸은 0이 아닙니다. 미확인·해당 없음 또는 반복 생략 항목입니다.']}}
test('explicit export language preserves raw fields, zero/null distinction and application language',()=>{
 I.setLanguage('ko');const source=table(),before=JSON.stringify(source),model=D.normalize(source,{language:'en',translator:I,title:'조직별 필요 조치',context:[{label:'검색 조건',value:'법인 직접 메모',raw:true}]});
 assert.equal(I.getLanguage(),'ko');assert.equal(JSON.stringify(source),before);assert.equal(model.rows[0][0],'명판');assert.equal(model.rows[0][2],0);assert.equal(model.rows[1][2],'');
 assert.doesNotMatch(model.rows[0][1],/[가-힣]/);assert.match(model.context[0],/법인 직접 메모/);assert.doesNotMatch(model.notes.join(''),/[가-힣]/);
});
test('CSV and copied tables retain all rows while preview may be limited',()=>{
 const source=table();source.rows=Array.from({length:37},(_,i)=>['TEST-'+i,'추가 PO 총 3개 필요',i]);
 const model=D.normalize(source,{language:'en',translator:I,reportDate:'2024-09-30',context:['Flex']});
 assert.equal((D.tableHTML(model,20).match(/<tr/g)||[]).length,21);assert.match(D.csv(model),/TEST-36/);assert.match(D.tsv(model),/TEST-36/);assert.match(D.html(model),/TEST-36/);
 assert.match(D.csv(model),/Report date/);assert.match(D.csv(model),/Selected scope/);assert.match(D.csv(model),/Notes/);assert.match(D.csv(model),/Blank cells are not zero/);
});
test('raw spreadsheet-like input remains text and markup is escaped',()=>{
 const model=D.normalize({columns:[{label:'원문',raw:true}],rows:[[' \t=SUM(1,2)'],['@TEST'],['<img src=x onerror=alert(1)>']]},{language:'ko'});
 assert.match(D.csv(model),/"' \t=SUM/);assert.match(D.tsv(model),/'@TEST/);assert.doesNotMatch(D.html(model),/<img/);assert.match(D.html(model),/&lt;img/);assert.equal(D.safeCell(0),'0');assert.equal(D.safeCell(null),'');
});
test('unresolved-part notes and source date labels translate without replacing the actual dates',()=>{
 assert.equal(I.text('필요 부품 확인 필요: 3대','en'),'Products with unresolved required parts: 3');
 const text=I.text('센터 재고: 2032-01-02 · 법인 재고: 미확인 · 본사 재고: 2031-12-31','en');assert.doesNotMatch(text,/[가-힣]/);assert.match(text,/2032-01-02/);assert.match(text,/2031-12-31/);
});
