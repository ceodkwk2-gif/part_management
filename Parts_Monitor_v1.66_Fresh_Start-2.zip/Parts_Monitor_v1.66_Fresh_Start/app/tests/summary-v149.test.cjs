const test=require('node:test');
const assert=require('node:assert/strict');
const O=require('../src/overview.js');
const row=(part,center='Flex',changes={})=>({id:center+'|'+part,part,center,name:'Cooling fan',stock:2,india:5,hq:20,avg:.5,needed:3,shortage:1,proposed:2,open:0,poOrdered:0,currentAssessed:true,orderAssessed:true,waitingCovered:false,...changes});
function fixture(){
 const rows=[row('A'),row('A','CTDI'),row('B','Flex',{needed:0,shortage:0,stock:0,proposed:1}),row('C','Flex',{needed:0,shortage:0,stock:0,proposed:0,open:1,poOrdered:1,waitingCovered:true})];
 return {week:'2026-10-12',asof:'2026-10-12',settings:{targetMonths:1},metricsByCenter:{'전체':{registeredKinds:3},Flex:{registeredKinds:3},CTDI:{registeredKinds:1}},rows,tasks:rows.filter(r=>r.proposed>0).map(r=>({id:r.id+'|ORDER',rowId:r.id,recipient:'CENTER',kind:'ORDER',quantity:r.proposed,textKo:'발주',textEn:'Order'})),
 products:[{id:'F1',center:'Flex',operator:'Jio',receipt:'2026-07-04',date:'2026-10-12',age:100,fan:false,parts:[{part:'A',quantity:2,firstDate:'2026-09-28',firstAge:86,baseline:true}]},{id:'C1',center:'CTDI',operator:'Vi',receipt:'2026-08-13',date:'2026-10-12',age:60,fan:true,parts:[{part:'A',quantity:1,firstDate:'2026-10-05',firstAge:53}]},{id:'F2',center:'Flex',receipt:'2026-08-28',date:'2026-10-12',age:45,parts:[{part:'B',quantity:1}]}],
 pos:[{center:'Flex',part:'A',po:'CPO-1',poDate:'2026-09-29',pending:5,etd:'2026-10-16'}],
 sourceDates:[{type:'wip',center:'Flex',date:'2026-10-12'},{type:'wip',center:'CTDI',date:'2026-10-12'}],
 trend:['2026-09-21','2026-09-28','2026-10-05','2026-10-12'].map(week=>({week,metricsByCenter:{'전체':{shortageKinds:1,orderKinds:1,waitKinds:1,wip:3,over45:2,over45PartKinds:1,over45RequiredQty:3},Flex:{over45:1,over45PartKinds:1,over45RequiredQty:2},CTDI:{over45:1,over45PartKinds:1,over45RequiredQty:1}}})),
 siel:{asof:'2026-10-19',reportWeek:'2026-10-12',demo:true,rows:[{part:'A',po:'HQPO-1',poDate:'2026-09-30',ordered:9,pending:null,eta:'2026-10-22',stage:'hq-order',docs:[],sourceDate:'2026-10-19'}]}};
}
test('summary directly exposes overdue timeline and stock decision tables, with no popup prerequisite',()=>{
 const h=O.render({data:fixture()});
 assert(h.includes('class="ov-timeline-list"'));assert(h.indexOf('class="ov-timeline-list"')<h.indexOf('class="ov-stock-table"'));
 assert(h.indexOf('class="ov-stock-table"')<h.indexOf('class="ov-secondary-evidence"'));
 for(const field of ['부품대기','센터 → 법인 PO','공용 법인 → 본사 PO','필요 조치','재고 (개)','월평균','현 수리 필요','현재 부족','기발주','미입고','추가 필요','조치 담당 · 할 일'])assert(h.includes(field),field);
 const main=h.split('data-ov-summary-overdue-row="Flex|A"')[1].split('<details class="ov-trace-evidence">')[0];
 assert(main.includes('class="ov-product-history"'));assert(main.includes('class="ov-supply-flow"'));
 assert.match(main,/data-event="observed"><b>09\/28<\/b>[\s\S]*?TAT 86일/);
 assert(h.includes('2026-09-28'));assert(h.includes('2026-09-29'));assert(h.includes('2026-09-30'));assert(h.includes('2026-10-22'));
 assert(h.includes('data-ov-summary-stock-row="Flex|A"'));assert(h.includes('data-ov-summary-stock-row="CTDI|A"'));
});
test('category cards remain exclusive while shared part centers are nested under one code',()=>{
 const d=fixture(),m=O.metrics(d,'ALL'),h=O.render({data:d});
 assert.deepEqual([m.SHORTAGE.parts,m.ORDER.parts,m.WAIT.parts],[1,1,1]);
 assert(h.includes('rowspan="2"'));assert(h.includes('data-ov-part="A" data-ov-row=""'));
 assert.equal((h.match(/data-ov-summary-overdue-row=/g)||[]).length,2);
 assert.equal(O.overdueStats(d,'ALL').products,2);assert.equal(O.overdueStats(d,'ALL').quantity,3);
});
test('all overdue parts stay visible while stock pagination and full exports remain',()=>{
 const d=fixture();d.rows=Array.from({length:7},(_,i)=>row('P'+i));d.tasks=[];d.products=d.rows.map((r,i)=>({id:'W'+i,center:'Flex',age:100-i,parts:[{part:r.part,quantity:1}]}));
 const h1=O.render({data:d,summaryPage:1,overduePage:1,summaryPageSize:3}),h2=O.render({data:d,summaryPage:2,overduePage:2,summaryPageSize:3});
 assert.equal((h1.match(/data-ov-summary-overdue-row=/g)||[]).length,7);assert.equal((h2.match(/data-ov-summary-overdue-row=/g)||[]).length,7);
 for(const r of d.rows){assert(h1.includes('data-ov-summary-overdue-row="'+r.id+'"'));assert(h2.includes('data-ov-summary-overdue-row="'+r.id+'"'));}
 assert.equal((h1.match(/data-ov-summary-stock-row=/g)||[]).length,3);assert.equal((h2.match(/data-ov-summary-stock-row=/g)||[]).length,3);
 assert.equal(O.exportRowIds(d,{kind:'SHORTAGE'}).length,7);assert.equal(O.exportOverdueRowIds(d,{}).length,7);
 assert(!h1.includes('data-ov-overdue-page='));assert(!h2.includes('data-ov-overdue-page='));assert(h1.includes('data-ov-summary-page="2"'));
});
test('center filter scopes both direct tables and combo chart without allocating shared SIEL',()=>{
 const d=fixture(),f=O.render({data:d,center:'Flex'}),c=O.render({data:d,center:'CTDI'});
 assert(!f.includes('data-ov-summary-overdue-row="CTDI|'));assert(!c.includes('data-ov-summary-overdue-row="Flex|'));
 assert(!f.includes('data-ov-bar-center="CTDI"'));assert(!c.includes('data-ov-bar-center="Flex"'));
 assert(f.includes('발주 9개'));assert(c.includes('발주 9개'));
});
test('SIEL order quantities are not represented as pending or physical receipts',()=>{
 const d=fixture(),h=O.render({data:d});
 assert(h.includes('실제 입고·잔량 미확인'));assert(!h.includes('미공급 9'));assert(!h.includes('미입고 9'));
 assert(h.includes('2026-10-19 자료를 2026-10-12주에 적용한 데모'));
 const r={...d.rows[0],open:5};assert.equal(O.supplyStage(d,r,d.pos,'ko').label,'본사 공급 일정 확인');
 d.siel.rows[0].docs=[{delivery:'D1'}];d.siel.rows[0].stage='supply-documents';
 assert.equal(O.supplyStage(d,r,d.pos,'ko').label,'공급 서류 있음');assert.equal(O.supplyStage(d,r,d.pos,'ko').detail,'법인 실제 입고 미확인');
});
test('raw ETD never overrides unmatched PO; validated partial ETD applies only to its quantity',()=>{
 const d=fixture(),r={...d.rows[0],open:8};d.siel.rows=[];
 assert.equal(O.supplyStage(d,r,d.pos,'ko').label,'센터 PO 미입고');
 d.tasks.push({rowId:r.id,kind:'SUPPLY',recipient:'INDIA',poFollowup:{matched:false,plannedQuantity:5,dates:['2026-10-16']}});
 assert.notEqual(O.supplyStage(d,r,d.pos,'ko').label,'법인 출고 예정');
 d.tasks.at(-1).poFollowup={matched:true,plannedQuantity:5,unplannedQuantity:3,dates:['2026-10-16']};
 const stage=O.supplyStage(d,r,d.pos,'ko');assert.equal(stage.label,'법인 출고 예정');assert.equal(stage.partial,true);assert(stage.detail.startsWith('5개'));assert(!stage.detail.startsWith('8개'));
});
test('supply actions preserve validated quantity and joint teams rather than row open total',()=>{
 const d=fixture(),r=d.rows[0];r.open=8;
 const text='기존 PO 5개 · 법인 출고 예정 2026-10-16';const joint='기존 PO 3개 입고 대기 (ETD 미정) · 법인·본사 공급 일정 확인';
 const t={rowId:r.id,kind:'SUPPLY',recipient:'INDIA',quantity:8,textKo:text+' / '+joint,textEn:'5 pcs dispatch planned / 3 pcs schedule needed'};
 d.tasks.push(t,{rowId:r.id,kind:'HQ_SUPPLY',recipient:'HQ',textKo:joint,textEn:'3 pcs schedule needed'});
 assert.equal(O.taskText(t,r,'ko'),text+' / '+joint);
 const h=O.render({data:d}),stock=h.split('class="ov-stock-table"')[1].split('</table>')[0];
 assert(stock.includes(text));assert.equal((stock.match(/기존 PO 3개 입고 대기/g)||[]).length,1);assert(!stock.includes('기존 PO 8개 공급 일정'));
 assert.equal((stock.match(/센터 · 추가 PO 2개/g)||[]).length,2);
});
test('low-use category count ignores normal other-center row',()=>{
 const d=fixture();d.rows=[row('A','Flex',{lowUsage:false}),row('A','CTDI',{lowUsage:true,shortage:0,needed:0,proposed:0})];
 assert.equal(O.metrics(d,'ALL').SHORTAGE.low,0);d.rows[0].lowUsage=true;assert.equal(O.metrics(d,'ALL').SHORTAGE.low,1);
});
test('first-source observation is not claimed as actual waiting start or a specific PO allocation',()=>{
 const h=O.render({data:fixture()});assert(h.includes('첫 자료부터 대기'));assert(h.includes('실제 대기 시작일 미확인'));assert(h.includes('관련 PO는 제품별 배정이 아닙니다.'));
});
test('summary interactions stay in summary while detail and full exports remain available',()=>{
 let click;const calls=[],container={addEventListener:(type,f)=>{if(type==='click')click=f},removeEventListener(){},contains:()=>true};
 O.bind(container,{onSummaryFilter:x=>calls.push(['filter',x]),onSummaryPage:x=>calls.push(['summary',x]),onOverduePage:x=>calls.push(['overdue',x]),onMail:x=>calls.push(['mail',x])});
 for(const [attribute,key,value] of [['data-ov-summary-filter','ovSummaryFilter','ORDER'],['data-ov-summary-page','ovSummaryPage','2'],['data-ov-overdue-page','ovOverduePage','3'],['data-ov-mail','ovMail','OVERDUE']])click({target:{closest:()=>({dataset:{[key]:value},hasAttribute:x=>x===attribute})}});
 assert.deepEqual(calls,[['filter','ORDER'],['summary',2],['overdue',3],['mail','OVERDUE']]);
});
test('all chart and download hooks survive desktop redesign in both languages',()=>{
 for(const language of ['ko','en']){const h=O.render({data:fixture(),language});for(const chart of ['OVERDUE','ACTIONS','PRODUCTS','AGING'])assert(h.includes('data-ov-chart="'+chart+'"'));for(const kind of ['SUMMARY','OVERDUE','TREND_OVERDUE','TREND_ACTIONS','TREND_PRODUCTS','AGING'])assert(h.includes('data-ov-export="'+kind+'"'));assert(!h.includes('undefined'));assert(!h.includes('NaN'));}
});

test('part pagination keeps every center row of a part together',()=>{const d=fixture();d.rows=[row('A'),row('A','CTDI'),row('B'),row('B','CTDI'),row('C')];d.tasks=[];const h=O.render({data:d,summaryPageSize:1});assert.equal((h.match(/data-ov-summary-stock-row=/g)||[]).length,2);assert(h.includes('data-ov-summary-stock-row="Flex|A"'));assert(h.includes('data-ov-summary-stock-row="CTDI|A"'));assert(!h.includes('data-ov-summary-stock-row="Flex|B"'));assert.equal(O.exportRowIds(d,{kind:'SHORTAGE'}).length,5);});

test('read-only summary report renders every matching row rather than first page',()=>{const d=fixture();d.rows=Array.from({length:8},(_,i)=>row('R'+i));d.tasks=[];d.products=d.rows.map((r,i)=>({id:'W'+i,center:'Flex',age:80,parts:[{part:r.part,quantity:1}]}));const h=O.render({data:d,exportAll:true});assert.equal((h.match(/data-ov-summary-overdue-row=/g)||[]).length,8);assert.equal((h.match(/data-ov-summary-stock-row=/g)||[]).length,8);assert(!h.includes('data-ov-summary-page='));assert(!h.includes('data-ov-overdue-page='));});

test('operator ETA and plan appear directly in both summary sections without changing source facts',()=>{const d=fixture(),before=JSON.stringify(d),h=O.render({data:d,notes:{'Flex|A':{eta:'2026-10-24',plan:'센터에서 일정 재확인'}}});const main=h.split('data-ov-summary-overdue-row="Flex|A"')[1].split('<details class="ov-trace-evidence">')[0],stock=h.split('class="ov-stock-table"')[1].split('</table>')[0];for(const visible of [main,stock]){assert(visible.includes('입력된 센터 입고 예정 2026-10-24'));assert(visible.includes('대책: 센터에서 일정 재확인'));}assert.equal(JSON.stringify(d),before);assert(!h.includes('Confirmed center receipt'));});
