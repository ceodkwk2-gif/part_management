const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm');
const Server=require('../src/server-app.js');
const displayVersion='v'+require('../package.json').version.split('.').slice(0,2).join('.');

function shellFixture(){
 const state={renderOptions:null,detailOptions:null,callbacks:null,filters:[],dialog:null,html:'',fields:new Map(),scrolls:0,jumps:[]},data={asof:'2026-10-12',week:'2026-10-12',rows:[{id:'Flex|A',part:'A',center:'Flex'}],products:[],trend:[],sourceDates:[],manualNotes:{}};
 const doc={documentElement:{},activeElement:null,body:{append(){},appendChild(){}},addEventListener(){},removeEventListener(){}};
 function element(selector,dataset={}){return {dataset,value:'',selectionStart:0,selectionEnd:0,matches:s=>s===selector,focus(opts){this.focusOptions=opts;doc.activeElement=this},setSelectionRange(start,end){this.selectionStart=start;this.selectionEnd=end},scrollIntoView(options){if(selector!=='#ov-stock-work')throw Error('Search must not scroll the page');state.jumps.push({selector,options})},remove(){}}}
 const tabs=['summary','details'].map(tab=>element('',{tab,saTab:tab})),centers=['ALL','Flex','CTDI'].map(center=>element('',{center,saCenter:center}));
 const root={contains:el=>!!el,querySelector:selector=>query(selector),querySelectorAll:selector=>queryAll(selector)};
 Object.defineProperty(root,'innerHTML',{get:()=>state.html,set:value=>{state.html=value;state.fields=new Map();for(const section of ['stock','overdue']){const selector='input[data-ov-summary-search="'+section+'"]',field=element(selector);field.value=state.renderOptions?.[section==='stock'?'summarySearch':'overdueSearch']||'';state.fields.set(selector,field)}}});
 function query(selector){if(selector==='input[data-ov-filter="search"]'){if(!state.fields.has(selector))state.fields.set(selector,element(selector,{ovFilter:'search'}));return state.fields.get(selector)}if(state.fields.has(selector))return state.fields.get(selector);if(selector.startsWith('#')){if(!state.fields.has(selector))state.fields.set(selector,element(selector));return state.fields.get(selector)}return null}
 function queryAll(selector){return /data-(?:sa-)?center/.test(selector)?centers:/data-(?:sa-)?tab/.test(selector)?tabs:[]}
 doc.getElementById=id=>id==='current-data'?{textContent:JSON.stringify(data)}:['root','app'].includes(id)?root:query('#'+id);doc.querySelector=query;doc.querySelectorAll=queryAll;
 const overview={render:opts=>{state.renderOptions=opts;return '<section>SUMMARY</section>'},renderDetails:opts=>{state.detailOptions=opts;return '<section>DETAILS</section>'},bind:(_el,callbacks)=>{state.callbacks=callbacks},exportRowIds:(_data,filters)=>{state.filters.push({...filters});return ['Flex|A']},exportOverdueRowIds:(_data,filters)=>{state.filters.push({...filters});return ['Flex|A']},selectWaitingProducts:()=>[]};
 const model=()=>({title:'test',rows:[],columns:[],notes:[]}),w={document:doc,PartsWorkflow:require('../src/workflow.js'),PartsWorkflowUI:require('../src/workflow-ui.js'),PartsOverview:overview,PartsExampleMail:{buildActionTable:model,buildWaitingTable:model},PartsOverdueMail:{build:model},PartsSummaryDownloads:{buildTable:model},PartsShareDialog:{open:opts=>state.dialog=opts},addEventListener(){},scrollTo(){state.scrolls++}};
 return {state,data,doc,root,w,tabs,centers,field:section=>query('input[data-ov-summary-search="'+section+'"]')};
}
function startCurrent(f){const context={...f.w,window:f.w,document:f.doc,console};vm.runInNewContext(fs.readFileSync(require.resolve('../src/current-view.js'),'utf8'),context);return f.w.PartsCurrentView}
async function startServer(f){f.w.PartsUploadPanel={manifestState:m=>m.state,buildModel:()=>({reportDate:'2026-10-12'})};f.w.PartsUploadFlow={};f.w.PartsServerClient={create:()=>({session:async()=>{},request:async path=>path==='/api/view'?{revision:1,data:f.data}:{revision:1,state:{partFollowups:{},settings:{}}}})};const app=Server.start(f.w);await app.runtime.load();return app}

for(const type of ['saved HTML','server'])test(type+': independent summary searches reset only their own page and retain focus and selection',async()=>{
 const f=shellFixture(),app=type==='server'?await startServer(f):startCurrent(f),original=JSON.stringify(f.data);
 try{
  f.state.callbacks.onSummaryPage(3);f.state.callbacks.onOverduePage(4);
  const old=f.field('stock');old.selectionStart=2;old.selectionEnd=5;f.doc.activeElement=old;
  f.state.callbacks.onSummarySearch({section:'stock',value:'0904-002867'});
  assert.equal(f.state.renderOptions.summarySearch,'0904-002867');assert.equal(f.state.renderOptions.overdueSearch,'');assert.equal(f.state.renderOptions.summaryPage,1);assert.equal(f.state.renderOptions.overduePage,4);
  assert.notEqual(f.doc.activeElement,old);assert.equal(f.doc.activeElement,f.field('stock'));assert.equal(f.doc.activeElement.selectionStart,2);assert.equal(f.doc.activeElement.selectionEnd,5);assert.equal(f.doc.activeElement.focusOptions.preventScroll,true);
  f.state.callbacks.onSummaryPage(2);f.doc.activeElement=f.field('overdue');f.doc.activeElement.selectionStart=1;f.doc.activeElement.selectionEnd=1;
  f.state.callbacks.onSummarySearch({section:'overdue',value:'FAN'});
  assert.equal(f.state.renderOptions.summarySearch,'0904-002867');assert.equal(f.state.renderOptions.overdueSearch,'FAN');assert.equal(f.state.renderOptions.summaryPage,2);assert.equal(f.state.renderOptions.overduePage,1);
  f.doc.activeElement={dataset:{},matches:()=>false};f.state.callbacks.onSummarySearch({section:'overdue',value:''});
  assert.equal(f.state.renderOptions.overdueSearch,'');assert.equal(f.state.renderOptions.summarySearch,'0904-002867');assert.equal(f.doc.activeElement,f.field('overdue'));assert.equal(f.doc.activeElement.selectionStart,0);assert.equal(f.doc.activeElement.focusOptions.preventScroll,true);
  assert(f.state.html.includes('>'+displayVersion+'<'),'shell shows current package major/minor version');assert.match(f.state.html,/SUMMARY/);assert.equal(f.state.detailOptions,null);assert.equal(f.state.scrolls,0);assert.equal(JSON.stringify(f.data),original);
 }finally{app.destroy?.()}
});

for(const type of ['saved HTML','server'])test(type+': summary mail export uses the corresponding search, center, category and recipient, separate from details search',async()=>{
 const f=shellFixture(),app=type==='server'?await startServer(f):startCurrent(f);
 const mail=(kind,recipient)=>{if(type==='server'){app.openMail(kind);f.state.dialog.tables[0].build({recipient,language:'en'})}else app.mailModel(kind,recipient,'en');return f.state.filters.at(-1)};
 try{
  f.state.callbacks.onSummarySearch({section:'stock',value:'0904'});f.state.callbacks.onSummarySearch({section:'overdue',value:'EP31'});
  f.centers.find(e=>e.dataset.center==='Flex').onclick();f.state.callbacks.onSummaryFilter('ORDER');
  assert.deepEqual(mail('ORDER','CENTER'),{center:'Flex',kind:'ORDER',role:'CENTER',poFilter:'ALL',search:'0904'});
  assert.deepEqual(mail('OVERDUE','INDIA_HQ'),{center:'Flex',kind:'OVERDUE',role:'INDIA_HQ',poFilter:'ALL',search:'EP31'});
  f.state.callbacks.onCategory('WAITING');f.state.callbacks.onFilter({search:'DETAIL',role:'HQ',poFilter:'NONE'});
  assert.deepEqual(mail('ORDER','HQ'),{center:'Flex',kind:'ORDER',role:'HQ',poFilter:'NONE',search:'DETAIL'});
  f.tabs.find(e=>e.dataset.tab==='summary').onclick();
  assert.equal(f.state.renderOptions.summarySearch,'0904');assert.equal(f.state.renderOptions.overdueSearch,'EP31');assert.equal(mail('OVERDUE','all').search,'EP31');assert.equal(mail('ORDER','all').search,'0904');
 }finally{app.destroy?.()}
});

for(const type of ['saved HTML','server'])test(type+': top cards open the full matching table at page one and preserve center and overdue search',async()=>{
 const f=shellFixture(),app=type==='server'?await startServer(f):startCurrent(f),original=JSON.stringify(f.data);
 try{
  f.centers.find(e=>e.dataset.center==='CTDI').onclick();
  f.state.callbacks.onSummarySearch({section:'overdue',value:'FAN'});
  for(const kind of ['SHORTAGE','ORDER','WAIT']){
   f.state.callbacks.onSummarySearch({section:'stock',value:'old search'});
   f.state.callbacks.onSummaryPage(3);
   f.state.callbacks.onSummaryFilter(kind,{jump:true});
   const opts=f.state.renderOptions;
   assert.equal(opts.summaryKind,kind);assert.equal(opts.summaryPage,1);assert.equal(opts.summarySearch,'');assert.equal(opts.summaryFocused,true);
   assert.equal(opts.center,'CTDI');assert.equal(opts.overdueSearch,'FAN');
   assert.equal(f.state.jumps.at(-1).selector,'#ov-stock-work');
   assert.equal(f.state.jumps.at(-1).options.block,'start');
   assert.equal(f.doc.activeElement.focusOptions.preventScroll,true);
   assert.equal(f.state.detailOptions,null);
  }
  assert.equal(f.state.jumps.length,3);
  f.state.callbacks.onSummarySearch({section:'stock',value:'keep search'});
  f.state.callbacks.onSummaryFilter('ORDER');
  assert.equal(f.state.renderOptions.summarySearch,'keep search');assert.equal(f.state.jumps.length,3);
  assert.equal(JSON.stringify(f.data),original);
 }finally{app.destroy?.()}
});


for(const type of ['saved HTML','server'])test(type+': Details contains product history only; part lists stay on Summary',async()=>{
 const f=shellFixture(),app=type==='server'?await startServer(f):startCurrent(f);
 try{
  f.tabs.find(e=>e.dataset.tab==='details').onclick();assert.equal(f.state.detailOptions.kind,'WAITING');assert.match(f.state.html,/DETAILS/);assert.doesNotMatch(f.state.html,/SUMMARY|pm-supply-stages|data-(?:sa-)?kind=/);
  f.state.callbacks.onCategory('ORDER_ALL');assert.match(f.state.html,/SUMMARY/);assert.doesNotMatch(f.state.html,/DETAILS/);assert.equal(f.state.renderOptions.summaryKind,'ORDER_ALL');
 }finally{app.destroy?.()}
});
