'use strict';
// Invented material codes only. No operational source files are loaded.
const test=require('node:test');
const assert=require('node:assert/strict');
const Core=require('../src/core.js');
const LeadTime=require('../src/leadtime.js');
const PART='TEST-000001',OTHER='TEST-000002';
const marker={longLead:true,months:6,note:'Synthetic long-lead characteristic'};

test('unregistered part is unknown, not confirmed short-lead',()=>{
 const state=Core.empty();
 assert.equal(LeadTime.get(state,PART),null);
 assert.deepEqual(LeadTime.summarize(state,[{part:PART}]),{partCount:1,taggedPartCount:0,parts:[PART],taggedParts:[]});
 assert.equal(Object.hasOwn(state,'partLeadTimes'),false);
});
test('explicit sticker supports unknown approximate L/T',()=>{
 for(const months of [undefined,null,'','   ']){
  const state=LeadTime.set(Core.empty(),PART,{longLead:true,months});
  assert.deepEqual(LeadTime.get(state,PART),{longLead:true,months:null,note:''});
 }
});
test('one static record is shared by every center using a code',()=>{
 const state=LeadTime.set(Core.empty(),' test-000001 ',{longLead:true,months:' 6 ',note:' shared '});
 assert.deepEqual(state.partLeadTimes,{[PART]:{longLead:true,months:6,note:'shared'}});
 assert.deepEqual(LeadTime.summarize(state,[{center:'Flex',part:PART},{center:'CTDI',part:'test-000001'},{part:OTHER}]),{
  partCount:2,taggedPartCount:1,parts:[PART,OTHER],taggedParts:[PART]
 });
 assert.equal(LeadTime.get(state,' test-000001 ').months,6);
});
test('positive finite approximate month fractions are accepted without threshold inference',()=>{
 assert.equal(LeadTime.get(LeadTime.set(Core.empty(),PART,{longLead:true,months:0.5}),PART).months,0.5);
 for(const value of [{months:6},{longLead:false,months:6},null])assert.throws(()=>LeadTime.set(Core.empty(),PART,value),/장납 여부/);
});
test('invalid L/T is rejected without changing existing state',()=>{
 const state=LeadTime.set(Core.empty(),PART,marker),before=JSON.stringify(state);
 for(const months of [0,-1,Infinity,-Infinity,NaN,'abc','0','-2',true,[],{}]){
  assert.throws(()=>LeadTime.set(state,PART,{longLead:true,months}),/예상 L\/T/);
  assert.equal(JSON.stringify(state),before);
 }
});
test('state updates and removals preserve all unrelated data and input references',()=>{
 const state={...Core.empty(),notes:{private:'keep'},extra:{value:17}};
 const before=JSON.stringify(state),next=LeadTime.set(state,PART,marker);
 assert.equal(JSON.stringify(state),before);
 assert.equal(next.sources,state.sources);
 assert.equal(next.settings,state.settings);
 assert.equal(next.notes,state.notes);
 assert.equal(next.extra,state.extra);
 const withOther=LeadTime.set(next,OTHER,{longLead:true}),removed=LeadTime.remove(withOther,'test-000001');
 assert.equal(LeadTime.get(removed,PART),null);
 assert.deepEqual(LeadTime.get(removed,OTHER),{longLead:true,months:null,note:''});
 assert.deepEqual(LeadTime.get(withOther,PART),marker);
});
test('same-date correction and next weekly source upload preserve the part registry',()=>{
 const source=date=>({type:'dashboard',center:'Flex',operator:'',date,file:'synthetic.xlsx',sheet:'Synthetic',rows:[{part:PART,row:2,stock:0,hold:0,po:0,usage:{}}]});
 const state=LeadTime.set(Core.empty(),PART,marker);
 const first=Core.merge(state,[source('2024-08-05')]);
 const corrected=Core.merge(first,[{...source('2024-08-05'),file:'synthetic-corrected.xlsx'}]);
 const next=Core.merge(corrected,[source('2024-08-12')]);
 assert.equal(corrected.sources.length,1);
 assert.equal(next.sources.length,2);
 assert.deepEqual(next.partLeadTimes,state.partLeadTimes);
});
test('JSON backup roundtrip retains markers and their approximate months',()=>{
 const state=LeadTime.set(LeadTime.set(Core.empty(),PART,marker),OTHER,{longLead:true});
 const restored=LeadTime.normalizeState(JSON.parse(JSON.stringify(state)));
 assert.deepEqual(restored,state);
});
test('tagging never alters calculated inventory, demand, order or shortage results',()=>{
 const state=Core.empty();
 state.sources=[{type:'dashboard',center:'Flex',operator:'',date:'2024-08-12',holdDate:'2024-08-12',file:'synthetic.xlsx',sheet:'Synthetic',usageMonths:['2024-02','2024-03','2024-04','2024-05','2024-06','2024-07'],rows:[{part:PART,row:2,stock:1,hold:3,po:0,usage:{'2024-02':2,'2024-03':2,'2024-04':2,'2024-05':2,'2024-06':2,'2024-07':2}}]}];
 assert.deepEqual(Core.calculate(LeadTime.set(state,PART,marker),'2024-08-12'),Core.calculate(state,'2024-08-12'));
});
test('normalization canonicalizes identical duplicate entries but rejects conflicting metadata',()=>{
 assert.deepEqual(LeadTime.normalizeRegistry({'test-000001':marker,' TEST-000001 ':marker}),{[PART]:marker});
 assert.throws(()=>LeadTime.normalizeRegistry({'test-000001':marker,[PART]:{...marker,months:9}}),/서로 다릅니다/);
});
test('malformed metadata is surfaced instead of silently changing classification',()=>{
 for(const registry of [[],42,'text'])assert.throws(()=>LeadTime.normalizeRegistry(registry),/형식/);
 assert.throws(()=>LeadTime.set(Core.empty(),'  ',marker),/부품 코드/);
 assert.throws(()=>LeadTime.set(Core.empty(),PART,{...marker,note:123}),/텍스트/);
});
test('unique tagged parts summarize only the selected list and no derived shortage quantity',()=>{
 const state=LeadTime.set(LeadTime.set(Core.empty(),PART,marker),OTHER,{longLead:true});
 const summary=LeadTime.summarize(state,[{center:'Flex',part:PART,shortage:2},{center:'CTDI',part:PART,shortage:3}]);
 assert.equal(summary.partCount,1);
 assert.equal(summary.taggedPartCount,1);
 assert.deepEqual(summary.taggedParts,[PART]);
 assert.equal(Object.hasOwn(summary,'shortage'),false);
});

test('procurement review compares raw LT demand inclusively without rounding up',()=>{
 const state=LeadTime.set(Core.empty(),PART,{...marker,months:1.5});
 const check=hq=>LeadTime.procurementReview(state,{parts:[{part:PART,demand:1.5,hq,description:'Synthetic part'}]});
 for(const hq of [0,2,2.25]){
  const result=check(hq);
  assert.equal(result.rows[0].status,'CHECK_PROCUREMENT');
  assert.equal(result.rows[0].leadDemand,2.25);
  assert.equal(result.rows[0].coverageMonths,hq/1.5);
  assert.equal(result.alerts.length,1);
  assert.equal(result.reviewableCount,1);
  assert.equal(result.rows[0].requestOwner,'법인');
  assert.equal(result.rows[0].purchaseOwner,'본사');
  assert.equal(result.rows[0].nextAction,'선행 확보 요청 검토');
 }
 const above=check(2.5);
 assert.equal(above.rows[0].status,'ABOVE_REFERENCE');
 assert.equal(above.rows[0].leadDemand,2.25);
 assert.equal(above.alerts.length,0);
 assert.equal(above.reviewableCount,1);
 assert.equal(above.unknownCount,0);
 assert.match(above.rows[0].reason,/안전을 확정하지 않음/);
});

test('zero usage does not create a procurement alert even with zero HQ stock',()=>{
 const state=LeadTime.set(Core.empty(),PART,marker);
 const result=LeadTime.procurementReview(state,{parts:[{part:PART,demand:0,hq:0,immediateShortage:9}]});
 assert.equal(result.rows[0].status,'NO_USAGE');
 assert.equal(result.rows[0].leadDemand,0);
 assert.equal(result.rows[0].coverageMonths,null);
 assert.equal(result.alerts.length,0);
 assert.equal(result.reviewableCount,0);
 assert.equal(result.unknownCount,0);
});

test('missing LT, unregistered source code and missing source values remain unknown',()=>{
 const state=LeadTime.set(LeadTime.set(Core.empty(),PART,marker),OTHER,{longLead:true});
 const cases=[{}, {parts:[]}, {parts:[{part:PART,demand:null,demandKnownSubtotal:8,hq:0}]},
  {parts:[{part:PART,demand:1,hq:null}]}, {parts:[{part:PART,demand:1,hq:''}]},
  {parts:[{part:PART,demand:1,demandComplete:false,hq:0}]}, {parts:[{part:PART,demand:NaN,hq:0}]},
  {parts:[{part:PART,demand:1,hq:-1}]}];
 for(const support of cases){
  const result=LeadTime.procurementReview(state,support);
  assert.equal(result.rows.length,2);
  assert.equal(result.unknownCount,2);
  assert.equal(result.reviewableCount,0);
  assert.equal(result.alerts.length,0);
  assert.ok(result.rows.every(row=>row.status==='DATA_NEEDED'));
 }
 const missingLT=LeadTime.procurementReview(state,{parts:[{part:OTHER,demand:3,hq:1}]}).rows.find(row=>row.part===OTHER);
 assert.equal(missingLT.months,null);
 assert.equal(missingLT.leadDemand,null);
 assert.match(missingLT.reason,/L\/T 미입력/);
});

test('one shared India demand reference ignores center pending and does not allocate HQ stock',()=>{
 const state=LeadTime.set(Core.empty(),PART,marker),support={parts:[{part:PART,demand:3,hq:12,india:400,centerPending:999,
  centers:[{center:'Flex',avg:1},{center:'CTDI',avg:2}],centerBalances:[{center:'Flex',open:999},{center:'CTDI',open:999}]}]};
 const result=LeadTime.procurementReview(state,support);
 assert.equal(result.rows.length,1);
 assert.equal(result.alerts.length,1);
 assert.equal(result.rows[0].leadDemand,18);
 assert.equal(result.rows[0].hq,12);
 assert.equal(result.rows[0].coverageMonths,4);
 assert.equal(Object.hasOwn(result.rows[0],'proposed'),false);
 assert.equal(Object.hasOwn(result.rows[0],'shortage'),false);
});

test('procurement reference preserves inputs and current shortage/order results through JSON restore',()=>{
 const state=Core.empty();
 state.sources=[{type:'dashboard',center:'Flex',operator:'',date:'2024-08-12',holdDate:'2024-08-12',file:'synthetic.xlsx',sheet:'Synthetic',usageMonths:['2024-02','2024-03','2024-04','2024-05','2024-06','2024-07'],rows:[{part:PART,row:2,stock:1,hold:3,po:0,usage:{'2024-02':2,'2024-03':2,'2024-04':2,'2024-05':2,'2024-06':2,'2024-07':2}}]}];
 const marked=LeadTime.set(state,PART,{...marker,months:6.25}),restored=LeadTime.normalizeState(JSON.parse(JSON.stringify(marked)));
 const support={parts:[{part:PART,demand:1.25,hq:7.5}]},before=JSON.stringify(restored),supportBefore=JSON.stringify(support);
 const result=LeadTime.procurementReview(restored,support);
 assert.equal(result.rows[0].months,6.25);
 assert.equal(result.rows[0].leadDemand,7.8125);
 assert.equal(result.rows[0].status,'CHECK_PROCUREMENT');
 assert.equal(JSON.stringify(restored),before);
 assert.equal(JSON.stringify(support),supportBefore);
 assert.deepEqual(Core.calculate(restored,'2024-08-12'),Core.calculate(state,'2024-08-12'));
});
