'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const S=require('../src/share-dialog.js'),E=require('../src/report-export.js'),X=require('../vendor/xlsx.full.min.js');
test('Excel export retains every row, typed numbers, unknown blanks and text-like formula input',()=>{
 const m=S.normalize({title:'Table / inventory',localized:true,columns:[{key:'part',label:'Part'},{key:'qty',label:'Qty'}],rows:Array.from({length:45},(_,i)=>[i===0?'=TEST()':'P'+i,i===1?null:i]),notes:['Stock is shared.']},{language:'en',reportDate:'2030-01-07',context:['Flex']});
 const bytes=S.workbook([m,{...m,title:'Table / inventory'}],X),book=X.read(bytes,{type:'array'});
 assert.equal(book.SheetNames.length,2);assert.notEqual(...book.SheetNames);
 const sh=book.Sheets[book.SheetNames[0]],rows=X.utils.sheet_to_json(sh,{header:1,defval:null});
 const header=rows.findIndex(r=>r[0]==='Part');assert.equal(rows.length-header-1,45);
 assert.equal(rows[header+1][0],'=TEST()');assert.equal(rows[header+2][1],'');assert.equal(rows.at(-1)[1],44);
 assert.equal(sh['A'+(header+2)].t,'s');assert.equal(sh['A'+(header+2)].f,undefined);
 assert(rows.some(r=>r.includes('Flex')));assert(rows.some(r=>r.includes('2030-01-07')));
});
function fixture(){
 const row=(center,part,stock)=>({id:center+'|'+part,center,part,name:'Part '+part,stock,india:0,hq:10,avg:.5,needed:0,shortage:0,proposed:0,open:0,poOrdered:0,currentAssessed:true,orderAssessed:true});
 const metrics={over45:1,over45PartKinds:1,over45RequiredQty:2,wip:1,shortageKinds:0,orderKinds:0,waitKinds:0};
 return {asof:'2030-01-07',week:'2030-01-07',settings:{targetMonths:1},rows:[row('Flex','P1',4),row('CTDI','P2',3)],tasks:[],pos:[],products:[{id:'one',center:'Flex',operator:'Jio',sn:'SN1',rma:'R1',age:46,date:'2030-01-07',receipt:'2029-11-22',parts:[{part:'P1',quantity:2}]}],sourceDates:[{type:'wip',center:'Flex',date:'2030-01-07',fresh:true},{type:'wip',center:'CTDI',date:'2030-01-07',fresh:true}],metricsByCenter:{전체:{registeredKinds:2},Flex:{registeredKinds:1},CTDI:{registeredKinds:1}},trend:[{week:'2030-01-07',sourceDates:[{type:'wip',center:'Flex',date:'2030-01-07'}],metricsByCenter:{전체:metrics,Flex:metrics,CTDI:{...metrics,over45:0,over45PartKinds:0,over45RequiredQty:0,wip:0}}}]};
}
test('all-table workbook retains normal inventory and only the selected center',()=>{
 const data=fixture(),before=JSON.stringify(data),bytes=E.allWorkbook({data,center:'Flex',language:'en'},X),book=X.read(bytes,{type:'array'});
 assert.equal(book.SheetNames.length,14);
 for(const type of ['WAIT_TRACE','OVERDUE_TRACE']){const m=E.model(type,{data,center:'Flex',language:'en'});assert.equal(m.rows.length,1);assert(m.rows[0].includes('SN1'));}
 const index=book.SheetNames.findIndex(x=>x.startsWith('All material')),sheet=book.Sheets[book.SheetNames[index]],rows=X.utils.sheet_to_json(sheet,{header:1,defval:''});
 assert(rows.some(r=>r[0]==='P1'));assert(!rows.some(r=>r[0]==='P2'));assert.equal(JSON.stringify(data),before);
});
test('standalone chart includes units, center and report date without external dependencies',()=>{
 const svg=E.chartSVG('TREND_OVERDUE',{data:fixture(),center:'Flex',language:'en'});
 assert.match(svg,/<svg xmlns="http:\/\/www.w3.org\/2000\/svg"/);assert.match(svg,/Flex.*2030-01-07/);assert.match(svg,/Required quantity/);assert.match(svg,/part kinds/);assert.match(svg,/data-ov-bar-center="Flex"/);assert.doesNotMatch(svg,/data-ov-bar-center="CTDI"/);assert.doesNotMatch(svg,/<script|https:\/\//);
});
