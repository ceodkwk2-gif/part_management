'use strict';
// Synthetic data only; operations labels must not mutate approved quantities.
const test=require('node:test');
const assert=require('node:assert/strict');
const Core=require('../src/core.js');
const Operations=require('../src/operations.js');
const Actions=require('../src/actions.js');
const PART='TEST-000001',OTHER='TEST-000002',DATE='2024-08-12';
const MONTHS=['2024-02','2024-03','2024-04','2024-05','2024-06','2024-07'];
function member(extra={}){return {center:'Flex',part:PART,stock:0,needed:4,shortage:4,open:0,india:0,hq:9,avg:1,target:1,proposed:5,...extra}}
function dashboard(center='Flex',rows,extra={}){return {type:'dashboard',center,date:DATE,file:'synthetic.xlsx',sheet:'Synthetic',usageMonths:MONTHS,rows:rows||[
 {part:PART,row:2,usage:Object.fromEntries(MONTHS.map((month,index)=>[month,index===5?2:0]))}],...extra}}
function calculate(rows,extra={},state={settings:{}}){return Operations.evaluate(state,{parts:rows,allParts:rows,used:[dashboard()],...extra})}
function role(result,name){return result.roles.find(role=>role.key===name)}
test('low usage defaults to positive up to two units in the actual completed six months',()=>{
 const r=calculate([member()]);assert.equal(r.threshold,2);const item=r.lowUsage['Flex|'+PART];
 assert.equal(item.total,2);assert.equal(item.valid,true);assert.equal(item.flag,true);assert.deepEqual(item.months,MONTHS);
 assert.equal(item.row,2);assert.equal(item.sourceDate,DATE);
});
test('low usage six months are independent of existing average settings and configurable maximum',()=>{
 const low=calculate([member()],{}, {settings:{months:3,lowUsageSixMonthMax:1}});
 assert.equal(low.lowUsage['Flex|'+PART].flag,false);assert.equal(low.lowUsage['Flex|'+PART].total,2);
 assert.equal(calculate([member()],{}, {settings:{months:12,lowUsageSixMonthMax:3}}).lowUsage['Flex|'+PART].flag,true);
 for(const invalid of [0,-1,1.5,null,'3',NaN])assert.equal(calculate([member()],{}, {settings:{lowUsageSixMonthMax:invalid}}).threshold,2);
});
test('zero, missing, invalid and stale monthly values never receive low usage marker',()=>{
 const source=dashboard(),base=source.rows[0];
 const cases=[
  {...base,usage:Object.fromEntries(MONTHS.map(month=>[month,0]))},
  {...base,usage:{...base.usage,'2024-04':null}},
  {...base,usage:{...base.usage,'2024-04':-1}},
  {...base,usage:{...base.usage,'2024-04':'1'}}
 ];
 for(const row of cases){const item=calculate([member()],{used:[dashboard('Flex',[row])]}).lowUsage['Flex|'+PART];assert.equal(item.flag,false)}
 const zero=calculate([member()],{used:[dashboard('Flex',[cases[0]])]}).lowUsage['Flex|'+PART];assert.equal(zero.valid,true);assert.equal(zero.total,0);
 for(const extra of [{date:null},{date:'2024-09-12'},{usageMonths:MONTHS.filter(month=>month!=='2024-04')}]){
  const item=calculate([member()],{used:[dashboard('Flex',undefined,extra)]}).lowUsage['Flex|'+PART];assert.equal(item.valid,false);assert.equal(item.total,null);assert.equal(item.flag,false);
 }
});
test('low usage uses original top row and remains center-specific for shared codes',()=>{
 const first=dashboard().rows[0],later={...first,row:9,usage:Object.fromEntries(MONTHS.map(month=>[month,40]))};
 const r=calculate([member(),member({center:'CTDI'})],{used:[dashboard('Flex',[later,first]),dashboard('CTDI',[later])]});
 assert.equal(r.lowUsage['Flex|'+PART].total,2);assert.equal(r.lowUsage['Flex|'+PART].row,2);assert.equal(r.lowUsage['Flex|'+PART].flag,true);
 assert.equal(r.lowUsage['CTDI|'+PART].total,240);assert.equal(r.lowUsage['CTDI|'+PART].flag,false);
});
test('covered current PO compares global shortage once and assigns one joint category without allocating stock',()=>{
 const rows=[member({india:5,open:4}),member({center:'CTDI',india:5,shortage:3,needed:3,open:3})],r=calculate(rows);
 assert.equal(r.shortagePartCount,1);assert.deepEqual(r.roles.map(role=>role.partCount),[0,0,1,0]);
 const detail=r.groups[0].rows[0];assert.equal(detail.globalShortage,7);assert.equal(detail.india,5);assert.equal(detail.shortage,7);
 assert.deepEqual(role(r,'INDIA_HQ').rows[0].centers,['Flex','CTDI']);assert.equal(role(r,'INDIA_HQ').rows[0].poNeed,null);
 assert.deepEqual(r.memberInfo['Flex|'+PART].roleKeys,['INDIA_HQ']);assert.equal(r.allocationConfirmed,false);assert.equal(r.liabilityConfirmed,false);
 assert.equal(r.hqAssignmentAvailable,true);assert.match(r.hqAssignmentNote,/귀책 또는 신규 구매를 확정하지/);
 assert.equal(detail.supplyAction,'본사→법인→센터 공급 진행');assert.equal(detail.supplyGap,0);
});

test('center action needs only current shortage and pending, independent of missing average and proposed',()=>{
 const r=calculate([member({needed:3,shortage:3,open:1,avg:null,target:null,proposed:null})]);
 assert.equal(role(r,'CENTER').partCount,1);assert.equal(role(r,'CENTER').rows[0].poNeed,2);
 assert.equal(r.memberInfo['Flex|'+PART].nextAction,'현재 수리용 PO 2개 필요 (보유분·총 추가 PO 미계산) · 기존 PO 1개 공급 진행');
 const unknown=calculate([member({open:null,proposed:null})]);assert.equal(role(unknown,'CENTER').partCount,0);
 const invalid=calculate([member({open:-1})]);assert.equal(role(invalid,'CENTER').partCount,0);
});
test('one total PO instruction preserves the separate owner criterion and parallel supply task',()=>{
 const row=member({stock:2,needed:12,shortage:10,open:3,avg:2,target:4,proposed:11}),before=JSON.stringify(row);
 const r=calculate([row],{}, {settings:{targetMonths:2}}),info=r.memberInfo['Flex|'+PART];
 assert.equal(info.nextOwner,'CENTER');assert.equal(role(r,'CENTER').rows[0].poNeed,7,'The owner criterion remains the current-repair gap');
 assert.equal(info.nextAction,'추가 PO 총 11개 필요 (현 수리 필요 12 + 2개월 보유 4 − 센터 재고 2 − PO 미입고 3) · 기존 PO 3개 공급 진행');
 assert.equal(info.nextAction.match(/추가 PO 총/g).length,1);assert.doesNotMatch(info.nextAction,/현재 수리용 7개 추가 발주|현재 수리용 PO 7개 필요/);
 assert.equal(r.groups[0].rows[0].members[0].nextAction,info.nextAction);
 assert.equal(r.groups[0].rows[0].nextAction,info.nextAction);assert.equal(JSON.stringify(row),before);
});
test('shared order text supports a compact total, zero inputs and unknown total without inventing buffer demand',()=>{
 const row=member({needed:0,shortage:0,stock:0,open:0,proposed:2,target:2});
 assert.equal(Operations.orderActionText(row),'추가 PO 총 2개 필요 (현 수리 필요 0 + 1개월 보유 2 − 센터 재고 0 − PO 미입고 0)');
 assert.equal(Operations.orderActionText(row,{includeBasis:false}),'추가 PO 총 2개 필요');
 assert.equal(Operations.orderActionText({...row,target:null}),'추가 PO 총 2개 필요');
 assert.equal(Operations.orderActionText({...row,proposed:0}),'');
 assert.equal(Operations.orderActionText({...row,needed:5,stock:1,open:1,proposed:null,target:null}),'현재 수리용 PO 3개 필요 (보유분·총 추가 PO 미계산)');
 assert.equal(Operations.orderActionText({...row,needed:null,proposed:null}),'');
 assert.equal(Operations.orderActionText({...row,proposed:1200},{includeBasis:false,format:value=>value.toLocaleString('en-US')}),'추가 PO 총 1,200개 필요');
});
test('covered PO with unknown upstream stock remains an alert without converting unknown to zero',()=>{
 for(const stocks of [{india:null,hq:9},{india:0,hq:null},{india:null,hq:0}]){
  const r=calculate([member({...stocks,open:4})]),detail=r.groups[0].rows[0];
  assert.equal(r.groups[0].key,'INFORMATION_CHECK');assert.deepEqual(r.roles.map(role=>role.partCount),[0,0,0,0]);
  assert.equal(detail.supplyGap,null);assert.equal(detail.classificationComplete,false);assert.equal(r.dataAlerts.length,1);
  assert.match(detail.supplyReason,/재고 일부 미확인/);
 }
});

test('covered PO and both upstream stocks zero assigns HQ secure task without presuming a new purchase or fault',()=>{
 const r=calculate([member({india:0,hq:0,open:9})]);assert.deepEqual(r.roles.map(role=>role.partCount),[0,0,0,1]);
 const item=role(r,'HQ').rows[0];assert.equal(item.nextAction,'구매·입고 진행 및 자재 확보');assert.equal(item.supplyGap,4);
 assert.match(item.reason,/기존 구매·입고 진행을 포함/);assert.match(item.reason,/신규 구매·귀책을 확정하지/);
 assert.equal(r.liabilityConfirmed,false);assert.equal(r.allocationConfirmed,false);
});

test('center filtering never reuses shared India stock independently for each center',()=>{
 const flex=member({needed:4,shortage:4,india:5,open:4}),ctdi=member({center:'CTDI',needed:4,shortage:4,india:5,open:4});
 const commonSupport={parts:[{part:PART,shortageKnownSubtotal:8,shortageComplete:true,india:5,hq:9}]};
 const all=calculate([flex,ctdi],{commonSupport}),filtered=calculate([flex],{commonSupport});
 for(const result of [all,filtered]){
  assert.equal(role(result,'INDIA_HQ').partCount,1);assert.equal(role(result,'INDIA').partCount,0);
  assert.equal(role(result,'INDIA_HQ').rows[0].globalShortage,8);assert.equal(role(result,'INDIA_HQ').rows[0].india,5);
 }
 assert.equal(role(filtered,'INDIA_HQ').rows[0].shortage,4);assert.deepEqual(role(filtered,'INDIA_HQ').rows[0].centers,['Flex']);
});

test('next-owner counts are exclusive unique shortage codes and never count future target alone',()=>{
 const r=calculate([member({india:1}),member({center:'CTDI',india:1}),member({part:OTHER,needed:0,shortage:0,proposed:9})]);
 assert.equal(r.shortagePartCount,1);assert.equal(role(r,'CENTER').partCount,1);assert.equal(role(r,'INDIA').partCount,0);assert.equal(role(r,'HQ').partCount,0);
 assert.equal(role(r,'CENTER').rows[0].poNeed,8);assert.equal(r.memberInfo['Flex|'+OTHER].roleKeys.length,0);
});

test('unknown other-center demand preserves evidence and alert without inventing HQ responsibility',()=>{
 const rows=[member({india:2}),member({center:'CTDI',needed:null,shortage:null,open:null,india:2})],r=calculate(rows);
 const item=role(r,'CENTER').rows[0];assert.equal(item.globalShortage,4);assert.equal(item.globalShortageComplete,false);
 assert.equal(item.classificationComplete,false);assert.equal(role(r,'HQ').partCount,0);
 const sufficientKnown=calculate(rows.map(row=>({...row,india:5})));assert.equal(role(sufficientKnown,'CENTER').partCount,1);assert.equal(role(sufficientKnown,'HQ').partCount,0);
});

test('operations projection never mutates or replaces core quantities',()=>{
 const state=Core.empty(),calculated={parts:[member()],allParts:[member()],used:[dashboard()]},before=JSON.stringify({state,calculated});
 Operations.evaluate(state,calculated);assert.equal(JSON.stringify({state,calculated}),before);
});
test('India and HQ reference months change only shared reference goals, never center quantities, action cards or owner combinations',()=>{
 const state=Core.empty(),row=(part,monthly,stock,hold,po)=>({part,row:part===PART?2:3,stock,hold,po,
  usage:Object.fromEntries(MONTHS.map(month=>[month,monthly]))});
 state.sources=[
  dashboard('Flex',[row(PART,2,1,6,2),row(OTHER,6,2,0,0)],{holdDate:DATE}),
  dashboard('CTDI',[row(PART,3,2,5,4),row(OTHER,4,1,0,5)],{holdDate:DATE}),
  {type:'india',date:DATE,file:'synthetic-india.xlsx',sheet:'Stock',rows:[{part:PART,qty:3,row:2},{part:OTHER,qty:20,row:3}]},
  {type:'hq',date:DATE,file:'synthetic-hq.xlsx',sheet:'Stock',rows:[{part:PART,qty:4,row:2},{part:OTHER,qty:25,row:3}]}
 ];
 const before=Core.calculate(state,DATE),owners=Operations.evaluate(state,before),cards=Actions.evaluate(state,DATE);
 const reference=before.commonSupport.parts.find(part=>part.part===PART);
 assert.equal(reference.demand,5);assert.equal(reference.indiaTarget,0);assert.equal(reference.hqTarget,15);
 assert.equal(cards.tasks.supply.partCount,1);assert.equal(cards.tasks.order.partCount,2);
 assert.equal(owners.groups.length,1);assert.equal(owners.groups[0].key,'CENTER');
 assert.equal(owners.groups[0].quantity,8);
 for(const [indiaMonths,hqMonths] of [[2,6],[0.1,0.1],[24,24]]){
  const changed=structuredClone(state);changed.settings.indiaMonths=indiaMonths;changed.settings.hqMonths=hqMonths;
  const after=Core.calculate(changed,DATE),support=after.commonSupport.parts.find(part=>part.part===PART);
  assert.equal(support.indiaTarget,Math.ceil(5*indiaMonths));assert.equal(support.hqTarget,Math.ceil(5*hqMonths));
  assert.equal(support.indiaGap,Math.max(0,support.indiaTarget-3));assert.equal(support.hqGap,Math.max(0,support.hqTarget-4));
  assert.notEqual(support.indiaTarget,reference.indiaTarget);assert.notEqual(support.hqTarget,reference.hqTarget);
  assert.deepEqual(after.parts,before.parts);assert.deepEqual(after.allParts,before.allParts);
  assert.deepEqual(Actions.evaluate(changed,DATE),cards);
  assert.deepEqual(Operations.evaluate(changed,after),owners);
 }
});
test('four exclusive task categories reconcile shortage codes without double-counting the joint role',()=>{
 const rows=[member({india:4}),member({part:OTHER,open:4,india:4}),member({part:'TEST-000003',open:4,india:2,hq:9}),member({part:'TEST-000004',open:4,hq:0})];
 const r=calculate(rows);
 assert.deepEqual(r.groups.map(group=>[group.key,group.partCount]),[['CENTER',1],['INDIA',1],['INDIA_HQ',1],['HQ',1]]);
 assert.equal(r.groupTotal,4);assert.equal(r.groupTotal,r.shortagePartCount);assert.equal(r.groupingComplete,true);
 assert.equal(r.groups.reduce((sum,group)=>sum+group.quantity,0),16);
 assert.equal(new Set(r.groups.flatMap(group=>group.parts)).size,4);assert.deepEqual(r.roles.map(role=>role.partCount),[1,1,1,1]);
});

test('mixed center stages use center first once per part while retaining per-center owners and pending followup',()=>{
 const r=calculate([member({needed:7,stock:2,shortage:5,open:3,india:5}),member({center:'CTDI',needed:4,stock:1,shortage:3,open:3,india:5})]);
 assert.equal(r.groups.length,1);const g=r.groups[0],p=g.rows[0];
 assert.equal(g.key,'CENTER');assert.equal(g.partCount,1);assert.equal(g.quantity,8);
 assert.equal(p.globalShortage,8);assert.equal(p.india,5);assert.equal(p.currentOrderNeed,2);
 assert.deepEqual(p.members.map(row=>({center:row.center,needed:row.needed,stock:row.stock,shortage:row.shortage,open:row.open,gap:row.currentOrderNeed,poKnown:row.poKnown})),[
  {center:'Flex',needed:7,stock:2,shortage:5,open:3,gap:2,poKnown:true},
  {center:'CTDI',needed:4,stock:1,shortage:3,open:3,gap:0,poKnown:true}
 ]);
 assert.deepEqual(p.members.map(row=>row.nextOwner),['CENTER','INDIA_HQ']);
 assert.deepEqual(r.memberInfo['Flex|'+PART].roleKeys,['CENTER']);assert.deepEqual(r.memberInfo['CTDI|'+PART].roleKeys,['INDIA_HQ']);
 assert.equal(r.memberInfo['Flex|'+PART].pendingFollowup,true);assert.match(r.memberInfo['Flex|'+PART].pendingFollowupReason,/기존 미입고 PO 3개: 법인·본사/);
 assert.deepEqual(p.roleDetails.find(role=>role.key==='CENTER').centers,['Flex']);
 assert.deepEqual(p.roleDetails.find(role=>role.key==='INDIA_HQ').centers,['CTDI']);assert.equal(p.classificationComplete,true);
 assert.deepEqual(r.roles.map(role=>role.partCount),[1,0,0,0]);
});

test('center filtered next owner covers only visible shortages while keeping global stock evidence',()=>{
 const p=member({needed:4,shortage:4,open:4,india:5}),commonSupport={parts:[{part:PART,shortageKnownSubtotal:8,shortageComplete:true,india:5,hq:9}]};
 const r=calculate([p],{commonSupport});assert.equal(r.groups[0].key,'INDIA_HQ');assert.equal(r.groupTotal,1);assert.equal(r.groupingComplete,true);
 const detail=r.groups[0].rows[0];assert.equal(detail.shortage,4);assert.equal(detail.globalShortage,8);assert.equal(detail.india,5);assert.deepEqual(detail.centers,['Flex']);
});

test('unknown PO remains an information alert with null gap and no fabricated supply owner',()=>{
 const r=calculate([member({open:null,proposed:null})]),p=r.groups[0].rows[0];
 assert.equal(r.groups[0].key,'INFORMATION_CHECK');assert.equal(r.groupTotal,1);assert.equal(r.groupingComplete,true);
 assert.equal(p.poKnown,false);assert.equal(p.currentOrderNeed,null);assert.equal(p.currentOrderNeedKnownSubtotal,0);
 assert.equal(p.members[0].open,null);assert.equal(p.members[0].currentOrderNeed,null);assert.equal(p.classificationComplete,false);
 assert.ok(p.checks.some(text=>text.includes('PO 잔량 미확인')));assert.deepEqual(p.roleKeys,[]);
 assert.equal(r.dataAlerts.length,1);assert.equal(p.members[0].nextOwner,'INFORMATION_CHECK');assert.deepEqual(r.roles.map(role=>role.partCount),[0,0,0,0]);
});

test('unassigned context stays in exactly one information-check group without a fabricated owner or zero PO',()=>{
 // Defensive coverage for an incomplete/inconsistent supplied support projection.
 const commonSupport={parts:[{part:PART,shortageKnownSubtotal:0,shortageComplete:false,india:0,hq:null}]};
 const r=calculate([member({open:null,india:0,hq:null})],{commonSupport}),p=r.groups[0].rows[0];
 assert.equal(r.groups[0].key,'INFORMATION_CHECK');assert.equal(r.groups[0].label,'조치 정보 확인');
 assert.equal(r.groupTotal,1);assert.equal(r.groupingComplete,true);assert.equal(p.classificationComplete,false);
 assert.deepEqual(p.roleKeys,[]);assert.equal(p.members[0].open,null);assert.equal(p.hq,null);
});
test('classification evidence retains actual dashboard row and need dates and selected stock source rows',()=>{
 const source=dashboard('Flex',[{...dashboard().rows[0],stock:1,hold:4,po:2}]);
 const commonSupport={parts:[{part:PART,shortageKnownSubtotal:3,shortageComplete:true,india:0,hq:9,
  inventorySources:{india:{file:'synthetic-india.xlsx',sheet:'Stock',date:DATE,selectedRow:4,qty:0,reason:'원본 재고',ignoredRows:[]},
   hq:{file:'synthetic-hq.xlsx',sheet:'Stock',date:DATE,selectedRow:8,qty:9,reason:'중복코드 맨 위 행 사용',ignoredRows:[16]}}}]};
 const r=calculate([member({stock:1,needed:4,shortage:3,open:2,needBasis:'dashboard',needDate:DATE,dashboardDate:DATE})],{used:[source],commonSupport});
 const e=r.groups[0].rows[0].members[0].sourceEvidence;
 assert.equal(e.dashboard[0].row,2);assert.equal(e.dashboard[0].quantity,1);assert.equal(e.need[0].field,'Waiting/Hold');assert.equal(e.need[0].quantity,4);assert.equal(e.need[0].date,DATE);
 assert.equal(e.po[0].basis,'dashboard');assert.equal(e.po[0].quantity,2);assert.equal(e.india[0].row,4);assert.equal(e.india[0].quantity,0);
 assert.equal(e.hq[0].row,8);assert.equal(e.hq[0].quantity,9);assert.deepEqual(e.hq[0].ignoredRows,[16]);
});
test('classification evidence includes all center WIP operators used in total need and detail pending sources',()=>{
 const wip=(operator,quantity)=>({type:'wip',center:'CTDI',operator,file:operator+'-synthetic.xlsx',sheet:'WIP',date:DATE,rows:[{row:7,tokens:{parts:{[PART]:quantity}}}]});
 const po={type:'po',center:'CTDI',file:'synthetic-po.xlsx',sheet:'Orders',date:DATE,rows:[{row:11,part:PART,po:'SYN-PO',item:'10',pending:2}]};
 const r=calculate([member({center:'CTDI',needed:3,shortage:3,open:2,needBasis:'wip',needDate:DATE})],{used:[wip('Jio',1),wip('Airtel',2),po]});
 const e=r.groups[0].rows[0].members[0].sourceEvidence;
 assert.deepEqual(e.need.map(ref=>[ref.operator,ref.quantity,ref.row]),[['Jio',1,7],['Airtel',2,7]]);
 assert.equal(e.po[0].basis,'detail');assert.equal(e.po[0].quantity,2);assert.equal(e.po[0].row,11);assert.equal(e.po[0].po,'SYN-PO');
});
test('detail PO evidence shows only selected duplicate row and explains ignored rows without changing the open quantity',()=>{
 const first={row:5,part:PART,po:'SYN-PO',item:'10',pending:2},po={type:'po',center:'Flex',file:'synthetic-po.xlsx',sheet:'Orders',date:DATE,
  rows:[{...first,row:18},first,{row:9,part:PART,po:'SYN-OTHER',item:'10',pending:1}]};
 const r=calculate([member({open:3})],{used:[po]}),memberResult=r.groups[0].rows[0].members[0],refs=memberResult.sourceEvidence.po;
 assert.equal(memberResult.open,3);assert.equal(memberResult.currentOrderNeed,1);assert.equal(refs.length,2);
 assert.deepEqual(refs.map(ref=>ref.row),[5,9]);assert.equal(refs.reduce((sum,ref)=>sum+ref.quantity,0),3);
 assert.deepEqual(refs[0].ignoredRows,[18]);assert.equal(refs[0].used,true);assert.match(refs[0].reason,/맨 위 행 1회 반영/);assert.match(refs[0].reason,/18행/);
});
test('conflicting detail PO evidence retains source values as evidence but never presents them as applied pending quantities',()=>{
 const first={row:5,part:PART,po:'SYN-PO',item:'10',pending:2},po={type:'po',center:'Flex',file:'synthetic-po.xlsx',sheet:'Orders',date:DATE,
  rows:[first,{...first,row:18,pending:9},{row:9,part:PART,po:'SYN-OTHER',item:'10',pending:1}]};
 const r=calculate([member({open:null,proposed:null})],{used:[po]}),memberResult=r.groups[0].rows[0].members[0],refs=memberResult.sourceEvidence.po;
 assert.equal(memberResult.open,null);assert.equal(memberResult.currentOrderNeed,null);assert.equal(refs.length,3);
 assert.ok(refs.every(ref=>ref.quantity===null&&ref.detailPending===null&&ref.used===false));
 assert.deepEqual(refs.map(ref=>ref.originalQuantity),[2,9,1]);assert.ok(refs.every(ref=>ref.reason.includes('합산·반영 보류')));
 assert.match(refs[0].reason,/원본 Pending 2개/);assert.match(refs[1].reason,/원본 Pending 9개/);
});


test('low usage is recomputed from corrected usage and the next completed-month window',()=>{
 const row={part:PART,row:2,usage:Object.fromEntries(MONTHS.map((month,index)=>[month,index===0?2:0]))};
 const evaluate=source=>Operations.evaluate({settings:{}},{parts:[member()],allParts:[member()],used:[source]}).lowUsage['Flex|'+PART];
 const current=dashboard('Flex',[row]);assert.equal(evaluate(current).flag,true);
 const corrected=dashboard('Flex',[{...row,usage:{...row.usage,'2024-07':1}}]);
 assert.equal(evaluate(corrected).total,3);assert.equal(evaluate(corrected).flag,false);
 const nextMonths=[...MONTHS.slice(1),'2024-08'];
 const next=dashboard('Flex',[{...row,usage:{...row.usage,'2024-08':0}}],{date:'2024-09-02',usageMonths:nextMonths});
 assert.deepEqual(evaluate(next).months,nextMonths);assert.equal(evaluate(next).total,0);assert.equal(evaluate(next).flag,false);
 next.rows[0].usage['2024-08']=1;assert.equal(evaluate(next).total,1);assert.equal(evaluate(next).flag,true);
});


test('future replenishment alone never changes the shared supply task to center',()=>{
 const r=calculate([member({needed:38,shortage:38,open:41,avg:24,target:24,proposed:21,india:0,hq:100})]);
 assert.equal(r.groups[0].key,'INDIA_HQ');assert.equal(r.groups[0].rows[0].currentOrderNeed,0);
 assert.equal(r.memberInfo['Flex|'+PART].nextOwner,'INDIA_HQ');assert.equal(role(r,'CENTER').partCount,0);
});
test('no PO assigns center alone even when both upstream locations have ample stock',()=>{
 const r=calculate([member({open:0,india:1000,hq:1000})]);
 assert.equal(r.groups[0].key,'CENTER');assert.deepEqual(r.memberInfo['Flex|'+PART].roleKeys,['CENTER']);
 assert.equal(r.memberInfo['Flex|'+PART].pendingFollowup,false);assert.equal(r.memberInfo['Flex|'+PART].pendingFollowupReason,'');
 assert.deepEqual(r.roles.map(role=>role.partCount),[1,0,0,0]);
});
test('mixed unknown and known pending cannot claim that all centers are covered',()=>{
 const r=calculate([member({open:4}),member({center:'CTDI',open:null})]);
 assert.equal(r.groups[0].key,'INFORMATION_CHECK');assert.equal(r.groups[0].rows[0].classificationComplete,false);
 assert.deepEqual(r.groups[0].rows[0].members.map(row=>row.nextOwner),['INDIA_HQ','INFORMATION_CHECK']);
 const confirmedOrder=calculate([member({open:0}),member({center:'CTDI',open:null})]);
 assert.equal(confirmedOrder.groups[0].key,'CENTER');assert.equal(confirmedOrder.dataAlerts.length,1);
});
test('center filtering recomputes primary owner from that center while preserving mixed-center evidence in all view',()=>{
 const flex=member({open:0}),ctdi=member({center:'CTDI',open:4}),all=[flex,ctdi];
 const combined=calculate(all),selected=calculate([ctdi],{allParts:all});
 assert.equal(combined.groups[0].key,'CENTER');assert.equal(selected.groups[0].key,'INDIA_HQ');
 assert.equal(selected.groups[0].rows[0].globalShortage,8);assert.equal(selected.groups[0].rows[0].shortage,4);
});


test('known shortage lower bound can prove shared task but cannot prove India stock is sufficient',()=>{
 const rows=[member({india:3,open:4}),member({center:'CTDI',india:3,needed:null,shortage:null,open:null})];
 const r=calculate(rows);assert.equal(r.groups[0].key,'INDIA_HQ');
 assert.equal(r.memberInfo['Flex|'+PART].supplyAction,'보유분 공급 · 추가 필요량 확인');
 assert.equal(r.groups[0].rows[0].globalShortageComplete,false);assert.equal(r.groups[0].rows[0].supplyGap,null);assert.equal(r.dataAlerts.length,1);
 const covered=calculate(rows.map(row=>({...row,india:5})));assert.equal(covered.groups[0].key,'INFORMATION_CHECK');
 assert.match(covered.memberInfo['Flex|'+PART].supplyReason,/전체 센터 부족량이 완전하지/);
 const provenGap=calculate(rows.map(row=>({...row,hq:0})));assert.equal(provenGap.groups[0].key,'INDIA_HQ');
 assert.equal(provenGap.groups[0].rows[0].supplyGapKnownLowerBound,1);assert.equal(provenGap.groups[0].rows[0].supplyGap,null);
 assert.equal(provenGap.memberInfo['Flex|'+PART].supplyAction,'보유분 공급 · 본사 부족분 확보');
});

test('India stock equality covers complete shortage even when unrelated HQ stock is unknown',()=>{
 const r=calculate([member({india:4,hq:null,open:4})]);assert.equal(r.groups[0].key,'INDIA');
 assert.equal(r.groups[0].rows[0].classificationComplete,true);assert.equal(r.dataAlerts.length,0);
 assert.equal(r.memberInfo['Flex|'+PART].nextAction,'센터 공급 진행');
});
test('positive but insufficient shared stocks use joint supply and HQ secure action at exact boundaries',()=>{
 for(const [india,hq,action,gap] of [[1,3,'본사→법인→센터 공급 진행',0],[1,2,'보유분 공급 · 본사 부족분 확보',1],[1,0,'보유분 공급 · 본사 부족분 확보',3],[0,4,'본사→법인→센터 공급 진행',0],[0,3,'보유분 공급 · 본사 부족분 확보',1]]){
  const r=calculate([member({india,hq,open:4})]);assert.equal(r.groups[0].key,'INDIA_HQ');
  assert.equal(r.groups[0].rows[0].supplyAction,action);assert.equal(r.groups[0].rows[0].supplyGap,gap);
 }
});
test('center priority preserves parallel HQ securing and existing PO tasks without increasing role count',()=>{
 for(const open of [0,2]){
  const r=calculate([member({india:0,hq:0,open})]),info=r.memberInfo['Flex|'+PART];
  assert.deepEqual(r.roles.map(role=>role.partCount),[1,0,0,0]);assert.equal(info.supplyRoleKey,'HQ');
  assert.match(info.nextAction,/본사 자재 확보 필요/);assert.equal(info.pendingFollowup,open>0);
  if(open>0){assert.match(info.nextAction,/기존 PO 2개 공급 진행/);assert.match(info.pendingFollowupReason,/기존 미입고 PO 2개: 본사/);assert.match(info.pendingFollowupReason,/구매·입고 진행 및 자재 확보/)}
 }
});
test('known center order task remains assigned while missing upstream evidence stays in alerts',()=>{
 const r=calculate([member({india:null,hq:null,open:1})]),info=r.memberInfo['Flex|'+PART];
 assert.equal(r.groups[0].key,'CENTER');assert.equal(r.groups[0].rows[0].currentOrderNeed,3);
 assert.equal(info.supplyRoleKey,'INFORMATION_CHECK');assert.match(info.pendingFollowupReason,/공급 재고 자료 확인/);
 assert.equal(r.dataAlerts.length,1);assert.equal(r.groups[0].rows[0].classificationComplete,false);
});
test('zero known upstream stock proves HQ securing despite other-center demand still unknown',()=>{
 const rows=[member({india:0,hq:0,open:4}),member({center:'CTDI',india:0,hq:0,needed:null,shortage:null,open:null})];
 const r=calculate(rows);assert.equal(r.groups[0].key,'HQ');assert.equal(r.dataAlerts.length,1);
 assert.equal(r.groups[0].rows[0].supplyGap,null);assert.equal(r.groups[0].rows[0].supplyGapKnownLowerBound,4);
});


test('PO follow-up splits matching dated and undated lines without changing balances',()=>{
 const base=member({open:7,proposed:3}),po=(item,pending,etd,extra={})=>({center:'Flex',part:PART,po:'P1',item,pending,etd,row:+item,...extra});
 const rows=[po('1',4,'2026-10-02'),po('2',3,null),po('3',99,'2026-10-03',{center:'CTDI'})],before=JSON.stringify({base,rows});
 const out=Operations.poFollowup(base,rows);
 assert.equal(out.matched,true);assert.equal(out.plannedQuantity,4);assert.equal(out.unplannedQuantity,3);
 assert.deepEqual(out.tasks.map(t=>[t.owner,t.quantity]),[['법인',4],['법인·본사',3]]);
 assert.equal(out.dispatchConfirmed,false);assert.equal(out.receiptConfirmed,false);assert.equal(JSON.stringify({base,rows}),before);
});
test('PO follow-up does not apply dated detail amounts to missing, mismatched or conflicting balances',()=>{
 const base=member({open:7}),line={center:'Flex',part:PART,po:'P1',item:'1',pending:4,etd:'2026-10-02',row:2};
 for(const rows of [[],[line],[{...line,pending:null}],[line,{...line,pending:3,row:3}]]){
  const out=Operations.poFollowup(base,rows);assert.equal(out.matched,false);assert.equal(out.plannedQuantity,0);assert.equal(out.unplannedQuantity,7);
  assert.deepEqual(out.tasks.map(t=>[t.owner,t.quantity]),[['법인·본사',7]]);
 }
 assert.equal(Operations.poFollowup(member({open:0}),[line]).tasks.length,0);
});
test('PO follow-up deduplicates exact lines and exposes date differences without claiming receipt',()=>{
 const line={center:'Flex',part:PART,po:'P1',item:'1',pending:7,etd:'2026-09-01',date:'2026-09-18',shipped:4,row:2};
 const out=Operations.poFollowup(member({open:7,dashboardDate:'2026-09-22'}),[line,{...line,row:3}]);
 assert.equal(out.matched,true);assert.equal(out.plannedQuantity,7);assert.equal(out.datedRows.length,1);
 assert.match(out.sourceDateNote,/2026-09-22.*2026-09-18/);assert.equal(out.receiptConfirmed,false);assert.equal(out.dispatchConfirmed,false);
});
