const test=require('node:test');
const assert=require('node:assert/strict');
const C=require('../src/core.js'),R=require('../src/reporting.js'),P=require('../src/pipeline.js');
const U=require('../src/upload-panel.js'),F=require('../src/upload-flow.js');
const source=(type,date,file,extra={})=>({type,date,file,sheet:'Sheet1',center:type==='india'?'India':type==='hq'?'HQ':'Flex',operator:type==='wip'?'Jio':null,rows:[],...extra});

test('folder selection preserves each relative path and explicitly lists unsupported/temporary files',()=>{
 const a={name:'wip.xlsb',webkitRelativePath:'0921/Flex/wip.xlsb'},b={name:'wip.xlsb',webkitRelativePath:'0921/CTDI/wip.xlsb'},zip={name:'stock.zip',webkitRelativePath:'0921/stock.zip'};
 const result=F.inspectSelection([a,b,zip,{name:'~$stock.xlsx',webkitRelativePath:'0921/~$stock.xlsx'},{name:'readme.txt',webkitRelativePath:'0921/readme.txt'},{name:'bad.xlsx',webkitRelativePath:'../bad.xlsx'}],{folder:true});
 assert.deepEqual(result.files,[a,b,zip]);assert.equal(a.partsImportPath,'0921/Flex/wip.xlsb');assert.notEqual(a.partsImportPath,b.partsImportPath);
 assert.deepEqual(result.issues.map(x=>x.reason),['TEMPORARY_FILE','UNSUPPORTED_FILE','UNSAFE_PATH']);assert.equal(result.issues.every(x=>x.excluded),true);
 assert.equal(F.isExcel('sub/~$stock.xlsx'),false);
});

test('dropped folders include every reader batch and preserve subfolders',async()=>{
 const fileEntry=name=>({name,isFile:true,file:resolve=>resolve({name})});
 const directory=(name,batches)=>({name,isDirectory:true,createReader(){let i=0;return {readEntries(resolve){resolve(batches[i++]||[])}}}});
 const folder=directory('0921',[[fileEntry('hq.xlsx')],[directory('Flex',[[fileEntry('wip.xlsb')]])]]);
 const files=await F.collectDropFiles({items:[{webkitGetAsEntry:()=>folder}]});
 assert.deepEqual(files.map(f=>f.partsImportPath),['0921/hq.xlsx','0921/Flex/wip.xlsb']);
 await assert.rejects(()=>F.collectDropFiles({items:[{webkitGetAsEntry:()=>folder}]},{limit:1}),/한 주 자료/);
});

test('saved week status distinguishes applied from completeness with all eleven slots',()=>{
 let state=R.applySources(C.empty(),[source('india','2026-09-21','india.xlsx'),source('wip','2026-09-21','flex-wip.xlsb')],'2026-09-21');
 state=R.applySources(state,[source('wip','2026-09-28','flex-wip-next.xlsb')],'2026-09-28');
 const model=U.buildModel({state,reportDate:'2026-09-28'}),week=model.weekStatuses.at(-1);
 assert.equal(model.slots.length,11);assert.equal(model.slots.find(s=>s.key==='siel').source,null);
 assert.deepEqual(week.counts.wip,{total:4,available:1,current:1,references:0,missing:3});
 assert.deepEqual(week.counts.other,{total:7,available:1,current:0,references:1,missing:6});
 assert.ok(week.lastApplied);const html=U.render({state,reportDate:'2026-09-28'});
 assert.match(html,/주별 반영 현황/);assert.match(html,/반영 완료/);assert.match(html,/자료 누락 있음/);assert.match(html,/WIP 1\/4/);assert.match(html,/재고·PO 1\/7/);assert.match(html,/2026-09-28 ~ 2026-10-04/);assert.match(html,/KST/);assert.doesNotMatch(html,/11\/11/);
});

test('past week with no earlier inventory never borrows a future stock snapshot',()=>{
 const state=R.applySources(C.empty(),[source('india','2026-10-12','latest.xlsx')],'2026-10-12');
 const m=U.buildModel({state,reportDate:'2026-09-21',mode:'new'});
 assert.equal(m.slots.find(s=>s.key==='india').source,null);assert.equal(m.sourceCounts.other.available,0);
 assert.match(U.render({state,reportDate:'2026-09-21',mode:'new'}),/최신 재고를 과거에 소급하지 않으며/);
});

test('WIP-only partial upload stays valid while absent SIEL is displayed without blocking',()=>{
 const state=C.empty(),staged=[source('wip','2026-09-21','wip.xlsb')],review=P.evaluate(state,staged,'2026-09-21');
 const model=U.buildModel({state,staged,review,reportDate:'2026-09-21'});
 assert.equal(model.canApply,true);assert.equal(model.sourceCounts.wip.available,1);assert.equal(model.sourceCounts.other.missing,7);
});

test('analysis, saving and calculation stages show real elapsed time without fabricated percentages',()=>{
 const base={state:C.empty(),reportDate:'2026-09-21',busy:true};
 for(const [phase,label] of [['analyzing','파일 분석'],['saving','원본 저장'],['calculating','결과 계산']]){
  const html=U.render({...base,job:{phase,elapsedMs:67400}});
  assert.match(html,new RegExp('class="active">[0-9]\\. '+label));assert.match(html,/data-up-elapsed>경과 1분 7초/);assert.doesNotMatch(html,/100%|남은 시간/);
 }
 const failed=U.render({...base,busy:false,job:{phase:'failed',elapsedMs:1000,detail:'Disk error'}});assert.match(failed,/반영 실패 · 기존 자료 유지/);assert.match(failed,/Disk error/);
});

test('empty start clearly identifies the selected old week and folder inputs remain available',()=>{
 const html=U.render({state:C.empty(),reportDate:'2026-09-21',mode:'new'});
 assert.match(html,/아직 반영된 주간 자료가 없습니다/);assert.match(html,/보고 주차 · 월요일/);assert.match(html,/id="report-date" type="date" value="2026-09-21"/);assert.match(html,/id="folder-files" type="file" webkitdirectory directory multiple/);assert.match(html,/여러 주를 섞지 말고 한 주씩/);
});


test('review shows automatically advanced cutoff without changing selected week or source dates',()=>{
 const state=C.empty(),staged=[source('wip','2026-09-27','wip.xlsb')],review=P.evaluate(state,staged,'2026-09-27'),before=JSON.stringify(staged);
 const model=U.buildModel({state,staged,review,reportDate:'2026-09-21'}),html=U.render({state,staged,review,reportDate:'2026-09-21'});
 assert.equal(model.reportDate,'2026-09-21');assert.equal(model.effectiveReportDate,'2026-09-27');assert.equal(model.week,'2026-09-21');
 assert.match(html,/id="report-date" type="date" value="2026-09-21"/);assert.match(html,/반영될 보고 기준일 2026-09-27/);assert.match(html,/선택한 주 안의 최신 자료 날짜를 자동 적용/);assert.equal(JSON.stringify(staged),before);
 const other=U.buildModel({state,review:{...review,reportDate:'2026-09-28'},reportDate:'2026-09-21'});assert.equal(other.effectiveReportDate,'2026-09-21');
});
