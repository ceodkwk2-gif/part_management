'use strict';
// Synthetic data only. Verify lazy source storage, durable metadata writes and
// migration without depending on the current week's operating workbooks.
const test=require('node:test'),assert=require('node:assert/strict');
const fs=require('node:fs'),path=require('node:path'),os=require('node:os'),crypto=require('node:crypto'),zlib=require('node:zlib');
const {createStore}=require('../server/store.cjs');
const {reference}=require('../server/source-blobs.cjs');
const C=require('../src/core.js'),R=require('../src/reporting.js');
const PART='1000-000001',sha=bytes=>crypto.createHash('sha256').update(bytes).digest('hex');
const copy=value=>JSON.parse(JSON.stringify(value));
function dashboard(date='2024-08-12',stock=1){return {type:'dashboard',center:'Flex',operator:'',date,dateLabel:date,file:'Synthetic '+date+'.xlsx',sheet:'Dashboard',holdDate:date,usageMonths:['2024-07'],rows:[{part:PART,row:2,stock,po:0,hold:3,usage:{'2024-07':2}}]};}
function wip(date='2024-08-12'){const rows=Array.from({length:12},(_,i)=>({key:'S'+i,status:'Waiting for Component',sn:'S'+i,rma:'R'+i,receipt:'2024-07-01',row:i+2,tokens:{parts:{[PART]:1},unparsed:''}}));return {type:'wip',center:'Flex',operator:'Jio',date,file:'Synthetic WIP '+date+'.xlsb',sheet:'InHouse',rows,statuses:Object.fromEntries(rows.map(row=>[row.key,row.status])),duplicates:[]};}
function fixture(){
 let state=R.normalizeState({...C.empty(),sources:[dashboard(),wip(),{type:'india',date:'2024-08-12',file:'Synthetic India.xlsx',sheet:'Stock',rows:[{part:PART,row:2,qty:10}]}],notes:{[PART]:'Original note'}});
 state=R.applySources(state,[dashboard('2024-08-12',7),wip('2024-08-19')],'2024-08-19');
 return R.applySources(state,[dashboard('2024-08-26',11),wip('2024-08-26')],'2024-08-26');
}
function temp(t){const dir=fs.mkdtempSync(path.join(os.tmpdir(),'parts-blobs-test-'));t.after(()=>fs.rmSync(dir,{recursive:true,force:true}));return dir;}
function blobFiles(dir){const folder=path.join(dir,'sources');return fs.existsSync(folder)?fs.readdirSync(folder).filter(name=>name.endsWith('.json.gz')).sort():[];}
function blobSnapshot(dir){return Object.fromEntries(blobFiles(dir).map(name=>{const file=path.join(dir,'sources',name),stat=fs.statSync(file,{bigint:true});return [name,{size:String(stat.size),mtime:String(stat.mtimeNs),hash:sha(fs.readFileSync(file))}];}));}
function monitoredFs(dir){
 const io=Object.create(fs),reads=[],writes=[],folder=path.join(dir,'sources')+path.sep;
 const isBlob=value=>typeof value==='string'&&value.startsWith(folder);
 io.readFileSync=(file,...args)=>{if(isBlob(file))reads.push(path.basename(file));return fs.readFileSync(file,...args);};
 io.openSync=(file,flags,...args)=>{if(isBlob(file)&&/[wa+]/.test(String(flags)))writes.push(path.basename(file));return fs.openSync(file,flags,...args);};
 return {io,reads,writes,clear(){reads.length=0;writes.length=0;}};
}
function refOf(source){return {key:C.sourceKey(source),revision:source.reportingRevision};}
function refKey(ref){return JSON.stringify([ref.key,ref.revision]);}
function compactChecks(manifest){
 assert.equal(Object.hasOwn(manifest.state,'sources'),false);assert.equal(Object.hasOwn(manifest.state,'reportingSourceArchive'),false);
 assert.ok(Array.isArray(manifest.sourceIndex));assert.ok(Array.isArray(manifest.currentSourceRefs));assert.ok(manifest.archiveSourceRefs&&typeof manifest.archiveSourceRefs==='object');
 for(const entry of manifest.sourceIndex){assert.equal(typeof entry.key,'string');assert.equal(typeof entry.revision,'string');assert.match(entry.hash,/^[a-f0-9]{64}$/);assert.ok(entry.meta);assert.equal(Object.hasOwn(entry.meta,'rows'),false);assert.equal(Object.hasOwn(entry.meta,'statuses'),false);}
}

test('compact manifest omits source payloads while key/revision and hash reads preserve full legacy state',t=>{
 const seed=fixture(),store=createStore({dataDir:temp(t),seedState:seed}),manifest=store.compactManifest();
 compactChecks(manifest);assert.equal(manifest.revision,0);assert.deepEqual(store.read().state,seed);
 assert.ok(Object.keys(manifest.archiveSourceRefs).length>0,'fixture retains a genuinely older same-key revision');
 assert.equal(new Set(manifest.sourceIndex.map(refKey)).size,manifest.sourceIndex.length);
 const expected=seed.sources[0],entry=manifest.sourceIndex.find(item=>refKey(item)===refKey(refOf(expected)));
 assert.ok(entry);assert.deepEqual(store.readSources([refOf(expected)]),[expected]);assert.deepEqual(store.readSources([{hash:entry.hash}]),[expected]);
 const leaked=store.readSources([{hash:entry.hash}]);leaked[0].rows[0].stock=999;
 assert.deepEqual(store.readSources([refOf(expected)]),[expected]);
 manifest.state.notes[PART]='External mutation';assert.equal(store.compactManifest().state.notes[PART],'Original note');
});

test('saving notes reads and rewrites zero source blobs and preserves file count, bytes and modification times',t=>{
 const dir=temp(t),monitor=monitoredFs(dir),store=createStore({dataDir:dir,seedState:fixture(),fs:monitor.io});
 const before=blobSnapshot(dir),manifest=store.compactManifest();assert.ok(Object.keys(before).length>1);monitor.clear();
 const saved=store.saveMetadata({patch:{notes:{...manifest.state.notes,[PART]:'Confirmed delivery next week'}},baseRevision:0,operation:'notes'});
 compactChecks(saved);assert.equal(saved.revision,1);assert.equal(saved.state.notes[PART],'Confirmed delivery next week');
 assert.deepEqual(monitor.reads,[]);assert.deepEqual(monitor.writes,[]);assert.deepEqual(blobSnapshot(dir),before);
 assert.deepEqual(saved.sourceIndex,manifest.sourceIndex);assert.deepEqual(saved.currentSourceRefs,manifest.currentSourceRefs);assert.deepEqual(saved.archiveSourceRefs,manifest.archiveSourceRefs);
 store.close();const reopened=createStore({dataDir:dir});assert.equal(reopened.read().state.notes[PART],'Confirmed delivery next week');
 assert.equal(reopened.listCommits()[0].operation,'notes');
});

test('reading one saved report hydrates only that report sources, including its archived revision',t=>{
 const dir=temp(t),seed=fixture();createStore({dataDir:dir,seedState:seed}).close();
 const monitor=monitoredFs(dir),store=createStore({dataDir:dir,fs:monitor.io}),manifest=store.compactManifest(),id='2024-08-12';monitor.clear();
 const reportState=store.readReportState(id),expected=R.reportState(seed,id),allowed=new Set(expected.sources.map(source=>manifest.sourceIndex.find(entry=>refKey(entry)===refKey(refOf(source))).hash+'.json.gz'));
 assert.deepEqual(reportState.sources,expected.sources);assert.equal(reportState.selectedReportingWeek,id);
 assert.equal(Object.keys(reportState.reportingSourceArchive||{}).length,0);
 assert.ok(monitor.reads.every(name=>allowed.has(name)),'no unrelated later-week source payload is read');
 assert.ok(reportState.sources.length<seed.sources.length+Object.keys(seed.reportingSourceArchive).length);
 assert.equal(C.calculate(reportState,'2024-08-12','Flex').parts[0].stock,1);
 assert.throws(()=>store.readReportState('2099-01-01'));
});

test('a source hash mismatch fails closed without silently returning altered rows or changing the selected generation',t=>{
 const dir=temp(t),store=createStore({dataDir:dir,seedState:fixture()}),manifest=store.compactManifest(),entry=manifest.sourceIndex[0];store.close();
 const pointer=fs.readFileSync(path.join(dir,'current.json')),file=path.join(dir,'sources',entry.hash+'.json.gz');
 fs.writeFileSync(file,zlib.gzipSync(Buffer.from(JSON.stringify({...dashboard(),rows:[{part:PART,row:2,stock:999}]}))));
 assert.throws(()=>{const reopened=createStore({dataDir:dir});reopened.readSources([{hash:entry.hash}]);});
 assert.deepEqual(fs.readFileSync(path.join(dir,'current.json')),pointer);
});

test('backup contains committed source blobs and raw files but excludes pending originals and orphan blobs',t=>{
 const dir=temp(t),restoreDir=temp(t),store=createStore({dataDir:dir,seedState:fixture()});
 const raw=store.addRaw({name:'Committed.xlsx',bytes:Buffer.from('committed original')});
 store.save({state:store.read().state,baseRevision:0,rawIds:[raw.id]});
 const pending=store.addRaw({name:'Pending.xlsx',bytes:Buffer.from('pending original')}),orphanHash='f'.repeat(64);
 assert.equal(store.compactManifest().sourceIndex.some(item=>item.hash===orphanHash),false);
 fs.writeFileSync(path.join(dir,'sources',orphanHash+'.json.gz'),zlib.gzipSync(Buffer.from('uncommitted source')));
 const entries=store.backupEntries(),names=new Set(entries.map(entry=>entry.name));
 for(const entry of store.compactManifest().sourceIndex)assert.ok(names.has('sources/'+entry.hash+'.json.gz'));
 assert.ok(names.has('raw/'+raw.sha256+'.bin'));assert.equal(names.has('raw/'+pending.sha256+'.bin'),false);assert.equal(names.has('sources/'+orphanHash+'.json.gz'),false);
 for(const entry of entries){const target=path.join(restoreDir,entry.name);fs.mkdirSync(path.dirname(target),{recursive:true});fs.writeFileSync(target,entry.bytes);}
 const restored=createStore({dataDir:restoreDir});assert.deepEqual(restored.read(),store.read());assert.deepEqual(restored.readRaw(raw.id).bytes,Buffer.from('committed original'));
 assert.deepEqual(restored.readReportState('2024-08-12').sources,R.reportState(fixture(),'2024-08-12').sources);
});

function writeLegacy(dir,state){
 const generation='000000000000-'+crypto.randomUUID()+'.json.gz',updatedAt='2024-08-26T10:00:00.000Z';
 const envelope={format:1,state,revision:0,updatedAt,raw:{},commits:[{revision:0,updatedAt,operation:'initialize',reportDate:'2024-08-26',week:'2024-08-26',rawIds:[],generation}]};
 const bytes=zlib.gzipSync(Buffer.from(JSON.stringify(envelope))),pointer={format:1,revision:0,generation,sha256:sha(bytes)};
 fs.mkdirSync(path.join(dir,'generations'),{recursive:true});fs.writeFileSync(path.join(dir,'generations',generation),bytes);fs.writeFileSync(path.join(dir,'current.json'),JSON.stringify(pointer));
 return {generation,bytes,pointerBytes:fs.readFileSync(path.join(dir,'current.json'))};
}

test('explicit migration preserves a manually written format 1 generation and its exact state while publishing format 2',t=>{
 const dir=temp(t),seed=fixture(),legacy=writeLegacy(dir,seed),store=createStore({dataDir:dir,seedState:C.empty()});
 assert.deepEqual(store.read().state,seed);compactChecks(store.compactManifest());
 assert.deepEqual(fs.readFileSync(path.join(dir,'current.json')),legacy.pointerBytes,'reading legacy data does not publish a migration');
 const migrated=store.migrate({baseRevision:0});compactChecks(migrated);assert.equal(migrated.revision,1);
 const pointer=JSON.parse(fs.readFileSync(path.join(dir,'current.json'),'utf8')),generation=JSON.parse(zlib.gunzipSync(fs.readFileSync(path.join(dir,'generations',pointer.generation))).toString('utf8'));
 assert.equal(generation.format,2);assert.deepEqual(fs.readFileSync(path.join(dir,'generations',legacy.generation)),legacy.bytes);
 assert.deepEqual(fs.readFileSync(path.join(dir,'previous.json')),legacy.pointerBytes);assert.deepEqual(store.read().state,seed);
 store.close();const reopened=createStore({dataDir:dir});assert.deepEqual(reopened.read().state,seed);assert.equal(reopened.read().revision,1);
 assert.ok(reopened.backupEntries().some(entry=>entry.name==='generations/'+legacy.generation));
});

test('manifest save supports metadata-only updates, rejects stale writers and refuses unresolved source references',t=>{
 const dir=temp(t),store=createStore({dataDir:dir,seedState:fixture()}),initial=store.compactManifest(),changed=copy(initial);
 changed.state.settings.hqMonths=4;
 const saved=store.saveManifest({manifest:changed,sources:[],baseRevision:0,operation:'settings'});
 compactChecks(saved);assert.equal(saved.revision,1);assert.equal(store.read().state.settings.hqMonths,4);assert.deepEqual(saved.sourceIndex,initial.sourceIndex);
 assert.throws(()=>store.saveMetadata({patch:{notes:{[PART]:'Stale'}},baseRevision:0,operation:'notes'}),error=>error.status===409);
 assert.throws(()=>store.saveManifest({manifest:changed,sources:[],baseRevision:0,operation:'settings'}),error=>error.status===409);
 const invalid=copy(saved);invalid.state.reportingWeeks[0].sourceRefs[0].revision='missing-source-revision';
 assert.throws(()=>store.saveManifest({manifest:invalid,sources:[],baseRevision:1,operation:'update'}));
 assert.equal(store.compactManifest().revision,1);assert.equal(store.read().state.settings.hqMonths,4);
});

test('metadata save persists the actual partLeadTimes field and rejects a nonexistent selected report',t=>{
 const dir=temp(t),store=createStore({dataDir:dir,seedState:fixture()}),before=blobSnapshot(dir);
 const partLeadTimes={[PART]:{longLead:true,months:6,note:'Manufacturer PO to HQ receipt'}};
 const saved=store.saveMetadata({patch:{partLeadTimes},baseRevision:0,operation:'settings'});
 compactChecks(saved);assert.equal(saved.revision,1);assert.deepEqual(saved.state.partLeadTimes,partLeadTimes);
 assert.deepEqual(blobSnapshot(dir),before);
 assert.throws(()=>store.saveMetadata({patch:{selectedReportingWeek:'2099-01-01'},baseRevision:1,operation:'settings'}));
 assert.equal(store.compactManifest().revision,1);assert.equal(store.compactManifest().state.selectedReportingWeek,'2024-08-26');
 store.close();assert.deepEqual(createStore({dataDir:dir}).read().state.partLeadTimes,partLeadTimes);
});

test('saving a new source for the current report never reads unchanged historical-only source blobs',t=>{
 const dir=temp(t),monitor=monitoredFs(dir),store=createStore({dataDir:dir,seedState:fixture(),fs:monitor.io}),manifest=store.compactManifest();
 const latest=manifest.state.reportingWeeks.find(report=>report.id==='2024-08-26'),previousReports=copy(manifest.state.reportingWeeks.filter(report=>report.id!=='2024-08-26'));
 const oldRef=latest.sourceRefs.find(ref=>manifest.sourceIndex.find(item=>refKey(item)===refKey(ref)).meta.type==='dashboard');
 const source=R.normalizeState({...C.empty(),sources:[dashboard('2024-08-26',17)]}).sources[0],newRef=reference(source);
 latest.sourceRefs=latest.sourceRefs.map(ref=>refKey(ref)===refKey(oldRef)?newRef:ref);latest.updatedAt='2024-08-27T10:00:00.000Z';
 manifest.currentSourceRefs=manifest.currentSourceRefs.map(ref=>refKey(ref)===refKey(oldRef)?newRef:ref);
 manifest.archiveSourceRefs[refKey(oldRef)]=oldRef;
 const activeKeys=new Set(latest.sourceRefs.map(refKey)),historicalOnly=new Set(previousReports.flatMap(report=>report.sourceRefs).filter(ref=>!activeKeys.has(refKey(ref))).map(ref=>manifest.sourceIndex.find(item=>refKey(item)===refKey(ref)).hash+'.json.gz'));
 assert.ok(historicalOnly.size>=3);monitor.clear();
 const saved=store.saveManifest({manifest,sources:[source],baseRevision:0,operation:'import',reportDate:'2024-08-26'});
 assert.equal(saved.revision,1);
 assert.deepEqual(monitor.reads.filter(name=>historicalOnly.has(name)),[],'unchanged earlier reports must not be hydrated just because one new source arrived');
 assert.deepEqual(saved.state.reportingWeeks.filter(report=>report.id!=='2024-08-26'),previousReports);
 assert.equal(C.calculate(store.readReportState('2024-08-26'),'2024-08-26','Flex').parts[0].stock,17);
 assert.equal(C.calculate(store.readReportState('2024-08-12'),'2024-08-12','Flex').parts[0].stock,1);
});

test('streaming backup descriptors verify raw files in fixed chunks without retaining raw buffers',t=>{
 const dir=temp(t),io=Object.create(fs);let prohibitWholeRawRead=false,maxRead=0;
 io.readFileSync=(file,...args)=>{if(prohibitWholeRawRead&&typeof file==='string'&&file.startsWith(path.join(dir,'raw')+path.sep))throw Error('Whole raw read is forbidden');return fs.readFileSync(file,...args);};
 io.readSync=(fd,buffer,offset,length,position)=>{maxRead=Math.max(maxRead,length);return fs.readSync(fd,buffer,offset,length,position);};
 const store=createStore({dataDir:dir,seedState:fixture(),fs:io}),bytes=Buffer.alloc(3*1024*1024+71,42),raw=store.addRaw({name:'Large synthetic.xlsx',bytes});
 store.save({state:store.read().state,baseRevision:0,rawIds:[raw.id]});prohibitWholeRawRead=true;
 const entries=store.backupFileEntries(),original=entries.find(entry=>entry.name==='raw/'+raw.sha256+'.bin');
 assert.ok(original);assert.equal(original.size,bytes.length);assert.equal(original.sha256,sha(bytes));assert.equal(original.bytes,undefined);assert.ok(maxRead<=1024*1024);
 assert.ok(entries.filter(entry=>entry.name.startsWith('sources/')||entry.name.startsWith('generations/')).every(entry=>entry.path&&!entry.bytes));
 const fixedPointer=Buffer.from(entries.find(entry=>entry.name==='current.json').bytes);
 store.saveMetadata({patch:{notes:{afterBackup:true}},baseRevision:1});assert.deepEqual(entries.find(entry=>entry.name==='current.json').bytes,fixedPointer);
 const originalPath=original.path,fd=fs.openSync(originalPath,'r+');fs.writeSync(fd,Buffer.from('changed'),0,7,0);fs.closeSync(fd);
 assert.throws(()=>store.backupFileEntries(),error=>error.code==='RAW_INTEGRITY_ERROR');
});

test('legacy cumulative report references hydrate only the latest source per slot without changing saved history or calculations',t=>{
 const dir=temp(t),seed=fixture(),report=seed.reportingWeeks.find(item=>item.id==='2024-08-26');report.sourceRefs=seed.sources.map(refOf);
 assert.ok(report.sourceRefs.length>3);const expected=C.calculate(R.reportState(seed,report.id),report.cutoff),monitor=monitoredFs(dir),store=createStore({dataDir:dir,seedState:seed,fs:monitor.io}),manifest=store.compactManifest();monitor.clear();
 const selected=store.readReportState(report.id);assert.equal(selected.sources.length,3);assert.equal(selected.reportingWeeks[0].sourceRefs.length,3);assert.equal(monitor.reads.length,3);
 assert.deepEqual(C.calculate(selected,report.cutoff),expected);assert.deepEqual(R.reportWarnings(selected,report.id),[]);
 assert.deepEqual(store.compactManifest().state.reportingWeeks,manifest.state.reportingWeeks);assert.deepEqual(store.read().state,seed);
});
