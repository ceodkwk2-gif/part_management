'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const I=require('../src/i18n.js');
const Operations=require('../src/operations.js');
test('language is presentation-only and Korean remains the source text',()=>{
 const source='1개월분 부족 · 발주 필요';
 I.setLanguage('ko',{persist:false});assert.equal(I.text(source),source);
 I.setLanguage('en',{persist:false});assert.equal(I.text(source),'1-month stock shortfall · PO needed');
 assert.equal(I.text('0.5개월분 부족 · 입고 대기'),'0.5-month stock shortfall · Awaiting receipt');
 assert.equal(I.text(source,'ko'),source);assert.equal(I.text(null),null);assert.equal(I.text(12.5),12.5);
 I.setLanguage('invalid',{persist:false});assert.equal(I.getLanguage(),'ko');
});
test('one total additional PO instruction survives translation, not duplicate repair and total orders',()=>{
 const row={needed:44,target:17,stock:0,open:0,proposed:61};
 const before=JSON.stringify(row),source=Operations.orderActionText(row),translated=I.text(source,'en');
 assert.equal(translated,'Total additional PO needed: 61 pcs (Current repair need 44 + 1-month stock target 17 − Center stock 0 − Open PO 0)');
 assert.equal((translated.match(/PO needed:/g)||[]).length,1);assert.equal(JSON.stringify(row),before);
 assert.equal(I.text('현재 수리용 PO 4개 필요 (보유분·총 추가 PO 미계산)','en'),'PO needed for current repairs: 4 pcs (reserve and total additional PO not calculated)');
});
test('ETD localization preserves dispatch semantics without inventing receipt',()=>{
 assert.equal(I.text('기존 PO 57개 입고 대기 (ETD 미정)','en'),'Existing PO 57 pcs awaiting receipt (ETD not set)');
 assert.equal(I.text('기존 PO 121개 입고 대기 (법인 출고 예정 2026-10-02)','en'),'Existing PO 121 pcs awaiting receipt (India planned dispatch 2026-10-02)');
 const action=I.text('[CTDI] 기존 PO 57개 공급 일정·출고 여부 확인 · 본사 자재 확보 요청 검토\n[Flex] 추가 PO 총 4개 필요','en');
 assert.ok(!/[가-힣]/.test(action));assert.match(action,/\[CTDI\].*57 pcs/);assert.match(action,/\n\[Flex\]/);
});
test('planned and undated PO portions keep their own quantities in English actions and CSV exports',()=>{
 const planned='기존 PO 2개 · 법인 출고 예정 2024-08-19';
 const unscheduled='기존 PO 3개 입고 대기 (ETD 미정) · 법인·본사 공급 일정 확인';
 const hq='기존 PO 3개 · 본사 자재 확보·공급 일정 확인 (ETD 미정)';
 const notes=[
  'ETD는 법인에서 센터로 보낼 예정일이며 실제 출고·센터 입고를 확정하지 않습니다.',
  '조치 담당은 다음 업무 담당이며 지연 귀책 판정이 아닙니다.',
  '기존 법인 요청·구매 진행을 확인하며 신규 구매수량을 자동 확정하지 않습니다.'];
 assert.equal(I.text(planned,'en'),'Existing PO 2 pcs · India planned dispatch 2024-08-19');
 assert.equal(I.text(unscheduled,'en'),'Existing PO 3 pcs awaiting receipt (ETD not set) · Check the India / HQ supply schedule');
 assert.equal(I.text(hq,'en'),'Existing PO 3 pcs · Check HQ parts availability and supply schedule (ETD not set)');
 const combined=I.text(planned+' / '+unscheduled,'en');
 assert.match(combined,/Existing PO 2 pcs.*Existing PO 3 pcs/);assert.doesNotMatch(combined,/Existing PO 5 pcs/);
 const result=I.translateCsv(['부품 코드','필요 조치','판단 근거'],[['TEST-000001',planned+' / '+unscheduled,notes.join(' ')]],'en');
 assert.doesNotMatch(JSON.stringify(result),/[가-힣]/);assert.match(result.rows[0][2],/not confirmation/);assert.match(result.rows[0][2],/not a finding of delay responsibility/);
 assert.equal(I.text(planned,'ko'),planned);
});
test('FAN and general products retain unit counts and age labels',()=>{
 assert.equal(I.text('FAN 132대 · 일반 제품 358대','en'),'FAN 132 units · General products 358 units');
 assert.equal(I.text('입고 45일 초과','en'),'Over 45 days since receipt');
 assert.equal(I.text('45일 초과 · 부품 수량(개)','en'),'Over 45 days · Part qty (pcs)');
 assert.equal(I.text('잠정 0개월','en'),'Provisional 0 months');
 assert.equal(I.text('54일 · 45일 초과','en'),'54 days · Over 45 days');
 assert.equal(I.text('월평균소요량_계산원값_개','en'),'Avg monthly use_RawValue_pcs');
});
test('CSV translates generated headers and actions but preserves raw data and memo values',()=>{
 const headers=['부품 코드','부품명','센터','필요 조치','원본 부품 설명','PO기발주_원본파일','PO기발주_원본시트','Required Part 원문','원본 상태','장납메모','메모','검색 조건','현재 부족량'];
 const rows=[['명판','명판','Flex','추가 PO 총 61개 필요','본사 재고 없음','법인.xlsx','센터 재고','수리센터 #2','확인완료','본사에 확인 필요','법인 재고 확인','법인 재고',44]];
 const snapshot=JSON.stringify({headers,rows}),english=I.translateCsv(headers,rows,'en');
 assert.equal(english.rows[0][0],'명판');assert.equal(english.rows[0][1],'Nameplate');assert.equal(english.rows[0][3],'Total additional PO needed: 61 pcs');
 for(const index of [4,5,6,7,8,9,10,11])assert.equal(english.rows[0][index],rows[0][index]);
 assert.equal(english.rows[0][12],44);assert.equal(JSON.stringify({headers,rows}),snapshot);
 assert.deepEqual(I.translateCsv(headers,rows,'ko'),{headers,rows});
});
test('file names and source columns are protected without protecting generated action columns',()=>{
 for(const header of ['SN','RMA','PO','Item','원본','시트','이전원본','이번원본','제품 코드','원본 설명','부품 코드·명칭','Required Part 원문'])assert.equal(I.isRawColumn(header),true,header);
 for(const header of ['필요 조치','수리센터 조치','법인 조치','본사 조치','원본 기준일','조치 담당'])assert.equal(I.isRawColumn(header),false,header);
 assert.equal(I.rawFileText('법인 재고.xlsx'),true);assert.equal(I.rawFileText('센터 재고 4개'),false);
});
test('CSV decision evidence retains every numeric term and zero-demand meaning in English',()=>{
 const formula='현 수리 필요 수 44개 − 센터 재고 0개 = 지금 44개 부족 / 필요 44개 + 보유 목표 17개 − 재고 0개 − 미입고 PO 0개 = 추가 발주 61개';
 const translated=I.text(formula,'en');assert.ok(!/[가-힣]/.test(translated));assert.deepEqual(translated.match(/\d+/g),formula.match(/\d+/g));
 const zero=I.text('현 수리 필요 수 0개 · 센터 재고 0개: 확인된 현 수리 수요 없음, 대응 재고 없음','en');assert.match(zero,/no known current repair demand and no stock available/);assert.doesNotMatch(zero,/repairable|repair possible/i);
});
