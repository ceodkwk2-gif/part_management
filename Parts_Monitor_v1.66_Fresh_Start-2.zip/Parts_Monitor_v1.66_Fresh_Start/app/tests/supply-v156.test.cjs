'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const S=require('../src/supply-stages.js'),D=require('../src/stage-data.js'),A=require('../src/action-requests.js'),Share=require('../src/share-dialog.js'),C=require('../src/core.js'),X=require('../vendor/xlsx.full.min.js');
const row=(x={})=>({id:'CTDI|TEST-000001',center:'CTDI',part:'TEST-000001',shortage:10,needed:10,stock:0,target:5,proposed:5,open:10,india:0,hq:0,siel:[],pos:[],...x});
const po=(x={})=>({po:'00001',item:'10',ordered:10,pending:10,stage:'hq-order',...x});
const project=(rs,source={available:true})=>Object.fromEntries([...S.classify(rs,source)].map(([id,as])=>[id,Object.fromEntries([...new Set(as.map(a=>a.code))].map(code=>[code,as.filter(a=>a.code===code).reduce((s,a)=>s+a.quantity,0)]))]));
const cases=[
 ['center must issue PO even if India stock exists',{open:0,india:100},{ORDER:10}],
 ['partially ordered repair qty',{open:4,india:4},{ORDER:6,DISPATCH:4}],
 ['India has available stock',{india:10},{DISPATCH:10}],
 ['HQ stock cannot replace India PO',{hq:100},{INDIA_ORDER:10}],
 ['India PO already issued',{siel:[po()]},{HQ:10}],
 ['three distinct supply quantities',{india:3,siel:[po({pending:4})]},{DISPATCH:3,HQ:4,INDIA_ORDER:3}],
 ['missing center PO',{open:null},{OTHER:10}],['missing India stock',{india:null},{OTHER:10}],
 ['missing India PO report',{}, {OTHER:10},{available:false}],
 ['SIEL order and ETA do not require a physical pending field',{siel:[po({pending:null,documentPending:null,eta:'2027-01-05'})]},{HQ:10}],
 ['Delivery does not remove a placed order from the status',{siel:[po({pending:null,documentPending:0,documentedQty:10})]},{HQ:10}],
 ['Delivery quantity is not deducted from SIEL reported orders',{siel:[po({pending:null,documentPending:6,documentedQty:4})]},{HQ:10}],
 ['dashboard balance higher than detailed PO',{pos:[{pending:6,shipped:4}],india:10},{OTHER:4,DISPATCH:6}],
 ['detailed PO higher than dashboard balance',{open:6,pos:[{pending:10}],india:6},{OTHER:4,DISPATCH:6}],
 ['duplicate identical HQ items',{siel:[po(),po()]},{HQ:10}],
 ['conflicting HQ items',{siel:[po(),po({pending:5})]},{OTHER:10}]
];
for(const [title,patch,expected,source] of cases)test('four-stage routing: '+title,()=>{assert.deepEqual(project([row(patch)],source)[row().id],expected)});
test('shared partial stock and PO never acquire an invented center allocation when filtered',()=>{
 const rows=[row({india:5}),row({id:'Flex|TEST-000001',center:'Flex',india:5})];
 assert.deepEqual(Object.values(project(rows)),[{OTHER:10},{OTHER:10}]);
 for(const r of rows){r.india=0;r.siel=[po({pending:15})]};assert.deepEqual(Object.values(project(rows)),[{OTHER:10},{OTHER:10}]);
 for(const r of rows)r.siel=[po({pending:20})];assert.deepEqual(Object.values(project(rows)),[{HQ:10},{HQ:10}]);
 const d={asof:'2026-10-12',rows:rows.map(({siel,...r})=>r),siel:{available:true,rows:[{...po({pending:15}),part:'TEST-000001'}]}};
 assert(A.records(d,{center:'Flex'}).filter(a=>a.repairQuantity>0).every(a=>a.code==='OTHER'));
});
test('ETD changes never change the action stage',()=>{for(const etd of [null,'2026-01-01','2027-01-01'])assert.deepEqual(project([row({pos:[{pending:10,etd}],siel:[po()]})])[row().id],{HQ:10})});
function data(){return {asof:'2026-10-12',week:'2026-10-12',settings:{targetMonths:1},rows:[row({open:4,india:4,proposed:11,name:'Fan, "large"\nline 2',currentAssessed:true,orderAssessed:true}),row({id:'Flex|TEST-000002',center:'Flex',part:'TEST-000002',shortage:0,stock:10,needed:1,open:0,proposed:0,target:5})],products:[],pos:[],siel:{available:true,rows:[]},trend:[],sourceDates:[]};}
test('request adds repair and buffer once, preserves owner scope and never mutates uploaded data',()=>{
 const d=data(),before=JSON.stringify(d),rs=A.records(d);assert.equal(rs.length,2);const order=rs.find(a=>a.code==='ORDER');assert.equal(order.quantity,11);assert.equal(order.repairQuantity,6);assert.equal(order.bufferQuantity,5);assert.equal(rs.find(a=>a.code==='DISPATCH').quantity,4);
 assert.equal(A.records(d,{recipient:'CENTER'}).length,1);assert.equal(A.records(d,{recipient:'INDIA'}).length,1);assert.equal(A.records(d,{recipient:'HQ'}).length,0);assert.equal(A.records(d,{center:'Flex'}).length,0);assert.equal(A.records(d,{rowIds:[]}).length,0);assert.equal(JSON.stringify(d),before);
});
test('status exports merge stages per part and retain numeric quantities, BOM and formula escaping',()=>{
 const d=data();d.rows[0].name='=HYPERLINK("bad")';const model=Share.normalize(A.build(d,{recipient:'CENTER',language:'en'}),{language:'en'}),csv=Share.csv(model);
 assert.equal(model.rows.length,1);assert(csv.startsWith('\uFEFF'));assert(csv.includes("'=HYPERLINK"));assert.equal(typeof model.rows[0][model.columns.findIndex(c=>c.key==='proposed')],'number');
 assert(model.columns.length<=10);assert(!model.columns.some(c=>c.reply));assert(!csv.includes('Requested action'));assert(!csv.includes('Report date'));assert(!csv.includes('Source dates'));
 assert(!/[가-힣]/.test(JSON.stringify(model)));assert.equal(Share.safeCell('000123'),'000123');
 const escaped=Share.csv(Share.normalize(A.build(data(),{recipient:'CENTER'})));assert(escaped.includes('Fan, ""large""\nline 2'));
});
test('status Excel contains one compact native table, frozen header and text part codes',()=>{
 const model=Share.normalize(A.build(data(),{recipient:'CENTER',language:'en'}),{language:'en'}),bytes=Share.workbook([model],X),wb=X.read(bytes,{type:'array'}),z=X.CFB.read(bytes,{type:'array'}),read=name=>new TextDecoder().decode(X.CFB.find(z,'/'+name).content);
 assert.equal(wb.SheetNames.length,1);assert.equal(wb.Sheets[wb.SheetNames[0]].B2.v,'TEST-000001');assert.equal(wb.Sheets[wb.SheetNames[0]].H2.v,11);assert(!wb.Sheets[wb.SheetNames[0]].B2.f);
 assert.match(read('xl/worksheets/sheet1.xml'),/state="frozen"/);assert.match(read('xl/worksheets/sheet1.xml'),/<tablePart r:id="rIdTable"/);assert.match(read('xl/tables/table1.xml'),/<autoFilter ref="A1:J2"/);assert.match(read('xl/styles.xml'),/FFE8F3FF/);
 assert.equal(z.FullPaths.filter(n=>n.endsWith('/xl/styles.xml')).length,1);
});
test('exclusive summary gives a shared part the highest-priority category but requests retain other center actions',()=>{
 const d=data();d.rows.push(row({id:'Flex|TEST-000001',center:'Flex',shortage:0,needed:0,stock:0,open:0,proposed:5,currentAssessed:true,orderAssessed:true}));
 const out=D.build(d);assert.equal(out.indexes.ALL.SHORTAGE.length,1);assert.equal(out.indexes.ALL.ORDER.length,0);assert.equal(out.indexes.Flex.ORDER.length,1);assert(A.records(d,{center:'Flex'}).some(a=>a.code==='ORDER'));
});
test('all saved calendar weeks accumulate, missing weeks are gaps and unknown metrics are not zero',()=>{
 const out=D.calendarTrend([{week:'2026-09-21',metricsByCenter:{'전체':{shortageKinds:3}}},{week:'2026-10-05',metricsByCenter:{'전체':{shortageKinds:null}}}]);assert.deepEqual(out.map(p=>p.week),['2026-09-21','2026-09-28','2026-10-05']);assert(out[1].missing);assert.equal(out[1].metrics['전체'],undefined);assert.equal(out[2].metrics['전체'].shortageKinds, null);
});
test('CTDI compact ETD uses DDMMYY; Excel serial, Flex order and invalid days remain distinct',()=>{
 assert.equal(C.scheduleDate('171026','dmy'),'2026-10-17');assert.equal(C.scheduleDate(171026,'dmy'),'2026-10-17');assert.equal(C.scheduleDate('17/10/26','dmy'),'2026-10-17');assert.equal(C.scheduleDate('101726','mdy'),'2026-10-17');assert.equal(C.scheduleDate('17-Oct-26'),'2026-10-17');assert.equal(C.scheduleDate('290227'),null);assert.equal(C.scheduleDate('not a date'),null);assert.equal(C.scheduleDate(45000),C.date(45000));assert.equal(C.date('171026'),null);
});
test('Open PO Report compact filename uses DDMMYY while SIEL and generic filenames retain their own date rules',()=>{
 const wb=X.utils.book_new();X.utils.book_append_sheet(wb,X.utils.aoa_to_sheet([['Part No','Pending Qty','Ship To Name','PO No','Item No','PO Qty','Shipped Qty','PO Date','ETD'],['TEST-000001',3,'CTDI Communications','00001',10,3,0,'2026-10-01','171026']]),'Sheet1');
 const source=C.importWorkbook(wb,'Open PO Report_171026.xlsx',X).sources[0];assert.equal(source.date,'2026-10-17');assert.equal(source.rows[0].etd,'2026-10-17');assert.equal(C.fileDate('SIEL_PO Summary_261019.xlsx'),'2026-10-19');assert.equal(C.importWorkbook(wb,'Open PO Report_171026.xlsx',X,{date:'2026-10-19'}).sources[0].date,'2026-10-19');
});
