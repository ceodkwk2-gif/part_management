'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm');
const X=require('../vendor/xlsx.full.min.js'),P=require('../src/packaging.js');
const readZip=bytes=>X.CFB.read(bytes,{type:'buffer'});
const content=(archive,name)=>X.CFB.find(archive,name)?.content;
test('Weekly ZIP preserves multiple HTML, JSON and Korean guide contents byte for byte',()=>{
 const files=[
  {name:'Parts_Monitor_Admin.html',content:'<!doctype html><title>주간 관리자 · 확인</title>'},
  {name:'Parts_Monitor_Viewer.html',content:'<!doctype html><title>팀원 조회본</title>'},
  {name:'Parts_Monitor_Data.json',content:JSON.stringify({selectedReportingWeek:'2026-09-28',note:'재고·소요량·조치 담당',quantity:7})},
  {name:'START_PARTS_MONITOR.md',content:'# 다음 주 갱신\n최신 작업본 열기 → 폴더 선택 → 반영·저장\n'}
 ];
 const zip=P.createZip(files),archive=readZip(zip);
 assert(zip instanceof Uint8Array);assert.deepEqual(Array.from(zip.slice(0,4)),[80,75,3,4]);
 for(const file of files)assert.equal(new TextDecoder().decode(content(archive,file.name)),file.content);
 const entries=archive.FileIndex.filter(entry=>entry.type===2&&entry.name!=='\u0001Sh33tJ5');
 assert.equal(entries.length,files.length);
 // ZIP local header method 8 is DEFLATE: repeated HTML should not be stored raw.
 assert.equal(new DataView(zip.buffer,zip.byteOffset,zip.byteLength).getUint16(8,true),8);
});
test('ZIP supports binary byte views without including surrounding buffer bytes',()=>{
 const surrounding=new Uint8Array([99,0,1,127,128,255,88]),bytes=surrounding.subarray(1,6);
 const archive=readZip(P.createZip([{name:'Data.bin',content:bytes}]));
 assert.deepEqual(Array.from(content(archive,'Data.bin')),Array.from(bytes));
 assert.deepEqual(Array.from(surrounding),[99,0,1,127,128,255,88]);
});
test('ZIP rejects absent data and empty files instead of silently omitting a backup',()=>{
 for(const files of [undefined,null,{},[]])assert.throws(()=>P.createZip(files),/파일이 없습니다/);
 for(const value of ['',new Uint8Array()])assert.throws(()=>P.createZip([{name:'Data.json',content:value}]),/빈 파일/);
 for(const value of [undefined,null,42,{},[],new ArrayBuffer(4)])assert.throws(()=>P.createZip([{name:'Data.json',content:value}]),/문자열 또는 Uint8Array/);
});
test('ZIP rejects unsafe paths, unsupported filenames and duplicates before packing',()=>{
 for(const name of ['../Data.json','folder/Data.json','folder\\Data.json','C:Data.json','.hidden','한글.json','A\0.json','Data.json.','Data.json ','a'.repeat(201)])assert.throws(()=>P.createZip([{name,content:'x'}]),/파일명/);
 assert.throws(()=>P.createZip([{name:'Data.json',content:'one'},{name:'data.JSON',content:'two'}]),/중복된 파일명/);
 assert.throws(()=>P.createZip([null]),/파일명/);
});
test('ZIP module exposes the browser API and fails clearly without the bundled writer',()=>{
 const source=fs.readFileSync(require.resolve('../src/packaging.js'),'utf8'),context={XLSX:X,TextEncoder,Uint8Array};
 context.self=context;vm.runInNewContext(source,context);
 const bytes=context.PartsPackage.createZip([{name:'Guide.md',content:'한글 저장'}]);
 assert.equal(new TextDecoder().decode(content(readZip(bytes),'Guide.md')),'한글 저장');
 const unavailable={TextEncoder,Uint8Array};unavailable.self=unavailable;vm.runInNewContext(source,unavailable);
 assert.throws(()=>unavailable.PartsPackage.createZip([{name:'Guide.md',content:'test'}]),/ZIP 저장 기능/);
});
