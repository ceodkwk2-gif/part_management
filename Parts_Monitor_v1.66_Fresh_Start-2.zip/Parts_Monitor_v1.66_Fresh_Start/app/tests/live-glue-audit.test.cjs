'use strict';
// Exercise the actual app wiring without claiming browser or layout coverage.
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const C=require('../src/core.js'),R=require('../src/reporting.js'),P=require('../src/pipeline.js'),U=require('../src/upload-flow.js');
const O=require('../src/overview.js'),Mail=require('../src/summary-mail.js'),Overdue=require('../src/overdue-mail.js');
const app=fs.readFileSync(path.join(__dirname,'../src/app.js'),'utf8');
function install(context,start,end){const a=app.indexOf(start),b=app.indexOf(end,a);assert(a>=0&&b>a);vm.runInContext(app.slice(a,b),context);}
const src=(type,file,date='2026-10-12')=>({type,file,date,dateLabel:date,sheet:'Sheet1',center:type==='india'?'India':type==='hq'?'HQ':'Flex',rows:[]});
function imports(parser){
 const c=vm.createContext({state:C.empty(),staged:[],stageExcluded:new Set(),importIssues:[],importChoices:{},importRawBySource:new WeakMap(),serverMode:true,serverSaving:false,serverPendingSave:null,busy:false,reportDateManual:false,importReportDate:'2026-10-12',packageStatus:null,importLog:'',R,PartsUploadFlow:U,PartsPipeline:P,render(){},toast(message){c.message=message},parseInWorker:parser,WeakMap,Set,Date,JSON,console});
 install(c,'async function importFiles(','function parseInWorker(');return c;
}
function file(name){return {name,arrayBuffer:async()=>new ArrayBuffer(1)}}

test('actual import glue appends successive selections and preserves staged cancellation',async()=>{
 const c=imports(async(_,name)=>({sources:[src(name==='flex.xlsx'?'dashboard':'india',name)]}));
 const first=file('flex.xlsx'),second=file('india.xlsx');
 await c.importFiles([first]);c.stageExcluded.add(0);await c.importFiles([second]);
 assert.deepEqual(Array.from(c.staged,s=>s.file),['flex.xlsx','india.xlsx']);assert(c.stageExcluded.has(0));
 assert.equal(c.importRawBySource.get(c.staged[1]),second);assert.equal(c.busy,false);
});
test('replacing one staged workbook preserves other files and reindexes their exclusions',async()=>{
 const c=imports(async(_,name)=>({sources:[src(name==='flex.xlsx'?'dashboard':'india',name)]}));
 await c.importFiles([file('flex.xlsx'),file('india.xlsx')]);c.stageExcluded.add(1);
 const corrected=file('flex.xlsx');await c.importFiles([corrected]);
 assert.deepEqual(Array.from(c.staged,s=>s.file),['india.xlsx','flex.xlsx']);assert.deepEqual(Array.from(c.stageExcluded),[0]);assert.equal(c.importRawBySource.get(c.staged[1]),corrected);
});
test('busy import ignores a concurrent selection instead of replacing its in-flight batch',async()=>{
 let release;const c=imports((_,name)=>new Promise(resolve=>{release=()=>resolve({sources:[src('dashboard',name)]})}));
 const first=c.importFiles([file('first.xlsx')]);await new Promise(resolve=>setImmediate(resolve));assert.equal(c.busy,true);
 await c.importFiles([file('second.xlsx')]);release();await first;
 assert.deepEqual(Array.from(c.staged,s=>s.file),['first.xlsx']);assert.equal(c.busy,false);
});
test('actual apply wiring commits raw files by active index after a different file was cancelled',async()=>{
 const c=imports(async(_,name)=>({sources:[src(name==='flex.xlsx'?'dashboard':'india',name)]}));
 await c.importFiles([file('flex.xlsx'),file('india.xlsx')]);c.stageExcluded.add(0);
 c.reviewReportDate=()=>c.importReportDate;c.persistServer=async(next,options,done)=>{c.saved={next,options};done();};
 install(c,'function activeStaged(','async function recordExistingWeek(');
 await c.applyImport();assert.equal(c.message,undefined);assert.deepEqual(Array.from(c.saved.options.rawFiles,f=>f.name),['india.xlsx']);
 assert.equal(c.saved.next.sources.filter(s=>s.type==='india').length,1);assert.equal(c.saved.next.sources.filter(s=>s.type==='dashboard').length,0);assert.equal(c.staged.length,0);
});
function data(){
 const rows=['A','B','C'].map((part,i)=>({id:(i===2?'CTDI':'Flex')+'|'+part,part,center:i===2?'CTDI':'Flex',name:'Material '+part,stock:0,india:5,hq:5,needed:2,shortage:2,proposed:3,open:0,currentAssessed:true,orderAssessed:true}));
 return {asof:'2026-10-12',rows,tasks:rows.map(r=>({id:r.id+'|ORDER',rowId:r.id,part:r.part,center:r.center,recipient:'CENTER',kind:'ORDER',quantity:3,textKo:'추가 PO 3개',textEn:'Additional PO 3'})),products:rows.map((r,i)=>({id:'product'+i,center:r.center,operator:'Jio',sn:'SN-'+r.part,rma:'R'+i,receipt:'2026-01-01',date:'2026-10-12',age:80,parts:[{part:r.part,quantity:2,firstDate:'2026-10-05'}]})),sourceDates:[]};
}
function mailContext(d,values={}){
 const c=vm.createContext({tab:'details',detailKind:'SHORTAGE',detailRole:'ALL',detailPo:'ALL',detailSearch:'',center:'전체',state:{partFollowups:{}},I:{getLanguage:()=> 'ko'},liveSummaryData:()=>d,PartsOverview:O,PartsExampleMail:Mail,PartsOverdueMail:Overdue,PartsShareDialog:{open(options){c.dialog=options}},download(){},...values});
 install(c,'function openLiveMail(','function openPartFollowup(');return c;
}
function table(c,language='ko'){return c.dialog.tables[0].build({recipient:c.dialog.defaultRecipient||'all',language})}
test('summary mail exports all current overdue rows despite a previous detail search/owner',()=>{
 const c=mailContext(data(),{tab:'summary',detailSearch:'DOES NOT EXIST',detailRole:'HQ',detailPo:'NONE'});c.openLiveMail('OVERDUE');
 assert.equal(c.dialog.defaultRecipient,'all');assert.equal(table(c).rows.length,3);assert.equal(table(c,'en').rows.length,3);
});
test('detail overdue mail preserves current center, search and owner filters',()=>{
 const c=mailContext(data(),{center:'Flex',detailSearch:'Material A',detailRole:'CENTER'});c.openLiveMail('OVERDUE');
 assert.equal(c.dialog.defaultRecipient,'CENTER');assert.equal(table(c).rows.length,1);assert.match(table(c).rows[0][0],/Material A/);
});
test('waiting-product mail shares detail filtering and exports every filtered page',()=>{
 const d=data();d.products=Array.from({length:31},(_,i)=>({...d.products[0],id:'MATCH-'+i,sn:'MATCH-'+i})).concat(d.products[1],d.products[2]);
 const c=mailContext(d,{center:'Flex',detailSearch:'MATCH'});c.openLiveMail('WAITING');
 const model=table(c),english=table(c,'en');assert.equal(model.rows.length,31);assert.equal(english.rows.length,31);assert.equal(model.productCount,31);
 assert(model.rows.every(r=>String(r[1]).startsWith('MATCH-')));assert.equal(c.tab,'details');assert.equal(c.dialog.tables[0].recipients,false);
});

test('applying staged sources cannot replace a prior failed save awaiting retry',async()=>{
 const c=imports(async(_,name)=>({sources:[src('india',name)]}));
 await c.importFiles([file('india.xlsx')]);const stagedSource=c.staged[0];
 const pending={next:{partFollowups:{'Flex|A':{plan:'Unsaved confirmed plan'}}},options:{operation:'notes'}};
 c.serverPendingSave=pending;c.reviewReportDate=()=>c.importReportDate;
 let commits=0;c.persistServer=async()=>{commits++};
 install(c,'function activeStaged(','async function recordExistingWeek(');
 await c.applyImport();
 assert.equal(commits,0);assert.equal(c.serverPendingSave,pending);assert.equal(c.staged[0],stagedSource);
 assert.match(c.message,/다시 저장하거나 취소/);
});
test('cancelling an applied file cannot discard another failed save awaiting retry',async()=>{
 const c=imports(async()=>({sources:[]})),panel=require('../src/upload-panel.js');
 c.state=R.applySources(C.empty(),[src('india','india.xlsx')],'2026-10-12');
 const pending={next:{partFollowups:{'Flex|A':{plan:'Unsaved confirmed plan'}}},options:{operation:'notes'}};
 const before=JSON.stringify(c.state);c.serverPendingSave=pending;c.PartsUploadPanel=panel;
 let commits=0,confirmations=0;c.persistServer=async()=>{commits++};c.confirm=()=>{confirmations++;return true};
 install(c,'async function cancelAppliedFile(','function openLiveMail(');
 const key=panel.buildModel({state:c.state,reportDate:c.importReportDate}).files[0].key;
 await c.cancelAppliedFile(key);
 assert.equal(commits,0);assert.equal(confirmations,0);assert.equal(c.serverPendingSave,pending);assert.equal(JSON.stringify(c.state),before);
 assert.match(c.message,/다시 저장하거나 취소/);
});
