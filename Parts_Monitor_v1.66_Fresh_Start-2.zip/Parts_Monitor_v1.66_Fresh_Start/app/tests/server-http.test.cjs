const wips=date=>require('../src/weekly-policy.js').required.map(s=>({type:'wip',center:s.center,operator:s.operator,date,file:s.key+'-'+date+'.xlsb',sheet:'WIP',rows:[]}));
'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const fs=require('node:fs'),path=require('node:path'),os=require('node:os'),http=require('node:http');
const {createApplication}=require('../server.cjs');
const C=require('../src/core.js'),R=require('../src/reporting.js');
const XLSX=require('../vendor/xlsx.full.min.js');
function source(date='2024-08-12',stock=1){return {type:'dashboard',center:'Flex',operator:'',date,dateLabel:date,file:'Synthetic.xlsx',sheet:'Dashboard',holdDate:date,usageMonths:['2024-07'],rows:[{part:'TEST-000001',row:5,stock,po:0,hold:3,usage:{'2024-07':2}}]};}
function seed(){return R.normalizeState({...C.empty(),sources:[source()],notes:{'TEST-000001':'Persistent action note'}});}
function temp(t){const dir=fs.mkdtempSync(path.join(os.tmpdir(),'parts-http-test-'));t.after(()=>fs.rmSync(dir,{recursive:true,force:true}));return dir;}
function options(t,extra={}){
 const base=temp(t),templatePath=path.join(base,'template.html');fs.writeFileSync(templatePath,'<!doctype html><html><body data-mode="viewer"><script id="seed" type="application/json">{}</script></body></html>');
 return {config:path.join(base,'missing-config.json'),host:'127.0.0.1',port:0,dataDir:path.join(base,'data'),initialRawDir:path.join(base,'missing-initial'),seedState:seed(),templatePath,...extra};
}
async function start(t,config=options(t)){const app=createApplication(config),address=await app.listen();t.after(()=>app.close());return {app,address,config};}
function request(address,route,{method='GET',body,headers={}}={}){
 return new Promise((resolve,reject)=>{let bytes=body;if(body!==undefined&&!Buffer.isBuffer(body)&&typeof body!=='string'){bytes=Buffer.from(JSON.stringify(body));headers={'Content-Type':'application/json',...headers};}else if(typeof body==='string')bytes=Buffer.from(body);if(bytes!==undefined)headers={'Content-Length':bytes.length,...headers};
  const req=http.request(new URL(route,address.localUrl),{method,headers,agent:false},res=>{const chunks=[];res.on('data',chunk=>chunks.push(chunk));res.on('end',()=>{const data=Buffer.concat(chunks),text=data.toString('utf8');let json;try{json=JSON.parse(text)}catch{}resolve({status:res.statusCode,headers:res.headers,bytes:data,text,json});});});req.on('error',reject);if(bytes!==undefined)req.write(bytes);req.end();
 });
}
async function session(address){const response=await request(address,'/api/session');assert.equal(response.status,200,response.text);assert.equal(response.json.noPasswordRequired,true);assert.match(response.json.csrfToken,/^[a-f0-9]{64}$/);assert.equal(response.headers['set-cookie'],undefined);return {csrf:response.json.csrfToken};}
const writeHeaders=session=>({'X-Parts-Request':'1','X-CSRF-Token':session.csrf});
const nextState=state=>R.applySources(state,[source('2024-08-19',7),...wips('2024-08-19')],'2024-08-19');
const upload=(address,session,name,bytes)=>request(address,'/api/raw',{method:'POST',body:bytes,headers:{...writeHeaders(session),'Content-Type':'application/octet-stream','X-File-Name':encodeURIComponent(name)}});
const commit=(address,session,state,baseRevision,extra={})=>request(address,'/api/commit',{method:'POST',body:{state,baseRevision,operation:'import',...extra},headers:writeHeaders(session)});

test('dashboard, original history and backup are available without passwords or cookies; invalid hosts are rejected',async t=>{
 const {app,address,config}=await start(t);assert.ok(app.store);
 for(const route of ['/','/api/state','/api/status','/api/session','/api/history','/api/backup']){const response=await request(address,route);assert.equal(response.status,200,response.text);assert.equal(response.headers['cache-control'],'no-store');assert.equal(response.headers['x-content-type-options'],'nosniff');assert.equal(response.headers['set-cookie'],undefined);}
 assert.match((await request(address,'/')).text,/data-mode="admin" data-server="true"/);
 const info=(await request(address,'/api/session')).json;assert.equal(info.authenticated,true);assert.equal(info.editAllowed,true);assert.equal(info.setupRequired,false);assert.equal(info.setupAllowed,false);
 assert.equal(fs.existsSync(path.join(config.dataDir,'admin-auth.json')),false);
 for(const route of ['/api/setup','/api/login','/api/logout'])assert.equal((await request(address,route,{method:'POST',body:{}})).status,404);
 for(const route of ['/api/raw','/api/commit'])assert.equal((await request(address,route,{method:'POST',body:{},headers:{'X-Parts-Request':'1'}})).status,403);
 assert.equal((await request(address,'/api/status')).json.revision,0);
 assert.equal((await request(address,'/',{headers:{Host:'attacker.invalid'}})).status,403);
 assert.equal((await request(address,'/',{headers:{Host:'127.0.0.2'}})).status,403);
});

test('passwordless writes still require the current token, a custom request header and same-origin requests',async t=>{
 const {address}=await start(t),current=await session(address),body={state:seed(),baseRevision:0,operation:'settings'};
 for(const headers of [{},{'X-Parts-Request':'1'},{'X-CSRF-Token':current.csrf},{...writeHeaders(current),'X-CSRF-Token':'wrong'},{...writeHeaders(current),Origin:'http://attacker.invalid'}])assert.equal((await request(address,'/api/commit',{method:'POST',body,headers})).status,403);
 assert.equal((await request(address,'/api/status')).json.revision,0);
 const saved=await request(address,'/api/commit',{method:'POST',body,headers:{...writeHeaders(current),Origin:address.localUrl}});assert.equal(saved.status,200,saved.text);assert.equal(saved.json.revision,1);
});

test('fresh default installation ignores bundled historical data and all ten bundled original files',async t=>{
 const config=options(t);delete config.seedState;
 const initial=path.join(path.dirname(config.dataDir),'initial'),raw=path.join(initial,'reference_data');fs.mkdirSync(raw,{recursive:true});
 fs.writeFileSync(path.join(initial,'Parts_Monitor_Data.json'),JSON.stringify(seed()));for(let i=0;i<10;i++)fs.writeFileSync(path.join(raw,'Historical-'+i+'.xlsx'),'bundled old sample '+i);
 fs.writeFileSync(config.config,JSON.stringify({seedPath:'initial/Parts_Monitor_Data.json',initialRawDir:'initial/reference_data',bootstrap:'empty'}));delete config.initialRawDir;
 const {address,app}=await start(t,config),loaded=(await request(address,'/api/state')).json;
 assert.equal(loaded.state.sources.length,0);assert.equal(R.reports(loaded.state).length,0);assert.equal(app.store.status().rawCount,0);assert.equal(app.store.status().reportDate,null);
 assert.equal((await request(address,'/api/history')).json.raw.length,0);
 assert.equal(fs.readdirSync(path.join(config.dataDir,'raw')).length,0);
});

test('bundled data migration remains an explicit opt-in and preserves originals',async t=>{
 const config=options(t);delete config.seedState;
 const initial=path.join(path.dirname(config.dataDir),'initial'),raw=path.join(initial,'reference_data');fs.mkdirSync(raw,{recursive:true});
 const seedPath=path.join(initial,'Parts_Monitor_Data.json');fs.writeFileSync(seedPath,JSON.stringify(seed()));fs.writeFileSync(path.join(raw,'Historical.xlsx'),'explicit migration original');
 fs.writeFileSync(config.config,JSON.stringify({seedPath:'initial/Parts_Monitor_Data.json',initialRawDir:'initial/reference_data',bootstrap:'bundled'}));delete config.initialRawDir;
 const first=await start(t,config);assert.equal(first.app.store.status().reportCount,1);assert.equal(first.app.store.status().rawCount,1);await first.app.close();
 const explicit=await start(t,options(t,{seedState:undefined,seedPath,initialRawDir:raw}));assert.equal(explicit.app.store.status().reportCount,1);assert.equal(explicit.app.store.status().rawCount,1);
});

test('Excel upload is staged until a successful atomic commit; stale revisions cannot overwrite saved weekly data',async t=>{
 const {address}=await start(t),current=await session(address),bytes=Buffer.from('Synthetic original Excel byte stream');
 const uploaded=await upload(address,current,'이번 주 원본.xlsx',bytes);assert.equal(uploaded.status,201,uploaded.text);const id=uploaded.json.id;
 assert.equal((await request(address,'/api/history')).json.raw.length,0);assert.equal((await request(address,'/api/raw?id='+id)).status,404);
 const state=(await request(address,'/api/state')).json.state,next=nextState(state);
 const saved=await commit(address,current,next,0,{rawIds:[id],reportDate:'2024-08-19'});assert.equal(saved.status,200,saved.text);assert.equal(saved.json.revision,1);assert.equal(saved.json.rawCount,1);
 const download=await request(address,'/api/raw?id='+id);assert.equal(download.status,200);assert.deepEqual(download.bytes,bytes);assert.match(download.headers['content-disposition'],/filename\*=UTF-8/);
 const stale=await commit(address,current,state,0,{operation:'settings'});assert.equal(stale.status,409);assert.equal(stale.json.code,'REVISION_CONFLICT');assert.deepEqual((await request(address,'/api/state')).json.state,next);
 const history=await request(address,'/api/history');assert.equal(history.json.commits.length,2);assert.equal(history.json.raw.length,1);
 const backup=await request(address,'/api/backup');assert.equal(backup.status,200);assert.equal(backup.headers['content-type'],'application/zip');assert.equal(backup.bytes.readUInt32LE(0),0x04034b50);
});

test('server restart preserves saved state without login, changes the write token and rejects the obsolete token safely',async t=>{
 const first=await start(t),oldSession=await session(first.address),state=nextState(first.app.store.read().state);
 assert.equal((await commit(first.address,oldSession,state,0)).status,200);
 await first.app.close();const second=await start(t,{...first.config,seedState:C.empty()});
 const loaded=(await request(second.address,'/api/state')).json;assert.equal(loaded.revision,1);assert.deepEqual(loaded.state,state);
 const stale=await commit(second.address,oldSession,state,1,{operation:'settings'});assert.equal(stale.status,403);assert.equal(stale.json.code,'SESSION_REFRESH_REQUIRED');assert.equal(second.app.store.read().revision,1);
 const newSession=await session(second.address);assert.notEqual(newSession.csrf,oldSession.csrf);assert.equal((await request(second.address,'/api/history')).status,200);
 assert.equal((await commit(second.address,newSession,state,1,{operation:'settings'})).status,200);
});

test('legacy malformed authentication files do not block passwordless startup or become new backup content',async t=>{
 const config=options(t);fs.mkdirSync(config.dataDir,{recursive:true});const credential=path.join(config.dataDir,'admin-auth.json');fs.writeFileSync(credential,'{obsolete broken credentials');
 const {app,address}=await start(t,config),current=await session(address);assert.equal((await commit(address,current,nextState(app.store.read().state),0)).status,200);
 assert.equal(fs.readFileSync(credential,'utf8'),'{obsolete broken credentials');
 const decoded=require('../scripts/restore-server-backup.cjs').decodeBackup((await request(address,'/api/backup')).bytes);assert.equal(decoded.files.some(file=>file.path==='admin-auth.json'),false);
});

test('empty start, first week, same-week correction, next week and restart preserve weekly snapshots and original Excel bytes',async t=>{
 const config=options(t,{seedState:undefined}),first=await start(t,config),current=await session(first.address);assert.equal(first.app.store.status().reportCount,0);
 const originalFiles=[];let revision=0,state=(await request(first.address,'/api/state')).json.state;
 async function reflect(date,stock,expectedWeeks){
  const workbook=XLSX.utils.book_new();XLSX.utils.book_append_sheet(workbook,XLSX.utils.aoa_to_sheet([['Part','Stock','Date'],['TEST-000001',stock,date]]),'Dashboard');
  const bytes=Buffer.from(XLSX.write(workbook,{type:'buffer',bookType:'xlsx'})),name='Flex-'+date+'.xlsx',uploaded=await upload(first.address,current,name,bytes);assert.equal(uploaded.status,201,uploaded.text);
  state=R.applySources(state,[source(date,stock),...wips(date)],date);state.settings.hqMonths=4;state.notes['TEST-000001']='Keep weekly note';
  const saved=await commit(first.address,current,state,revision,{rawIds:[uploaded.json.id],reportDate:date});assert.equal(saved.status,200,saved.text);revision=saved.json.revision;
  assert.equal(first.app.store.status().reportCount,expectedWeeks);originalFiles.push({id:uploaded.json.id,name,bytes});
 }
 await reflect('2024-08-12',1,1);await reflect('2024-08-14',4,1);await reflect('2024-08-19',7,2);
 const saved=(await request(first.address,'/api/state')).json;assert.equal(saved.revision,3);assert.equal(saved.state.settings.hqMonths,4);assert.equal(saved.state.notes['TEST-000001'],'Keep weekly note');
 assert.equal(C.calculate(R.reportState(saved.state,'2024-08-12'),'2024-08-14').parts[0].stock,4);
 assert.equal(C.calculate(R.reportState(saved.state,'2024-08-19'),'2024-08-19').parts[0].stock,7);
 assert.deepEqual(R.reports(saved.state).map(report=>report.reportDate),['2024-08-14','2024-08-19']);
 await first.app.close();const second=await start(t,{...config,seedState:seed()});assert.deepEqual((await request(second.address,'/api/state')).json,saved);
 const history=(await request(second.address,'/api/history')).json;assert.equal(history.commits.length,4);assert.equal(history.raw.length,3);
 for(const file of originalFiles){const downloaded=await request(second.address,'/api/raw?id='+file.id);assert.equal(downloaded.status,200);assert.deepEqual(downloaded.bytes,file.bytes);}
});

test('only one writer starts per data folder; rejected second startup does not alter state or remove the first lock',async t=>{
 const first=await start(t),lock=path.join(first.config.dataDir,'server.lock'),before=fs.readFileSync(path.join(first.config.dataDir,'current.json'));
 const second=createApplication({...first.config,seedState:C.empty()});t.after(()=>second.close());assert.equal(second.store,undefined);
 await assert.rejects(second.listen(),/이미 실행 중/);assert.deepEqual(fs.readFileSync(path.join(first.config.dataDir,'current.json')),before);
 await second.close();assert.equal(fs.existsSync(lock),true);assert.equal((await request(first.address,'/api/status')).json.revision,0);
 await first.app.close();assert.equal(fs.existsSync(lock),false);const secondAddress=await second.listen();assert.equal((await request(secondAddress,'/api/status')).json.reportCount,1);
});

test('write failure leaves previously saved report authoritative and a retry can succeed',async t=>{
 const {app,address,config}=await start(t),current=await session(address),before=(await request(address,'/api/state')).json,state=nextState(before.state);
 const dir=path.join(config.dataDir,'generations'),moved=path.join(config.dataDir,'generations-paused');fs.renameSync(dir,moved);fs.writeFileSync(dir,'synthetic unavailable directory');
 let failed;try{failed=await commit(address,current,state,0);}finally{fs.unlinkSync(dir);fs.renameSync(moved,dir);}
 assert.equal(failed.status,500);assert.deepEqual((await request(address,'/api/state')).json,before);assert.equal(app.store.listCommits().length,1);
 const retry=await commit(address,current,state,0);assert.equal(retry.status,200,retry.text);assert.equal(retry.json.revision,1);
});

test('bad file paths, unsupported uploads, oversized data, invalid state and report-history removal are rejected',async t=>{
 const {address}=await start(t,options(t,{maxUploadMB:0.00001})),current=await session(address);
 const raw=(name,bytes=Buffer.from('data'))=>upload(address,current,name,bytes);
 assert.equal((await raw('../outside.xlsx')).status,400);assert.equal((await raw('outside.txt')).status,400);assert.equal((await raw('empty.xlsx',Buffer.alloc(0))).status,400);assert.equal((await raw('large.xlsx',Buffer.alloc(100))).status,413);
 assert.equal((await request(address,'/api/raw?id=..%2Fadmin-auth.json')).status,400);
 assert.equal((await commit(address,current,{version:99},0)).status,422);
 assert.equal((await request(address,'/api/commit',{method:'POST',body:'{bad json',headers:{...writeHeaders(current),'Content-Type':'application/json'}})).status,400);
 assert.equal((await request(address,'/api/status')).json.revision,0);
 const state=seed(),next=nextState(state);assert.equal((await commit(address,current,next,0)).status,200);
 assert.equal((await commit(address,current,state,1,{operation:'remove'})).status,422);
 assert.equal((await request(address,'/api/status')).json.reportCount,2);
});

test('HTML contains no annual source state; metadata preserves literal script-like notes as JSON',async t=>{
 const state=seed();state.notes['TEST-000001']="Literal $& $$ $` $' </script><script>alert(1)</script>";
 const {address}=await start(t,options(t,{seedState:state})),response=await request(address,'/');assert.equal(response.status,200);
 const match=response.text.match(/<script id="seed" type="application\/json">([\s\S]*?)<\/script>/);assert.ok(match);
 assert.deepEqual(JSON.parse(match[1]),C.empty());assert.equal(response.text.includes('<script>alert(1)</script>'),false);
 const manifest=(await request(address,'/api/manifest')).json;
 assert.deepEqual(manifest.state.notes,state.notes);assert.equal(manifest.state.sources.length,1);assert.deepEqual(manifest.state.sources[0].rows,[]);
});

test('compact endpoints review only new sources, commit a week, retain history, and serve derived results',async t=>{
 const {app,address}=await start(t),current=await session(address),before=(await request(address,'/api/status')).json;
 const manifest=(await request(address,'/api/manifest')).json;assert.equal(manifest.state.sources[0].rowCount,1);assert.equal(manifest.state.reportingWeeks.length,1);
 const source2=source('2024-08-19',7),review=await request(address,'/api/review',{method:'POST',headers:writeHeaders(current),body:{sources:[source2,...wips('2024-08-19')],reportDate:'2024-08-19'}});
 assert.equal(review.status,200,review.text);assert.equal(review.json.canApply,true);assert.equal(review.json.selectedSources[0].rows,undefined);
 const saved=await request(address,'/api/update',{method:'POST',headers:writeHeaders(current),body:{operation:'import',baseRevision:before.revision,reportDate:'2024-08-19',sources:[source2,...wips('2024-08-19')]}});
 assert.equal(saved.status,200,saved.text);assert.equal(saved.json.state,undefined);assert.equal(saved.json.reportCount,2);
 const result=await request(address,'/api/view');assert.equal(result.status,200,result.text);assert.equal(result.json.data.trend.length,2);assert.equal(result.json.data.rows[0].stock,7);
 const historical=await request(address,'/api/report?reportId=2024-08-12');assert.equal(historical.json.state.sources.length,1);assert.equal(historical.json.state.sources[0].rows[0].stock,1);
 const notes=await request(address,'/api/update',{method:'POST',headers:writeHeaders(current),body:{operation:'notes',baseRevision:saved.json.revision,patch:{partFollowups:{'Flex|TEST-000001':{plan:'Check confirmed shipment'}}}}});
 assert.equal(notes.status,200,notes.text);assert.equal((await request(address,'/api/manifest')).json.state.partFollowups['Flex|TEST-000001'].plan,'Check confirmed shipment');
 assert.equal((await request(address,'/api/view')).json.revision,notes.json.revision);
 assert.equal((await request(address,'/api/update',{method:'POST',headers:writeHeaders(current),body:{operation:'notes',baseRevision:saved.json.revision,patch:{notes:{}}}})).status,409);
 assert.equal(app.store.status().reportCount,2);
});

test('valid saved state reopens even if the obsolete initial seed file has become malformed',async t=>{
 const first=await start(t),state=nextState(first.app.store.read().state);first.app.store.save({state,baseRevision:0,operation:'import'});await first.app.close();
 const malformedSeed=path.join(path.dirname(first.config.dataDir),'obsolete-seed.json');fs.writeFileSync(malformedSeed,'{broken initial seed');
 const second=await start(t,{...first.config,seedState:undefined,seedPath:malformedSeed});assert.deepEqual((await request(second.address,'/api/state')).json.state,state);
});
