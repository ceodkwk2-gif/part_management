'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm');
const D=require('../src/summary-downloads.js'),O=require('../src/overview.js'),Mail=require('../src/summary-mail.js'),Overdue=require('../src/overdue-mail.js'),Share=require('../src/share-dialog.js');
const row=(center,part,extra={})=>({id:center+'|'+part,center,part,name:'Part '+part,stock:2,india:3,hq:4,avg:.25,needed:0,shortage:0,poOrdered:0,open:0,proposed:0,currentAssessed:true,orderAssessed:true,...extra});
const entries=(part,quantity=1)=>({part,quantity,firstDate:'2026-09-28',baseline:true});
function fixture(){
 const rows=[row('Flex','A',{needed:5,shortage:3,proposed:4}),row('CTDI','A',{proposed:2}),row('Flex','B',{proposed:1}),row('CTDI','C',{waitingCovered:true,open:7}),row('Flex','NORMAL')];
 const products=[
  {id:'F1',center:'Flex',operator:'Jio',sn:'S1',rma:'R1',receipt:'2026-08-01',date:'2026-10-12',age:72,fan:true,parts:[entries('A',3),entries('B',1)],source:'flex.xlsb',sheet:'FAN',row:2,required:'A #3, B'},
  {id:'C1',center:'CTDI',operator:'Jio',sn:'S2',rma:'R2',receipt:'2026-06-01',date:'2026-10-12',age:133,fan:false,parts:[entries('A',2)]},
  {id:'C2',center:'CTDI',operator:'Vi',sn:'S3',rma:'R3',receipt:'2026-08-27',date:'2026-10-12',age:46,fan:false,parts:[],unparsed:'Unknown text',hasUnresolvedParts:true},
  {id:'F2',center:'Flex',operator:'Jio',sn:'S4',rma:'R4',date:'2026-10-12',age:45,fan:false,parts:[entries('C')]},
  {id:'C3',center:'CTDI',operator:'Airtel',sn:'S5',rma:'R5',date:'2026-10-12',age:181,fan:false,parts:[entries('D')]}
 ];
 const sourceDates=[{type:'wip',center:'Flex',operator:'Jio',date:'2026-10-12',fresh:true,file:'flex.xlsb',sheet:'WIP'},...['Jio','Airtel','Vi'].map(operator=>({type:'wip',center:'CTDI',operator,date:'2026-10-12',fresh:true,file:operator+'.xlsb'})),{type:'india',date:null,reportWeek:'2026-10-05',datePrecision:'week',carriedForward:true,file:'WK41.xlsx'}];
 const metrics={shortageKinds:1,shortageQty:3,orderKinds:1,orderQty:1,waitKinds:1,waitQty:7,wip:5,over45:4,over45PartKinds:3,over45RequiredQty:7,partKinds:4,neededQty:8,over45Fan:1,over45General:3,over45Unparsed:1,fan:1,general:4,unparsedProducts:1};
 const availabilityByCenter={'전체':{wip:true,repairDemand:true},Flex:{wip:true,repairDemand:true},CTDI:{wip:true,repairDemand:true}};
 const point=(week)=>({week,asof:week,sourceDates:sourceDates.map(s=>({...s,date:s.type==='wip'?week:s.date})),availableByCenter:availabilityByCenter,metricsByCenter:{'전체':{...metrics},Flex:{...metrics,over45:1,over45PartKinds:2,over45RequiredQty:4},CTDI:{...metrics,over45:3,over45PartKinds:2,over45RequiredQty:3}}});
 return {dataAvailable:true,asof:'2026-10-12',week:'2026-10-12',rows,products,sourceDates,availabilityByCenter,settings:{targetMonths:1},trend:[point('2026-10-05'),point('2026-10-12')],overdue:{freshByCenter:{'전체':true,Flex:true,CTDI:true}},tasks:[{id:'task1',rowId:'Flex|A',center:'Flex',part:'A',recipient:'CENTER',kind:'ORDER',quantity:4,textKo:'추가 PO 4개 필요',textEn:'Additional PO 4 pcs needed'}],pos:[{center:'Flex',part:'A',po:'P1',ordered:8,pending:3,poDate:'2026-10-01',etd:'2026-10-15'}]};
}
function records(model){return model.rows.map(row=>Object.fromEntries(model.columns.map((c,i)=>[c.key,row[i]])))}
function record(model,where){return records(model).find(where)}

test('summary offers combined and separate scopes with deduplicated codes and distinct quantity units',()=>{
 const d=fixture(),m=D.buildTable('SUMMARY',{data:d}),all=record(m,r=>r.center==='전체'&&r.category==='45일 초과 자재대기'),flex=record(m,r=>r.center==='Flex'&&r.category==='45일 초과 자재대기'),ctdi=record(m,r=>r.center==='CTDI'&&r.category==='45일 초과 자재대기');
 assert.deepEqual([all.products,all.parts,all.quantity],[4,3,7]);assert.deepEqual([flex.products,flex.parts,flex.quantity],[1,2,4]);assert.deepEqual([ctdi.products,ctdi.parts,ctdi.quantity],[3,2,3]);assert.equal(all.unparsed,1);assert.equal(flex.fan,1);assert.equal(ctdi.general,3);assert.equal(all.products,flex.products+ctdi.products);assert(all.parts<flex.parts+ctdi.parts);
 const shortage=record(m,r=>r.center==='전체'&&r.category==='현재 수리분 부족'),order=record(m,r=>r.center==='전체'&&r.category.includes('추가 PO'));
 assert.deepEqual([shortage.parts,shortage.quantity],[1,3]);assert.deepEqual([order.parts,order.quantity],[1,1]);assert.equal(order.products,null);assert.equal(order.quantityBasis,'추가 PO 필요 수량');assert.equal(m.rows.length,15);
});
test('single-center selection scopes every table, inventory, product and source export',()=>{
 const d=fixture(),all=D.buildAll({data:d,center:'Flex',language:'en'});assert.equal(all.length,D.TYPES.length);
 for(const id of ['SUMMARY','TREND_OVERDUE','TREND_ACTIONS','TREND_PRODUCTS','AGING','PARTS']){const m=all.find(t=>t.id===id);assert(records(m).every(r=>r.center==='Flex'));assert(m.context.some(x=>x==='Center: Flex'));}
 assert.equal(all.find(t=>t.id==='OVERDUE_PRODUCTS').productCount,1);assert.equal(all.find(t=>t.id==='WAITING_PRODUCTS').productCount,2);
 assert(records(all.find(t=>t.id==='SOURCES')).every(r=>r.center==='Flex'||r.center==='Shared'));
});
test('full weekly trend retains more than a year and null unavailable observations without invented weeks',()=>{
 const d=fixture(),base=d.trend[0];d.trend=Array.from({length:60},(_,i)=>({...base,week:'fixture-week-'+i,asof:'source-cutoff-'+i}));d.trend[13]={...base,week:'fixture-week-13',availableByCenter:{...base.availableByCenter,Flex:{wip:false,repairDemand:false}},metricsByCenter:{...base.metricsByCenter,Flex:{...base.metricsByCenter.Flex,over45:123,over45PartKinds:null}}};
 const m=D.buildTable('TREND_OVERDUE',{data:d,center:'Flex'}),r=records(m)[13];assert.equal(m.rows.length,60);assert.equal(r.over45,null);assert.equal(r.over45PartKinds,null);assert.equal(r.over45RequiredQty,null);assert.match(r.wipState,/참고/);assert.equal(records(m).at(-1).week,'fixture-week-59');assert.equal(D.buildTable('TREND_OVERDUE',{data:d}).rows.length,180);
});
test('missing WIP never becomes zero current metrics or zero aging, genuine empty WIP can be zero',()=>{
 const d=fixture();d.products=[];d.sourceDates=d.sourceDates.filter(s=>s.type!=='wip');d.availabilityByCenter={'전체':{wip:false},Flex:{wip:false},CTDI:{wip:false}};
 const m=D.buildTable('SUMMARY',{data:d,center:'Flex'}),r=record(m,r=>r.category==='45일 초과 자재대기');assert.equal(r.products,null);assert.equal(r.quantity,null);assert.equal(r.parts,null);assert.equal(r.productsChange,null);assert.match(r.wipState,/없음/);assert(records(D.buildTable('AGING',{data:d,center:'Flex'})).every(r=>r.products===null));
 d.sourceDates.push({type:'wip',center:'Flex',operator:'Jio',date:'2026-10-12'});const zero=record(D.buildTable('SUMMARY',{data:d,center:'Flex'}),r=>r.category==='45일 초과 자재대기');assert.equal(zero.products,0);assert.equal(zero.quantity,0);
});
test('reference WIP current totals remain visible but fresh weekly comparison stays blank',()=>{
 const d=fixture();d.availabilityByCenter={...d.availabilityByCenter,Flex:{wip:false}};d.sourceDates=d.sourceDates.map(s=>s.center==='Flex'?{...s,date:'2026-10-05',carriedForward:true}:s);
 const r=record(D.buildTable('SUMMARY',{data:d,center:'Flex'}),r=>r.category==='45일 초과 자재대기');assert.equal(r.products,1);assert.equal(r.productsChange,null);assert.equal(r.priorProducts,null);assert.match(r.wipDates,/2026-10-05/);assert(!r.wipDates.includes('2026-10-12'));assert.match(r.wipState,/참고/);
});
test('TAT age bands partition 46+ product count, preserve unparsed product and gross part quantities',()=>{
 const m=D.buildTable('AGING',{data:fixture()}),rs=records(m).filter(r=>r.center==='전체');assert.deepEqual(rs.map(r=>r.products),[2,1,1]);assert.equal(rs.reduce((s,r)=>s+r.products,0),4);assert.equal(rs.reduce((s,r)=>s+r.percent,0),100);assert.equal(rs.reduce((s,r)=>s+r.quantity,0),7);assert.equal(rs[0].unparsed,1);assert.deepEqual(rs.map(r=>r.band),['46–90일','91–180일','181+일']);
});
test('overdue product and part reports include all products, multipart and unresolved records without PO allocation',()=>{
 const d=fixture(),products=D.buildTable('OVERDUE_PRODUCTS',{data:d}),parts=D.buildTable('OVERDUE',{data:d,notes:{'Flex|A':{eta:'2026-10-20',plan:'Confirmed plan'}}});
 assert.equal(products.productCount,4);assert(!JSON.stringify(products.rows).includes('S4 / R4'));assert(JSON.stringify(products.rows).includes('A × 3'));assert(JSON.stringify(products.rows).includes('Unknown text'));assert.equal(parts.rows.length,5);assert(JSON.stringify(parts.rows).includes('P1'));assert(JSON.stringify(parts.rows).includes('2026-10-20'));assert(JSON.stringify(parts.rows).includes('Confirmed plan'));assert(parts.notes.some(n=>n.includes('ETD')));
});
test('full materials export includes normal and taskless rows, whole monthly usage and manual notes',()=>{
 const d=fixture(),m=D.buildTable('PARTS',{data:d,notes:{'Flex|NORMAL':{eta:'2026-11-01',plan:'Keep'}}}),rs=records(m);assert.equal(rs.length,d.rows.length);assert.equal(m.partCount,4);const normal=rs.find(r=>r.part==='NORMAL');assert.equal(normal.actions,'');assert.equal(normal.category,'정상');assert.equal(normal.avg,1);assert.equal(d.rows.find(r=>r.part==='NORMAL').avg,.25);assert.equal(normal.poOrdered,0);assert.equal(normal.plan,'Keep');
 const ctdi=rs.find(r=>r.part==='A'&&r.center==='CTDI');assert.match(ctdi.category,/추가 PO/);assert.equal(ctdi.summaryCategory,'현재 수리분 부족');assert.equal(D.buildTable('PARTS',{data:d,rowIds:['CTDI|A']}).rows.length,1);
});
test('source files preserve actual missing date versus confirmed week and their reference state',()=>{
 const m=D.buildTable('SOURCES',{data:fixture()}),r=record(m,r=>r.type==='법인 재고');assert.equal(r.date,null);assert.equal(r.week,'2026-10-05');assert.equal(r.precision,'주차만 확인');assert.match(r.state,/참고/);assert.equal(r.file,'WK41.xlsx');
});
test('localized models share numeric facts and use ordinary share-dialog CSV safety without modifying raw data',()=>{
 const d=fixture();d.products[0].sn='=BAD()';const before=JSON.stringify(d),ko=D.buildAll({data:d,center:'Flex'}),en=D.buildAll({data:d,center:'Flex',language:'en'});assert.equal(JSON.stringify(d),before);
 for(let i=0;i<ko.length;i++){assert.equal(ko[i].rows.length,en[i].rows.length);assert.deepEqual(ko[i].rows.flat().filter(x=>typeof x==='number'),en[i].rows.flat().filter(x=>typeof x==='number'));assert.equal(ko[i].localized,true);assert.equal(en[i].localized,true);}
 const model=Share.normalize(en.find(x=>x.id==='WAITING_PRODUCTS'),{language:'en'});assert.match(Share.csv(model),/'=BAD\(\)/);assert(!en.find(x=>x.id==='SUMMARY').columns.some(x=>/[가-힣]/.test(x.label)));assert.equal(JSON.stringify(d),before);
});
test('browser UMD requires no Node APIs, filesystem, downloads or XLSX vendor',()=>{
 const sandbox={PartsOverview:O,PartsExampleMail:Mail,PartsOverdueMail:Overdue};sandbox.self=sandbox;vm.runInNewContext(fs.readFileSync(require.resolve('../src/summary-downloads.js'),'utf8'),sandbox);const model=sandbox.PartsSummaryDownloads.buildTable('SUMMARY',{data:fixture(),center:'CTDI'});assert.equal(model.rows.length,5);assert.throws(()=>D.buildTable('bad'),/Unknown summary/);
});

test('action trend export keeps unavailable stock or PO decisions blank without dropping valid center figures',()=>{
 const d=fixture();d.trend[0].availableByCenter={...d.trend[0].availableByCenter,Flex:{wip:true,repairDemand:true,actionAvailability:{shortage:true,order:false,wait:false}}};
 const table=D.buildTable('TREND_ACTIONS',{data:d,center:'Flex',language:'ko'}),at=key=>table.columns.findIndex(c=>c.key===key);
 assert.equal(table.rows[0][at('shortageKinds')],1);assert.equal(table.rows[0][at('orderKinds')],null);assert.equal(table.rows[0][at('waitQty')],null);assert.match(table.rows[0][at('actionState')],/추가 PO: 산정 불가/);assert.equal(table.rows.length,2);
});

test('current summary export masks unavailable action totals and retains confirmed zero totals',()=>{
 const d=fixture();d.availabilityByCenter.Flex.actionAvailability={shortage:true,order:false,wait:false};
 let rs=records(D.buildTable('SUMMARY',{data:d,center:'Flex'}));
 assert.equal(rs[0].parts,1);for(const r of rs.slice(1,3)){assert.equal(r.parts,null);assert.equal(r.quantity,null);assert.equal(r.zero,null);assert.equal(r.partsChange,null);}
 d.rows=[];d.availabilityByCenter.Flex.actionAvailability={shortage:true,order:true,wait:true};
 rs=records(D.buildTable('SUMMARY',{data:d,center:'Flex'}));for(const r of rs.slice(0,3)){assert.equal(r.parts,0);assert.equal(r.quantity,0);}
});
test('summary comparison does not skip a missing calendar week or use unavailable prior action values',()=>{
 const d=fixture();d.trend[0].week='2026-09-28';
 let r=records(D.buildTable('SUMMARY',{data:d,center:'Flex'}))[0];assert.equal(r.previousWeek,'2026-10-05');assert.equal(r.priorParts,null);assert.equal(r.partsChange,null);
 d.trend[0].week='2026-10-05';d.trend[0].availableByCenter={...d.trend[0].availableByCenter,Flex:{actionAvailability:{shortage:false,order:false,wait:false}}};
 r=records(D.buildTable('SUMMARY',{data:d,center:'Flex'}))[0];assert.equal(r.priorParts,null);assert.equal(r.priorQty,null);assert.equal(r.partsChange,null);
});
