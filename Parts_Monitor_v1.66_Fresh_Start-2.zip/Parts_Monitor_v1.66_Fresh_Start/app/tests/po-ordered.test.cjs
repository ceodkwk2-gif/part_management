'use strict';
// Synthetic purchase-order data only; quantity is not number of orders.
const test=require('node:test'),assert=require('node:assert/strict');
const C=require('../src/core');
const PART='TEST-000001';
const row=(changes={})=>({part:PART,po:'ORDER-1',item:'10',shipto:'CENTER',ordered:10,shipped:6,pending:4,row:2,...changes});

test('PO Qty sums distinct order lines and removes exact copies once',()=>{
 const rows=[row(),row({row:3,item:'010'}),row({po:'ORDER-2',ordered:20,shipped:15,pending:5,row:4})];
 const before=JSON.stringify(rows),r=C.detailPoSummary(rows);
 assert.equal(r.ordered,30);assert.equal(r.pending,9);assert.equal(r.rows.length,2);
 assert.equal(r.diagnostics[0].type,'identical-po-duplicate');assert.equal(JSON.stringify(rows),before);
});

test('missing or invalid PO Qty is not replaced by Pending plus Shipped',()=>{
 for(const value of [null,undefined,-1,NaN,'10']){
  const r=C.detailPoSummary([row({ordered:value})]);
  assert.equal(r.ordered,null);assert.equal(r.pending,4);assert.match(r.orderedReason,/PO Qty/);
  assert.ok(r.diagnostics.some(issue=>issue.type==='invalid-po-ordered'));
 }
 assert.equal(C.detailPoSummary([]).ordered,null);
 assert.equal(C.detailPoSummary([row({ordered:0,shipped:0,pending:0})]).ordered,0);
});

test('valid order quantity does not depend on Pending or Shipped completeness',()=>{
 const r=C.detailPoSummary([row({pending:null,shipped:null})]);
 assert.equal(r.ordered,10);assert.equal(r.pending,null);
});

test('conflicting order identity does not double-count original order quantity',()=>{
 const r=C.detailPoSummary([row(),row({row:3,pending:2,shipped:8})]);
 assert.equal(r.ordered,null);assert.equal(r.pending,null);assert.match(r.orderedReason,/불일치/);
});

test('display order quantity preserves stock, dashboard PO priority and additional-order calculation',()=>{
 const state=C.empty(),date='2024-08-12',months=['2024-02','2024-03','2024-04','2024-05','2024-06','2024-07'];
 state.sources=[
  {type:'dashboard',center:'Flex',date,file:'synthetic-dashboard.xlsx',sheet:'Stock',holdDate:date,usageMonths:months,rows:[{part:PART,row:5,stock:2,po:4,hold:8,usage:Object.fromEntries(months.map(m=>[m,3]))}]},
  {type:'po',center:'Flex',date:'2024-08-10',file:'synthetic-po.xlsx',sheet:'Orders',rows:[row({ordered:30,shipped:24,pending:6})]}
 ];
 const before=JSON.stringify(state),r=C.calculate(state,date,'Flex').parts[0];
 assert.equal(r.poOrdered,30);assert.equal(r.poOrderedReason,'');assert.equal(r.detailPending,6);assert.equal(r.open,4);
 assert.equal(r.stock,2);assert.equal(r.shortage,6);assert.equal(r.proposed,5);
 assert.equal(r.poSourceDate,'2024-08-10');assert.equal(r.poSourceFile,'synthetic-po.xlsx');assert.equal(r.poSourceSheet,'Orders');
 assert.equal(JSON.stringify(state),before);
 state.sources[1].rows=[];
 const unmatched=C.calculate(state,date,'Flex').parts[0];
 assert.equal(unmatched.poOrdered,0);assert.equal(unmatched.open,4);assert.equal(unmatched.shortage,6);assert.equal(unmatched.proposed,5);
 assert.match(unmatched.poOrderedReason,/해당 자재 없음/);
 assert.match(unmatched.poOrderedReason,/0개 적용/);
 assert.ok(unmatched.issues.includes('상세 PO 미매칭'));
 state.sources[1].rows=[row({part:'TEST-000002'})];
 const unlisted=C.calculate(state,date,'Flex').parts.find(p=>p.part===PART);
 assert.equal(unlisted.poOrdered,0);assert.equal(unlisted.open,4);assert.equal(unlisted.shortage,6);assert.equal(unlisted.proposed,5);
 state.sources[1].rows=[row({ordered:null})];
 const invalid=C.calculate(state,date,'Flex').parts.find(p=>p.part===PART);
 assert.equal(invalid.poOrdered,null);assert.match(invalid.poOrderedReason,/PO Qty/);
 assert.ok(invalid.issues.some(issue=>/기발주 수량 빈칸/.test(issue)));
 assert.equal(invalid.open,4);assert.equal(invalid.shortage,6);assert.equal(invalid.proposed,5);
 state.sources[1].rows=[row(),row({row:3,pending:2,shipped:8})];
 const conflict=C.calculate(state,date,'Flex').parts.find(p=>p.part===PART);
 assert.equal(conflict.poOrdered,null);assert.match(conflict.poOrderedReason,/불일치/);
 assert.equal(conflict.open,4);assert.equal(conflict.shortage,6);assert.equal(conflict.proposed,5);
 state.sources.pop();
 const absent=C.calculate(state,date,'Flex').parts[0];
 assert.equal(absent.poOrdered,null);assert.match(absent.poOrderedReason,/원본 없음/);assert.equal(absent.open,4);
});
