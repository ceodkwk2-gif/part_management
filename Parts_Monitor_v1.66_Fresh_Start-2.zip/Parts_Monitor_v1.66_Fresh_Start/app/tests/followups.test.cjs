'use strict';
// Synthetic evidence only. Follow-up tasks never replace source quantities.
const test=require('node:test');
const assert=require('node:assert/strict');
const Core=require('../src/core.js');
const Followups=require('../src/followups.js');
const PART='TEST-000001',OTHER='TEST-000002',DATE='2024-08-12';
const MONTHS=['2024-02','2024-03','2024-04','2024-05','2024-06','2024-07'];
function member(extra={}){return {center:'Flex',part:PART,description:'Synthetic part',stock:0,needed:5,shortage:5,
 open:2,proposed:4,avg:1,target:1,india:0,hq:0,dashboardDate:DATE,needDate:DATE,poSourceDate:DATE,issues:[],...extra};}
function state(extra={}){return {...Core.empty(),...extra};}
function waiting(extra={}){return {center:'Flex',operator:'Jio',sn:'SYNTHETIC-SN',rma:'SYNTHETIC-RMA',status:'Waiting for Component',
 required:PART,tokens:{parts:{[PART]:1},unparsed:''},receipt:'2024-06-27',date:DATE,source:'synthetic-wip.xlsx',sheet:'Synthetic',row:2,...extra};}
function calculated(rows,extra={}){
 const sources=['Flex','CTDI'].map(center=>({type:'dashboard',center,date:DATE,file:'synthetic-dashboard.xlsx',sheet:'Synthetic',
  usageMonths:MONTHS,rows:rows.filter(row=>row.center===center).map((row,index)=>({part:row.part,row:index+2,
   usage:Object.fromEntries(MONTHS.map((month,i)=>[month,i===5?2:0]))}))}));
 const grouped=new Map();for(const row of rows){if(!grouped.has(row.part))grouped.set(row.part,[]);grouped.get(row.part).push(row);}
 const commonSupport={sourceDates:{Flex:DATE,CTDI:DATE,india:DATE,hq:DATE},parts:[...grouped].map(([part,ms])=>({part,
  india:ms[0].india,hq:ms[0].hq,demand:ms.reduce((sum,m)=>sum+(m.avg||0),0),demandComplete:ms.every(m=>m.avg!=null),
  shortageKnownSubtotal:ms.reduce((sum,m)=>sum+(m.shortage||0),0),shortageComplete:ms.every(m=>m.shortage!=null)}))};
 return {parts:rows,allParts:rows,used:sources,wip:[],pos:[],commonSupport,...extra};
}
function keys(result){return result.tasks.map(task=>task.kind+'|'+task.recipient);}
function deepFreeze(value){if(value&&typeof value==='object'&&!Object.isFrozen(value)){Object.freeze(value);for(const entry of Object.values(value))deepFreeze(entry);}return value;}

test('parallel center order, India PO follow-up and HQ supply are retained under one representative center owner',()=>{
 const row=member({india:1,hq:5}),result=Followups.evaluate(state(),calculated([row]),{asof:DATE});
 assert.deepEqual(keys(result),['ORDER|CENTER','SUPPLY|INDIA','HQ_SUPPLY|HQ']);
 assert.equal(result.partCount,1);assert.equal(result.taskCount,3);
 assert.deepEqual(result.recipients.map(r=>r.partCount),[1,1,1]);
 const order=result.tasks.find(t=>t.kind==='ORDER'),supply=result.tasks.find(t=>t.kind==='SUPPLY'),hq=result.tasks.find(t=>t.kind==='HQ_SUPPLY');
 assert.equal(order.quantity,4);assert.equal(supply.quantity,2);assert.equal(hq.quantity,null);
 assert.equal(order.row,row);assert.equal(order.id,'Flex|TEST-000001|ORDER|CENTER');
 assert.match(supply.text,/기존 PO 2개/);assert.match(supply.text,/법인·본사 공급 일정/);
 assert.equal(hq.quantityBasis,'SUPPLY_REVIEW_NOT_PURCHASE_QTY');assert.equal(result.quantityTotal,null);
});

test('no center PO leaves the order with the center regardless of upstream stock',()=>{
 for(const stock of [{india:0,hq:0},{india:0,hq:10},{india:10,hq:0},{india:null,hq:null}]){
  const row=member({open:0,proposed:6,...stock}),result=Followups.evaluate(state(),calculated([row]),{asof:DATE});
  assert.deepEqual(keys(result),['ORDER|CENTER']);
  assert.equal(result.tasks[0].quantity,6);assert.equal(result.tasks[0].quantityBasis,'TOTAL_ADDITIONAL_PO');
  assert.match(result.tasks[0].text,/추가 PO 총 6개 필요/);
 }
});

test('known repair-only PO need remains actionable when the total average/target is unknown',()=>{
 const row=member({stock:1,needed:5,shortage:4,open:1,avg:null,target:null,proposed:null});
 const task=Followups.evaluate(state(),calculated([row]),{asof:DATE}).tasks.find(t=>t.kind==='ORDER');
 assert.equal(task.quantity,3);assert.equal(task.quantityBasis,'CURRENT_REPAIR_ONLY');assert.match(task.text,/보유분·총 추가 PO 미계산/);
 const unknown=member({stock:null,needed:5,shortage:null,open:1,avg:null,target:null,proposed:null});
 assert.equal(Followups.evaluate(state(),calculated([unknown]),{asof:DATE}).tasks.some(t=>t.kind==='ORDER'),false);
});

test('all actionable center rows survive a global representative category and a center filter',()=>{
 const rows=[member(),member({center:'CTDI',stock:0,needed:0,shortage:0,open:0,proposed:2,target:2,avg:2})];
 const input=calculated(rows);input.parts=[rows[0]];
 const all=Followups.evaluate(state(),input,{asof:DATE});
 assert(all.tasks.some(t=>t.center==='CTDI'&&t.kind==='ORDER'));
 const ctdi=Followups.evaluate(state(),input,{asof:DATE,center:'CTDI'});
 assert.deepEqual(ctdi.tasks.map(t=>t.center),['CTDI']);assert.equal(ctdi.partCount,1);
});

test('stock verification requires linked WIP gross need and genuinely known sufficient center stock',()=>{
 const wip=[waiting()],row=member({stock:1,needed:1,shortage:0,open:0,proposed:0,dashboardDate:'2024-08-10'});
 const result=Followups.evaluate(state(),calculated([row],{wip}),{asof:DATE});
 assert.deepEqual(keys(result),['WIP_STOCK|CENTER']);const task=result.tasks[0];
 assert.equal(task.quantity,1);assert.equal(task.priority,1);assert.equal(task.text,'재고 사용·자재대기 상태 확인');
 assert.match(task.notes.join(' '),/기준일 차이/);assert.match(task.notes.join(' '),/제품 전체의 즉시 수리 가능/);
 for(const stock of [0,null,undefined,-1]){
  const bad={...row,stock};assert.equal(Followups.evaluate(state(),calculated([bad],{wip}),{asof:DATE}).tasks.some(t=>t.kind==='WIP_STOCK'),false);
 }
 assert.equal(Followups.evaluate(state(),calculated([row]),{asof:DATE}).tasks.some(t=>t.kind==='WIP_STOCK'),false);
});

test('TAT uses WIP source dates and deduplicates products across parallel tasks and required parts',()=>{
 const wip=[waiting({receipt:'2024-06-28',tokens:{parts:{[PART]:1,[OTHER]:1},unparsed:''}}),
  waiting({sn:'SYNTHETIC-TWO',rma:'RMA-TWO',receipt:'2024-06-27'}),
  waiting({sn:'SYNTHETIC-THREE',rma:'RMA-THREE',receipt:null})];
 const result=Followups.evaluate(state(),calculated([member(),member({part:OTHER})],{wip}),{asof:'2024-09-12'});
 const task=result.tasks.find(t=>t.part===PART);assert.deepEqual(task.tat,{products:3,overdueProducts:1,maxAge:46,unknownAgeProducts:1,sourceDates:[DATE]});
 assert.equal(result.tatSummary.products,3);assert.equal(result.tatSummary.overdueProducts,1);
 assert.equal(result.tasks.find(t=>t.part===OTHER).tat.overdueProducts,0);
 assert(result.tasks.reduce((sum,t)=>sum+t.tat.products,0)>result.tatSummary.products);
});

test('ETD matching is not shipment confirmation and mismatched PO quantities never assign its date to all pending units',()=>{
 const po={center:'Flex',part:PART,po:'SYN-PO',item:'1',ordered:2,shipped:0,pending:2,etd:'2024-08-10',date:'2024-08-09',row:2};
 const row=member({poSourceDate:po.date}),input=calculated([row],{pos:[po]});
 const task=Followups.evaluate(state(),input,{asof:DATE}).tasks.find(t=>t.kind==='SUPPLY');
 assert.match(task.scheduleNote,/법인 출고 예정 2024-08-10/);assert.match(task.scheduleNote,/실제 출고 여부 확인/);
 assert.equal(task.poFollowup.receiptConfirmed,false);assert.equal(task.poFollowup.dispatchConfirmed,false);
 const mismatched=Followups.evaluate(state(),calculated([{...row,open:3,india:1}],{pos:[po]}),{asof:DATE}).tasks.find(t=>t.kind==='SUPPLY');
 assert.equal(mismatched.poFollowup.matched,false);assert.equal(mismatched.poFollowup.plannedQuantity,0);
 assert.doesNotMatch(mismatched.scheduleNote,/법인 출고 예정 2024-08-10/);assert.match(mismatched.scheduleNote,/연결 확인/);
 assert.equal(mismatched.recipient,'INDIA');
});

test('normal stock with an open PO does not create noisy supply requests while quantity-covered low stock does',()=>{
 const normal=member({stock:20,needed:0,shortage:0,open:5,proposed:0,target:2});
 assert.equal(Followups.evaluate(state(),calculated([normal]),{asof:DATE}).tasks.length,0);
 const covered={...normal,stock:0};const result=Followups.evaluate(state(),calculated([covered]),{asof:DATE});
 assert.deepEqual(keys(result),['HQ_SUPPLY|HQ']);assert.equal(result.tasks[0].quantity,null);
 assert.match(result.tasks[0].text,/기존 PO 5개/);assert.match(result.tasks[0].text,/본사 자재 확보/);
});

test('valid ETD pending quantity belongs to India scheduling even when both stock snapshots are zero',()=>{
 const row=member({open:5,proposed:1}),po={center:'Flex',part:PART,po:'SYN-PO',item:'1',ordered:5,shipped:0,pending:5,etd:'2024-08-19',date:DATE,row:2};
 const result=Followups.evaluate(state(),calculated([row],{pos:[po]}),{asof:DATE});
 assert.deepEqual(keys(result),['ORDER|CENTER','SUPPLY|INDIA']);
 const task=result.tasks.find(t=>t.kind==='SUPPLY');
 assert.equal(task.quantity,5);assert.match(task.text,/기존 PO 5개 · 법인 출고 예정 2024-08-19/);
 assert.equal(task.supplyRoleKey,'INDIA');assert.equal(task.poFollowup.receiptConfirmed,false);
});

test('partial ETD separates India scheduled supply from the unscheduled upstream portion',()=>{
 const row=member({open:5,proposed:1}),pos=[
  {center:'Flex',part:PART,po:'SYN-PO',item:'1',ordered:2,shipped:0,pending:2,etd:'2024-08-19',date:DATE,row:2},
  {center:'Flex',part:PART,po:'SYN-PO',item:'2',ordered:3,shipped:0,pending:3,etd:null,date:DATE,row:3}];
 const result=Followups.evaluate(state(),calculated([row],{pos}),{asof:DATE});
 assert.deepEqual(keys(result),['ORDER|CENTER','SUPPLY|INDIA','HQ_SUPPLY|HQ']);
 const india=result.tasks.find(t=>t.recipient==='INDIA'),hq=result.tasks.find(t=>t.recipient==='HQ');
 assert.equal(india.quantity,2);assert.match(india.text,/기존 PO 2개/);assert.doesNotMatch(india.text,/기존 PO 5개/);
 assert.match(hq.text,/기존 PO 3개 · 본사 자재 확보/);assert.equal(hq.quantity,null);
 const shared=Followups.evaluate(state(),calculated([{...row,india:2}],{pos}),{asof:DATE});
 const sharedIndia=shared.tasks.find(t=>t.recipient==='INDIA'),sharedHq=shared.tasks.find(t=>t.recipient==='HQ');
 assert.equal(sharedIndia.quantity,5);assert.match(sharedIndia.text,/기존 PO 2개.*기존 PO 3개/);
 assert.match(sharedHq.text,/기존 PO 3개 입고 대기.*법인·본사 공급 일정/);
 assert.equal(shared.quantityTotal,null);
});

test('low usage is a badge only, never an exclusion, quantity change, priority change or sorting key',()=>{
 const rows=[member({part:OTHER}),member()],input=calculated(rows);
 const low=Followups.evaluate(state(),input,{asof:DATE});
 const highInput=structuredClone(input);for(const source of highInput.used)for(const row of source.rows)for(const month of MONTHS)row.usage[month]=20;
 const high=Followups.evaluate(state(),highInput,{asof:DATE});
 assert(low.tasks.every(t=>t.lowUsage));assert(high.tasks.every(t=>!t.lowUsage));
 assert.deepEqual(low.tasks.map(t=>[t.id,t.priority,t.quantity]),high.tasks.map(t=>[t.id,t.priority,t.quantity]));
});

test('current shortage priorities use related overdue products and age before material codes, with no low-use demotion',()=>{
 const rows=[member(),member({part:OTHER,shortage:1,needed:1,open:0,proposed:2})];
 const wip=[waiting({tokens:{parts:{[PART]:1},unparsed:''},receipt:'2024-08-01'}),
  waiting({sn:'SECOND',rma:'SECOND',tokens:{parts:{[OTHER]:1},unparsed:''},receipt:'2024-05-01'})];
 const result=Followups.evaluate(state(),calculated(rows,{wip}),{asof:DATE});
 assert.equal(result.tasks[0].part,OTHER);assert.equal(result.tasks[0].priority,0);
});

test('long-lead requests are common per code and recipient counts deduplicate simultaneous shortage work',()=>{
 const rows=[member(),member({center:'CTDI'})],st=state({partLeadTimes:{[PART]:{longLead:true,months:6,note:''}}});
 const input=calculated(rows),result=Followups.evaluate(st,input,{asof:DATE});
 const lt=result.tasks.filter(t=>t.kind.startsWith('LT_'));
 assert.equal(lt.length,2);assert.deepEqual(lt.map(t=>t.center),['공통','공통']);assert(lt.every(t=>t.quantity===null&&t.longLead));
 assert.equal(lt.find(t=>t.recipient==='INDIA').kind,'LT_REQUEST');assert.equal(lt.find(t=>t.recipient==='HQ').kind,'LT_REVIEW');
 assert.equal(result.recipients.find(r=>r.key==='HQ').partCount,1);assert.equal(result.recipients.find(r=>r.key==='HQ').taskCount,3);
 const scoped=Followups.evaluate(st,input,{asof:DATE,center:'CTDI'});assert.equal(scoped.tasks.filter(t=>t.kind.startsWith('LT_')).length,2);
 assert(scoped.tasks.every(t=>t.center==='CTDI'||t.center==='공통'));
 const unlinked=Followups.evaluate(st,input,{asof:DATE,center:'UnknownCenter'});assert.equal(unlinked.tasks.length,0);
});

test('long-lead source gaps and confirmed zero usage do not become purchase review tasks',()=>{
 const st=state({partLeadTimes:{[PART]:{longLead:true,months:6,note:''}}});
 const row=member({needed:0,shortage:0,open:0,proposed:0,avg:0});
 assert.equal(Followups.evaluate(st,calculated([row]),{asof:DATE}).tasks.length,0);
 for(const missing of [{demand:null,demandComplete:false},{hq:null}]){
  const input=calculated([{...row,avg:1}]);Object.assign(input.commonSupport.parts[0],missing);
  assert.equal(Followups.evaluate(st,input,{asof:DATE}).tasks.some(t=>t.kind.startsWith('LT_')),false);
 }
});

test('evaluation preserves frozen state and calculation evidence, and ids survive report/quantity updates',()=>{
 const st=deepFreeze(state()),input=deepFreeze(calculated([member()],{wip:[waiting()]})),before=JSON.stringify({st,input});
 const first=Followups.evaluate(st,input,{asof:DATE});assert.equal(JSON.stringify({st,input}),before);
 const second=Followups.evaluate(st,calculated([member({proposed:8})],{wip:[waiting()]}),{asof:'2024-08-19'});
 assert.deepEqual(first.tasks.map(t=>t.id),second.tasks.map(t=>t.id));
 assert.equal(first.tasks.find(t=>t.kind==='ORDER').quantity,4);assert.equal(second.tasks.find(t=>t.kind==='ORDER').quantity,8);
 assert.equal(first.liabilityConfirmed,false);
});
