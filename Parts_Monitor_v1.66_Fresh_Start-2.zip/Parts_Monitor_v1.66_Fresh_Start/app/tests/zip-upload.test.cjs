'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),zlib=require('node:zlib'),fs=require('node:fs'),os=require('node:os'),path=require('node:path'),http=require('node:http');
const {expandZip,crc32}=require('../server/zip-upload.cjs');
const {createApplication}=require('../server.cjs');
function archive(entries){
 const locals=[],central=[];let offset=0;
 for(const entry of entries){
  const name=entry.rawName||Buffer.from(entry.name,'utf8'),content=Buffer.from(entry.content??'Excel bytes'),method=entry.method??8,flags=entry.flags??0x808,packed=method===8?zlib.deflateRawSync(content):content,crc=crc32(content),l=Buffer.alloc(30),c=Buffer.alloc(46);l.writeUInt32LE(0x04034b50);l.writeUInt16LE(20,4);l.writeUInt16LE(flags,6);l.writeUInt16LE(method,8);l.writeUInt16LE(name.length,26);
  if(!(flags&8)){l.writeUInt32LE(crc,14);l.writeUInt32LE(packed.length,18);l.writeUInt32LE(content.length,22);}
  const descriptor=flags&8?Buffer.alloc(16):Buffer.alloc(0);if(descriptor.length){descriptor.writeUInt32LE(0x08074b50);descriptor.writeUInt32LE(crc,4);descriptor.writeUInt32LE(packed.length,8);descriptor.writeUInt32LE(content.length,12);}
  c.writeUInt32LE(0x02014b50);c.writeUInt16LE(0x314,4);c.writeUInt16LE(20,6);c.writeUInt16LE(flags,8);c.writeUInt16LE(method,10);c.writeUInt32LE(crc,16);c.writeUInt32LE(packed.length,20);c.writeUInt32LE(content.length,24);c.writeUInt16LE(name.length,28);c.writeUInt32LE(entry.attributes??0,38);c.writeUInt32LE(offset,42);locals.push(l,name,packed,descriptor);central.push(c,name);offset+=l.length+name.length+packed.length+descriptor.length;
 }
 const directory=Buffer.concat(central),end=Buffer.alloc(22);end.writeUInt32LE(0x06054b50);end.writeUInt16LE(entries.length,8);end.writeUInt16LE(entries.length,10);end.writeUInt32LE(directory.length,12);end.writeUInt32LE(offset,16);return Buffer.concat([...locals,directory,end]);
}
const expand=(entries,options)=>expandZip(archive(entries),{archiveName:'Weekly.zip',...options});
test('stored and deflated Excel in nested folders retain exact bytes and Korean names; other files are listed',()=>{
 const data=Buffer.from([0,1,2,255,128,7]),result=expand([{name:'2026-10-12/' ,content:'',method:0,flags:0x800},{name:'2026-10-12/법인 재고.xlsx',content:data},{name:'WIP.xlsb',content:data,method:0,flags:0x800},{name:'legacy.xls',content:data},{name:'readme.txt',content:'hello'},{name:'~$lock.xlsx',content:'temp'},{name:'nested.zip',content:'not expanded'}]);
 assert.equal(result.fileCount,3);assert.equal(result.totalBytes,data.length*3);assert.deepEqual(result.excelFiles.map(f=>f.name),['법인 재고.xlsx','WIP.xlsb','legacy.xls']);for(const file of result.excelFiles)assert.deepEqual(Buffer.from(file.base64,'base64'),data);assert.equal(result.excelFiles[0].relativePath,'2026-10-12/법인 재고.xlsx');assert.equal(result.ignoredEntries.length,4);assert.match(result.ignoredEntries.at(-1).reason,/내부 ZIP/);
});
test('legacy Korean names without UTF-8 flag can be read without renaming',()=>{const result=expand([{rawName:Buffer.concat([Buffer.from([0xb0,0xa1]),Buffer.from('.xlsx')]),flags:0,method:0}]);assert.equal(result.excelFiles[0].name,'가.xlsx');});
test('traversal, absolute paths, Windows drives and NUL names are rejected before export',()=>{for(const name of ['../stock.xlsx','x/../../stock.xlsx','/stock.xlsx','C:\\stock.xlsx','a//stock.xlsx','a/./stock.xlsx','a\u0000.xlsx'])assert.throws(()=>expand([{name}]),/허용하지 않는 파일 경로/);});
test('duplicate Excel basenames are rejected rather than silently overwriting a staged file',()=>{assert.throws(()=>expand([{name:'a/WIP.xlsb'},{name:'b/wip.XLSB'}]),/같은 Excel 파일 이름/);assert.throws(()=>expand([{name:'WIP.xlsb'},{name:'WIP.xlsb'}]),/같은 경로/);});
test('encrypted, symlink and unsupported compression are rejected',()=>{assert.throws(()=>expand([{name:'WIP.xlsb',flags:0x809}]),/암호화/);assert.throws(()=>expand([{name:'WIP.xlsb',attributes:(0xa1ff<<16)>>>0}]),/일반 파일/);assert.throws(()=>expand([{name:'WIP.xlsb',method:12}]),/압축 방식/);});
test('truncated ZIP, local-header mismatch, corrupt data and corrupt descriptor fail atomically',()=>{
 const good=archive([{name:'stock.xlsx',method:0,flags:0x800}]);assert.throws(()=>expandZip(good.subarray(0,good.length-5)),/완전한 ZIP/);
 const name=Buffer.from(good);name[30]^=1;assert.throws(()=>expandZip(name),/목록과 본문/);
 const bad=Buffer.from(good);bad[30+'stock.xlsx'.length]^=1;assert.throws(()=>expandZip(bad),/무결성/);
 const descriptor=archive([{name:'stock.xlsx'}]);const idx=descriptor.indexOf(Buffer.from([0x50,0x4b,0x07,0x08]));descriptor[idx+4]^=1;assert.throws(()=>expandZip(descriptor),/끝 정보/);
});
test('declared size and count budgets prevent oversized expansion, including ignored files',()=>{
 assert.throws(()=>expand([{name:'stock.xlsx',content:'123456'}],{maxEntryBytes:5}),/허용 범위/);
 assert.throws(()=>expand([{name:'stock.xlsx',content:'123'},{name:'notes.txt',content:'123'}],{maxTotalBytes:5}),/전체 크기/);
 assert.throws(()=>expand([{name:'one.xls'},{name:'two.xls'}],{maxExcelFiles:1}),/Excel 파일 수/);
 assert.throws(()=>expand([{name:'one.xls'},{name:'two.txt'}],{maxEntries:1}),/항목이 너무 많/);
 assert.throws(()=>expand([{name:'stock.xlsx',content:'a'.repeat(10000)}],{maxRatio:2}),/허용 범위/);
});
test('empty workbook and archive with no workbook do not appear as a successful import',()=>{assert.throws(()=>expand([{name:'empty.xlsx',content:''}]),/빈 Excel/);assert.throws(()=>expand([{name:'notes.txt'}]),/읽을 Excel/);assert.throws(()=>expandZip(Buffer.alloc(0)),/완전한 ZIP/);});
function request(address,route,{method='GET',body,headers={}}={}){return new Promise((resolve,reject)=>{const req=http.request(new URL(route,address.localUrl),{method,headers:{...(body?{'Content-Length':body.length}:{}),...headers},agent:false},res=>{const chunks=[];res.on('data',v=>chunks.push(v));res.on('end',()=>{const text=Buffer.concat(chunks).toString();let data;try{data=JSON.parse(text)}catch{}resolve({status:res.statusCode,data,text});});});req.on('error',reject);if(body)req.write(body);req.end();});}
async function start(t,options={}){const base=fs.mkdtempSync(path.join(os.tmpdir(),'parts-zip-test-')),templatePath=path.join(base,'template.html');fs.writeFileSync(templatePath,'<!doctype html><html><script id="seed" type="application/json">{}</script></html>');const app=createApplication({config:path.join(base,'none.json'),dataDir:path.join(base,'data'),templatePath,host:'127.0.0.1',port:0,...options});const address=await app.listen();t.after(async()=>{await app.close();fs.rmSync(base,{recursive:true,force:true});});const session=await request(address,'/api/session');return {app,address,headers:{'X-Parts-Request':'1','X-CSRF-Token':session.data.csrfToken,'X-File-Name':encodeURIComponent('이번 주.zip'),'Content-Type':'application/zip'}};}
test('ZIP HTTP expansion uses existing same-origin/token protection and never changes stored data',async t=>{
 const {app,address,headers}=await start(t),body=archive([{name:'센터/WIP.xlsb',content:'exact bytes'}]);
 for(const bad of [{},{...headers,'X-CSRF-Token':'wrong'},{...headers,Origin:'http://attacker.invalid'}])assert.equal((await request(address,'/api/expand-upload',{method:'POST',headers:bad,body})).status,403);
 const response=await request(address,'/api/expand-upload',{method:'POST',headers:{...headers,Origin:address.localUrl},body});assert.equal(response.status,200,response.text);assert.equal(response.data.fileCount,1);assert.equal(response.data.excelFiles[0].name,'WIP.xlsb');assert.equal(Buffer.from(response.data.excelFiles[0].base64,'base64').toString(),'exact bytes');assert.equal(app.store.status().rawCount,0);assert.equal(app.store.status().revision,0);
 assert.equal((await request(address,'/api/expand-upload',{method:'POST',headers:{...headers,'X-File-Name':'..%2Fbad.zip'},body})).status,400);
 assert.equal((await request(address,'/api/expand-upload',{method:'POST',headers:{...headers,'Content-Type':'application/json'},body})).status,415);
});
test('ZIP HTTP request observes upload cap before parsing',async t=>{const {address,headers}=await start(t,{maxUploadMB:0.00001});assert.equal((await request(address,'/api/expand-upload',{method:'POST',headers,body:archive([{name:'WIP.xlsb'}])})).status,413);});
