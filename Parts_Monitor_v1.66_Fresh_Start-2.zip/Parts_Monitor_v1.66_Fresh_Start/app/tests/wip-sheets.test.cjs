'use strict';
// Invented workbooks only. Register names describe supported public schemas;
// product identities, codes, dates and quantities below are synthetic.
const test=require('node:test'),assert=require('node:assert/strict');
const C=require('../src/core.js'),R=require('../src/reporting.js'),P=require('../src/pipeline.js'),T=require('../src/wip-tat.js'),H=require('../src/history.js');
const X=require('../vendor/xlsx.full.min.js');
const DATE='2024-08-12',PART='TEST-000001',OTHER='TEST-000002';
const HEADERS=['Final Status','Required Part','Serial No','RMA No','Physical Receipt Date','FERT','Family'];
function row(sn,required=PART,status='Waiting for Component',rma='R'+sn){return [status,required,sn,rma,'07/01/2024','TEST-PRODUCT','TEST-FAMILY']}
function workbook(sheets){const wb=X.utils.book_new();for(const [name,rows] of Object.entries(sheets))X.utils.book_append_sheet(wb,X.utils.aoa_to_sheet([HEADERS,...rows]),name);return wb}
function load(sheets,options={}){return C.importWorkbook(workbook(sheets),'Synthetic_Flex_12082024.xlsx',X,{center:'Flex',...options})}
function stateFor(sources){const state=C.empty(),months=['2024-02','2024-03','2024-04','2024-05','2024-06','2024-07'];state.sources=[
 {type:'dashboard',center:'Flex',operator:'',date:DATE,dateLabel:DATE,file:'Synthetic_Stock.xlsx',sheet:'Inventory',holdDate:null,usageMonths:months,rows:[{part:PART,stock:0,po:0,usage:Object.fromEntries(months.map(m=>[m,1])),row:4}]},
 {type:'po',center:'Flex',operator:'',date:DATE,dateLabel:DATE,file:'Synthetic_PO.xlsx',sheet:'Orders',rows:[]},
 ...sources
 ];return state}

test('all supported current registers become one logical WIP snapshot with row provenance',()=>{
 const imported=load({Inhouse:[row('BASE')],'InHouse FAN Repair':[row('FAN',PART+' #2')],'FAN-Inhouse':[row('OTHER',OTHER)],'CDU50 SHELF':[row('EMPTY','','')]});
 assert.equal(imported.sources.length,1);const source=imported.sources[0];
 assert.equal(source.type,'wip');assert.equal(source.total,4);assert.equal(source.rows.length,3);
 assert.deepEqual(source.sheets,['Inhouse','InHouse FAN Repair','FAN-Inhouse','CDU50 SHELF']);
 assert.equal(source.statuses.EMPTY,undefined);assert.equal(source.statuses['EMPTY|REMPTY'],'');
 assert.equal(source.sheetAudit.length,4);assert(source.sheetAudit.every(a=>a.status==='included'));
 assert.equal(source.sheetAudit.find(a=>a.sheet==='CDU50 SHELF').waitingRows,0);
 assert.equal(source.rows.find(r=>r.sn==='FAN').sheet,'InHouse FAN Repair');
 assert.equal(source.wipImportComplete,true);assert.equal(new Set(imported.sources.map(C.sourceKey)).size,1);
 const merged=C.merge(C.empty(),imported.sources),normalized=R.normalizeState(merged);
 assert.equal(normalized.sources.length,1);assert.equal(normalized.sources[0].rows.length,3);
 const review=P.evaluate(C.empty(),imported.sources,DATE);assert.equal(review.ok,true);assert.equal(review.selectedSources.length,1);assert.equal(review.rows.find(r=>r.key==='flex:wip:Jio').status,'new');
 const restored=R.normalizeState(JSON.parse(JSON.stringify(normalized)));assert.equal(restored.sources[0].rows.length,3);assert.deepEqual(restored.sources[0].sheetAudit,source.sheetAudit);
});

test('only Waiting Component and Module are demand even when other statuses have Required Part',()=>{
 const imported=load({Inhouse:[row('MAIN')],'InHouse FAN Repair':[
  row('MODULE',PART+' #3','Waiting for Module'),row('SHIPPED',PART+' #9','Shipped HQ'),row('REPAIR',PART+' #8','For Repair'),row('YET',PART+' #7','Yet HQ'),row('BLANK',PART+' #6','')
 ]});
 const source=imported.sources[0];assert.equal(source.total,6);assert.equal(source.rows.length,2);
 assert.equal(source.sheetAudit.find(a=>a.sheet==='InHouse FAN Repair').requiredRows,5);
 assert.equal(source.sheetAudit.find(a=>a.sheet==='InHouse FAN Repair').waitingQuantity,3);
 assert.equal(C.calculate(stateFor(imported.sources),DATE,'Flex').parts.find(p=>p.part===PART).needed,4);
});

test('separate operators remain separate snapshots inside a workbook',()=>{
 const imported=load({'WIP_Jio':[row('J')],'WIP_Airtel':[row('A')],'WIP_Vi':[row('V')]},{center:'CTDI'});
 assert.deepEqual(imported.sources.map(s=>s.operator),['Jio','Airtel','Vi']);assert.equal(new Set(imported.sources.map(C.sourceKey)).size,3);
 const state=C.merge(C.empty(),imported.sources);assert.equal(state.sources.length,3);
 assert.equal(C.calculate(state,DATE,'CTDI').wip.length,3);
});

test('identical cross-sheet products count once with an audit and preserve first status',()=>{
 const imported=load({Inhouse:[row('SAME'),row('DONE',PART,'Repaired')],'FAN-Inhouse':[row('SAME'),row('DONE',PART,'Repaired'),row('NEW',OTHER)]}),source=imported.sources[0];
 assert.equal(source.total,3);assert.equal(source.rows.length,2);assert.equal(source.duplicates.length,0);
 assert.equal(source.duplicateDetails.length,2);assert(source.duplicateDetails.every(d=>d.kind==='identical'&&d.crossSheet));
 assert.equal(source.duplicateDetails[0].selected.sheet,'Inhouse');assert.equal(source.duplicateDetails[0].ignored.sheet,'FAN-Inhouse');
 assert.equal(source.statuses['DONE|RDONE'],'Repaired');assert.equal(source.rows[0].sheet,'Inhouse');
 assert.equal(C.calculate(stateFor(imported.sources),DATE,'Flex').parts.find(p=>p.part===PART).needed,1);
 assert(imported.warnings.some(w=>w.includes('FAN-Inhouse')&&w.includes('중복')));
});

test('conflicting cross-sheet products never silently sum and incomplete demand stays unknown',()=>{
 const imported=load({Inhouse:[row('SAME',PART,'Repaired')],'FAN-Inhouse':[row('SAME',PART+' #5')]}),source=imported.sources[0];
 assert.equal(source.total,1);assert.equal(source.rows.length,0);assert.equal(source.statuses['SAME|RSAME'],'Repaired');
 assert.deepEqual(source.duplicates,['SAME|RSAME']);assert.equal(source.duplicateDetails[0].kind,'conflicting');assert.equal(source.wipImportComplete,false);
 const result=C.calculate(stateFor(imported.sources),DATE,'Flex');assert.equal(result.parts.find(p=>p.part===PART).needed,null);assert(result.warnings.some(w=>w.includes('값 불일치')));
});

test('identical same-sheet products count once and preserve the duplicate audit',()=>{
 const imported=load({Inhouse:[row('DUP'),row('DUP')]}),source=imported.sources[0];
 assert.equal(source.rows.length,1);assert.equal(source.total,1);assert.equal(source.duplicateDetails[0].crossSheet,false);assert.equal(source.duplicates.length,1);
 assert.equal(C.calculate(stateFor(imported.sources),DATE,'Flex').parts.find(p=>p.part===PART).needed,1);
 assert.equal(C.wipIntegrity(source).productsComplete,true);
});

test('conflicting nonwaiting records do not suppress unrelated waiting demand, including old saved imports',()=>{
 const imported=load({Inhouse:[row('WAIT',PART+' #6'),row('TEST','0','For Test')],'FAN-Inhouse':[row('TEST','2nd lot(510#)','Repairable')]});
 const s=imported.sources[0],before=JSON.stringify(s),result=C.calculate(stateFor(imported.sources),DATE,'Flex');
 assert.equal(s.wipImportComplete,false); // Original audit remains intact.
 assert.equal(C.wipIntegrity(s).demandComplete,true);
 assert.equal(result.parts.find(p=>p.part===PART).needed,6);
 assert.equal(result.parts.find(p=>p.part===PART).shortage,6);
 assert.equal(result.wip.length,1);assert.equal(JSON.stringify(s),before);
});

test('waiting conflicts affect both candidate parts but leave independent parts calculable',()=>{
 const third='TEST-000003',imported=load({Inhouse:[row('BAD',PART+' #2'),row('GOOD',third+' #7')],'FAN-Inhouse':[row('BAD',OTHER+' #4')]});
 const result=C.calculate(stateFor(imported.sources),DATE,'Flex'),by=new Map(result.parts.map(r=>[r.part,r]));
 assert.equal(by.get(PART).needed,null);assert.equal(by.get(OTHER).needed,null);
 assert.equal(by.get(third).needed,7);assert.equal(by.get(third).shortage,7);
 assert.equal(result.wip.length,1);assert.equal(result.wip[0].sn,'GOOD');
});

test('unlocatable waiting conflicts and unexplained legacy duplicate flags remain blocked',()=>{
 const s=load({Inhouse:[row('BAD',PART)],'FAN-Inhouse':[row('BAD','unreadable')]}).sources[0];
 assert.equal(C.wipIntegrity(s).globalBlocked,true);
 assert.equal(C.wipIntegrity({duplicates:['legacy'],rows:[]}).globalBlocked,true);
});

test('recognized auxiliary, historical and summary sheets are audited without double counting',()=>{
 const imported=load({Inhouse:[row('SAME')],'Delay Cause':[row('SAME')],'TEFR':[row('OTHER',PART+' #50')],'Nameplate Tracker':[row('PLATE','Name Plate')],'Historical':[row('HIST',PART+' #70')],'WIP Summary':[row('SUM',PART+' #90')],'WIP Aging':[row('AGING',PART+' #80')]}),source=imported.sources[0];
 assert.equal(source.rows.length,1);assert.equal(source.total,1);assert.equal(source.wipImportComplete,true);assert.equal(source.sheetAudit.length,7);
 assert(source.sheetAudit.filter(a=>a.status==='excluded').every(a=>a.waitingRows===1&&!a.reviewRequired));
 assert.equal(C.calculate(stateFor(imported.sources),DATE,'Flex').parts.find(p=>p.part===PART).needed,1);
});

test('unknown detail sheets with active waiting rows visibly block a complete WIP demand claim',()=>{
 const imported=load({Inhouse:[row('MAIN')],'Unregistered Register':[row('NEW',OTHER+' #4')]}),source=imported.sources[0];
 const audit=source.sheetAudit.find(a=>a.sheet==='Unregistered Register');assert.equal(audit.status,'excluded');assert.equal(audit.reviewRequired,true);assert.equal(audit.waitingRows,1);assert.equal(source.wipImportComplete,false);
 assert.equal(source.rows.length,1);assert(source.importWarnings.some(w=>w.includes('Unregistered Register')));
 const result=C.calculate(stateFor(imported.sources),DATE,'Flex');assert.equal(result.parts.find(p=>p.part===PART).needed,null);assert(result.warnings.some(w=>w.includes('전체 필요량 확정 불가')));
 const withHold=stateFor(imported.sources);withHold.sources[0].holdDate=DATE;withHold.sources[0].rows[0].hold=8;
 const part=C.calculate(withHold,DATE,'Flex').parts.find(p=>p.part===PART);assert.equal(part.needed,8);assert.equal(part.needBasis,'dashboard');
 const quiet=load({Inhouse:[row('MAIN')],'Unregistered Register':[row('NEW',OTHER,'Repaired')]});assert.equal(quiet.sources[0].wipImportComplete,true);
});

test('supported register with broken headers fails rather than silently omitting products',()=>{
 const wb=workbook({Inhouse:[row('MAIN')]});X.utils.book_append_sheet(wb,X.utils.aoa_to_sheet([['Final Status','Serial No','RMA No'],['Waiting for Component','BAD','RBAD']]),'FAN-Inhouse');
 assert.throws(()=>C.importWorkbook(wb,'Synthetic_Flex_12082024.xlsx',X,{center:'Flex'}),/FAN-Inhouse.*WIP 필수 헤더/);
});

test('unknown product detail with waiting status and missing Required Part still blocks completeness',()=>{
 const wb=workbook({Inhouse:[row('MAIN')]});X.utils.book_append_sheet(wb,X.utils.aoa_to_sheet([['Final Status','Serial No','RMA No'],['Waiting for Component','NEW','RNEW']]),'Unknown Register');
 const imported=C.importWorkbook(wb,'Synthetic_Flex_12082024.xlsx',X,{center:'Flex'}),source=imported.sources[0],audit=source.sheetAudit.find(a=>a.sheet==='Unknown Register');
 assert.equal(audit.waitingRows,1);assert.equal(audit.requiredRows,0);assert.equal(audit.reviewRequired,true);assert.equal(source.wipImportComplete,false);
 assert.equal(C.calculate(stateFor(imported.sources),DATE,'Flex').parts.find(p=>p.part===PART).needed,null);
});

test('WIP Aging without product detail headers is a summary rather than a broken register',()=>{
 const wb=workbook({Inhouse:[row('MAIN')]});X.utils.book_append_sheet(wb,X.utils.aoa_to_sheet([['Status','0-30 days','31-45 days'],['Waiting',4,2]]),'WIP Aging');
 const imported=C.importWorkbook(wb,'Synthetic_Flex_12082024.xlsx',X,{center:'Flex'}),source=imported.sources[0];
 assert.equal(source.rows.length,1);assert.equal(source.wipImportComplete,true);
 const audit=source.sheetAudit.find(a=>a.sheet==='WIP Aging');assert.equal(audit.kind,'summary');assert.equal(audit.status,'excluded');assert.equal(audit.reviewRequired,false);
});

test('empty known registers plus an unimported waiting sheet do not create a zero history total',()=>{
 const imported=load({Inhouse:[],'Unknown Register':[row('NEW')]}),state=C.merge(C.empty(),imported.sources);
 const snapshot=H.snapshot(state,DATE,{centers:['Flex']});assert.equal(snapshot.centers[0].parts.length,0);
 assert.equal(snapshot.centers[0].needed.value,null);assert.equal(snapshot.centers[0].needed.complete,false);assert(snapshot.centers[0].needed.reasons.some(r=>r.includes('불완전')));
 const legacy=C.empty();legacy.sources=[{type:'wip',center:'Flex',operator:'Jio',date:DATE,file:'Legacy.xlsx',sheet:'Inhouse',rows:[],duplicates:[]}];
 const legacySnapshot=H.snapshot(legacy,DATE,{centers:['Flex']});assert.equal(legacySnapshot.centers[0].needed.value,0);assert.equal(legacySnapshot.centers[0].needed.complete,true);
});

test('sheet and row evidence reaches material demand, missing-master origins and TAT',()=>{
 const imported=load({Inhouse:[row('MAIN')],'FAN-Inhouse':[row('FAN',OTHER+' #2')]}),result=C.calculate(stateFor(imported.sources),DATE,'Flex');
 const detail=result.wip.find(r=>r.sn==='FAN');assert.equal(detail.sheet,'FAN-Inhouse');assert.equal(detail.row,2);
 const missing=result.masterAlerts.find(a=>a.part===OTHER);assert.equal(missing.origins[0].sheet,'FAN-Inhouse');assert.equal(missing.origins[0].row,2);
 const tat=T.evaluate(result.wip);assert.equal(tat.summary.quantity,3);assert.equal(tat.rows.find(r=>r.sn==='FAN').sheet,'FAN-Inhouse');assert.equal(tat.rows.find(r=>r.sn==='FAN').age,42);
});

test('same-week correction replaces the entire bundle while earlier report versions survive',()=>{
 const original=load({Inhouse:[row('MAIN')],'FAN-Inhouse':[row('FAN',OTHER)]}).sources;
 let state=R.applySources(R.normalizeState(stateFor([])),original,DATE);
 state=R.recordWeek(state,'2024-08-19');const first=R.reports(state)[0],before=JSON.stringify(R.reportState(state,first.id).sources);
 const corrected=load({Inhouse:[row('MAIN')],'FAN-Inhouse':[row('FAN',OTHER+' #5')]}).sources;
 state=R.applySources(state,corrected,'2024-08-19');
 assert.equal(R.reports(state).length,2);assert.equal(JSON.stringify(R.reportState(state,first.id).sources),before);
 const latest=R.reportState(state),selected=latest.sources.find(s=>s.type==='wip');assert.equal(selected.rows.length,2);assert.equal(selected.rows.find(r=>r.sn==='FAN').tokens.parts[OTHER],5);
 const revised=load({Inhouse:[row('MAIN')],'FAN-Inhouse':[]}).sources;state=R.applySources(state,revised,'2024-08-19');
 assert.equal(R.reportState(state).sources.find(s=>s.type==='wip').rows.length,1);assert.equal(R.reports(state).length,2);assert.equal(JSON.stringify(R.reportState(state,first.id).sources),before);
});

test('code-separator spaces are normalized without inventing missing characters',()=>{
 for(const value of ['TEST- 000001','TEST -000001','TEST - 000001']){assert.deepEqual(C.partTokens(value+' #3').parts,{[PART]:3});assert.equal(C.partTokens(value+' #3').unparsed,'')}
 assert.deepEqual(C.partTokens('TES-000001').parts,{});assert.equal(C.partTokens('TES-000001').unparsed,'TES-000001');
 assert.deepEqual(C.partTokens('TEST-000001X9').parts,{['TEST-000001X9']:1});
 assert.deepEqual(C.partTokens('TEST - 000001 #2 + Nameplate').parts,{[PART]:2});
});
