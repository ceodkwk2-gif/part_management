'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),Dash=require('../src/stage-dashboard.js');
function fixture(){
 const elements=new Map(),make=(id='',dataset={})=>({id,dataset,attrs:{},listeners:{},innerHTML:'',textContent:'',value:'',hidden:true,disabled:false,setAttribute(k,v){this.attrs[k]=v},hasAttribute(k){return Object.hasOwn(this.dataset,k.replace(/^data-/,'').replace(/-([a-z])/g,(_,c)=>c.toUpperCase()))},addEventListener(k,f){this.listeners[k]=f},removeEventListener(k){delete this.listeners[k]},closest(){return this},getBoundingClientRect(){return {width:430}}});
 for(const m of Dash.TEMPLATE.matchAll(/id="([^"]+)"/g))elements.set('#'+m[1],make(m[1]));elements.set('.pa-summary',make());elements.set('.pf-centers',make());elements.set('[data-live-date]',make());elements.set('[data-empty-upload]',make());const centers=['ALL','CTDI','Flex'].map(center=>make('',{center}));
 const root=make('root');root.querySelector=s=>{assert(elements.has(s),'Missing selector '+s);return elements.get(s)};root.querySelectorAll=s=>s==='[data-center]'?centers:[];root.contains=()=>true;
 return {root,el:id=>elements.get('#'+id),click:dataset=>root.listeners.click({target:make('',dataset)})};
}
const rows=Array.from({length:25},(_,i)=>({id:'CTDI|TEST-'+String(i).padStart(6,'0'),part:'TEST-'+String(i).padStart(6,'0'),center:'CTDI',name:'Part '+i,stock:0,needed:i+1,shortage:i+1,open:0,india:0,hq:0,target:5,proposed:i+6,orderAssessed:true}));
const input={asof:'2026-10-12',week:'2026-10-12',rows,products:[],pos:[],siel:{available:false},sourceDates:[],trend:[{week:'2026-09-28',metricsByCenter:{'전체':{shortageKinds:10}}},{week:'2026-10-12',metricsByCenter:{'전체':{shortageKinds:25}}}]};
test('live dashboard pagination, actions, search, detail and request buttons use current data and full filtered scope',()=>{
 const f=fixture(),before=JSON.stringify(input),requests=[];let saved;const mount=Dash.mount(f.root,input,{onState:s=>saved=s,onRequests:o=>requests.push(o)});
 assert.match(f.el('pf-result-count').textContent,/25종 · 325개/);assert.equal((f.el('pf-table-body').innerHTML.match(/data-record-id=/g)||[]).length,10);
 f.click({requestSelected:''});assert.equal(requests.at(-1).rowIds.length,25);
 f.click({step:'1'});assert.equal(saved.page,2);assert.match(f.el('pf-page-info').textContent,/11–20/);
 f.el('pf-search').listeners.input({target:{value:'TEST-000024'}});assert.equal(saved.page,1);assert.match(f.el('pf-result-count').textContent,/1종 · 25개/);f.click({row:'CTDI|TEST-000024'});assert.match(f.el('pf-table-body').innerHTML,/현재 상태와 재고/);assert(!/NaN|undefined/.test(f.el('pf-table-body').innerHTML));
 f.click({action:'ORDER'});assert.equal(saved.query,'');f.click({requestSelected:''});assert.equal(requests.at(-1).action,'ORDER');assert.equal(requests.at(-1).rowIds.length,25);
 f.click({kind:'WAIT'});assert.equal(saved.action,'ALL');assert.equal(f.root.querySelector('.pa-summary').hidden,true);assert.match(f.el('pf-result-count').textContent,/0종/);
 f.click({center:'Flex'});f.click({requestAll:''});assert.equal(requests.at(-1).center,'Flex');assert.equal(requests.at(-1).rowIds,undefined);
 assert.equal(JSON.stringify(input),before);assert(f.el('pf-chart-actions').innerHTML.includes('10/05'));mount.destroy();assert.equal(f.root.listeners.click,undefined);
});
test('fresh dashboard gives an upload path without showing fabricated metrics',()=>{const f=fixture();let opened=false;Dash.mount(f.root,{rows:[]},{onUpload:()=>opened=true});assert.match(f.root.innerHTML,/첫 주차 자료를 업로드/);assert(!f.root.innerHTML.includes('0종'));f.root.querySelector('[data-empty-upload]').onclick();assert(opened)});

test('missing inputs show unassessed cards, not healthy zero shortages',()=>{const f=fixture();Dash.mount(f.root,{...input,rows:[],availabilityByCenter:{'전체':{actionAvailability:{shortage:false,order:false,wait:false}}}});assert.match(f.el('pf-metrics').innerHTML,/산정 불가/);assert.match(f.el('pf-metrics').innerHTML,/—<small>종<\/small>/);assert(!f.el('pf-metrics').innerHTML.includes('<strong>0'));assert.equal(f.root.querySelector('.pa-summary').hidden,true)});

test('embedded dashboard has a single center control and no request instructions',()=>{
 const f=fixture();Dash.mount(f.root,input,{externalCenterControl:true});assert.equal(f.root.querySelector('.pf-centers').hidden,true);
 assert(!/요청서|필요 액션|공급문서|자료 확인 필요/.test(f.root.innerHTML+f.el('pf-table-body').innerHTML+f.el('pa-context').innerHTML));
});
test('all-parts details include normal rows and all-order view uses the same status dashboard',()=>{
 const d={...input,rows:[...rows,{...rows[0],id:'CTDI|NORMAL-0001',part:'NORMAL-0001',stock:100,needed:1,shortage:0,proposed:0}]};
 const f=fixture();const mount=Dash.mount(f.root,d,{kind:'ALL'});assert.match(f.el('pf-result-count').textContent,/26종/);
 f.el('pf-search').listeners.input({target:{value:'NORMAL-0001'}});assert.match(f.el('pf-table-body').innerHTML,/수리센터 재고로 충당/);mount.destroy();
});

test('summary cards keep the table in place and PO calculation is available in expanded detail',()=>{
 const f=fixture();let target,saved;
 const row={...rows[0],needed:88,shortage:88,target:26,proposed:114};
 Dash.mount(f.root,{...input,rows:[row]},{onDetails:kind=>target=kind,onState:s=>saved=s});
 const html=f.el('pf-table-body').innerHTML;
 assert(!html.includes('pd-formula'));assert.match(html,/114개/);f.click({row:row.id});const detail=f.el('pf-table-body').innerHTML;assert.match(detail,/pd-formula/);assert.match(detail,/>88<\/span>/);assert.match(detail,/>26<\/span>/);assert.match(detail,/>114<\/strong>/);
 f.click({kind:'ORDER'});assert.equal(target,undefined);assert.equal(saved.kind,'ORDER');assert.match(f.el('pf-result-count').textContent,/0종/);
 f.click({kind:'SHORTAGE'});assert.match(f.el('pf-result-count').textContent,/1종 · 88개/);
 assert(!f.root.innerHTML.includes('id="pf-quality"'));assert(!f.root.innerHTML.includes('id="pf-order-total"'));
});
test('known adjacent weekly points stay connected when unresolved product identities change',()=>{
 const f=fixture(),trend=['2026-09-28','2026-10-05','2026-10-12'].map((week,i)=>({week,metricsByCenter:{'전체':{over45PartKinds:19+i,over45RequiredQty:25+i}},qualityByCenter:{'전체':{overdue:{partial:true,signature:String(i)}}}}));
 Dash.mount(f.root,{...input,trend});
 const path=f.el('pf-chart-combo').innerHTML.match(/<path d="([^"]+)"/)[1];
 assert.equal((path.match(/M/g)||[]).length,1);assert.equal((path.match(/L/g)||[]).length,2);
});

test('basic rows show PO dates and ETA; calculation and review evidence remain in expansion',()=>{
 const f=fixture(),row={...rows[0],needed:0,shortage:0,stock:2,target:15,open:20,proposed:0,waitingCovered:true,hq:970,india:0};
 const d={...input,rows:[row],siel:{available:true,sourceDate:'2026-10-19',rows:[{part:row.part,po:'P',item:'10',ordered:50,eta:'2027-01-28',status:'Buyer I/R'}]},availabilityByCenter:{'전체':{actionAvailability:{order:false}}}};
 let opened=false;Dash.mount(f.root,d,{kind:'WAIT',onChecks:()=>opened=true});
 assert.match(f.el('pf-metrics').innerHTML,/pf-coverage-note/);assert(!f.el('pf-metrics').innerHTML.includes('color:var(--pf-warm)'));
 assert.doesNotMatch(f.el('pf-table-body').innerHTML,/본사 재고·ETA 확인|PO 수량 확인/);assert.match(f.el('pf-table-body').innerHTML,/2027-01-28/);assert(!f.el('pf-table-body').innerHTML.includes('Buyer I/R'));
 assert(!Dash.TEMPLATE.includes('추가 PO 계산'));assert.match(Dash.TEMPLATE,/최초 부품대기 확인일/);
 f.click({showChecks:''});assert.equal(opened,true);f.click({row:row.id});assert.match(f.el('pf-table-body').innerHTML,/본사 재고 970개/);assert(!f.el('pf-table-body').innerHTML.includes('Buyer I/R'));
});


test('requested columns preserve monthly usage and each original PO date and quantity',()=>{
 const f=fixture(),r={...rows[0],avg:14.5,target:30,proposed:0,stock:2,needed:0,shortage:0,open:20,waitingCovered:true,hq:970,india:0};
 const d={...input,settings:{targetMonths:2},rows:[r],pos:[{part:r.part,center:'CTDI',po:'CENTER',poDate:'2026-10-10',ordered:20,pending:20,etd:'2026-10-22'}],siel:{available:true,rows:[{part:r.part,po:'HQ1',item:'10',poDate:'2026-09-25',ordered:10,eta:'2027-01-28'},{part:r.part,po:'HQ2',item:'10',poDate:'2026-10-07',ordered:20,eta:null}]}};
 let saved;Dash.mount(f.root,d,{kind:'WAIT',onState:s=>saved=s});const html=f.el('pf-table-body').innerHTML;
 const columns=['pd-part-cell','pd-stock-cell','pd-demand-cell','pd-usage-cell','pd-first-cell','pd-center-po','pd-hq-po','pd-action-cell'];
 for(let i=1;i<columns.length;i++)assert(html.indexOf(columns[i])>html.indexOf(columns[i-1]));
 assert.match(html,/pd-usage-cell[\s\S]*?<strong>15<\/strong>/);assert.match(html,/10\/10 · 20개/);assert.match(html,/ETD 10\/22/);assert.match(html,/09\/25 · 10개/);assert.match(html,/ETA 2027-01-28/);assert.match(html,/10\/07 · 20개/);assert.match(html,/도착 예정일 미정/);assert.match(Dash.TEMPLATE,/colspan="2" class="pd-po-group">PO/);
 f.el('pf-list-kind').listeners.change({target:{value:'ALL'}});assert.equal(saved.kind,'ALL');
 f.el('pf-list-kind').listeners.change({target:{value:'ORDER_ALL'}});assert.equal(saved.kind,'ORDER_ALL');
});

test('summary has one download entry and item notes stay optional, escaped and scoped',()=>{const f=fixture(),r=rows[0];let opened;Dash.mount(f.root,{...input,rows:[r]},{notes:{[r.id]:{plan:'<private memo>',editor:'Tester'}},onMemo:id=>opened=id});f.click({row:r.id});assert.match(f.el('pf-table-body').innerHTML,/&lt;private memo&gt;/);assert.match(f.el('pf-table-body').innerHTML,/메모 수정/);f.click({itemMemo:r.id});assert.equal(opened,r.id);assert(!Dash.TEMPLATE.includes('data-request-all'));assert.equal((Dash.TEMPLATE.match(/data-request-selected/g)||[]).length,1);});

test('action filters retain repair shortage 55; only action quantities split 11 and 44 in rows and exports',()=>{
 const Requests=require('../src/action-requests.js'),f=fixture();
 const r={id:'Flex|TEST-SPLIT',part:'TEST-SPLIT',center:'Flex',name:'Split supply',stock:0,needed:55,shortage:55,avg:54.7,target:55,open:151,proposed:0,india:11,hq:41,orderAssessed:true};
 const d={...input,rows:[r],products:[{center:'Flex',sn:'SN-41',age:41,parts:[{part:r.part,quantity:55}]}],siel:{available:true,rows:[{part:r.part,po:'HQ-ORDER',item:'1',ordered:189,eta:'2027-01-12'}]}};
 const before=JSON.stringify(d),cell=()=>f.el('pf-table-body').innerHTML.match(/<td class="pd-demand-cell">([\s\S]*?)<\/td>/)[1];
 Dash.mount(f.root,d);
 for(const action of ['ALL','DISPATCH','HQ','MULTI']){
  f.click({action});assert.match(cell(),/<\/span>55<\/strong>/);assert.doesNotMatch(cell(),/pd-secondary|전체 부족/);
  assert.match(f.el('pf-result-count').textContent,/1종 · 55개/);
  assert.match(f.el('pf-table-body').innerHTML,/법인 → 수리센터 공급 필요 <strong>11개/);
  assert.match(f.el('pf-table-body').innerHTML,/본사 → 법인 입고 대기 <strong>44개/);
  const exported=Requests.build(d,{rowIds:[r.id],action}).rows[0];assert.equal(exported.shortage,55);
  if(action==='DISPATCH')assert.match(exported.status,/공급 필요 11/);
  if(action==='HQ')assert.match(exported.status,/입고 대기 44/);
 }
 f.click({action:'ALL'});f.el('pf-list-kind').listeners.change({target:{value:'ALL'}});assert.match(cell(),/<\/span>55<\/strong>/);
 assert.equal(JSON.stringify(d),before);
 const aged={...d,products:[{center:'Flex',sn:'SN-60',age:60,parts:[{part:r.part,quantity:7}]},{center:'Flex',sn:'SN-41',age:41,parts:[{part:r.part,quantity:48}]}]},g=fixture();
 Dash.mount(g.root,aged);g.click({action:'DISPATCH'});
 const agedCell=g.el('pf-table-body').innerHTML.match(/<td class="pd-demand-cell">([\s\S]*?)<\/td>/)[1];
 assert.match(agedCell,/<\/span>55<\/strong>/);assert.match(agedCell,/45↑ 필요 7/);assert.doesNotMatch(agedCell,/전체 부족/);
});

test('reserve order and waiting lists share the same shortage and action quantities with exports',()=>{
 const Requests=require('../src/action-requests.js');
 const base={center:'Flex',stock:2,needed:0,shortage:0,avg:15,target:15,india:0,hq:0,orderAssessed:true};
 const order={...base,id:'Flex|TEST-RESERVE-ORDER',part:'TEST-RESERVE-ORDER',open:3,proposed:10},wait={...base,id:'Flex|TEST-RESERVE-WAIT',part:'TEST-RESERVE-WAIT',open:20,proposed:0,waitingCovered:true};
 const d={...input,rows:[order,wait],products:[],pos:[]};
 for(const [kind,r,expected]of [['ORDER',order,/추가 PO 필요 <strong>10개/],['WAIT',wait,/수리센터 입고 대기 <strong>20개/]]){
  const f=fixture();Dash.mount(f.root,d,{kind});const h=f.el('pf-table-body').innerHTML;
  assert.match(h,/<td class="pd-demand-cell">[\s\S]*?<\/span>0<\/strong>/);assert.match(h,expected);
  const exported=Requests.build(d,{rowIds:[r.id],kind}).rows[0];assert.equal(exported.shortage,0);
  if(kind==='ORDER'){assert.match(h,/수리 0 \+ 보유 10/);assert.match(exported.status,/수리 0 \+ 보유 10/);}
  else {assert.match(h,/보유분 부족 13개 · 추가 PO 0개/);assert.equal(exported.open,20);assert.match(exported.status,/입고 대기 20/);}
 }
});
