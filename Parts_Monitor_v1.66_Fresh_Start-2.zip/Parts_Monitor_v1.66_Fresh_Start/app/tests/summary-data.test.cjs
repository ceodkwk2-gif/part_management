'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm');
const C=require('../src/core'),R=require('../src/reporting'),A=require('../src/actions'),O=require('../src/operations'),S=require('../src/summary-data');
const part='1000-000001',other='1000-000002',months=['2026-04','2026-05','2026-06','2026-07','2026-08','2026-09'];
const product=(sn='S1',parts={[part]:1},extra={})=>({key:sn+'|R1',sn,rma:'R1',receipt:'2026-08-01',status:'Waiting for Component',required:Object.keys(parts).join(','),tokens:{parts,unparsed:''},row:2,...extra});
const wip=(date,rows=[product()],center='Flex',operator='Jio',extra={})=>({type:'wip',center,operator,date,file:'Synthetic.xlsx',sheet:'Inhouse',duplicates:[],wipImportComplete:true,statuses:Object.fromEntries(rows.map(row=>[row.key,row.status])),rows,...extra});
const dashboard=(date,rows)=>({type:'dashboard',center:'Flex',operator:'',date,file:'Dashboard.xlsx',sheet:'Parts',holdDate:null,usageMonths:months,rows:rows||[{part,description:'RCHIP; Synthetic',stock:0,hold:0,po:0,row:2,usage:Object.fromEntries(months.map(month=>[month,1]))}]});
function initial(sources){return R.normalizeState({...C.empty(),sources});}
function fullWeek(date,rows){return [dashboard(date),wip(date,rows),{type:'po',center:'Flex',date,file:'PO.xlsx',sheet:'PO',rows:[]},{type:'india',date,file:'India.xlsx',sheet:'Stock',rows:[]},{type:'hq',date,file:'HQ.xlsx',sheet:'Stock',rows:[]}];}
function latest(state){return R.reports(state).at(-1);}

test('empty installation provides a complete empty contract without inventing a week',()=>{
 const result=S.build(C.empty());assert.equal(result.dataAvailable,false);assert.equal(result.week,null);assert.deepEqual(result.trend,[]);assert.equal(result.metricsByCenter['전체'].wip,0);assert.equal(result.overdue.fresh,false);assert.deepEqual(result.supplierEvidence,[]);assert.throws(()=>S.build(C.empty(),{reportId:'2026-10-05'}),/저장된/);
});
test('latest saved report is default, explicit past report excludes future evidence, and input stays unchanged',()=>{
 let state=initial(fullWeek('2026-09-28'));state=R.applySources(state,fullWeek('2026-10-05',[product(),product('S2')]),'2026-10-05');state=R.selectReport(state,'2026-09-28');const before=JSON.stringify(state);
 const now=S.build(state),past=S.build(state,{reportId:'2026-09-28'});assert.equal(now.week,'2026-10-05');assert.equal(now.products.length,2);assert.equal(past.products.length,1);assert.equal(past.trend.length,1);assert.equal(JSON.stringify(state),before);assert(now.checks.traceKeysComplete);assert(now.checks.exclusiveMetricsMatch);
});
test('reused old WIP is reference only and does not become a fresh weekly point',()=>{
 let state=initial([wip('2026-09-28')]);state=R.applySources(state,[],'2026-10-05');const output=S.build(state),point=output.trend.at(-1);
 assert.equal(output.products[0].date,'2026-09-28');assert.equal(output.products[0].age,58);assert.equal(output.products[0].parts[0].observations,1);assert.equal(output.overdue.freshByCenter.Flex,false);
 for(const key of ['wip','over45','over45PartKinds','over45RequiredQty'])assert.equal(point.metricsByCenter.Flex[key],null);assert.equal(point.observedWaitingChanges.Flex.available,false);
});
test('week-only inventory and PO retain unknown actual date and never create day ages',()=>{
 const india=C.assignReportWeek({type:'india',date:null,file:'WK41.xlsx',sheet:'Stock',rows:[{part,qty:12,row:2}]},'2026-10-05');
 const po=C.assignReportWeek({type:'po',center:'Flex',date:null,file:'PO.xlsx',sheet:'PO',rows:[{part,po:'P1',item:'1',poDate:'2026-09-28',ordered:3,shipped:1,pending:2,etd:'2026-10-08',row:2}]},'2026-10-05');
 const output=S.build(initial([dashboard('2026-10-05'),wip('2026-10-05'),india,po]));const src=output.sourceDates.find(source=>source.type==='india');
 assert.equal(src.date,null);assert.equal(src.reportWeek,'2026-10-05');assert.equal(src.datePrecision,'week');assert.equal(src.hasExactDate,false);assert.equal(src.fresh,true);assert.equal(output.availabilityByCenter.Flex.indiaStock,true);assert.equal(output.rows[0].india,12);assert.equal(output.rows[0].sourceDates.india,null);assert.equal(output.rows[0].sourceWeeks.india,'2026-10-05');assert.equal(output.pos[0].age,null);assert.equal(output.pos[0].date,null);assert.equal(output.pos[0].reportWeek,'2026-10-05');
});
test('four genuine reports preserve baseline, new/continuing/not-listed and gaps without claiming repairs completed',()=>{
 let state=initial([wip('2026-09-21',[product('A')])]);state=R.applySources(state,[wip('2026-09-28',[product('A'),product('B')])],'2026-09-28');state=R.applySources(state,[wip('2026-10-05',[product('B')])],'2026-10-05');state=R.applySources(state,[wip('2026-10-19',[product('B'),product('C')])],'2026-10-19');
 const output=S.build(state),points=output.trend;assert.equal(points.length,4);assert.equal(points[0].observedWaitingChanges.Flex.newProducts,null);assert.equal(points[1].observedWaitingChanges.Flex.newProducts,1);assert.equal(points[2].observedWaitingChanges.Flex.notListedProducts,1);assert.match(points[2].observedWaitingChanges.Flex.reason,/수리 완료를 뜻하지 않음/);assert.equal(points[3].observedWaitingChanges.Flex.reportGapDays,14);assert.equal(points[3].observedWaitingChanges.Flex.consecutiveReportingWeeks,false);assert.equal(points[3].observedWaitingChanges.Flex.continuingProducts,1);assert.deepEqual(points.map(p=>p.week),['2026-09-21','2026-09-28','2026-10-05','2026-10-19']);
});
test('multi-part products separate product count from required quantity and keep related PO unallocated',()=>{
 const input=product('A',{[part]:3,[other]:1});const state=initial([wip('2026-09-28',[input]),{type:'po',center:'Flex',date:'2026-09-28',file:'PO.xlsx',sheet:'PO',rows:[{part,po:'P1',item:'1',poDate:'2026-09-20',ordered:4,shipped:0,pending:4,row:2}]}]);
 const output=S.build(state);assert.equal(output.overdue.metricsByCenter['전체'].products,1);assert.equal(output.overdue.metricsByCenter['전체'].partKinds,2);assert.equal(output.overdue.metricsByCenter['전체'].requiredQty,4);assert.equal(output.overdue.groups.reduce((sum,group)=>sum+group.products,0),2);assert.deepEqual(output.overdue.groups.find(group=>group.part===part).centers[0].poIndices,[0]);assert.equal(output.pos[0].age,8);assert.equal(output.pos.length,1);assert(!('allocatedPO' in output.products[0]));assert(output.products[0].parts.every(entry=>entry.baseline));assert(output.products[0].parts.every(entry=>entry.firstDate==='2026-09-28'));
});
test('TAT boundary is strictly over 45 and incomplete CTDI WIP never claims a complete fresh trend',()=>{
 const state=initial([wip('2026-10-05',[product('A',{[part]:1},{receipt:'2026-08-21'}),product('B',{[part]:1},{receipt:'2026-08-20'})],'CTDI','Jio')]);const output=S.build(state);assert.equal(output.metricsByCenter.CTDI.wip,2);assert.equal(output.metricsByCenter.CTDI.over45,1);assert.equal(output.trend[0].metricsByCenter.CTDI.wip,null);assert.equal(output.overdue.freshByCenter.CTDI,false);
});
test('supplier evidence must match product and part, added date is not need date, future diagnostics are excluded',()=>{
 const state=initial([wip('2026-10-05')]),record={center:'Flex',operator:'Jio',sn:'S1',rma:'R1',part,date:'2026-10-05',source:'Synthetic.xlsx',sheet:'Delay Cause',row:2,addedDate:'2026-09-01'};
 state.supplierRecords=[record,{...record,row:3,recordedNeedDate:'2026-10-01',delayReason:'Vendor note'},{...record,row:4,part:other,recordedNeedDate:'2026-10-01'}];state.importDiagnostics={weeks:[{reportWeek:'2026-10-05',excluded:[]},{reportWeek:'2026-10-12',excluded:[{file:'future.xlsx'}]}]};
 const output=S.build(state);assert.equal(output.supplierEvidence.length,1);assert.equal(output.supplierEvidence[0].recordedNeedDate,'2026-10-01');assert.equal(output.supplierEvidence[0].liabilityConfirmed,false);assert.equal(output.products[0].parts[0].firstDate,'2026-10-05');assert.equal(output.importDiagnostics.weeks.length,1);assert.equal(state.importDiagnostics.weeks.length,2);
});
test('summary categories match full Actions evaluation while registered scope excludes WIP-only parts',()=>{
 const state=initial(fullWeek('2026-10-05',[product('A',{[part]:1,[other]:1})])),report=latest(state),resolved=R.reportState(state,report.id),calculated=C.calculate(resolved,report.cutoff),ex=A.exclusiveStatus(A.evaluate(resolved,report.cutoff),O.evaluate(resolved,calculated).lowUsage),output=S.build(state);
 for(const [code,name] of [['SUPPLY_NOW','shortage'],['ORDER','order'],['WAIT_PO','wait']]){const group=ex.groups.find(g=>g.code===code);assert.equal(output.metricsByCenter['전체'][name+'Kinds'],group.partCount);assert.equal(output.metricsByCenter['전체'][name+'Qty'],group.quantity.knownSubtotal);}
 assert.equal(output.metricsByCenter.Flex.registeredKinds,1);assert.equal(output.metricsByCenter['전체'].registeredKinds,null);assert.equal(output.metricsByCenter['전체'].dashboardMissingKinds,1);assert.equal(output.rows.find(row=>row.part===other).registered,false);assert.equal(output.rows.find(row=>row.part===other).avg,null);
});
test('blank supplier-row audit survives without manufacturing earlier audit totals',()=>{
 let state=initial([wip('2026-10-05')]);state=R.applySources(state,[wip('2026-10-12')],'2026-10-12');state.supplierRecords=[];state.supplierEvidenceStatus={reviewedRows:6,matchedRows:0,matchedPopulatedRows:0,available:false,sourceDates:['2026-10-05','2026-10-12'],bySource:[{date:'2026-10-05',reviewedRows:2},{date:'2026-10-12',reviewedRows:4}],note:'Blank supplier rows audited'};
 assert.equal(S.build(state).supplierEvidenceStatus.reviewedRows,6);assert.equal(S.build(state,{reportId:'2026-10-05'}).supplierEvidenceStatus.reviewedRows,2);assert.equal(S.build(state).supplierEvidence.length,0);
});
test('browser UMD works without require, filesystem or hardcoded data',()=>{
 const sandbox={PartsCore:C,PartsReporting:R,PartsActions:A,PartsOperations:O,PartsFollowups:require('../src/followups'),PartsWipTat:require('../src/wip-tat'),PartsWipTrace:require('../src/wip-trace'),PartsNames:require('../src/part-names'),PartsLeadTime:require('../src/leadtime'),PartsI18n:require('../src/i18n'),PartsSiel:require('../src/siel')};sandbox.self=sandbox;vm.runInNewContext(fs.readFileSync(require.resolve('../src/summary-data'),'utf8'),sandbox);const result=sandbox.PartsSummaryData.build(initial([wip('2026-09-28')]));assert.equal(result.products.length,1);assert.equal(result.week,'2026-09-28');
});
test('common stock reference keeps approved quantities and removes repeated raw evidence',()=>{
 const state=initial(fullWeek('2026-10-05')),report=latest(state),expected=C.calculate(R.reportState(state,report.id),report.cutoff).commonSupport,output=S.build(state).commonSupport;
 assert.equal(output.parts.length,expected.parts.length);assert.deepEqual(output.settings,expected.settings);assert.deepEqual(output.sourceDates,expected.sourceDates);
 for(const row of output.parts){const original=expected.parts.find(part=>part.part===row.part);for(const field of ['demand','demandComplete','india','hq','indiaTarget','hqTarget','indiaGap','hqGap','active'])assert.equal(row[field],original[field]);assert(!('owner' in row));assert(!('centerBalances' in row));assert.equal(typeof row.name,'string');}
});

test('WIP-only history counts unresolved waiting as shortage while PO trends stay unavailable',()=>{
 const output=S.build(initial([wip('2026-10-05')])),point=output.trend[0];
 assert.equal(point.metricsByCenter.Flex.wip,1);
 assert.deepEqual(point.availableByCenter.Flex.actionAvailability,{shortage:true,order:false,wait:false});
 assert.equal(point.metricsByCenter.Flex.shortageKinds,1);assert.equal(point.metricsByCenter.Flex.shortageQty,1);
 for(const c of ['전체','CTDI']){assert.equal(point.metricsByCenter[c].shortageKinds,null);assert.equal(point.metricsByCenter[c].shortageQty,null);}
 for(const c of ['전체','Flex','CTDI'])for(const kind of ['order','wait']){assert.equal(point.metricsByCenter[c][kind+'Kinds'],null);assert.equal(point.metricsByCenter[c][kind+'Qty'],null);}
 assert.match(point.notes.join(' '),/산정 불가/);
});
test('dashboard open PO supports replenishment without a detailed PO file; absent open quantity does not',()=>{
 const ready=S.build(initial([dashboard('2026-10-05'),wip('2026-10-05')]));
 assert.deepEqual(ready.availabilityByCenter.Flex.actionAvailability,{shortage:true,order:true,wait:true});assert.equal(ready.trend[0].metricsByCenter.Flex.shortageKinds,1);
 const ds=dashboard('2026-10-05');ds.rows[0].po=null;
 const missing=S.build(initial([ds,wip('2026-10-05')]));assert.deepEqual(missing.availabilityByCenter.Flex.actionAvailability,{shortage:true,order:false,wait:false});assert.equal(missing.trend[0].metricsByCenter.Flex.shortageKinds,1);assert.equal(missing.trend[0].metricsByCenter.Flex.orderKinds,null);
});
test('missing monthly demand hides only replenishment and waiting metrics; actual repair shortage remains valid',()=>{
 const ds=dashboard('2026-10-05');ds.rows[0].usage['2026-04']=null;
 const output=S.build(initial([ds,wip('2026-10-05')]));assert.deepEqual(output.availabilityByCenter.Flex.actionAvailability,{shortage:true,order:false,wait:false});assert.equal(output.trend[0].metricsByCenter.Flex.shortageQty,1);assert.equal(output.trend[0].metricsByCenter.Flex.waitQty,null);
});
test('legacy weekly PO trend retains registered known counts when a WIP-only code lacks usage',()=>{
 const base=initial([dashboard('2026-10-05'),wip('2026-10-05')]);
 const before=S.build(base).trend[0].metricsByCenter.Flex;
 const extended=initial([dashboard('2026-10-05'),wip('2026-10-05',[product(),product('S2',{[other]:1})])]);
 const output=S.build(extended),point=output.trend[0];
 assert.equal(point.availableByCenter.Flex.actionAvailability.order,false);
 assert.equal(point.qualityByCenter.Flex.order.unknownRows,1);
 assert.equal(output.rows.find(r=>r.part===other).proposed,null);
 assert.equal(point.metricsByCenter.Flex.orderKinds,before.orderKinds);
 assert.equal(point.metricsByCenter.Flex.orderQty,before.orderQty);
 assert.equal(point.metricsByCenter.Flex.waitQty,before.waitQty);
});
test('a complete center remains available when the other center lacks its stock and demand',()=>{
 const out=S.build(initial([...fullWeek('2026-10-05'),wip('2026-10-05',[product()],'CTDI','Jio')]));
 assert.equal(out.availabilityByCenter.Flex.actionAvailability.shortage,true);assert.equal(out.availabilityByCenter.CTDI.actionAvailability.shortage,false);assert.equal(out.availability.actionAvailability.shortage,false);
 assert.equal(out.trend[0].metricsByCenter.Flex.shortageKinds,1);assert.equal(out.trend[0].metricsByCenter.전체.shortageKinds,null);
});
test('valid retained source quantities remain dated references rather than unavailable sources',()=>{
 let state=initial(fullWeek('2026-10-05'));state=R.applySources(state,[wip('2026-10-12')],'2026-10-12');const out=S.build(state),p=out.trend.at(-1);
 assert.equal(p.availableByCenter.Flex.centerStock,false);assert.deepEqual(p.availableByCenter.Flex.actionAvailability,{shortage:true,order:true,wait:true});assert.equal(p.metricsByCenter.Flex.shortageKinds,1);assert(p.sourceDates.find(s=>s.type==='dashboard').carriedForward);
});
test('genuinely empty but valid dashboard and WIP supports zero action counts',()=>{
 const out=S.build(initial([dashboard('2026-10-05',[]),wip('2026-10-05',[])]));assert.deepEqual(out.availabilityByCenter.Flex.actionAvailability,{shortage:true,order:true,wait:true});assert.equal(out.trend[0].metricsByCenter.Flex.shortageKinds,0);assert.equal(out.trend[0].metricsByCenter.Flex.orderKinds,0);
});
