'use strict';

// Invented workbooks only; no operating exports or material codes.
const test = require('node:test');
const assert = require('node:assert/strict');
const C = require('../src/core.js');
const X = require('../vendor/xlsx.full.min.js');
const PART = 'TEST-000001';

function workbook(name, rows) {
  return {SheetNames:[name],Sheets:{[name]:X.utils.aoa_to_sheet(rows)}};
}
function poWorkbook(rows = [['PO-1','2026-09-20',8],['PO-2','2026-09-28',0]]) {
  return workbook('PO', [
    ['Part No','PO No','PO Date','PO Qty','Shipped Qty','Pending Qty','Pending Aging','Ship To Name'],
    ...rows.map(([po,date,age]) => [PART,po,date,10,2,8,age,'CTDI Communications']),
  ]);
}
function dashboardWorkbook(header = 'CTDI_20260928', holdDate = '2026-09-28') {
  return workbook('CTDI Component Dashboard', [
    ['Samsung Part','CTDI Part','Description','Component Usage','','Monthly Inflow','Waiting Component',header,''],
    ['','','','Jul-2026','Aug-2026','Sep-2026',holdDate,'Stock','Open PO'],
    [],
    [PART,'INTERNAL-1','Synthetic part',2,4,5,3,7,8],
  ]);
}

test('delimited YYMMDD source dates are calendar validated without interpreting an eight-digit suffix', () => {
  assert.equal(C.fileDate('Component dashboard_260928.xlsx'),'2026-09-28');
  assert.equal(C.fileDate('component (240229).xlsx'),'2024-02-29');
  assert.equal(C.fileDate('260928.xlsx'),'2026-09-28');
  assert.equal(C.fileDate('component_20260928.xlsx'),'2026-09-28');
  assert.equal(C.fileDate('Samsung4GWipReport28092026.xlsb'),'2026-09-28');
  for (const value of ['260230','250229','261332','991332','20260230','20261301','1260928','CODE260928']) {
    assert.equal(C.fileDate(`Synthetic_${value}.xlsx`),null,value);
  }
  assert.equal(C.fileDate('Network Stock WK40.xlsx'),null);
});

test('compact dashboard filename and explicit stock header agree without a warning', () => {
  const result=C.importWorkbook(dashboardWorkbook(),'Component dashboard_260928.xlsx',X);
  const s=result.sources[0];
  assert.equal(s.date,'2026-09-28');
  assert.equal(s.detectedFileDate,'2026-09-28');
  assert.equal(s.dateBasis,'filename');
  assert.equal(s.headerDate,'2026-09-28');
  assert.equal(s.headerDateCell,'H1');
  assert.equal(s.holdDate,'2026-09-28');
  assert.deepEqual(s.dateDiagnostics,[]);
  assert.equal(s.rows[0].stock,7);
  assert.equal(s.rows[0].po,8);
  assert.equal(s.rows[0].hold,3);
});

test('only an explicit center stock header can provide a missing dashboard snapshot date', () => {
  const result=C.importWorkbook(dashboardWorkbook(),'Component dashboard.xlsx',X);
  assert.equal(result.sources[0].date,'2026-09-28');
  assert.equal(result.sources[0].dateBasis,'dashboard-header');
  assert.equal(result.sources[0].detectedFileDate,null);
  const holdOnly=C.importWorkbook(dashboardWorkbook('CTDI_20'),'Component dashboard.xlsx',X);
  assert.equal(holdOnly.sources[0].date,null);
  assert.equal(holdOnly.sources[0].holdDate,'2026-09-28');
  assert.equal(holdOnly.sources[0].dateBasis,'unconfirmed');
  assert.ok(holdOnly.warnings.some(w=>w.includes('기준일 미확인')));
});

test('dashboard header and future Hold conflicts warn during import without changing the filename date', () => {
  const result=C.importWorkbook(dashboardWorkbook(),'Component dashboard_260921.xlsx',X),s=result.sources[0];
  assert.equal(s.date,'2026-09-21');
  assert.equal(s.dateBasis,'filename');
  assert.deepEqual(s.dateDiagnostics.map(d=>d.type),['dashboard-header-date-conflict','dashboard-hold-after-source-date']);
  assert.ok(result.warnings.some(w=>w.includes('2026-09-21')&&w.includes('2026-09-28')));
});

test('PO aging and future order dates warn before upload while keeping the detected filename date', () => {
  const result=C.importWorkbook(poWorkbook(),'Open PO Report_26.09.26.xlsx',X),s=result.sources[0];
  assert.equal(s.date,'2026-09-26');
  assert.equal(s.inferredDate,'2026-09-28');
  assert.equal(s.detectedFileDate,'2026-09-26');
  assert.equal(s.dateBasis,'filename');
  assert.deepEqual(s.dateDiagnostics.map(d=>d.type),['po-aging-date-conflict','po-order-after-source-date']);
  assert.deepEqual(s.dateDiagnostics[1].rows,[3]);
  assert.equal(s.rows[0].pending,8);
  assert.equal(result.warnings.length,2);
});

test('manual confirmed PO date is authoritative while preserving filename evidence', () => {
  const result=C.importWorkbook(poWorkbook(),'Open PO Report_26.09.26.xlsx',X,{date:'2026-09-28'}),s=result.sources[0];
  assert.equal(s.date,'2026-09-28');
  assert.equal(s.manualDate,'2026-09-28');
  assert.equal(s.dateBasis,'manual');
  assert.equal(s.detectedFileDate,'2026-09-26');
  assert.equal(s.inferredDate,'2026-09-28');
  assert.deepEqual(s.dateDiagnostics.map(d=>d.type),['manual-file-date-override']);
  assert.equal(s.dateDiagnostics[0].resolvedByManualDate,true);
  assert.ok(result.warnings[0].includes('사용자 지정 기준일'));
});

test('a manually chosen date still warns if orders occur after that date', () => {
  const result=C.importWorkbook(poWorkbook(),'Open PO Report_26.09.26.xlsx',X,{date:'2026-09-25'}),s=result.sources[0];
  assert.equal(s.date,'2026-09-25');
  assert.ok(s.dateDiagnostics.some(d=>d.type==='po-order-after-source-date'));
  assert.ok(s.dateDiagnostics.some(d=>d.type==='po-aging-date-conflict'));
});

test('consistent PO aging can supply an undated file but never a conflicting filename date', () => {
  const result=C.importWorkbook(poWorkbook(),'Open PO Report.xlsx',X),s=result.sources[0];
  assert.equal(s.date,'2026-09-28');
  assert.equal(s.dateBasis,'po-aging');
  assert.deepEqual(s.dateDiagnostics,[]);
  const inconsistent=C.importWorkbook(poWorkbook([['PO-1','2026-09-20',8],['PO-2','2026-09-20',7]]),'Open PO Report.xlsx',X);
  assert.equal(inconsistent.sources[0].date,null);
  const invalidAge=C.importWorkbook(poWorkbook([['PO-1','2026-09-20',-1]]),'Open PO Report.xlsx',X);
  assert.equal(invalidAge.sources[0].date,null);
});

test('week-only stock stays undated until explicitly confirmed, and invalid manual dates are rejected', () => {
  const wb=workbook('Stock',[['Material','UNR Stock'],[PART,14]]);
  const automatic=C.importWorkbook(wb,'Network Stock WK40.xlsx',X).sources[0];
  assert.equal(automatic.date,null);
  assert.equal(automatic.dateLabel,'WK40');
  assert.equal(automatic.dateBasis,'unconfirmed');
  const manual=C.importWorkbook(wb,'Network Stock WK40.xlsx',X,{date:'2026-09-28'}).sources[0];
  assert.equal(manual.date,'2026-09-28');
  assert.equal(manual.dateBasis,'manual');
  assert.equal(manual.detectedFileDate,null);
  for(const date of ['2026-02-30','09/28/2026','bad']) {
    assert.throws(()=>C.importWorkbook(wb,'Network Stock WK40.xlsx',X,{date}),/YYYY-MM-DD/);
  }
});
