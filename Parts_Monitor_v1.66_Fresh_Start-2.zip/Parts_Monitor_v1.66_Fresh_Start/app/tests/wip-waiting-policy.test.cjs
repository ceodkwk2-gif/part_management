'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const C=require('../src/core.js'),R=require('../src/reporting.js'),Summary=require('../src/summary-data.js'),Data=require('../src/stage-data.js'),Stages=require('../src/supply-stages.js'),Requests=require('../src/action-requests.js'),Dashboard=require('../src/stage-dashboard.js');
const DATE='2026-10-12',A='TEST-000301',B='TEST-000302',months=['2026-04','2026-05','2026-06','2026-07','2026-08','2026-09'];
function source(type,center,rows,extra={}){return {type,center,date:DATE,file:'Synthetic '+type+'.xlsx',sheet:'Synthetic',rows,...extra};}
function product(part,quantity,receipt,sn){return {key:sn+'|R',sn,rma:'R',receipt,status:'Waiting for Component',required:part+'#'+quantity,tokens:{parts:{[part]:quantity},unparsed:''},row:2};}
function wip(center,operator,rows){return source('wip',center,rows,{operator,duplicates:[],wipImportComplete:true,statuses:Object.fromEntries(rows.map(r=>[r.key,r.status]))});}
function fixture(){
 const row=(part,stock)=>({part,stock,hold:0,po:0,row:2,usage:Object.fromEntries(months.map(m=>[m,1]))});
 return R.normalizeState({...C.empty(),sources:[
  source('dashboard','Flex',[row(A,30)],{holdDate:null,usageMonths:months}),
  source('dashboard','CTDI',[row(A,1),row(B,0)],{holdDate:null,usageMonths:months}),
  wip('Flex','Jio',[product(A,4,'2026-08-01','F')]),
  wip('CTDI','Jio',[product(A,2,'2026-08-01','C1'),product(B,5,'2026-08-28','C2')]),
  wip('CTDI','Airtel',[]),wip('CTDI','Vi',[]),source('po','Flex',[]),source('po','CTDI',[]),source('india','',[]),source('hq','',[])
 ]});
}
test('WIP waiting counts remain with full, partial, zero or unknown center stock; PO quantities stay separate',()=>{
 for(const stock of [30,1,0,null]){
  const state=fixture();state.sources.find(s=>s.type==='dashboard'&&s.center==='Flex').rows[0].stock=stock;
  const before=JSON.stringify(state),r=C.calculate(state,DATE,'Flex').parts.find(r=>r.part===A);
  assert.equal(r.shortage,4);assert.equal(r.shortageBasis,'wip-waiting');assert.equal(r.wipWaitingQty,4);
  assert.equal(r.stockShortage,stock===null?null:Math.max(0,4-stock));
  assert.equal(r.proposed,stock===null?null:Math.max(0,5-stock));
  assert.equal(JSON.stringify(state),before);
  const check=require('../src/pipeline.js').validate(R.normalizeState({...C.empty(),sources:state.sources}));assert.equal(check.ok,true,check.errors.join(' / '));
 }
});
test('same-code center counts, 45-day boundary, cards, charts and overdue lists reconcile',()=>{
 const state=fixture(),before=JSON.stringify(state),input=Summary.build(state),d=Data.build(input),last=input.trend.at(-1);
 for(const [scope,kinds,quantity,overKinds,overQty] of [['ALL',2,11,1,6],['CTDI',2,7,1,2],['Flex',1,4,1,4]]){
  const m=d.reportMetrics[scope],t=last.metricsByCenter[scope==='ALL'?'전체':scope];
  assert.deepEqual(m.SHORTAGE,{parts:kinds,quantity});assert.deepEqual(m.OVERDUE,{parts:overKinds,quantity:overQty});
  assert.equal(t.shortageKinds,kinds);assert.equal(t.shortageQty,quantity);assert.equal(t.over45PartKinds,overKinds);assert.equal(t.over45RequiredQty,overQty);
 }
 assert.equal(JSON.stringify(state),before);
});
test('stock/WIP review retains quantities without creating a redundant repair PO or upstream instruction',()=>{
 const input=Summary.build(fixture()),data=Data.build(input),stages=Stages.classify(data.rows,data.siel);
 for(const r of data.rows)assert.equal(stages.get(r.id).reduce((n,a)=>n+a.quantity,0),r.shortage);
 const flex=data.rows.find(r=>r.center==='Flex'&&r.part===A),records=Stages.statusRecords(flex,stages.get(flex.id));
 assert.equal(records.length,1);assert.equal(records[0].code,'OTHER');assert.equal(records[0].quantity,4);assert.equal(records[0].basis,'center-stock-wip-review');
 assert.match(records[0].reason,/센터 재고.*WIP/);assert(flex.reviewFlags.some(f=>f.code==='WIP_STOCK'));
 assert(Requests.records(input,{recipient:'CENTER'}).some(a=>a.rowId===flex.id&&a.basis==='center-stock-wip-review'));
 assert(!Requests.records(input,{recipient:'INDIA'}).some(a=>a.rowId===flex.id));
 const checks=Dashboard.checksHTML(input,{center:'ALL',language:'ko'});assert.match(checks,/재고·WIP·PO·ETA/);assert.match(checks,/센터 재고 30 \/ WIP 자재대기 4/);
 const en=Dashboard.checksHTML(input,{center:'ALL',language:'en'});assert.match(en,/Center stock 30 \/ WIP waiting 4/);
 const ct=data.rows.find(r=>r.center==='CTDI'&&r.part===A),order=Stages.statusRecords(ct,stages.get(ct.id)).find(a=>a.code==='ORDER');
 assert.equal(order.quantity,2);assert.equal(order.repairQuantity,1);assert.equal(order.bufferQuantity,1);
});
test('stock-only corrections do not clear WIP; a changed WIP waiting list can clear it',()=>{
 const state=fixture(),stock=state.sources.find(s=>s.type==='dashboard'&&s.center==='Flex');stock.rows[0].stock=999;
 assert.equal(C.calculate(state,DATE,'Flex').parts.find(r=>r.part===A).shortage,4);
 const ws=state.sources.find(s=>s.type==='wip'&&s.center==='Flex');ws.rows=[];ws.statuses={};
 assert.equal(C.calculate(state,DATE,'Flex').parts.find(r=>r.part===A).shortage,0);
});
test('known WIP waiting remains in current and weekly metrics when stock is missing',()=>{
 const state=fixture();state.sources.find(s=>s.type==='dashboard'&&s.center==='Flex').rows[0].stock=null;
 const input=Summary.build(state),d=Data.build(input);
 assert.deepEqual(d.reportMetrics.ALL.SHORTAGE,{parts:2,quantity:11});
 assert.equal(input.trend.at(-1).metricsByCenter['전체'].shortageQty,11);
 assert.equal(input.trend.at(-1).metricsByCenter['전체'].shortageKinds,2);
 assert.equal(input.rows.find(r=>r.center==='Flex').proposed,null);
});

test('overdue downloads retain the selected WIP quantities alongside total repair shortage',()=>{
 const input=Summary.build(fixture()),d=Data.build(input),Share=require('../src/share-dialog.js'),XLSX=require('../vendor/xlsx.full.min.js');
 for(const scope of ['ALL','CTDI','Flex'])for(const language of ['ko','en']){
  const ids=d.indexes[scope].OVERDUE.flatMap(g=>g.ids),model=Requests.build(input,{center:scope,rowIds:ids,kind:'OVERDUE',recipient:'all',scopeSelection:true,language});
  assert.equal(model.partCount,d.reportMetrics[scope].OVERDUE.parts);
  assert.equal(model.rows.reduce((n,r)=>n+r.overdue,0),d.reportMetrics[scope].OVERDUE.quantity);
  assert(model.columns.some(c=>c.key==='overdue'));assert.match(Share.csv(Share.normalize(model,{language})),language==='en'?/Over-45-day required parts/:/45일 초과 필요 부품/);
  const bytes=Share.workbook([Share.normalize(model,{language})],XLSX),book=XLSX.read(bytes,{type:'array'});
  const cells=XLSX.utils.sheet_to_json(book.Sheets[book.SheetNames[0]],{header:1});
  const label=model.columns.find(c=>c.key==='overdue').label,header=cells.findIndex(row=>row.includes(label)),index=cells[header].indexOf(label);
  assert.equal(cells.slice(header+1).reduce((n,row)=>n+(Number(row[index])||0),0),d.reportMetrics[scope].OVERDUE.quantity);
 }
});
