'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const path = require('node:path');
const { spawnSync } = require('node:child_process');
const C = require('../src/core.js');
const R = require('../src/reporting.js');
const { verify } = require('../scripts/verify-state.cjs');

function fixture() {
  const state = C.empty();
  state.settings.months = 1;
  state.sources = ['Flex', 'CTDI'].map(center => ({
    type: 'dashboard', center, operator: '', date: '2024-08-12', holdDate: '2024-08-12',
    file: 'PRIVATE-NAME-MUST-NOT-APPEAR.xlsx', sheet: 'Synthetic', usageMonths: ['2024-07'],
    rows: [{ part: 'TEST-000001', row: 5, stock: 2, hold: 4, po: 1, usage: { '2024-07': 3 } }],
  }));
  return state;
}
test('read-only verifier checks arithmetic without exposing row identities', () => {
  const input = fixture(), before = JSON.stringify(input), report = verify(input);
  assert.equal(report.ok, true);
  assert.equal(report.summary.shortagePartKinds, 1);
  assert.equal(report.summary.shortageKnownUnits, 4);
  assert.equal(report.summary.additionalOrderKnownUnits, 8);
  assert.equal(JSON.stringify(input), before);
  assert(!JSON.stringify(report).includes('TEST-000001'));
  assert(!JSON.stringify(report).includes('PRIVATE-NAME'));
});
test('topmost duplicate remains usable; missing values remain warnings, not invented zeros', () => {
  const state = fixture();
  state.sources[0].rows.unshift({ ...state.sources[0].rows[0], row: 99, stock: 999 });
  state.sources[1].rows[0].usage['2024-07'] = null;
  const report = verify(state);
  assert.equal(report.ok, true);
  assert.equal(report.warnings.duplicate_groups_using_first_row, 1);
  assert.equal(report.summary.shortageKnownUnits, 4);
  assert.equal(report.summary.additionalOrderUnknownRows, 1);
});
test('invalid negative selected inventory is a failed check', () => {
  const state = fixture(); state.sources[0].rows[0].stock = -1;
  const report = verify(state);
  assert.equal(report.ok, false);
  assert.equal(report.errors.invalid_calculated_stock, 1);
});
test('baseline catches offsetting row changes even when total shortage does not change', () => {
  const state = fixture(), baseline = verify(state);
  state.sources[0].rows[0].stock = 1; state.sources[1].rows[0].stock = 3;
  const report = verify(state, { baseline });
  assert.equal(report.summary.shortageKnownUnits, baseline.summary.shortageKnownUnits);
  assert.equal(report.ok, false);
  assert.equal(report.errors.baseline_changed_calculationDigest, 1);
});
test('matching baseline passes; malformed state or source dates cannot silently pass', () => {
  const state = fixture(); assert.equal(verify(state, { baseline: verify(state) }).ok, true);
  assert.equal(verify({}).ok, false);
  state.sources[0].date = '2024-02-31'; assert.equal(verify(state).ok, false);
});
test('CLI requires an explicit existing seed and never leaks supplied path in error output', () => {
  const script = path.resolve(__dirname, '../scripts/verify-state.cjs');
  for (const args of [[], ['--seed', '/private-missing-seed.json']]) {
    const result = spawnSync(process.execPath, [script, ...args], { encoding: 'utf8' });
    assert.equal(result.status, 2); assert.equal(result.stdout, '');
    assert(!result.stderr.includes('/private-missing-seed.json'));
  }
});
test('selected weekly report is respected and a missing requested report cannot fall back silently', () => {
  let state = R.normalizeState(fixture());
  const correction = structuredClone(state.sources[0]);
  correction.rows[0].stock = 0;
  state = R.applySources(state, [correction], '2024-08-19');
  assert.equal(verify(state, { report: '2024-08-12' }).summary.shortageKnownUnits, 4);
  assert.equal(verify(state, { report: '2024-08-19' }).summary.shortageKnownUnits, 6);
  assert.throws(() => verify(state, { report: '1999-01-01' }));
});
