'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const fs=require('node:fs'),path=require('node:path'),os=require('node:os'),crypto=require('node:crypto'),zlib=require('node:zlib');
const {restoreBackup,decodeBackup}=require('../scripts/restore-server-backup.cjs');
const {createStore}=require('../server/store.cjs');
const {createAuth}=require('../server/auth.cjs');
const {backupBuffer}=require('../server.cjs');
const Package=require('../src/packaging.js'),C=require('../src/core.js'),R=require('../src/reporting.js');
const sha=bytes=>crypto.createHash('sha256').update(bytes).digest('hex');
function temp(t){const dir=fs.mkdtempSync(path.join(os.tmpdir(),'parts-restore-test-'));t.after(()=>fs.rmSync(dir,{recursive:true,force:true}));return dir;}
function fixture(date='2024-08-12',stock=2){return R.normalizeState({...C.empty(),sources:[{type:'dashboard',center:'Flex',operator:'',date,dateLabel:date,file:'Synthetic.xlsx',sheet:'Dashboard',holdDate:date,usageMonths:['2024-07'],rows:[{part:'TEST-000001',row:5,stock,po:0,hold:3,usage:{'2024-07':2}}]}],notes:{'TEST-000001':'Keep original note'}});}
function sample(t){const root=temp(t),dataDir=path.join(root,'source'),store=createStore({dataDir,seedState:fixture()}),auth=createAuth(dataDir);auth.setup('TestPassword123');const raw=store.addRaw({name:'원본 재고.xlsx',bytes:Buffer.from([1,0,3,255,87])});const next=R.applySources(store.read().state,fixture('2024-08-19',7).sources,'2024-08-19');next.settings.hqMonths=4;store.save({state:next,baseRevision:0,rawIds:[raw.id],operation:'import'});return {root,store,auth,raw,bytes:backupBuffer(store)};}
function rebuild(decoded,change){const manifest=JSON.parse(JSON.stringify(decoded.manifest)),files=decoded.files.map(file=>({path:file.path,bytes:Buffer.from(file.bytes)}));change(manifest,files);return Package.createZip([{name:'Server_Backup.json',content:JSON.stringify(manifest)},...files.map((file,i)=>({name:manifest.files[i].file,content:file.bytes}))]);}
function withLegacyCredentials(decoded,bytes){return rebuild(decoded,(manifest,files)=>{const file='Backup_'+String(files.length).padStart(6,'0')+'.bin';manifest.files.push({path:'admin-auth.json',file,sha256:sha(bytes),size:bytes.length});files.push({path:'admin-auth.json',bytes});});}

test('new passwordless backup restores history, settings and original bytes without copying legacy credentials',t=>{
 const source=sample(t),target=path.join(source.root,'restored');const result=restoreBackup({bytes:source.bytes,dataDir:target});
 assert.equal(result.revision,1);assert.equal(result.reportCount,2);assert.equal(result.rawCount,1);assert.equal(result.preservedDir,null);
 const restored=createStore({dataDir:target,seedState:C.empty()});assert.deepEqual(restored.read(),source.store.read());assert.deepEqual(restored.listCommits(),source.store.listCommits());assert.deepEqual(restored.readRaw(source.raw.id),source.store.readRaw(source.raw.id));
 assert.equal(fs.existsSync(path.join(target,'admin-auth.json')),false);assert.equal(createAuth(target).isSetup(),false);assert.equal(fs.existsSync(path.join(target,'server.lock')),false);
 assert.equal(decodeBackup(source.bytes).files.some(file=>file.path==='admin-auth.json'),false);
 assert.equal(C.calculate(R.reportState(restored.read().state,'2024-08-12'),'2024-08-12').parts[0].stock,2);
 assert.equal(C.calculate(R.reportState(restored.read().state,'2024-08-19'),'2024-08-19').parts[0].stock,7);
});

test('existing stopped data is preserved as a complete sibling folder',t=>{
 const source=sample(t),target=path.join(source.root,'active');const previous=createStore({dataDir:target,seedState:fixture('2024-08-05',99)}),before=previous.read();fs.writeFileSync(path.join(target,'keep.txt'),'Do not delete');
 const result=restoreBackup({bytes:source.bytes,dataDir:target});assert.ok(result.preservedDir);assert.equal(fs.readFileSync(path.join(result.preservedDir,'keep.txt'),'utf8'),'Do not delete');assert.deepEqual(createStore({dataDir:result.preservedDir}).read(),before);assert.deepEqual(createStore({dataDir:target}).read(),source.store.read());
});

test('bad hashes and unsafe or duplicate manifest paths never modify existing data',t=>{
 const source=sample(t),decoded=decodeBackup(source.bytes),target=path.join(source.root,'active');const original=createStore({dataDir:target,seedState:fixture()}),before=original.read();
 const corruptions=[
  manifest=>{manifest.files[0].sha256='0'.repeat(64);},
  manifest=>{manifest.files[0].path='../outside';},
  manifest=>{manifest.files[0].path='/absolute';},
  manifest=>{manifest.files[1].path=manifest.files[0].path;},
  manifest=>{manifest.revision=999;}
 ];
 for(const change of corruptions){assert.throws(()=>restoreBackup({bytes:rebuild(decoded,change),dataDir:target}));assert.deepEqual(createStore({dataDir:target}).read(),before);assert.equal(fs.existsSync(path.join(source.root,'outside')),false);}
 assert.equal(fs.readdirSync(source.root).some(name=>name.startsWith('.parts-restore-')),false);
});

test('duplicated ZIP entry names are rejected before the archive parser resolves them',t=>{
 const source=sample(t),bytes=Buffer.from(source.bytes);const from=Buffer.from('Backup_000001.bin'),to=Buffer.from('Backup_000000.bin');let at=0,count=0;while((at=bytes.indexOf(from,at))!==-1){to.copy(bytes,at);at+=from.length;count++;}assert.ok(count>=2);
 assert.throws(()=>restoreBackup({bytes,dataDir:path.join(source.root,'restore')}),/중복/);
});

test('restore refuses a running server before touching its data',t=>{
 const source=sample(t),target=path.join(source.root,'active');const original=createStore({dataDir:target,seedState:fixture()}),before=original.read();const lock=JSON.stringify({pid:process.pid});fs.writeFileSync(path.join(target,'server.lock'),lock);
 assert.throws(()=>restoreBackup({bytes:source.bytes,dataDir:target}),/실행 중/);assert.deepEqual(createStore({dataDir:target}).read(),before);assert.equal(fs.readFileSync(path.join(target,'server.lock'),'utf8'),lock);
});

test('a corrupt latest pointer cannot silently restore an older revision',t=>{
 const source=sample(t),decoded=decodeBackup(source.bytes);const bad=rebuild(decoded,(manifest,files)=>{const at=files.findIndex(file=>file.path==='current.json');files[at].bytes=Buffer.from('{"broken":true}');manifest.files[at].size=files[at].bytes.length;manifest.files[at].sha256=sha(files[at].bytes);});
 const target=path.join(source.root,'restore');assert.throws(()=>restoreBackup({bytes:bad,dataDir:target}),/current.json/);assert.equal(fs.existsSync(target),false);
});

test('missing committed raw content is rejected before replacement',t=>{
 const source=sample(t),decoded=decodeBackup(source.bytes);
 const bad=rebuild(decoded,(manifest,files)=>{const at=files.findIndex(file=>/^raw\//.test(file.path));files[at].bytes=Buffer.from('tampered');manifest.files[at].size=files[at].bytes.length;manifest.files[at].sha256=sha(files[at].bytes);});
 assert.throws(()=>restoreBackup({bytes:bad,dataDir:path.join(source.root,'restore')}));
});

test('legacy backups with valid credentials still restore, but the next backup omits authentication',t=>{
 const source=sample(t),decoded=decodeBackup(source.bytes),credential=fs.readFileSync(source.auth.file),bytes=withLegacyCredentials(decoded,credential),target=path.join(source.root,'legacy-restored');
 const result=restoreBackup({bytes,dataDir:target});assert.equal(result.reportCount,2);assert.deepEqual(fs.readFileSync(path.join(target,'admin-auth.json')),credential);
 const store=createStore({dataDir:target});assert.deepEqual(store.read(),source.store.read());assert.equal(decodeBackup(backupBuffer(store)).files.some(file=>file.path==='admin-auth.json'),false);
});

test('malformed optional legacy credentials are rejected before replacement',t=>{
 const source=sample(t),target=path.join(source.root,'active'),before=createStore({dataDir:target,seedState:fixture()}).read();
 const invalid=withLegacyCredentials(decodeBackup(source.bytes),Buffer.from('{"broken":true}'));
 assert.throws(()=>restoreBackup({bytes:invalid,dataDir:target}),/인증/);assert.deepEqual(createStore({dataDir:target}).read(),before);
});

test('an empty new installation backs up and restores as zero weeks and zero originals',t=>{
 const root=temp(t),store=createStore({dataDir:path.join(root,'empty'),seedState:C.empty()}),target=path.join(root,'empty-restored');
 const bytes=backupBuffer(store),result=restoreBackup({bytes,dataDir:target});assert.equal(result.revision,0);assert.equal(result.reportCount,0);assert.equal(result.rawCount,0);
 const restored=createStore({dataDir:target,seedState:fixture()});assert.deepEqual(restored.read(),store.read());assert.equal(fs.existsSync(path.join(target,'admin-auth.json')),false);
});

test('failed final directory rename rolls back to the original data',t=>{
 const source=sample(t),target=path.join(source.root,'active'),original=createStore({dataDir:target,seedState:fixture('2024-08-05',99)}),before=original.read();
 const ops=Object.create(fs);let failed=false;ops.renameSync=(from,to)=>{if(!failed&&path.basename(from).startsWith('.parts-restore-')){failed=true;throw Error('Synthetic rename failure');}return fs.renameSync(from,to);};
 assert.throws(()=>restoreBackup({bytes:source.bytes,dataDir:target,fsOps:ops}),/Synthetic rename failure/);assert.deepEqual(createStore({dataDir:target}).read(),before);assert.equal(fs.existsSync(path.join(target,'server.lock')),false);assert.equal(fs.readdirSync(source.root).some(name=>name.startsWith('.parts-restore-')),false);
});

test('source blobs restore with history and reject valid-zip tampering before replacing existing data',t=>{
 const source=sample(t),decoded=decodeBackup(source.bytes),target=path.join(source.root,'active');
 const prior=createStore({dataDir:target,seedState:fixture('2024-08-05',99)}).read();
 const sourceFiles=decoded.files.filter(file=>file.path.startsWith('sources/'));assert.equal(sourceFiles.length,2);
 const bad=rebuild(decoded,(manifest,files)=>{
  const at=files.findIndex(file=>file.path===sourceFiles[0].path),parsed=JSON.parse(zlib.gunzipSync(files[at].bytes));parsed.rows[0].stock=123456;
  files[at].bytes=zlib.gzipSync(Buffer.from(JSON.stringify(parsed)));manifest.files[at].size=files[at].bytes.length;manifest.files[at].sha256=sha(files[at].bytes);
 });
 assert.throws(()=>restoreBackup({bytes:bad,dataDir:target}),/분석 원본/);
 assert.deepEqual(createStore({dataDir:target}).read(),prior);
 const restored=restoreBackup({bytes:source.bytes,dataDir:target});assert.equal(restored.reportCount,2);
 for(const file of sourceFiles)assert.deepEqual(fs.readFileSync(path.join(target,file.path)),file.bytes);
});

test('a format 1 full-state generation remains restorable by the new storage engine',t=>{
 const root=temp(t),store=createStore({dataDir:path.join(root,'source'),seedState:fixture()}),decoded=decodeBackup(backupBuffer(store)),state=store.read().state;
 const legacy=rebuild(decoded,(manifest,files)=>{
  const ptrAt=files.findIndex(file=>file.path==='current.json'),pointer=JSON.parse(files[ptrAt].bytes),generationAt=files.findIndex(file=>file.path==='generations/'+pointer.generation);
  const envelope=JSON.parse(zlib.gunzipSync(files[generationAt].bytes));envelope.format=1;envelope.state=state;delete envelope.sourceIndex;delete envelope.currentSourceRefs;delete envelope.archiveSourceRefs;
  files[generationAt].bytes=zlib.gzipSync(Buffer.from(JSON.stringify(envelope)));pointer.sha256=sha(files[generationAt].bytes);files[ptrAt].bytes=Buffer.from(JSON.stringify(pointer));
  for(const at of [ptrAt,generationAt]){manifest.files[at].size=files[at].bytes.length;manifest.files[at].sha256=sha(files[at].bytes);}
 });
 const target=path.join(root,'restored');restoreBackup({bytes:legacy,dataDir:target});
 const restored=createStore({dataDir:target});assert.equal(restored.status().storageFormat,1);assert.deepEqual(restored.read().state,state);
 restored.migrate();assert.equal(restored.status().storageFormat,2);assert.deepEqual(restored.read().state,state);
});
