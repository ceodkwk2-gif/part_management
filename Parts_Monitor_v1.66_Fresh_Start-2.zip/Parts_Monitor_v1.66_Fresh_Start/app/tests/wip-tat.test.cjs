'use strict';
// Synthetic records only. WIP TAT is physical receipt -> source snapshot date.
const test=require('node:test');
const assert=require('node:assert/strict');
const Tat=require('../src/wip-tat.js');
const DAY=86400000,DATE='2024-09-30',PART='TEST-000001',OTHER='TEST-000002';
const receipt=age=>new Date(Date.parse(DATE+'T00:00:00Z')-age*DAY).toISOString().slice(0,10);
function row(age=1,extra={}){return {center:'Flex',operator:'Jio',source:'synthetic.xlsx',sheet:'WIP',row:2,sn:'SYNTHETIC-'+age,rma:'RMA-'+age,
 status:'Waiting for Component',receipt:receipt(age),date:DATE,age:999,tokens:{parts:{[PART]:2},unparsed:''},...extra}}
test('physical receipt calendar age boundaries are exact and overdue starts at 46 days',()=>{
 const boundaries=[[0,'DAY0'],[1,'D1_30'],[30,'D1_30'],[31,'D31_45'],[44,'D31_45'],[45,'D31_45'],[46,'D46_90'],[90,'D46_90'],[91,'D91_180'],[180,'D91_180'],[181,'D181_PLUS']];
 const output=Tat.evaluate(boundaries.map(([age])=>row(age)));
 assert.equal(output.summary.products,11);assert.equal(output.summary.partKinds,1);assert.equal(output.summary.quantity,22);
 for(const [index,[age,bucket]] of boundaries.entries()){
  const r=output.rows[index];assert.equal(r.age,age);assert.equal(r.ageDays,age);assert.equal(r.bucket,bucket);assert.equal(r.overdue,age>45);
 }
 const withinTat=output.buckets.find(b=>b.code==='D31_45');assert.equal(withinTat.products,3);assert.equal(withinTat.overdueProducts,0);assert.equal(withinTat.overdueQuantity,0);
 assert.equal(output.summary.overdueProducts,5);assert.equal(output.summary.overdueQuantity,10);assert.equal(output.summary.overduePartKinds,1);
 assert.equal(output.overdueDays,45);assert.equal(output.overdueInclusive,false);assert.equal(output.overdueStartsAt,46);
});
test('missing, invalid calendar, future and non-date values remain unknown, never age zero or row.age',()=>{
 const cases=[
  [{receipt:null},'MISSING_RECEIPT'],[{receipt:''},'MISSING_RECEIPT'],[{receipt:'2024-02-30'},'INVALID_RECEIPT'],[{receipt:'2023-02-29'},'INVALID_RECEIPT'],
  [{receipt:'2024-2-01'},'INVALID_RECEIPT'],[{receipt:'2024-01-01T00:00:00Z'},'INVALID_RECEIPT'],[{receipt:45200},'INVALID_RECEIPT'],
  [{date:null},'MISSING_SOURCE_DATE'],[{date:'2024-09-31'},'INVALID_SOURCE_DATE'],[{date:'2024-13-01'},'INVALID_SOURCE_DATE'],
  [{receipt:'2024-10-01'},'RECEIPT_AFTER_SOURCE']
 ];
 for(const [extra,issue] of cases){const output=Tat.evaluate([row(10,extra)]);assert.equal(output.rows[0].age,null);assert.equal(output.rows[0].ageIssue,issue);assert.equal(output.rows[0].bucket,'UNKNOWN');assert.equal(output.rows[0].overdue,null);assert.equal(output.summary.unknownAgeProducts,1);assert.equal(output.summary.unknownAgeQuantity,2);assert.equal(output.summary.overdueProducts,0)}
 assert.deepEqual(Tat.ageAt('2024-02-29','2024-03-01'),{age:1,issue:null});
 assert.deepEqual(Tat.ageAt('2024-03-10','2024-03-11'),{age:1,issue:null});
});
test('each source snapshot determines age, with no shared report or clock date',()=>{
 const input=[row(1,{receipt:'2024-01-01',date:'2024-01-31',sn:'ONE'}),row(1,{center:'CTDI',receipt:'2024-01-01',date:'2024-02-15',sn:'TWO'})];
 const original=JSON.stringify(input),output=Tat.evaluate(input);
 assert.deepEqual(output.rows.map(r=>r.age),[30,45]);assert.deepEqual(output.rows.map(r=>r.overdue),[false,false]);assert.equal(output.sourceDates.length,2);
 assert.equal(JSON.stringify(input),original);
});
test('product first row dedupe preserves two required parts and quantities without counting two products',()=>{
 const input=[row(46,{tokens:{parts:{[PART]:2,[OTHER]:3},unparsed:''}}),row(46,{row:9,tokens:{parts:{[PART]:20},unparsed:''}})];
 const output=Tat.evaluate(input);assert.equal(output.summary.products,1);assert.equal(output.summary.partKinds,2);assert.equal(output.summary.quantity,5);
 assert.equal(output.summary.overdueProducts,1);assert.equal(output.summary.overdueQuantity,5);assert.equal(output.duplicates.length,1);assert.equal(output.duplicates[0].selected.row,2);assert.equal(output.duplicates[0].ignored.row,9);
 assert.equal(output.parts.length,2);assert.equal(output.parts[0].products,1);assert.equal(output.parts[0].rows[0].partQuantity,3);
});
test('same part across centers and age buckets is one overall kind, but separate center rows',()=>{
 const output=Tat.evaluate([row(1),row(46),row(181,{center:'CTDI',operator:'Airtel'})]);
 assert.equal(output.summary.partKinds,1);assert.equal(output.summary.products,3);assert.equal(output.summary.quantity,6);assert.equal(output.parts.length,2);
 assert.equal(output.buckets.filter(b=>b.partKinds>0).length,3);
 const flex=output.parts.find(p=>p.center==='Flex');assert.equal(flex.products,2);assert.equal(flex.quantity,4);assert.equal(flex.overdueProducts,1);assert.equal(flex.overdueQuantity,2);
 assert.equal(flex.buckets.find(b=>b.code==='D46_90').overdueQuantity,2);assert.equal(flex.rows.length,2);
});
test('center and operator separate identities; missing identity falls back to source row',()=>{
 const output=Tat.evaluate([row(1),row(1,{center:'CTDI'}),row(1,{center:'CTDI',operator:'Airtel'}),row(1,{sn:'',rma:'',key:'',row:6}),row(1,{sn:'',rma:'',key:'',row:7}),row(1,{sn:'',rma:'',key:'',row:7})]);
 assert.equal(output.summary.products,5);assert.equal(output.duplicates.length,1);
 const anonymous=Tat.evaluate([{tokens:{parts:{}}},{tokens:{parts:{}}}]);assert.equal(anonymous.summary.products,2);
 const keyed=Tat.evaluate([row(1,{sn:'',rma:'',key:'KEY-A'}),row(1,{sn:'',rma:'',key:'KEY-A',row:12})]);assert.equal(keyed.summary.products,1);
});
test('unresolved or invalid part quantities preserve known partial quantity and product count',()=>{
 const output=Tat.evaluate([
  row(50,{tokens:{parts:{[PART]:2},unparsed:'unresolved note'}}),
  row(46,{tokens:{parts:{[PART]:null,[OTHER]:-2,'TEST-000003':'3'},unparsed:''}}),
  row(47,{tokens:{parts:{},unparsed:''}}),
  row(48,{tokens:{parts:{[PART]:0},unparsed:''}}),
  row(49,{tokens:null})
 ]);
 assert.equal(output.summary.products,5);assert.equal(output.summary.partKinds,1);assert.equal(output.summary.quantity,2);assert.equal(output.summary.overdueProducts,5);
 assert.equal(output.summary.unresolvedPartProducts,5);assert.equal(output.summary.unresolvedPartOverdueProducts,5);assert.equal(output.summary.quantityComplete,false);
 assert.equal(output.parts.length,1);assert.equal(output.parts[0].products,1);assert.equal(output.parts[0].quantity,2);assert.equal(output.issues.filter(i=>i.type==='UNRESOLVED_PARTS').length,5);
});
test('part code normalization merges repeated spelling within one product without product double counting',()=>{
 const output=Tat.evaluate([row(1,{tokens:{parts:{[PART]:2,' test-000001 ':3},unparsed:''}})]);
 assert.equal(output.summary.partKinds,1);assert.equal(output.summary.quantity,5);assert.equal(output.parts[0].products,1);assert.equal(output.parts[0].quantity,5);
});
test('Waiting for Module records supplied by Core remain included and empty input is complete',()=>{
 assert.equal(Tat.evaluate([row(50,{status:'Waiting for Module'})]).summary.overdueProducts,1);
 const output=Tat.evaluate([]);assert.equal(output.summary.products,0);assert.equal(output.summary.quantityComplete,true);assert.equal(output.buckets.length,7);assert.deepEqual(output.parts,[]);
});
test('product distribution partitions every age boundary once and preserves detailed input',()=>{
 const output=Tat.evaluate([0,30,31,45,46,90,91,180,181].map(age=>row(age)));
 const before=JSON.stringify(output),groups=Tat.productDistribution(output);
 assert.deepEqual(groups.map(group=>[group.code,group.products]),[
  ['D0_30',2],['D31_45',2],['D46_90',2],['D91_180',2],['D181_PLUS',1]
 ]);
 assert.deepEqual(groups[0].bucketCodes,['DAY0','D1_30']);
 assert.equal(groups.reduce((sum,group)=>sum+group.products,0),output.summary.products);
 assert.equal(groups.reduce((sum,group)=>sum+Math.round(group.displayPercent*10),0),1000);
 assert.equal(groups.filter(group=>['D46_90','D91_180','D181_PLUS'].includes(group.code)).reduce((sum,group)=>sum+group.products,0),output.summary.overdueProducts);
 assert.equal(JSON.stringify(output),before);
});
test('product distribution includes unresolved parts and unknown dates in the product denominator',()=>{
 const output=Tat.evaluate([
  row(10,{tokens:{parts:{[PART]:9},unparsed:''}}),
  row(50,{tokens:{parts:{},unparsed:'unresolved'}}),
  row(5,{receipt:null,tokens:{parts:{},unparsed:'unresolved'}})
 ]);
 const groups=Tat.productDistribution(output);
 assert.equal(output.summary.quantity,9);assert.equal(output.summary.products,3);
 assert.equal(groups.find(group=>group.code==='UNKNOWN').products,1);
 assert.deepEqual(groups.filter(group=>group.products>0).map(group=>[group.code,group.displayPercent]),[
  ['D0_30',33.4],['D46_90',33.3],['UNKNOWN',33.3]
 ]);
 for(const group of groups.filter(group=>group.products>0))assert.ok(Math.abs(group.percentage-100/3)<1e-12);
 assert.equal(groups.reduce((sum,group)=>sum+group.products,0),3);
 assert.equal(groups.reduce((sum,group)=>sum+Math.round(group.displayPercent*10),0),1000);
});
test('empty product distribution keeps zero date groups without NaN or unknown-date group',()=>{
 const groups=Tat.productDistribution(Tat.evaluate([]));
 assert.equal(groups.length,5);
 for(const group of groups){assert.equal(group.products,0);assert.equal(group.percentage,0);assert.equal(group.displayPercent,0)}
 assert.equal(groups.some(group=>group.code==='UNKNOWN'),false);
});
test('FAN repair categories use explicit register provenance, never required components or model families',()=>{
 for(const sheet of ['InHouse FAN Repair','FAN-Inhouse',' fan_inhouse ','INHOUSE  FAN  REPAIR'])assert.equal(Tat.repairCategoryFor({sheet}),'FAN');
 for(const sheet of ['InHouse','CDU50 SHELF','WIP','WIP_Jio'])assert.equal(Tat.repairCategoryFor({sheet,required:'FAN MOTOR #3',family:'FAN'}),'GENERAL');
 for(const sheet of ['',undefined,'InHouse + FAN-Inhouse','InHouse | FAN-Inhouse','Unknown Register','WIP_FAN'])assert.equal(Tat.repairCategoryFor({sheet}),'UNKNOWN');
 assert.equal(Tat.repairCategoryFor({sheet:'FAN-Inhouse',family:'DU',required:PART}),'FAN');
});
test('FAN and general metric counts partition deduplicated products, including unresolved requirements',()=>{
 const input=[
  row(10,{sheet:'FAN-Inhouse',tokens:{parts:{[PART]:5,[OTHER]:3},unparsed:''}}),
  row(46,{sheet:'InHouse FAN Repair',tokens:{parts:{},unparsed:'unresolved'}}),
  row(46,{sheet:'InHouse',row:9,tokens:{parts:{[PART]:20},unparsed:''}}),
  row(45,{sheet:'InHouse',required:'FAN MOTOR'}),
  row(50,{sheet:'CDU50 SHELF',tokens:{parts:{},unparsed:'unresolved'}}),
  row(181,{sheet:'InHouse + FAN-Inhouse'}),
  row(20,{sheet:'InHouse',receipt:null})
 ];
 const before=JSON.stringify(input),output=Tat.evaluate(input),s=output.summary;
 assert.equal(s.products,6);assert.equal(s.fanProducts,2);assert.equal(s.generalProducts,3);assert.equal(s.unknownCategoryProducts,1);
 assert.equal(s.overdueProducts,3);assert.equal(s.overdueFanProducts,1);assert.equal(s.overdueGeneralProducts,1);assert.equal(s.overdueUnknownCategoryProducts,1);
 assert.equal(s.fanProducts+s.generalProducts+s.unknownCategoryProducts,s.products);
 assert.equal(s.overdueFanProducts+s.overdueGeneralProducts+s.overdueUnknownCategoryProducts,s.overdueProducts);
 assert.equal(s.unresolvedPartProducts,2);assert.equal(s.unresolvedPartOverdueProducts,2);assert.equal(output.duplicates.length,1);
 assert.equal(output.rows.find(r=>r.age===46).repairCategory,'FAN');
 assert.equal(output.parts.find(p=>p.part===OTHER).rows[0].repairCategory,'FAN');
 for(const bucket of output.buckets){assert.equal(bucket.fanProducts+bucket.generalProducts+bucket.unknownCategoryProducts,bucket.products)}
 assert.equal(JSON.stringify(input),before);
 const empty=Tat.evaluate([]).summary;for(const key of ['fanProducts','generalProducts','unknownCategoryProducts','overdueFanProducts','overdueGeneralProducts','overdueUnknownCategoryProducts'])assert.equal(empty[key],0);
});
