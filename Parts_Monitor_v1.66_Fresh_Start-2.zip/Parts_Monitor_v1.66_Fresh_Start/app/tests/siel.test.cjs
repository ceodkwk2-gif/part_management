'use strict';
// Synthetic PO documents. Real raw workbooks stay outside public source/tests.
const test=require('node:test'),assert=require('node:assert/strict');
const X=require('../vendor/xlsx.full.min.js'),C=require('../src/core.js'),S=require('../src/siel.js'),P=require('../src/pipeline.js'),R=require('../src/reporting.js'),Summary=require('../src/summary-data.js'),Upload=require('../src/upload-panel.js');
const HEAD=['Process Status','Purch. Doc.','Item','P/O Date','Vendor','Plant','S.Loc','Material','Short Text','Quantity','BUn','(P)ETA','Delivery','(D)Item','(D)D/O Date','(D)Qty','(D)BUn','S/R','S/R Date','Billing','(B)Item','NEGO','(B)Posting Date','(B)Qty','(B)BUn'];
function line(overrides={}){const row={'Process Status':'Seller S/O','Purch. Doc.':'TESTPO','Item':'10','P/O Date':'2026-10-07',Material:'TEST-000001','Short Text':'Test part',Quantity:5,'(P)ETA':'2026-11-10','(D)Qty':0,'(B)Qty':0,...overrides};return HEAD.map(h=>row[h]??'');}
function workbook(rows){return {SheetNames:['Summary','Detail'],Sheets:{Summary:X.utils.aoa_to_sheet([['Material','Short Text','Total'],['TEST-000001','Test',5]]),Detail:X.utils.aoa_to_sheet([HEAD,...rows])}};}
function source(rows=[line()],name='SIEL_PO Summary_261019.xlsx'){return C.importWorkbook(workbook(rows),name,X).sources[0];}
function base(){return {...C.empty(),sources:[{type:'hq',date:'2026-10-12',file:'Synthetic HQ',sheet:'Stock',rows:[]}]};}
test('recognizes SIEL detail and skips pivot totals without interpreting it as center PO or stock',()=>{
 const parsed=C.importWorkbook(workbook([line()]),'SIEL_PO Summary_261019.xlsx',X);
 assert.equal(parsed.sources.length,1);const s=parsed.sources[0];assert.equal(s.type,'siel');assert.equal(s.date,'2026-10-19');assert.equal(s.rows.length,1);
 const row=s.rows[0];assert.equal(row.poDate,'2026-10-07');assert.equal(row.ordered,5);assert.equal(row.eta,'2026-11-10');assert.equal(row.row,2);assert.equal(row.sheet,'Detail');assert.equal(row.pending,null);assert.equal(row.receivedDate,null);
 assert.equal(P.slotKey(s),'siel');assert.equal(S.projection(s).rows[0].documentPending,5);
});
test('split delivery rows preserve source rows and count a PO item quantity once; documents do not confirm receipt',()=>{
 const s=source([line({Delivery:'DEL1','(D)Item':'1','(D)Qty':2,'(D)D/O Date':'2026-10-10'}),line({Delivery:'DEL2','(D)Item':'1','(D)Qty':3,'(D)D/O Date':'2026-10-12'})]);
 const view=S.projection(s,'2026-10-19');assert.equal(view.rawRowCount,2);assert.equal(view.rows.length,1);const row=view.rows[0];
 assert.equal(row.ordered,5);assert.equal(row.documentedQty,5);assert.equal(row.documentPending,0);assert.equal(row.pending,null);assert.equal(row.received,null);assert.equal(row.receiptConfirmed,false);assert.equal(row.stage,'supply-documents');assert.equal(row.docs.length,2);assert.equal(row.sourceRows.length,2);
});
test('repeated identical document is not summed twice and contradictory order quantities produce review',()=>{
 const first=line({Delivery:'DEL1','(D)Item':'1','(D)Qty':2});let row=S.projection(source([first,first])).rows[0];assert.equal(row.documentedQty,2);assert.equal(row.documentPending,3);
 const view=S.projection(source([first,line({Quantity:8,Delivery:'DEL2','(D)Item':'1','(D)Qty':3})]));row=view.rows[0];assert.equal(row.ordered,null);assert.equal(row.stage,'review');assert.equal(row.documentPending,null);assert.ok(view.issues.length);
});
test('demonstration week is explicit, SIEL-only, and never overwrites actual source or PO dates',()=>{
 const s=source(),demo=S.assignDemoWeek(s,'2026-10-12');assert.equal(C.sourceSelectionDate(s),'2026-10-19');assert.equal(C.sourceSelectionDate(demo),'2026-10-12');assert.equal(demo.date,'2026-10-19');assert.equal(demo.sourceDate,'2026-10-19');assert.equal(demo.rows[0].poDate,'2026-10-07');assert.equal(C.sourceKey(s),C.sourceKey(demo));
 assert.equal(C.sourceSelectionDate({...s,demo:true,reportWeek:'2026-10-12'}),'2026-10-19');assert.throws(()=>S.assignDemoWeek({...s,type:'po'},'2026-10-12'));
 assert.equal(S.build([demo],'2026-10-05','2026-10-05',C.sourceSelectionDate).available,false);assert.equal(S.build([demo],'2026-10-12','2026-10-12',C.sourceSelectionDate).demo,true);
 const label=Upload.dates(demo);assert.equal(label.actual,'2026-10-19');assert.match(label.note,/2026-10-12/);
});
test('ordinary future SIEL upload is rejected for an earlier cutoff, approved demo allowed',()=>{
 assert.equal(P.evaluate(C.empty(),[source()],'2026-10-12').canApply,false);
 const demo=S.assignDemoWeek(source(),'2026-10-12'),plan=P.evaluate(C.empty(),[demo],'2026-10-12');assert.equal(plan.canApply,true);assert.equal(plan.rows.find(r=>r.key==='siel').status,'new');
 const state=R.applySources(base(),plan.selectedSources,plan.reportDate);assert.equal(P.validate(state).ok,true);const view=Summary.build(state);assert.equal(view.siel.rows.length,1);assert.equal(view.siel.sourceDate,'2026-10-19');assert.equal(view.siel.reportWeek,'2026-10-12');assert.equal(view.siel.demo,true);
 assert.equal(view.rows.length,0);assert.equal(view.pos.length,0);assert.equal(view.siel.rows[0].allocationConfirmed,false);
});
test('weekly normal SIEL replacement carries to later reports without adding orders or altering old reports',()=>{
 const demo=S.assignDemoWeek(source(),'2026-10-12');let state=R.applySources(base(),[demo],'2026-10-12');
 const current=source([line({Quantity:9})],'SIEL_PO Summary_261026.xlsx');state=R.applySources(state,[current],'2026-10-26');
 const old=Summary.build(state,{reportId:'2026-10-12'}).siel,latest=Summary.build(state).siel;
 assert.equal(old.rows[0].ordered,5);assert.equal(old.demo,true);assert.equal(latest.rows[0].ordered,9);assert.equal(latest.demo,false);assert.equal(latest.sourceDate,'2026-10-26');
 const forward=S.build(R.reportState(state).sources,'2026-11-02','2026-11-02',C.sourceSelectionDate);assert.equal(forward.rows[0].ordered,9);assert.equal(P.validate(state).ok,true);
});
test('SIEL sources cannot change center stock, required quantities or center PO balances',()=>{
 const date='2026-10-12',months=['2026-04','2026-05','2026-06','2026-07','2026-08','2026-09'];
 const dash={type:'dashboard',center:'Flex',date,holdDate:date,file:'Synthetic dashboard',sheet:'Dashboard',usageMonths:months,rows:[{part:'TEST-000001',row:5,stock:2,hold:4,po:1,usage:Object.fromEntries(months.map(m=>[m,3]))}]};
 const state={...C.empty(),sources:[dash]},before=C.calculate(state,date),after=C.calculate({...state,sources:[dash,S.assignDemoWeek(source(),'2026-10-12')]},date);
 assert.deepEqual(after,before);
});
test('durable source metadata and restarted server keep the explicit demo assignment and actual dates',t=>{
 const fs=require('node:fs'),os=require('node:os'),path=require('node:path'),{createStore}=require('../server/store.cjs'),{createViewService}=require('../server/view-service.cjs');
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'siel-store-test-'));t.after(()=>fs.rmSync(dir,{recursive:true,force:true}));
 const store=createStore({dataDir:dir,seedState:R.normalizeState(base())}),state=R.applySources(store.read().state,[S.assignDemoWeek(source(),'2026-10-12')],'2026-10-12');
 store.save({state,baseRevision:store.read().revision,operation:'import',reportDate:'2026-10-12'});
 const restarted=createStore({dataDir:dir}),meta=restarted.compactManifest().sourceIndex.find(item=>item.meta.type==='siel').meta;
 assert.equal(meta.date,'2026-10-19');assert.equal(meta.demoAssignment,'user-approved-report-week');assert.equal(C.sourceSelectionDate(meta),'2026-10-12');
 const service=createViewService({store:restarted}),view=service.getView();assert.equal(view.siel.sourceDate,'2026-10-19');assert.equal(view.siel.rows.length,1);assert.equal(view.siel.rows[0].ordered,5);assert.equal(view.siel.demo,true);service.close();
});
