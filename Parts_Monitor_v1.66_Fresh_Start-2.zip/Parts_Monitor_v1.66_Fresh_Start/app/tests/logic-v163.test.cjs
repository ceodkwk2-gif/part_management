'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const Stages=require('../src/supply-stages'),A=require('../src/action-requests'),Siel=require('../src/siel'),Share=require('../src/share-dialog'),X=require('../vendor/xlsx.full.min');
const part='TEST-000001';
function row(patch={}){return {id:'CTDI|'+part,part,center:'CTDI',name:'Synthetic',needed:88,stock:0,shortage:88,open:0,target:26,proposed:114,india:25,hq:0,pos:[],siel:[],...patch};}
function data(rows,siel={available:true,rows:[]}){return {asof:'2026-10-12',week:'2026-10-12',rows,pos:rows.flatMap(r=>r.pos),siel,products:[],trend:[]};}
test('88 repair plus 26 buffer remains 114 on every selected status export and does not relabel repair partition',()=>{
 const r=row(),d=data([r]),repair=Stages.classify([r],{available:true}).get(r.id);assert.equal(repair[0].quantity,88);
 for(const kind of ['SHORTAGE','OVERDUE','ALL','ORDER_ALL'])for(const recipient of ['all','CENTER']){
  const m=A.build(d,{kind,recipient,rowIds:[r.id]});assert.equal(m.rows.length,1);assert.equal(m.rows[0].proposed,114);assert.equal(m.rows[0].status,'수리센터 → 법인 추가 PO 필요 114 (수리 88 + 보유 26)');
 }
 assert.match(A.build(d,{language:'en'}).rows[0].status,/114 \(repair 88 \+ buffer 26\)/);
});
test('stock and existing PO reduce repair and total gaps once, while repair supply stages conserve current shortage',()=>{
 const r=row({needed:12,stock:2,shortage:10,open:4,target:5,proposed:11,india:2,siel:[{part,po:'P',item:'10',ordered:2,pending:null}]}),stages=Stages.classify([r],{available:true}).get(r.id);
 assert.deepEqual(stages.map(a=>[a.code,a.quantity]),[['ORDER',6],['DISPATCH',2],['HQ',2]]);assert.equal(stages.reduce((n,a)=>n+a.quantity,0),10);
 const status=Stages.statusRecords(r,stages);assert.equal(status.find(a=>a.code==='ORDER').quantity,11);assert.equal(status.find(a=>a.code==='ORDER').bufferQuantity,5);
});
test('center balance 20, HQ ordered 50 and HQ stock 970 never merge or establish India receipt',()=>{
 const r=row({needed:0,stock:2,shortage:0,open:20,target:15,proposed:0,india:0,hq:970,waitingCovered:true});
 const source={type:'siel',date:'2026-10-19',file:'synthetic.xlsx',rows:[10,20,20].map((ordered,i)=>({part,po:'P'+i,item:'10',poDate:'2026-10-01',ordered,eta:['2027-01-28','2027-02-09','2027-02-14'][i],status:'Buyer I/R',pending:null,row:i+2}))};
 const siel=Siel.projection(source,'2026-10-12'),before=JSON.stringify(source),d=data([r],siel),m=A.build(d,{kind:'WAIT',rowIds:[r.id]});
 assert.equal(m.rows[0].open,20);assert.equal(m.rows[0].hq,970);assert.equal(m.rows[0].hqPo,50);assert.equal(m.rows[0].proposed,0);assert.equal(m.rows[0].status,'수리센터 입고 대기 20');
 assert.match(m.rows[0].eta,/2027-01-28 \/ 10/);assert.match(m.rows[0].eta,/2027-02-09 \/ 20/);assert(!JSON.stringify(m).includes('Buyer I/R'));assert.equal(siel.rows.every(p=>p.pending===null&&p.received===null),true);assert.equal(JSON.stringify(source),before);
});
test('physical pending evidence stays distinct while displayed action uses ETA availability',()=>{
 for(const pending of [null,5])for(const eta of [null,'2027-01-28']){const r=row({shortage:5,needed:5,open:5,proposed:0,india:0,siel:[{part,po:'P',item:'10',ordered:10,pending,eta}]}),records=Stages.classify([r],{available:true}).get(r.id),display=Stages.statusRecords(r,records);assert.equal(records[0].quantity,5);assert.equal(records[0].basis,pending===null?'siel-order':'confirmed-pending');assert.equal(Stages.statusLabel(display[0]),eta?'본사 → 법인 입고 대기':'본사 → 법인 ETA 확인 필요');}
});
test('same PO quantity is counted once while every original process status is preserved',()=>{
 const s=Siel.projection({date:'2026-10-19',rows:[{part,po:'P',item:'10',ordered:10,status:'Buyer I/R',row:2},{part,po:'P',item:'10',ordered:10,status:'Other source status',row:3}]});
 assert.equal(s.rows.length,1);assert.equal(s.rows[0].ordered,10);assert.deepEqual(s.rows[0].statuses,['Buyer I/R','Other source status']);assert.equal(s.rows[0].pending,null);
});
test('status CSV and Excel preserve part codes, numeric additional quantity, and the selected whole list',()=>{
 const rows=Array.from({length:25},(_,i)=>row({id:'CTDI|TEST-'+String(i).padStart(6,'0'),part:'TEST-'+String(i).padStart(6,'0')}));
 const model=Share.normalize(A.build(data(rows),{recipient:'CENTER',center:'CTDI'}),{language:'ko'}),csv=Share.csv(model),wb=X.read(Share.workbook([model],X),{type:'array'}),values=X.utils.sheet_to_json(wb.Sheets[wb.SheetNames[0]],{header:1});
 assert(csv.includes('114'));assert(csv.includes('TEST-000024'));assert(values.some(r=>r.includes('TEST-000024')));assert(values.some(r=>r.includes(114)));assert.equal(model.columns.length,9);
});
