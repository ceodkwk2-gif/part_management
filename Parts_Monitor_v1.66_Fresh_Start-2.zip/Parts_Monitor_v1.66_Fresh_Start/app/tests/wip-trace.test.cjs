'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const C=require('../src/core.js'),R=require('../src/reporting.js'),T=require('../src/wip-tat.js'),Trace=require('../src/wip-trace.js');
const A='1000-000001',B='1000-000002';
const product=(part=A,status='Waiting for Component',extra={})=>({key:'S1|R1',sn:'S1',rma:'R1',status,required:part,tokens:{parts:{[part]:1},unparsed:''},receipt:'2026-08-01',sheet:'Inhouse',row:2,...extra});
function source(date,rows=[product()],extra={}){return {type:'wip',center:'Flex',operator:'Jio',date,dateLabel:date,file:'Synthetic '+date+'.xlsx',sheet:'Inhouse',rows:rows.filter(row=>/^Waiting/.test(row.status)),statuses:Object.fromEntries(rows.map(row=>[row.key,row.status])),duplicates:[],wipImportComplete:true,...extra};}
const start=(date='2026-09-21',rows=[product()],extra={})=>R.normalizeState({...C.empty(),sources:[source(date,rows,extra)]});
const add=(state,date,rows=[product()],extra={})=>R.applySources(state,[source(date,rows,extra)],date);
const only=(state,options)=>Trace.evaluate(state,options).entries[0];
test('First observed source is a baseline with unknown onset, not a fabricated diagnosis date',()=>{
 const state=start('2026-09-25'),before=JSON.stringify(state),entry=only(state);
 assert.equal(entry.baselinePresent,true);assert.equal(entry.firstSeenDate,'2026-09-25');assert.equal(entry.firstSeenWeek,'2026-09-21');
 assert.equal(entry.firstSeenAgeDays,55);assert.equal(entry.actualNeedDate,null);assert.equal(entry.observationCount,1);assert.equal(entry.consecutiveWeeks,1);
 assert.equal(JSON.stringify(state),before);assert.equal(entry.liabilityConfirmed,false);
});
test('Explicit same-product prior status bounds first appearance; no exact diagnosis date inferred',()=>{
 let state=start('2026-09-21',[product(A,'Under Repair')]);state=add(state,'2026-09-28');
 const entry=only(state);assert.equal(entry.baselinePresent,false);assert.equal(entry.priorObservedWithoutDate,'2026-09-21');
 assert.equal(entry.firstSeenDate,'2026-09-28');assert.equal(entry.firstSeenAgeDays,58);assert.equal(entry.continuityUncertain,false);
});
test('Reused source is counted once and a carried weekly report is not fresh WIP evidence',()=>{
 let state=start();state=R.applySources(state,[],'2026-09-28');let entry=only(state);
 assert.equal(entry.observationCount,1);assert.equal(entry.consecutiveWeeks,1);assert.equal(entry.carriedForward,true);assert.equal(entry.lastSeenDate,'2026-09-21');
 state=add(state,'2026-10-05');entry=only(state);assert.equal(entry.observationCount,2);assert.equal(entry.consecutiveWeeks,1);assert.equal(entry.continuityUncertain,true);
});
test('Consecutive distinct source weeks count once each and use original snapshot TAT',()=>{
 let state=start('2026-09-27');state=add(state,'2026-09-28');state=add(state,'2026-10-05');
 const entry=only(state);assert.equal(entry.observationCount,3);assert.equal(entry.consecutiveWeeks,3);assert.equal(entry.currentAgeDays,65);
 assert.equal(entry.firstSeenAgeDays,57);assert.equal(entry.firstSeenWeek,'2026-09-21');
});
test('Missing product does not mean repair completion or material arrival',()=>{
 let state=start();state=add(state,'2026-09-28',[]);state=add(state,'2026-10-05');const entry=only(state);
 assert.equal(entry.firstSeenDate,'2026-09-21');assert.equal(entry.observationCount,2);assert.equal(entry.episodeIndex,1);
 assert.equal(entry.consecutiveWeeks,1);assert.equal(entry.continuityUncertain,true);assert.equal(entry.actualArrivalDate,null);
});
test('Explicit exit followed by reappearance begins a new observed episode',()=>{
 let state=start();state=add(state,'2026-09-28',[product(A,'Under Repair')]);state=add(state,'2026-10-05');const entry=only(state);
 assert.equal(entry.episodeStartDate,'2026-10-05');assert.equal(entry.firstSeenDate,'2026-10-05');assert.equal(entry.episodeIndex,2);
 assert.equal(entry.priorObservedWithoutDate,'2026-09-28');assert.equal(entry.baselinePresent,false);assert.equal(entry.observationCount,1);
});
test('Unparsed or incomplete snapshots cannot prove the requested part was absent',()=>{
 for(const middle of [source('2026-09-28',[product(B,'Waiting for Module',{tokens:{parts:{[B]:1},unparsed:'unreadable'}})]),source('2026-09-28',[product(B)],{wipImportComplete:false})]){
  let state=start();state=R.applySources(state,[middle],middle.date);state=add(state,'2026-10-05');const entry=only(state);
  assert.equal(entry.firstSeenDate,'2026-09-21');assert.equal(entry.episodeIndex,1);assert.equal(entry.continuityUncertain,true);
 }
});
test('Same-week correction replaces the snapshot while preserving previous published report',()=>{
 let state=start('2026-09-21',[product(A,'Under Repair')]);state=add(state,'2026-09-28');state=add(state,'2026-09-28',[product(B)]);
 assert.equal(state.reportingWeeks.length,2);assert.deepEqual(Trace.evaluate(state).entries.map(entry=>entry.part),[B]);
 assert.deepEqual(Trace.evaluate(state,{reportId:'2026-09-21',asof:'2026-09-21'}).entries,[]);
 state=add(state,'2026-10-05',[product(B)]);assert.equal(only(state).observationCount,2);assert.equal(only(state).firstSeenDate,'2026-09-28');
});
test('Identity separates operators, RMAs and parts and accepts Tat-enriched rows',()=>{
 const row={...product(),center:'CTDI',operator:'Vi',date:'2026-09-28',source:'A.xlsx'};
 assert.notEqual(Trace.rowKey(row,A),Trace.rowKey({...row,operator:'Jio'},A));
 assert.notEqual(Trace.rowKey(row,A),Trace.rowKey({...row,rma:'R2'},A));
 assert.notEqual(Trace.rowKey(row,A),Trace.rowKey(row,B));
 assert.equal(Trace.rowKey(row,A),Trace.rowKey(T.evaluate([row]).rows[0],A));
 const state=start(),calculated=C.calculate(R.reportState(state),'2026-09-21');const entry=Trace.evaluate(state).byKey[Trace.rowKey(T.evaluate(calculated.wip).rows[0],A)];assert(entry);
});
test('Report selection excludes future observations and retained legacy unused dates',()=>{
 let state=start();state.sources.unshift(source('2026-09-14'));state=add(state,'2026-09-28');
 assert.equal(only(state).firstSeenDate,'2026-09-21');assert.equal(only(state,{reportId:'2026-09-21',asof:'2026-09-21'}).observationCount,1);
});
test('Status variants accepted by Core also appear in history; unknown report IDs fail explicitly',()=>{
 const state=start('2026-09-21',[product(A,'Waiting for Component - local sourcing')]);
 assert.equal(Trace.evaluate(state).entries.length,1);
 assert.throws(()=>Trace.evaluate(state,{reportId:'2026-01-01'}),/주간 보고/);
});
test('Related PO returns every matching order with source-date age, never arrival or assignment',()=>{
 const calculated={used:[{type:'po',center:'Flex',date:'2026-09-28',file:'PO.xlsx'}],pos:[
  {center:'Flex',part:A,po:'P1',poDate:'2026-09-01',pending:2,shipped:1,etd:'2026-10-01',date:'2026-09-28'},
  {center:'Flex',part:A,po:'P2',poDate:'2026-09-20',pending:3,shipped:0,etd:null,date:'2026-09-28'},
  {center:'CTDI',part:A,po:'P3',poDate:'2026-09-20',pending:9,date:'2026-09-28'}]};
 const result=Trace.relatedPO(calculated,'Flex',A,'2026-10-19');assert.equal(result.rows.length,2);assert.deepEqual(result.rows.map(row=>row.poAgeDays),[27,8]);
 assert.equal(result.reportAvailable,true);assert.equal(result.productOrderLinked,false);assert(result.rows.every(row=>row.arrivalConfirmed===false));
 assert.equal(result.rows[0].shipped,1);assert.equal(result.sourceDate,'2026-09-28');
});
test('Missing PO source date is never filled by wall clock or report date; future order age stays unknown',()=>{
 const missing=Trace.relatedPO({pos:[{center:'Flex',part:A,poDate:'2026-09-01'}]},'Flex',A,'2026-10-19');assert.equal(missing.rows[0].poAgeDays,null);
 const future=Trace.relatedPO({pos:[{center:'Flex',part:A,poDate:'2026-10-01',date:'2026-09-28'}]},'Flex',A,'2026-10-19');assert.equal(future.rows[0].poDateIssue,'PO_AFTER_SOURCE');assert.equal(future.rows[0].poAgeDays,null);
 assert.equal(Trace.relatedPO({used:[{type:'po',center:'Flex',date:'2026-09-28'}],pos:[]},'Flex',A,'2026-09-28').reportAvailable,true);
 assert.equal(Trace.relatedPO({used:[],pos:[]},'Flex',A,'2026-09-28').reportAvailable,false);
});
