'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),os=require('node:os'),path=require('node:path');
const C=require('../src/core.js'),R=require('../src/reporting.js'),P=require('../src/pipeline.js'),U=require('../src/upload-panel.js'),D=require('../src/summary-data.js'),Stage=require('../src/stage-data.js'),{createStore}=require('../server/store.cjs'),{createUpdateService}=require('../server/update-service.cjs');
const wips=date=>require('../src/weekly-policy.js').required.map(s=>({type:'wip',center:s.center,operator:s.operator,date,file:s.key+'-'+date+'.xlsb',sheet:'WIP',rows:[]}));
const dash=(date,stock=0)=>({type:'dashboard',center:'Flex',operator:'',date,dateLabel:date,file:'Synthetic '+date+'.xlsx',sheet:'Dashboard',holdDate:date,usageMonths:['2026-08'],rows:[{part:'TEST-000001',row:2,stock,hold:5,po:2,usage:{'2026-08':2}}]});
const inv=(date,qty=10)=>({type:'india',date,dateLabel:date,file:'Synthetic India '+date+'.xlsx',sheet:'Stock',rows:[{part:'TEST-000001',row:2,qty}]});
function setup(t){const dataDir=fs.mkdtempSync(path.join(os.tmpdir(),'parts-v156-'));t.after(()=>fs.rmSync(dataDir,{recursive:true,force:true}));const store=createStore({dataDir,seedState:C.empty()}),service=createUpdateService({store});const update=(sources,reportDate,choices={})=>service.update({operation:'import',baseRevision:store.status().revision,sources:store.read().state.reportingWeeks?.some(r=>r.id===R.weekStart(reportDate))?sources:[...wips(reportDate),...sources],reportDate,choices});return {store,service,update,dataDir};}
test('fresh start imports weeks, excludes one source without fallback, persists and restores on reupload',t=>{
 const {store,service,update,dataDir}=setup(t);assert.equal(store.status().reportCount,0);assert.equal(D.build(store.read().state).dataAvailable,false);
 update([dash('2026-09-21'),inv('2026-09-21')],'2026-09-21');update([dash('2026-09-28',1)],'2026-09-28');
 update([dash('2026-10-05',2)],'2026-10-05',{india:'exclude'});
 let state=store.read().state;assert.equal(R.reportState(state,'2026-09-28').sources.find(s=>s.type==='india').rows[0].qty,10);assert(!R.reportState(state,'2026-10-05').sources.some(s=>s.type==='india'));
 let result=D.build(state);assert.equal(result.rows.find(r=>r.center==='Flex').india,null);assert.equal(result.trend.length,3);assert.equal(state.importReceipts['2026-10-05'].rows.find(r=>r.key==='india').choice,'exclude');
 const reportDate='2026-10-12';update([dash(reportDate,3)],reportDate);state=store.read().state;assert(!R.reportState(state,'2026-10-12').sources.some(s=>s.type==='india'));
 // A correction of an earlier India file cannot undo the explicit exclusion.
 update([inv('2026-09-28',99)],'2026-09-28');state=store.read().state;assert(!R.reportState(state,'2026-10-05').sources.some(s=>s.type==='india'));assert(!R.reportState(state,'2026-10-12').sources.some(s=>s.type==='india'));
 update([inv('2026-10-12',7)],'2026-10-12');const restarted=createStore({dataDir});state=restarted.read().state;result=D.build(state);assert.equal(result.rows.find(r=>r.center==='Flex').india,7);assert.equal(restarted.status().reportCount,4);assert.equal(Stage.build(result).trend.length,4);assert.equal(R.reportWarnings(state,'2026-10-05').length,0);
});
test('explicit skip is selective for a conflicting or future file and keeps other sources usable',()=>{
 const state=R.applySources(C.empty(),[dash('2026-09-21'),inv('2026-09-21')],'2026-09-21'),incoming=[dash('2026-09-28',1),dash('2026-09-28',2),inv('2026-10-05',9)];
 let plan=P.evaluate(state,incoming,'2026-09-28');assert(!plan.canApply);assert(plan.errors.length>=2);
 plan=P.evaluate(state,incoming,'2026-09-28',{'flex:dashboard':'incoming:1',india:'keep'});assert(plan.canApply);assert.equal(plan.selectedSources[0].rows[0].stock,2);assert.equal(plan.rows.find(r=>r.key==='india').source.rows[0].qty,10);
 plan=P.evaluate(state,incoming,'2026-09-28',{'flex:dashboard':'incoming:0',india:'exclude'});assert(plan.canApply);assert.equal(plan.rows.find(r=>r.key==='india').source,null);assert.deepEqual(plan.excludedSlots,['india']);
});
test('exclusion-only correction applies without changing the number of reporting weeks',t=>{
 const {store,update}=setup(t);update([dash('2026-09-21'),inv('2026-09-21')],'2026-09-21');update([],'2026-09-21',{india:'exclude'});assert.equal(store.status().reportCount,1);assert(!R.reportState(store.read().state).sources.some(s=>s.type==='india'));
});
test('upload preview does not show an excluded prior source as available and labels Monday explicitly',()=>{
 const state=R.applySources(C.empty(),[dash('2026-09-21'),inv('2026-09-21')],'2026-09-21'),review=P.evaluate(state,[dash('2026-09-28',1)],'2026-09-28',{india:'exclude'}),m=U.buildModel({state,reportDate:'2026-09-28',review,choices:{india:'exclude'}});
 assert.equal(m.slots.find(r=>r.key==='india').source,null);assert.equal(m.sourceCounts.requiredOther.available,1);assert(m.hasPending);const html=U.render({state,mode:'edit',reportDate:'2026-09-30',review,choices:{india:'exclude'}});assert.match(html,/보고 주차 · 월요일/);assert.match(html,/id="report-date" type="date" value="2026-09-28"/);assert.match(html,/data-pipeline-choice="india"/);assert.match(html,/이번 주 제외 · 미확인/);
});
test('missing calendar week is a graph gap while same-week correction stays one snapshot',t=>{
 const {store,update}=setup(t);update([dash('2026-09-21')],'2026-09-21');update([dash('2026-10-05',3)],'2026-10-05');update([dash('2026-10-05',4)],'2026-10-05');assert.equal(store.status().reportCount,2);const d=Stage.build(D.build(store.read().state));assert.equal(d.trend.length,3);assert(d.trend[1].missing);assert.equal(d.rows[0].stock,4);
});
