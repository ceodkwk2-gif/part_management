'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const fs=require('node:fs'),path=require('node:path'),os=require('node:os'),crypto=require('node:crypto'),zlib=require('node:zlib');
const XLSX=require('../vendor/xlsx.full.min.js'),Package=require('../src/packaging.js');
const {restoreBackup}=require('../scripts/restore-server-backup.cjs'),{createStore}=require('../server/store.cjs');
const C=require('../src/core.js'),R=require('../src/reporting.js');
const sha=bytes=>crypto.createHash('sha256').update(bytes).digest('hex');
const crcTable=Array.from({length:256},(_,n)=>{for(let i=0;i<8;i++)n=n&1?0xedb88320^(n>>>1):n>>>1;return n>>>0;});
const crc=bytes=>{let n=0xffffffff;for(const byte of bytes)n=crcTable[(n^byte)&255]^(n>>>8);return (n^0xffffffff)>>>0;};
function temp(t){const dir=fs.mkdtempSync(path.join(os.tmpdir(),'parts-restore-stream-'));t.after(()=>fs.rmSync(dir,{recursive:true,force:true}));return dir;}
function fixture(){return R.normalizeState({...C.empty(),sources:[{type:'dashboard',center:'Flex',date:'2024-08-12',dateLabel:'2024-08-12',file:'Synthetic.xlsx',sheet:'Dashboard',holdDate:'2024-08-12',usageMonths:['2024-07'],rows:[{part:'1000-000001',row:2,stock:2,po:0,hold:3,usage:{'2024-07':2}}]}],notes:{test:'Keep note'}});}
function sample(t,rawSize=64){
 const root=temp(t),store=createStore({dataDir:path.join(root,'source'),seedState:fixture()}),raw=store.addRaw({name:'Synthetic.xlsx',bytes:Buffer.alloc(rawSize,77)});
 store.save({state:store.read().state,baseRevision:0,rawIds:[raw.id]});
 const stored=store.backupEntries(),manifest={format:'parts-monitor-server-backup',version:1,revision:store.status().revision,files:stored.map((entry,i)=>({path:entry.name,file:'Backup_'+String(i).padStart(6,'0')+'.bin',sha256:sha(entry.bytes),size:entry.bytes.length}))};
 return {root,store,raw,manifest,entries:[{name:'Server_Backup.json',bytes:Buffer.from(JSON.stringify(manifest))},...stored.map((entry,i)=>({name:manifest.files[i].file,bytes:entry.bytes}))]};
}
// Independent ZIP32 writer, including descriptors produced by streaming writers.
function zip(entries,method=0,descriptor=false){
 const locals=[],central=[];let offset=0;
 for(const entry of entries){
  const name=Buffer.from(entry.name),body=method===8?zlib.deflateRawSync(entry.bytes):entry.bytes,sum=crc(entry.bytes),flags=0x0800|(descriptor?8:0),header=Buffer.alloc(30),directory=Buffer.alloc(46);
  header.writeUInt32LE(0x04034b50);header.writeUInt16LE(20,4);header.writeUInt16LE(flags,6);header.writeUInt16LE(method,8);
  if(!descriptor){header.writeUInt32LE(sum,14);header.writeUInt32LE(body.length,18);header.writeUInt32LE(entry.bytes.length,22);}header.writeUInt16LE(name.length,26);
  directory.writeUInt32LE(0x02014b50);directory.writeUInt16LE(20,4);directory.writeUInt16LE(20,6);directory.writeUInt16LE(flags,8);directory.writeUInt16LE(method,10);directory.writeUInt32LE(sum,16);directory.writeUInt32LE(body.length,20);directory.writeUInt32LE(entry.bytes.length,24);directory.writeUInt16LE(name.length,28);directory.writeUInt32LE(offset,42);
  const descriptorBytes=Buffer.alloc(descriptor?16:0);if(descriptor){descriptorBytes.writeUInt32LE(0x08074b50);descriptorBytes.writeUInt32LE(sum,4);descriptorBytes.writeUInt32LE(body.length,8);descriptorBytes.writeUInt32LE(entry.bytes.length,12);}
  locals.push(header,name,body,descriptorBytes);central.push(directory,name);offset+=header.length+name.length+body.length+descriptorBytes.length;
 }
 const directory=Buffer.concat(central),end=Buffer.alloc(22);end.writeUInt32LE(0x06054b50);end.writeUInt16LE(entries.length,8);end.writeUInt16LE(entries.length,10);end.writeUInt32LE(directory.length,12);end.writeUInt32LE(offset,16);
 return Buffer.concat([...locals,directory,end]);
}
function guardedRestore(filename,target,options={}){
 const original={open:fs.openSync,close:fs.closeSync,readFile:fs.readFileSync,read:fs.readSync,cfb:XLSX.CFB.read},fds=new Set(),requests=[];
 fs.openSync=(file,...args)=>{const fd=original.open(file,...args);if(typeof file==='string'&&path.resolve(file)===path.resolve(filename))fds.add(fd);return fd;};
 fs.closeSync=fd=>{fds.delete(fd);return original.close(fd);};
 fs.readFileSync=(file,...args)=>{if(fds.has(file)||typeof file==='string'&&path.resolve(file)===path.resolve(filename))throw Error('Whole ZIP read is forbidden');return original.readFile(file,...args);};
 fs.readSync=(fd,buffer,offset,length,position)=>{if(fds.has(fd))requests.push(length);return original.read(fd,buffer,offset,length,position);};
 XLSX.CFB.read=()=>{throw Error('CFB must not parse a backupPath ZIP');};
 try{return {result:restoreBackup({backupPath:filename,dataDir:target,...options}),requests};}
 finally{fs.openSync=original.open;fs.closeSync=original.close;fs.readFileSync=original.readFile;fs.readSync=original.read;XLSX.CFB.read=original.cfb;}
}

test('stored streaming ZIP restores through bounded seeks without whole-file or CFB reads',t=>{
 const source=sample(t,2*1024*1024+73),filename=path.join(source.root,'backup.zip'),target=path.join(source.root,'restored');fs.writeFileSync(filename,zip(source.entries,0,true));
 const {result,requests}=guardedRestore(filename,target);assert.equal(result.revision,1);assert.equal(result.rawCount,1);assert.ok(requests.length>5);assert.ok(requests.every(size=>size<=1024*1024));
 const restored=createStore({dataDir:target});assert.deepEqual(restored.read(),source.store.read());assert.deepEqual(restored.readRaw(source.raw.id).bytes,source.store.readRaw(source.raw.id).bytes);
 assert.equal(fs.readdirSync(source.root).some(name=>name.startsWith('.parts-restore-')),false);
});

test('legacy CFB deflated ZIP and deflated descriptor ZIP restore from disk one entry at a time',t=>{
 const source=sample(t,192*1024),variants=[Package.createZip(source.entries.map(entry=>({name:entry.name,content:entry.bytes}))),zip(source.entries,8,true),zip(source.entries,0,false)];
 variants.forEach((bytes,i)=>{const filename=path.join(source.root,'backup-'+i+'.zip'),target=path.join(source.root,'restored-'+i);fs.writeFileSync(filename,bytes);guardedRestore(filename,target);assert.deepEqual(createStore({dataDir:target}).read(),source.store.read());});
});

test('duplicate entries, local/central disagreement and truncated directories fail before replacing existing data',t=>{
 const source=sample(t),target=path.join(source.root,'active'),before=createStore({dataDir:target,seedState:fixture()}).read(),valid=zip(source.entries),mismatch=Buffer.from(valid),duplicate=Buffer.from(valid);
 mismatch[30]='X'.charCodeAt(0);const from=Buffer.from('Backup_000001.bin'),to=Buffer.from('Backup_000000.bin');let offset=0;while((offset=duplicate.indexOf(from,offset))!==-1){to.copy(duplicate,offset);offset+=from.length;}
 for(const [i,bytes]of [mismatch,duplicate,valid.subarray(0,valid.length-4)].entries()){
  const filename=path.join(source.root,'invalid-'+i+'.zip');fs.writeFileSync(filename,bytes);assert.throws(()=>guardedRestore(filename,target));assert.deepEqual(createStore({dataDir:target}).read(),before);
 }
 assert.equal(fs.readdirSync(source.root).some(name=>name.startsWith('.parts-restore-')),false);
});

test('manifest SHA failure and unsafe paths clean the staged files and retain the original target',t=>{
 const source=sample(t),target=path.join(source.root,'active'),before=createStore({dataDir:target,seedState:fixture()}).read();
 for(const [i,change]of [manifest=>{manifest.files[0].sha256='0'.repeat(64);},manifest=>{manifest.files[0].path='../outside';}].entries()){
  const manifest=JSON.parse(JSON.stringify(source.manifest));change(manifest);const entries=[{name:'Server_Backup.json',bytes:Buffer.from(JSON.stringify(manifest))},...source.entries.slice(1)],filename=path.join(source.root,'bad-manifest-'+i+'.zip');
  fs.writeFileSync(filename,zip(entries));assert.throws(()=>guardedRestore(filename,target));assert.deepEqual(createStore({dataDir:target}).read(),before);
 }
 assert.equal(fs.existsSync(path.join(source.root,'outside')),false);assert.equal(fs.readdirSync(source.root).some(name=>name.startsWith('.parts-restore-')),false);
});

test('disk-backed recovery retains rename rollback and releases its staging directory on failure',t=>{
 const source=sample(t),target=path.join(source.root,'active'),before=createStore({dataDir:target,seedState:fixture()}).read(),filename=path.join(source.root,'backup.zip');fs.writeFileSync(filename,zip(source.entries));
 const ops=Object.create(fs);ops.renameSync=(from,to)=>{if(path.basename(from).startsWith('.parts-restore-'))throw Error('Synthetic final rename failure');return fs.renameSync(from,to);};
 assert.throws(()=>guardedRestore(filename,target,{fsOps:ops}),/Synthetic final rename failure/);assert.deepEqual(createStore({dataDir:target}).read(),before);
 assert.equal(fs.existsSync(path.join(target,'server.lock')),false);assert.equal(fs.readdirSync(source.root).some(name=>name.startsWith('.parts-restore-')),false);
});
