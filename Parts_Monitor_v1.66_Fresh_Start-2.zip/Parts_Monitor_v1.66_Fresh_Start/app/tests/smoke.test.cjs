'use strict';

// Entirely invented fixtures. No production exports or real material codes.
const test = require('node:test');
const assert = require('node:assert/strict');
const C = require('../src/core.js');

const PART = 'TEST-000001';
const EXTRA = 'TEST-000002';
const DATE = '2024-08-12';
const MONTHS = ['2024-02', '2024-03', '2024-04', '2024-05', '2024-06', '2024-07'];

test('compact source dates work on the 19th, 20th and 21st without losing YYYYMMDD support', () => {
  for (const day of ['19', '20', '21']) {
    assert.equal(C.fileDate(`Synthetic dashboard ${day}092026.xlsx`), `2026-09-${day}`);
  }
  for (let month = 1; month <= 12; month++) {
    const mm = String(month).padStart(2, '0');
    assert.equal(C.fileDate(`SyntheticWip20${mm}2026.xlsb`), `2026-${mm}-20`);
  }
  assert.equal(C.fileDate('Synthetic stock_20261020.xlsx'), '2026-10-20');
  assert.equal(C.fileDate('Synthetic stock_20240229.xlsx'), '2024-02-29');
  assert.equal(C.fileDate('Synthetic PO_18.09.26.xlsx'), '2026-09-18');
});

test('source-date fallback does not turn invalid calendar dates into actual dates', () => {
  for (const value of ['31022026', '29022025', '20260230', '20261301', '32.09.26']) {
    assert.equal(C.fileDate(`Synthetic_${value}.xlsx`), null, value);
  }
  assert.equal(C.fileDate('Synthetic stock WK38.xlsx'), null);
});

function source(type, center, rows, extra = {}) {
  const s = {
    type, center, operator: '', date: DATE, dateLabel: DATE,
    file: `synthetic-${type}-${center || 'shared'}.xlsx`,
    sheet: 'Synthetic', rows, ...extra,
  };
  s.id = C.sourceKey(s);
  return s;
}

function dashboard(center, stock, monthlyUsage, hold) {
  return source('dashboard', center, [{
    part: PART, description: 'Synthetic fixture', row: 5, stock, po: 0,
    hold, usage: Object.fromEntries(MONTHS.map(m => [m, monthlyUsage])),
  }], { usageMonths: MONTHS, holdDate: DATE });
}

function fixture() {
  const state = C.empty();
  state.sources = [
    dashboard('Flex', 8, 4, 10),
    dashboard('CTDI', 4, 6, 7),
    source('india', '', [{ part: PART, row: 2, qty: 3 }]),
    source('hq', '', [{ part: PART, row: 2, qty: 10 }]),
  ];
  return state;
}

test('empty app state can calculate without private seed data', () => {
  const result = C.calculate(C.empty(), DATE);
  assert.deepEqual(result.parts, []);
  assert.deepEqual(result.commonSupport.parts, []);
  assert.equal(result.commonSupport.demandComplete, false);
});

test('required-part quantities preserve explicit multiplicity and unresolved text', () => {
  assert.deepEqual(C.partTokens(`${PART}#2, ${PART}, ${EXTRA} x3`).parts,
    { [PART]: 3, [EXTRA]: 3 });
  assert.equal(C.partTokens('UNRESOLVED LABEL').unparsed, 'UNRESOLVED LABEL');
});

test('current shortage is not erased by open orders or received-quantity fields', () => {
  const state = fixture();
  state.sources[0].rows[0].po = 8;
  state.sources.push(source('po', 'Flex', [{
    part: PART, row: 2, po: 'SYNTHETIC-PO', item: '1', ordered: 13,
    shipped: 5, pending: 8, poDate: '2024-08-01', etd: null,
  }]));
  const part = C.calculate(state, DATE, 'Flex').parts[0];
  assert.equal(part.stock, 8);
  assert.equal(part.shortage, 2);
  assert.equal(part.proposed, 0);
  assert.equal(part.open, 8);
});

test('duplicate stock uses the topmost source row, not array order or a sum', () => {
  const state = fixture();
  state.sources[0].rows.unshift({ ...state.sources[0].rows[0], row: 9, stock: 999 });
  const result = C.calculate(state, DATE, 'Flex');
  assert.equal(result.parts[0].stock, 8);
  assert.equal(result.parts[0].selectedSourceRow, 5);
  assert.deepEqual(result.duplicateDiagnostics[0].ignoredRows, [9]);
});

test('missing dashboard code uses zero stock but keeps usage unknown', () => {
  const state = fixture();
  state.sources.push(source('po', 'Flex', [{
    part: EXTRA, row: 2, po: 'SYNTHETIC-EXTRA', pending: 2,
  }]));
  const result = C.calculate(state, DATE, 'Flex');
  const part = result.parts.find(p => p.part === EXTRA);
  assert.equal(part.stock, 0);
  assert.equal(part.stockAssumedZero, true);
  assert.equal(part.avg, null);
  assert.equal(part.proposed, null);
  assert.equal(result.masterAlerts.length, 1);
});

test('common support counts shared stock once and preserves both-center demand', () => {
  const state = fixture();
  const result = C.calculate(state, DATE, 'Flex').commonSupport;
  assert.equal(result.parts.length, 1);
  const part = result.parts[0];
  assert.equal(part.demand, 10);
  assert.equal(part.india, 3);
  assert.equal(part.hq, 10);
  assert.equal(part.immediateShortage, 5);
  assert.equal(part.indiaTarget, 0);
  assert.equal(part.hqTarget, 30);
  assert.equal(part.indiaGap, 0);
  assert.equal(part.hqGap, 20);
  state.settings.indiaMonths = 2;
  assert.equal(C.calculate(state, DATE).commonSupport.parts[0].indiaTarget, 20);
});

test('India zero buffer default preserves actual demand and keeps an explicitly configured buffer', () => {
  assert.equal(C.empty().settings.indiaMonths, 0);
  for (const value of [undefined, null, '', 'invalid', -1, Infinity, 0, '0']) {
    assert.equal(C.effectiveSupportMonths({indiaMonths:value}, 'india'), 0);
  }
  for (const value of [0.1, 1, 2, 24]) {
    assert.equal(C.effectiveSupportMonths({indiaMonths:value}, 'india'), value);
  }
  assert.equal(C.effectiveSupportMonths({}, 'hq'), 3);
  assert.equal(C.effectiveSupportMonths({hqMonths:0}, 'hq'), 3);
  const state = fixture(), initial = C.calculate(state, DATE);
  const part = initial.commonSupport.parts[0];
  assert.equal(part.demand, 10);
  assert.equal(part.hqTarget, 30);
  assert.equal(part.indiaTarget, 0);
  assert.equal(part.indiaGap, 0);
  state.settings.indiaMonths = 1;
  const changed = C.calculate(state, DATE);
  assert.equal(changed.commonSupport.parts[0].indiaTarget, 10);
  assert.equal(changed.commonSupport.parts[0].demand, part.demand);
  assert.equal(changed.commonSupport.parts[0].hqTarget, part.hqTarget);
  assert.deepEqual(changed.parts, initial.parts);
});

test('zero India buffer does not replace unknown actual demand or inventory with zero', () => {
  const state = fixture();
  delete state.sources[0].rows[0].usage[MONTHS[0]];
  let part = C.calculate(state, DATE).commonSupport.parts[0];
  assert.equal(part.demand, null);
  assert.equal(part.demandKnownSubtotal, 6);
  assert.equal(part.indiaTarget, null);
  assert.equal(part.hqTarget, null);
  state.sources = state.sources.filter(source => source.type !== 'india');
  part = C.calculate(state, DATE).commonSupport.parts[0];
  assert.equal(part.india, null);
  assert.equal(part.indiaGap, null);
});

test('same-date correction replaces the source and resolves its current alert', () => {
  const state = fixture();
  state.sources[0].rows.push({ ...state.sources[0].rows[0], row: 9, stock: 99 });
  assert.equal(C.calculate(state, DATE).duplicateDiagnostics.length, 1);
  const corrected = dashboard('Flex', 8, 4, 10);
  corrected.file = 'synthetic-corrected-different-filename.xlsx';
  const merged = C.merge(state, [corrected]);
  assert.equal(merged.sources.length, state.sources.length);
  assert.equal(C.calculate(merged, DATE).duplicateDiagnostics.length, 0);
  assert.equal(state.sources[0].rows.length, 2);
});

test('absent upstream source remains unknown instead of becoming zero', () => {
  const state = fixture();
  state.sources = state.sources.filter(s => s.type !== 'hq');
  const part = C.calculate(state, DATE).commonSupport.parts[0];
  assert.equal(part.hq, null);
  assert.equal(part.hqGap, null);
});
