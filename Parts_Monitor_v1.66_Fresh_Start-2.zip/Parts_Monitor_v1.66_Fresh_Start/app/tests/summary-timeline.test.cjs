'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const Overview=require('../src/overview.js');
const row=(part,center='CTDI',extra={})=>({id:center+'|'+part,part,center,name:'TEST PART',stock:0,india:0,hq:10,avg:2,needed:2,shortage:2,open:5,poOrdered:5,proposed:0,currentAssessed:true,orderAssessed:true,...extra});
function fixture(){
 const r=row('TEST-1');
 return {asof:'2026-10-12',week:'2026-10-12',rows:[r],tasks:[{rowId:r.id,recipient:'INDIA',kind:'SUPPLY',textKo:'법인·본사 · 기존 PO 공급 일정 확인',textEn:'India / HQ · Check existing PO supply schedule'}],products:[{id:'SYNTHETIC-1',sn:'TEST-SN',center:'CTDI',operator:'Jio',receipt:'2026-05-25',date:'2026-10-12',age:140,parts:[{part:r.part,quantity:2,firstDate:'2026-09-27',firstAge:125,baseline:true}]}],pos:[{center:'CTDI',part:r.part,po:'TEST-PO',poDate:'2026-10-07',date:'2026-10-10',ordered:5,pending:5,shipped:0,etd:null}],sourceDates:[{type:'wip',center:'CTDI',date:'2026-10-12'}],siel:{rows:[{part:r.part,po:'TEST-HQ',poDate:'2026-10-09',ordered:5,pending:null,eta:'2027-02-11',sourceDate:'2026-10-19',docs:[]}]}};
}
const main=h=>h.split('data-ov-summary-overdue-row=')[1].split('<details class="ov-trace-evidence">')[0];
test('all overdue parts appear directly on Summary while stock pagination remains',()=>{
 const d=fixture();d.rows=Array.from({length:12},(_,i)=>row('TEST-'+i));d.products=d.rows.map((r,i)=>({...d.products[0],id:'P'+i,parts:[{...d.products[0].parts[0],part:r.part}]}));
 const h=Overview.render({data:d,overduePage:2,overduePageSize:3});
 assert.equal((h.match(/data-ov-summary-overdue-row=/g)||[]).length,12);
 assert.equal((h.match(/data-ov-timeline-part=/g)||[]).length,12);
 assert(!h.includes('data-ov-overdue-page='));assert(h.includes('data-ov-summary-page='));
 assert(h.includes('href="#ov-stock-work"'));assert(h.includes('href="#ov-overdue-work"'));
});
test('basic row separates oldest-product observations from supply evidence and keeps single-PO timing',()=>{
 const h=Overview.render({data:fixture()}),r=main(h),product=r.split('<div class="ov-product-history"')[1].split('<div class="ov-supply-flow"')[0],supply=r.split('<div class="ov-supply-flow"')[1];
 for(const text of ['1대','2개','TAT 140일','09/27','TAT 125일','10/07','TAT 135일','첫 관찰 10일 후','미입고 5개','2027/02/11','센터 배정 미확인','제품별 배정은 미확인','법인·본사','실제 입고·잔량 미확인'])assert(r.includes(text),text);
 assert(product.includes('data-event="receipt"'));assert(product.includes('data-event="observed"'));assert(product.includes('data-event="current"'));assert(!product.includes('data-event="po"'));
 assert(supply.indexOf('data-event="po"')<supply.indexOf('data-event="hq-po"'));assert(supply.indexOf('data-event="hq-po"')<supply.indexOf('data-event="india-eta"'));
 assert(r.includes('ov-supply-eta planned'));assert(r.includes('법인 도착 예정 · ETA'));assert(r.includes('센터 입고 예정일 아님'));
 assert(!r.includes('기준보다'));assert(!r.includes('ov-mini-supplier'));
});
test('PO before receipt stays in supply evidence with explicit context and no negative product TAT',()=>{
 const d=fixture();d.products[0].receipt='2026-07-08';d.products[0].age=96;d.products[0].parts[0].firstAge=81;d.pos[0].poDate='2026-07-04';
 const r=main(Overview.render({data:d}));assert(r.includes('입고 전부터 있던 PO'));assert(r.includes('제품별 배정은 미확인'));assert(!r.includes('첫 관찰'));assert(!r.includes('-4일'));assert(!r.includes('TAT -4'));
});
test('open PO without detail records stays open with unknown order date',()=>{
 const d=fixture();d.pos=[];const r=main(Overview.render({data:d}));assert(r.includes('발주일 미확인'));assert(r.includes('미입고 5개'));assert(r.includes('상세 발주 내역 미확인'));assert(!r.includes('미입고 PO 0개'));
});
test('unknown receipt does not create TAT zero and carried WIP does not claim current observation',()=>{
 const d=fixture();d.products[0].receipt=null;d.products[0].date='2026-10-05';d.overdue={freshByCenter:{CTDI:false}};
 const h=Overview.render({data:d}),r=main(h);assert(r.includes('입고일 미확인'));assert(!r.includes('TAT 0일'));assert(r.includes('이전 참고'));assert(h.includes('이후 계속 대기 중인지는 미확인'));
});
test('same shared HQ PO is visible under both centers without assigned balances or count mutation',()=>{
 const d=fixture();d.rows.push(row('TEST-1','Flex'));d.products.push({...d.products[0],id:'SYNTHETIC-2',center:'Flex'});const before=JSON.stringify(d),h=Overview.render({data:d});
 assert.equal((h.match(/data-ov-timeline-part=/g)||[]).length,1);assert.equal((h.match(/data-ov-summary-overdue-row=/g)||[]).length,2);const basic=h.split('data-ov-summary-overdue-row=').slice(1).map(x=>x.split('<details class="ov-trace-evidence">')[0]).join('');assert.equal((basic.match(/센터 배정 미확인/g)||[]).length,2);assert.equal(JSON.stringify(d),before);
 assert.equal(Overview.overdueStats(d,'ALL').parts,1);assert.equal(Overview.overdueStats(d,'ALL').products,2);
});
test('timeline search and English keep source text escaped and relevant detail expandable',()=>{
 const d=fixture();d.rows[0].name='<img src=x>';const h=Overview.render({data:d,language:'en',overdueSearch:'TEST-1'});assert(h.includes('&lt;img src=x&gt;'));assert(!h.includes('<img'));assert(h.includes('data-ov-summary-search="overdue"'));assert(h.includes('All 1 part kinds shown'));assert(h.includes('Center allocation unknown'));assert(h.includes('View history, stock and PO details'));assert(h.includes('data-ov-part="TEST-1"'));
});

test('reported supplier pending balance is retained and never replaced by unknown',()=>{
 const d=fixture();d.siel.rows[0].pending=3;const r=main(Overview.render({data:d}));assert(r.includes('미입고 3개'));assert(!r.includes('실제 입고·잔량 미확인'));
});

test('missing center PO shows zero once, and repair shortage is labelled for all repairs',()=>{
 const d=fixture();d.pos=[];d.rows[0].open=0;d.rows[0].shortage=20;d.rows[0].needed=20;
 const r=main(Overview.render({data:d})),po=r.split('data-event="po"')[1].split('data-event="hq-po"')[0];
 assert(po.includes('미입고 PO 0개'));assert(!po.includes('<span>미입고 0개</span>'));assert(r.includes('전체 수리분 부족 20개'));assert(!r.includes('센터 재고 부족'));
 const english=main(Overview.render({data:d,language:'en'}));assert(english.includes('All-repair shortage 20 pcs'));
});


test('multiple PO dates and ETA schedules remain ranges with distinct per-order detail',()=>{
 const d=fixture();d.products[0].receipt='2026-07-08';d.pos=[{...d.pos[0],po:'PO-1',poDate:'2026-07-04',pending:360,ordered:360},{...d.pos[0],po:'PO-2',poDate:'2026-07-10',pending:360,ordered:360}];d.rows[0].open=720;
 d.siel.rows=[{part:'TEST-1',po:'HQ-1',poDate:'2026-07-07',ordered:360,pending:null,eta:'2026-09-09'},{part:'TEST-1',po:'HQ-2',poDate:'2026-07-14',ordered:360,pending:null,eta:'2026-09-16'},{part:'TEST-1',po:'HQ-3',poDate:'2026-09-11',ordered:720,pending:null,eta:'2026-11-14'}];
 const h=Overview.render({data:d}),r=main(h);
 for(const text of ['07/04~07/10 / 2건','07/07~09/11 / 3건','2026/09/09~2026/11/14','복수 일정 3개','입고 전 PO 포함','미입고 720개','센터 배정 미확인'])assert(r.includes(text),text);
 assert(!r.includes('당시 제품 TAT'));assert(!r.includes('입고 완료'));assert(h.includes('법인 ETA 2026-09-09'));assert(h.includes('법인 ETA 2026-09-16'));assert(h.includes('법인 ETA 2026-11-14'));
});
test('reappearance and uncertain continuity remain visible before expanding evidence',()=>{
 const d=fixture();Object.assign(d.products[0].parts[0],{episodeIndex:2,episodeStartDate:'2026-10-05',continuityUncertain:true});
 assert(main(Overview.render({data:d})).includes('재등장 10/05'));
 d.products[0].parts[0].episodeIndex=1;assert(main(Overview.render({data:d})).includes('연속 여부 미확인'));
});
test('ETD is limited to matched dispatch quantity and never represented as actual receipt',()=>{
 const d=fixture();d.pos[0].etd='2026-10-15';d.tasks[0].poFollowup={matched:true,plannedQuantity:2,dates:['2026-10-15']};
 let r=main(Overview.render({data:d}));assert(r.includes('법인 출고 예정 2개 · ETD 10/15'));assert(!r.includes('법인 출고 예정 5개'));
 delete d.tasks[0].poFollowup;r=main(Overview.render({data:d}));assert(r.includes('ETD 기록 있음 · 수량 연결 확인 필요'));
});
test('missing HQ records indicate evidence limits rather than confirmed absence of an order',()=>{
 const d=fixture();d.siel.rows=[];const r=main(Overview.render({data:d}));assert(r.includes('센터 PO 있음 · 법인→본사 PO 기록 없음'));assert(r.includes('본사 발주 여부 확인 필요'));assert(!r.includes('본사 미발주 확정'));
});


test('stock and all-current-repair facts remain visible and separate from overdue quantity',()=>{
 const d=fixture();Object.assign(d.rows[0],{stock:48,india:4,hq:704,avg:22.2,needed:20,shortage:0});
 const r=main(Overview.render({data:d})),facts=r.split('<div class="ov-inventory-facts">')[1].split('<div class="ov-inventory-dates">')[0];
 for(const text of ['센터 재고','법인 재고 · 공용','본사 재고 · 공용','월평균 소요량','<strong>23<small>','전체 현 수리 필요','현재 수리분 부족','<strong>48<small>','<strong>4<small>','<strong>704<small>','<strong>20<small>','<strong>0<small>'])assert(facts.includes(text),text);
 assert(r.includes('1대 <span>· 2개'));assert(r.includes('재고 기준:'));
 assert(main(Overview.render({data:d,language:'en'})).includes('All current repair need'));
});
test('zero center PO with no supplier evidence removes hypothetical supply stages',()=>{
 const d=fixture();d.pos=[];d.siel.rows=[];Object.assign(d.rows[0],{open:0,poOrdered:0,stock:0,india:0,hq:0,needed:2,shortage:2});d.sourceDates.push({type:'po',center:'CTDI',date:'2026-10-12'});
 const r=main(Overview.render({data:d}));assert(r.includes('센터 미입고 PO 없음'));assert(r.includes('ov-product-history'));assert(r.includes('data-ov-fact="shortage"'));assert(!r.includes('ov-supply-flow'));assert(!r.includes('공용 법인 → 본사 PO'));assert(!r.includes('법인 도착 예정'));
});
test('missing PO source remains unknown instead of becoming an empty report or zero',()=>{
 const d=fixture();d.pos=[];d.siel.rows=[];d.rows[0].open=null;d.rows[0].poOrdered=null;
 const r=main(Overview.render({data:d}));assert(r.includes('센터 PO 미입고 수량 미확인'));assert(r.includes('상세 PO 원본 없음'));assert(!r.includes('센터 미입고 PO 없음'));assert(!r.includes('ov-supply-flow'));
});
test('PO ordered shipped and pending use detailed source numbers independently of dashboard balance',()=>{
 const d=fixture();Object.assign(d.pos[0],{ordered:110,shipped:28,pending:82});Object.assign(d.rows[0],{poOrdered:110,open:110});d.issues={po:[{center:'CTDI',part:'TEST-1',open:110,detailPending:82,issues:['PO 잔량 불일치']}]};
 const before=JSON.stringify(d),r=main(Overview.render({data:d}));
 for(const text of ['PO 기발주 110개','법인 출고 28개','PO 미입고 82개','대시보드 미입고 110개 / 상세 PO 82개'])assert(r.includes(text),text);
 assert(!r.includes('입고 완료 28'));assert(!r.includes('법인 출고 0개'));assert.equal(JSON.stringify(d),before);
});
test('dashboard-only PO exposes its balance without inventing zero ordered or shipped',()=>{
 const d=fixture();d.pos=[];d.rows[0].poOrdered=0;d.rows[0].open=20;d.sourceDates.push({type:'po',center:'CTDI',date:null,reportWeek:'2026-10-12'});
 const r=main(Overview.render({data:d}));assert(r.includes('대시보드 미입고 20개'));assert(r.includes('상세 발주 내역 미확인'));assert(!r.includes('PO 기발주 0개'));assert(!r.includes('법인 출고 0개'));
});
test('conflicting detailed PO rows keep quantities unknown instead of summing conflicting shipments',()=>{
 const d=fixture();d.pos.push({...d.pos[0],shipped:3});d.rows[0].poOrdered=null;d.issues={po:[{center:'CTDI',part:'TEST-1',open:5,detailPending:null,issues:['상세 PO 동일 식별키의 값 불일치 — 상세 잔량 미확인']}]};
 const r=main(Overview.render({data:d}));assert(r.includes('PO 기발주 —개'));assert(r.includes('법인 출고 —개'));assert(r.includes('PO 미입고 —개'));assert(!r.includes('법인 출고 3개'));
});
test('only top summary cards request navigation to the stock section',()=>{
 const h=Overview.render({data:fixture()});assert.equal((h.match(/data-ov-jump="stock"/g)||[]).length,3);assert(h.includes('id="ov-stock-work" tabindex="-1"'));
 let click;const calls=[],container={addEventListener:(type,handler)=>{if(type==='click')click=handler},removeEventListener(){},contains:()=>true};Overview.bind(container,{onSummaryFilter:(...args)=>calls.push(args)});
 const fire=dataset=>click({target:{closest:()=>({dataset,hasAttribute:name=>name==='data-ov-summary-filter'})}});
 fire({ovSummaryFilter:'ORDER',ovJump:'stock'});fire({ovSummaryFilter:'WAIT'});
 assert.deepEqual(calls,[['ORDER',{jump:true}],['WAIT']]);
});


test('stock view defaults to ten parts and card navigation retains the chosen page size',()=>{
 const d=fixture();d.rows=Array.from({length:12},(_,i)=>row('FOCUS-'+i));d.products=[];
 const normal=Overview.render({data:d}),focused=Overview.render({data:d,summaryFocused:true});
 assert.equal((normal.match(/data-ov-summary-stock-row=/g)||[]).length,10);
 assert.equal((focused.match(/data-ov-summary-stock-row=/g)||[]).length,10);
 assert(focused.includes('ov-stock-work ov-stock-focused'));assert(!normal.includes('ov-stock-work ov-stock-focused'));
 const second=Overview.render({data:d,summaryFocused:true,summaryPage:2});assert.equal((second.match(/data-ov-summary-stock-row=/g)||[]).length,2);assert(second.includes('ov-stock-work ov-stock-focused'));
});


test('monthly demand rounds all finite values up without mutating raw averages',()=>{
 const d=fixture();d.rows[0].avg=0.4;let r=main(Overview.render({data:d}));assert(r.includes('data-ov-fact="avg"><span>월평균 소요량</span><strong>1<small>'));
 d.rows[0].avg=0.01;r=main(Overview.render({data:d}));assert(r.includes('data-ov-fact="avg"><span>월평균 소요량</span><strong>1<small>'));
 for(const [raw,shown] of [[22.7,'23'],[23,'23'],[0,'0'],[null,'—']]){d.rows[0].avg=raw;r=main(Overview.render({data:d}));assert(r.includes('data-ov-fact="avg"><span>월평균 소요량</span><strong>'+shown+'<small>'));assert.equal(d.rows[0].avg,raw);}
});

test('additional PO is prominent with a single equation and stock-buffer purpose',()=>{
 const d=fixture();d.rows[0]={...d.rows[0],avg:0.5,target:1,needed:1,shortage:1,stock:0,open:1,proposed:1};d.settings={targetMonths:1};
 const before=JSON.stringify(d),r=main(Overview.render({data:d}));
 for(const text of ['data-ov-order-decision="needed"','추가 PO 1개 필요','1개월분 확보용','수리 1 + 1개월분 1 − 센터재고 0 − 미입고 PO 1 = 추가 1개'])assert(r.includes(text),text);
 assert(!r.includes('현재 수리용 추가발주'));assert.equal(JSON.stringify(d),before);
 const eng=main(Overview.render({data:d,language:'en'}));assert(eng.includes('Additional PO 1 pcs needed'));assert(eng.includes('For 1-month stock'));
});
test('sufficient existing PO shows no new order and an honest inequality instead of negative arithmetic',()=>{
 const d=fixture();Object.assign(d.rows[0],{needed:5,avg:9,target:9,stock:0,open:30,proposed:0,shortage:5});Object.assign(d.pos[0],{ordered:28,pending:28});
 const r=main(Overview.render({data:d}));
 for(const text of ['추가 PO 불필요','기존 PO 수량 충분 · 입고 필요','수리 5 + 1개월분 9 = 14개 ≤ 센터재고 0 + 미입고 PO 30','대시보드 미입고 30개 / 상세 PO 28개'])assert(r.includes(text),text);
 assert(!r.includes('− 미입고 PO 30 = 추가 0'));assert(!r.includes('수리 가능'));
});
test('stock and open PO combine only once and zero extra does not claim current repairs can proceed',()=>{
 const d=fixture();Object.assign(d.rows[0],{needed:4,avg:3,target:3,stock:2,open:7,proposed:0,shortage:2});d.pos=[];
 const r=main(Overview.render({data:d}));assert(r.includes('수리 4 + 1개월분 3 = 7개 ≤ 센터재고 2 + 미입고 PO 7'));assert(r.includes('기존 PO 수량 충분 · 입고 필요'));assert(!r.includes('센터 재고로 총 필요량 충족'));assert(!r.includes('수리 가능'));
});
test('unknown target or order inputs cannot become additional PO zero',()=>{
 const d=fixture();d.rows[0].target=null;d.rows[0].proposed=null;d.rows[0].orderAssessed=false;
 let r=main(Overview.render({data:d}));assert(r.includes('추가 PO 수량 미확인'));assert(r.includes('보유 기준 확인 필요'));assert(!r.includes('추가 PO 불필요'));
 d.rows[0].target=2;d.rows[0].open=null;r=main(Overview.render({data:d}));assert(r.includes('미입고 PO 확인 필요'));assert(!r.includes('미입고 PO 0 ='));
});
test('manual first-confirmed date applies to timeline while automatic observation and current TAT remain distinct',()=>{
 const d=fixture();Object.assign(d.products[0].parts[0],{firstDate:'2026-09-20',firstAge:118,autoFirstDate:'2026-09-27',autoFirstAge:125,manualFirstConfirmedDate:'2026-09-20',firstConfirmedSource:'manual',firstConfirmedConflict:true});
 const before=JSON.stringify(d),h=Overview.render({data:d}),r=main(h);
 for(const text of ['09/20','최초 부품대기 확인일 · 수기','TAT 118일','현재 <strong>TAT 140일','최초 부품대기 확인일 기록 재확인'])assert(r.includes(text),text);
 assert(!r.includes('첫 자료에 이미 대기'));assert(h.includes('수기 확인 · 자동 관찰 2026-09-27'));assert.equal(JSON.stringify(d),before);
});
test('unavailable card inputs are visibly unassessed instead of normal zero and center scope is respected',()=>{
 const d=fixture();d.availabilityByCenter={'전체':{actionAvailability:{shortage:false,order:false,wait:false}},CTDI:{actionAvailability:{shortage:true,order:true,wait:true}}};
 const all=Overview.render({data:d}).split('<div class="ov-cards">')[1].split('<div class="ov-command-band">')[0];
 assert.equal((all.match(/산정 불가/g)||[]).length,3);assert(!all.includes('<strong>0<small>'));assert(all.includes('확인된 자료의 목록만 표시'));
 const center=Overview.render({data:d,center:'CTDI'}).split('<div class="ov-cards">')[1].split('<div class="ov-command-band">')[0];assert(!center.includes('산정 불가'));assert(center.includes('<strong>1<small>종'));
});


test('WIP-only overdue rows need assessment data and never claim no action',()=>{
 const d=fixture();d.tasks=[];d.pos=[];d.siel.rows=[];
 Object.assign(d.rows[0],{stock:null,avg:null,needed:null,shortage:null,open:null,poOrdered:null,proposed:null,target:null,currentAssessed:false,orderAssessed:false});
 const h=Overview.render({data:d,center:'CTDI'}),r=main(h);
 assert(r.includes('현재 부족 여부 미확인'));assert(r.includes('센터 · 센터 재고·현 수리 필요 수·미입고 PO·보유 기준 자료 보완'));
 assert(!r.includes('추가 조치 없음'));assert(!r.includes('수리 진행 확인'));assert(r.includes('추가 PO 수량 미확인'));
 const detail=Overview.renderDetails({data:d,center:'CTDI',kind:'OVERDUE'});assert(detail.includes('자료 보완'));assert(!detail.includes('추가 조치 없음'));
 const english=main(Overview.render({data:d,center:'CTDI',language:'en'}));assert(english.includes('Current shortage not assessed'));assert(!english.includes('No additional action'));
});
test('same-date partial WIP is not falsely labelled as an older observation',()=>{
 const d=fixture();d.products[0].operator='Vi';d.overdue={freshByCenter:{CTDI:false},fresh:false};
 const h=Overview.render({data:d,center:'CTDI'}),r=main(h);
 assert(!r.includes('이전 참고'));assert(!h.includes('이전 자료 참고'));assert(r.includes('현재 <strong>TAT 140일'));
 d.products[0].date='2026-10-05';d.sourceDates[0].date='2026-10-05';
 const previous=Overview.render({data:d,center:'CTDI'});assert(main(previous).includes('이전 참고'));assert(previous.includes('이전 자료 참고'));
});
