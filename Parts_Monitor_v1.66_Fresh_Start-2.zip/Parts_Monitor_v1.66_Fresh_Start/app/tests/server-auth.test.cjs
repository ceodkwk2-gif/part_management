'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const fs=require('node:fs'),path=require('node:path'),os=require('node:os');
const {createAuth}=require('../server/auth.cjs');
const password='A-test-password-42';
function temp(t){const dir=fs.mkdtempSync(path.join(os.tmpdir(),'parts-auth-test-'));t.after(()=>fs.rmSync(dir,{recursive:true,force:true}));return dir;}
const status=expected=>error=>error.status===expected;
const cookie=session=>'unrelated=1; parts_session='+session.id+'; another=2';

test('first setup stores salted scrypt only and creates a revocable CSRF-bound session',t=>{
 const dir=temp(t),auth=createAuth(dir);assert.equal(auth.isSetup(),false);assert.equal(auth.get('parts_session=unknown'),null);
 assert.throws(()=>auth.login(password),status(409));assert.throws(()=>auth.setup('short'),status(400));assert.equal(fs.existsSync(auth.file),false);
 const session=auth.setup(password,'127.0.0.1');assert.equal(auth.isSetup(),true);assert.match(session.id,/^[a-f0-9]{64}$/);assert.match(session.csrfToken,/^[a-f0-9]{64}$/);assert.notEqual(session.id,session.csrfToken);
 const saved=fs.readFileSync(auth.file,'utf8'),credential=JSON.parse(saved);assert.equal(saved.includes(password),false);assert.match(credential.salt,/^[a-f0-9]{32}$/);assert.match(credential.hash,/^[a-f0-9]{128}$/);
 assert.deepEqual(auth.get(cookie(session)),session);assert.equal(auth.verifyCsrf(session,session.csrfToken),true);assert.equal(auth.verifyCsrf(session,'wrong'),false);assert.equal(auth.verifyCsrf(null,session.csrfToken),false);
 assert.throws(()=>auth.setup('another-password'),status(409));auth.logout(session.id);assert.equal(auth.get(cookie(session)),null);
});

test('restart retains password while expiring in-memory sessions; session lookup is defensive',t=>{
 const dir=temp(t),first=createAuth(dir),session=first.setup(password),second=createAuth(dir);
 assert.equal(second.isSetup(),true);assert.equal(second.get(cookie(session)),null);assert.throws(()=>second.login('wrong'),status(401));
 const next=second.login(password);assert.notEqual(next.id,session.id);const copy=second.get(cookie(next));copy.csrfToken='altered';assert.equal(second.get(cookie(next)).csrfToken,next.csrfToken);
});

test('sessions expire at the configured deadline and login failures are rate limited per IP',t=>{
 let time=1_700_000_000_000;const auth=createAuth(temp(t),{now:()=>time,ttl:1000});
 const session=auth.setup(password,'host');time+=999;assert.ok(auth.get(cookie(session)));time+=1;assert.equal(auth.get(cookie(session)),null);
 for(let i=0;i<5;i++)assert.throws(()=>auth.login('wrong','host'),status(401));
 assert.throws(()=>auth.login(password,'host'),status(429));assert.ok(auth.login(password,'other-host'));
 time+=15*60*1000+1;assert.ok(auth.login(password,'host'));
});

test('malformed or missing password never authenticates and corrupt credential file is not reset',t=>{
 const dir=temp(t),auth=createAuth(dir);auth.setup(password);
 for(const [index,value]of [null,undefined,{},'x'.repeat(1025)].entries())assert.throws(()=>auth.login(value,'host-'+index),status(401));
 fs.writeFileSync(auth.file,JSON.stringify({salt:'bad',hash:'bad'}));const before=fs.readFileSync(auth.file);
 assert.throws(()=>createAuth(dir),/인증 파일/);assert.deepEqual(fs.readFileSync(auth.file),before);
});
