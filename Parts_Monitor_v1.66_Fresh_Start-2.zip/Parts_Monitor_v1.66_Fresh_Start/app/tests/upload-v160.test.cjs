'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),os=require('node:os'),path=require('node:path');
const C=require('../src/core.js'),R=require('../src/reporting.js'),P=require('../src/pipeline.js'),Q=require('../src/weekly-policy.js'),U=require('../src/upload-panel.js'),B=require('../src/upload-board.js'),X=require('../vendor/xlsx.full.min.js');
const {createStore}=require('../server/store.cjs'),{createUpdateService}=require('../server/update-service.cjs');
const wips=date=>Q.required.map(s=>({type:'wip',center:s.center,operator:s.operator,date,file:s.key+'-'+date+'.xlsb',sheet:'WIP',rows:[],wipImportComplete:true}));
const inv=(date,qty=7)=>({type:'india',date,file:'unrelated-name.xlsx',sheet:'Stock',rows:[{part:'TEST-000001',qty,row:2}]});
function setup(t){const dataDir=fs.mkdtempSync(path.join(os.tmpdir(),'parts-v160-'));t.after(()=>fs.rmSync(dataDir,{force:true,recursive:true}));const store=createStore({dataDir,seedState:C.empty()}),service=createUpdateService({store});return {store,service,dataDir,run:(sources,date,choices={})=>service.update({operation:'import',baseRevision:store.status().revision,reportDate:date,sources,choices})};}
test('all four fresh WIP sources are mandatory; missing or excluded WIP cannot reuse a prior week',t=>{
 const {store,service,run}=setup(t);assert.throws(()=>run(wips('2026-10-05').slice(0,3),'2026-10-05'),/WIP 필수/);assert.equal(store.status().revision,0);
 run(wips('2026-10-05'),'2026-10-05');assert.throws(()=>run([inv('2026-10-12')],'2026-10-12'),/WIP 필수/);
 assert.throws(()=>run(wips('2026-10-12'),'2026-10-12',{'flex:wip:Jio':'exclude'}),/WIP 필수/);
 assert.throws(()=>run(wips('2026-10-12'),'2026-10-12',{'flex:wip:Jio':'keep'}),/WIP 필수/);
 assert.equal(store.status().reportCount,1);assert(!service.review({reportDate:'2026-10-12',sources:[]}).canRecordExisting);
});
test('same-week PO or stock correction keeps saved WIP; later missing stock is explicitly referenced',t=>{
 const {store,run,dataDir}=setup(t);run([...wips('2026-10-05'),inv('2026-10-05')],'2026-10-05');run([inv('2026-10-05',9)],'2026-10-05');
 run(wips('2026-10-12'),'2026-10-12');const reopened=createStore({dataDir}),state=reopened.read().state;
 assert.equal(store.status().reportCount,2);assert.equal(R.reportState(state,'2026-10-12').sources.find(s=>s.type==='india').rows[0].qty,9);
 const slot=U.buildModel({state,reportDate:'2026-10-12'}).slots.find(r=>r.key==='india');assert(slot.reference);assert.equal(slot.source.date,'2026-10-05');
 assert.equal(U.buildModel({state,reportDate:'2026-10-12'}).slots.find(r=>r.key==='hq').source,null);
});
test('future and older actual dates bind only to the explicitly selected week and retain original dates',t=>{
 const {store,run}=setup(t);run([...wips('2026-10-05'),inv('2026-10-05',7)],'2026-10-05');
 const future=wips('2026-10-19');future[0].rows=[{key:'A',part:'TEST-000001',tokens:C.partTokens('TEST-000001'),required:'TEST-000001',sn:'A',receipt:'2026-09-01',status:'Waiting for Component',age:48,row:2}];
 run([...future,inv('2026-09-28',11)],'2026-10-12');const state=store.read().state,prior=R.reportState(state,'2026-10-05'),current=R.reportState(state,'2026-10-12');
 assert.equal(prior.sources.find(s=>s.type==='india').rows[0].qty,7);assert.equal(current.sources.find(s=>s.type==='india').rows[0].qty,11);
 assert(current.sources.filter(s=>s.type==='wip').every(s=>s.date==='2026-10-19'&&s.assignedWeek==='2026-10-12'));
 assert.equal(current.sources.find(s=>s.type==='india').date,'2026-09-28');assert(P.validate(state).ok);assert.equal(C.calculate(current,'2026-10-12').wip[0].age,48);
});
test('last run can be undone without deleting archived originals, and cannot erase a later edit',t=>{
 const {store,service,run,dataDir}=setup(t),raw=store.addRaw({name:'archive.xlsx',bytes:Buffer.from('synthetic original')});
 service.update({operation:'import',baseRevision:0,reportDate:'2026-10-05',sources:wips('2026-10-05'),rawIds:[raw.id]});
 service.update({operation:'undoImport',baseRevision:1});assert.equal(store.status().reportCount,0);assert.equal(store.listRaw().length,1);
 assert.equal(createStore({dataDir}).status().reportCount,0);run(wips('2026-10-05'),'2026-10-05');
 service.update({operation:'notes',baseRevision:3,patch:{notes:{test:'retained'}}});assert.throws(()=>service.update({operation:'undoImport',baseRevision:4}),/다른 변경/);
 assert.equal(store.read().state.notes.test,'retained');
});
test('applied required WIP cannot be cancelled into a previous week while optional stock cancellation works',t=>{
 const {store,service,run}=setup(t);run([...wips('2026-10-05'),inv('2026-10-05')],'2026-10-05');run([...wips('2026-10-12'),inv('2026-10-12',12)],'2026-10-12');
 const state=store.read().state,s=R.reportState(state,'2026-10-12').sources;
 assert.throws(()=>service.update({operation:'remove',baseRevision:2,reportDate:'2026-10-12',sourceIds:[s.find(x=>x.type==='wip').id]}),/WIP 4종/);
 service.update({operation:'remove',baseRevision:2,reportDate:'2026-10-12',sourceIds:[s.find(x=>x.type==='india').id]});
 assert.equal(R.reportState(store.read().state,'2026-10-12').sources.find(x=>x.type==='india').date,'2026-10-05');
});
test('legacy commits also cannot add a WIP-free week',()=>{
 const state=C.empty(),next=R.applySources(state,[inv('2026-10-05')],'2026-10-05');assert.throws(()=>Q.guardLegacyCommit(state,next,'import'),/WIP 4종/);
 assert.doesNotThrow(()=>Q.guardLegacyCommit(state,next,'restore'));
});
test('11 fixed slots use explicit schema selection and do not infer source type from the filename',()=>{
 assert.equal(B.groups.flatMap(g=>g[1]).length,11);assert.equal(Q.required.length,4);
 const wb=X.utils.book_new();X.utils.book_append_sheet(wb,X.utils.aoa_to_sheet([['Material','Unr Stock'],['TEST-000001',7]]),'Stock');
 const result=C.importWorkbook(wb,'WIP CTDI 2026-10-05.xlsx',X,B.options('india'));assert.equal(result.sources.length,1);assert.equal(result.sources[0].type,'india');assert.equal(result.sources[0].rows[0].qty,7);
 assert.throws(()=>C.importWorkbook(wb,'WIP CTDI 2026-10-05.xlsx',X,B.options('ctdi:wip:Jio')));
 const html=B.render({queue:[{id:'1',file:{name:'strange<file>.xlsx'},slot:'',status:'new'}]});assert.equal((html.match(/data-slot-input=/g)||[]).length,11);assert.match(html,/strange&lt;file&gt;/);
});

test('fixed-slot weekly graphs retain known partial counts and disclose incomplete source evidence',t=>{
 const {store,run}=setup(t),W=wips('2026-10-05');W[0].wipImportComplete=false;W[0].duplicates=[{key:'dup'}];W[0].rows=[{key:'A',part:'TEST-000001',tokens:C.partTokens('TEST-000001'),required:'TEST-000001',sn:'A',receipt:'2026-08-01',status:'Waiting for Component',age:65,row:2}];
 const ds={type:'dashboard',center:W[0].center,date:'2026-10-05',file:'dashboard.xlsx',sheet:'Dashboard',holdDate:'2026-10-05',usageMonths:['2026-09'],rows:[{part:'TEST-000001',stock:0,po:0,hold:1,usage:{'2026-09':1},row:2}]};run([...W,ds],'2026-10-05');
 const S=require('../src/summary-data.js'),out=S.build(store.read().state),point=out.trend[0];assert.equal(point.available.wip,false);assert.equal(point.metricsByCenter['전체'].wip,1);assert(point.notes.some(n=>n.includes('부분합계')));assert.equal(point.metricsByCenter.CTDI.shortageKinds,null);
});
