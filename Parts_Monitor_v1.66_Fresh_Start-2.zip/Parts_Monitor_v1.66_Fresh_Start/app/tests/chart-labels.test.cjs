const test=require('node:test');
const assert=require('node:assert/strict');
const C=require('../src/chart-labels.js');
const defs=[{key:'shortageKinds',label:'부족',color:'#bd3e45'},{key:'orderKinds',label:'추가 PO',color:'#ab741c'},{key:'waitKinds',label:'입고 대기',color:'#356c8c'}];
function fixture(count=4,value=20){return {trend:Array.from({length:count},(_,i)=>({week:new Date(Date.UTC(2026,8,21+i*7)).toISOString().slice(0,10),availableByCenter:{전체:{wip:true},Flex:{wip:true},CTDI:{wip:true}},metricsByCenter:Object.fromEntries(['전체','Flex','CTDI'].map((c,j)=>[c,{shortageKinds:value,orderKinds:value,waitKinds:value,wip:value+1,over45:value,over45PartKinds:value,over45RequiredQty:j===0?value*2:value}])),sourceDates:[{type:'wip',center:'Flex',date:'2026-10-12'},{type:'wip',center:'CTDI',date:'2026-10-12'}]}))}}
function labels(html){return [...html.matchAll(/<g data-ov-data-label="([^"]*)" data-ov-week="([^"]*)" data-ov-value="([^"]*)" data-label-box="([^"]*)">([\s\S]*?)<\/g>/g)].map(m=>{const [x,y,width,height]=m[4].split(',').map(Number);return {series:m[1],week:m[2],value:Number(m[3]),box:{x,y,width,height},content:m[5]}})}
function checkGeometry(items){for(const [i,p] of items.entries()){const b=p.box;assert(b.x>=38&&b.x+b.width<=484,'left/right clipping');assert(b.y>=23&&b.y+b.height<=151,'unit/axis/legend collision');for(let j=0;j<i;j++)assert(!C.overlaps(b,items[j].box,1.9),'numeric labels overlap');}}
function render(data,center='ALL',language='ko'){return C.renderTrend(data,center,language,'ACTIONS','주간 부족·발주 추이',defs,'종')}

test('each series/week has a visible SVG numeric label, including every zero',()=>{
 for(const value of [0,1,24]){const d=fixture(12,value),html=render(d),items=labels(html);assert.equal(items.length,18);assert.equal((html.match(/data-ov-point=/g)||[]).length,18);for(const item of items){assert.equal(item.value,value);assert(item.content.includes('>'+value+'</text>'));assert(item.content.includes('font-size="14"'));assert(!item.content.includes('<title>'));}checkGeometry(items);}
});
test('near-equal and long values fit independently from the axis and legend',()=>{
 for(const value of [100,9999,99999,999999]){const d=fixture(12,value);d.trend.forEach((w,i)=>{w.metricsByCenter.전체.orderKinds+=i%2;w.metricsByCenter.전체.waitKinds+=i%3;});const items=labels(render(d));assert.equal(items.length,18);checkGeometry(items);}
});
test('labels remain plain numbers without leader lines or individual backgrounds',()=>{
 for(const h of [render(fixture(12,0)),C.renderCombo(fixture(12,10),'ALL','ko')]){assert(!h.includes('ov-chart-label-leaders'));for(const item of labels(h)){assert(!item.content.includes('<rect'));assert(!item.content.includes('<line'));assert(!item.content.includes('stroke='));}assert(h.includes('<rect width="100%" height="100%" fill="#fff"/>'),'established chart background remains unchanged');}
});
test('dense labels stay centered on their own points and within 48 SVG units',()=>{
 const points=Array.from({length:12},(_,i)=>Array.from({length:3},(_,j)=>({x:44+(434/12)*(i+.5),y:150,value:j,series:'S'+j,week:String(i)}))).flat(),items=C.layoutLabels(points);
 assert.equal(items.length,36);checkGeometry(items);
 items.forEach((item,i)=>{assert.equal(item.cx,points[i].x);assert(Math.abs(item.box.y+item.box.height/2-points[i].y)<=48);assert.equal(item.fontSize,14);});
});
test('the current four-week shapes keep labels near data points and above combo bars',()=>{
 const d=fixture(4),short=[26,27,42,47],order=[108,126,129,159],wait=[38,48,41,36],qty=[248,247,311,301],kinds=[20,19,24,28];
 d.trend.forEach((w,i)=>{Object.assign(w.metricsByCenter.전체,{shortageKinds:short[i],orderKinds:order[i],waitKinds:wait[i],over45RequiredQty:qty[i],over45PartKinds:kinds[i]});w.metricsByCenter.Flex.over45RequiredQty=20;w.metricsByCenter.CTDI.over45RequiredQty=qty[i]-20;});
 for(const mode of ['trend','combo']){const items=labels(mode==='trend'?render(d):C.renderCombo(d,'ALL','ko'));checkGeometry(items);for(const item of items){const i=d.trend.findIndex(w=>w.week===item.week),cx=44+(434/4)*(i+.5),max=mode==='trend'?159:item.series==='over45RequiredQty'?311:28,y=150-item.value/max*86;assert(Math.abs(item.box.x+item.box.width/2-cx)<.001,'label stays in same week column');assert(Math.abs(item.box.y+item.box.height/2-y)<=48,'label stays close to its point');assert(item.content.includes('font-size="14"'));if(mode==='combo')assert(item.box.y+item.box.height<=150-qty[i]/311*86-4,'numbers do not obscure the bars');}}
});
test('unavailable WIP breaks line segments and is not relabelled zero',()=>{
 const d=fixture(5,8);d.trend[2].availableByCenter.전체.wip=false;
 const h=C.renderTrend(d,'ALL','en','PRODUCTS','Waiting products',[{key:'wip',label:'Waiting',color:'#123456'}],'products');
 assert.equal(labels(h).length,4);assert.equal((h.match(/<polyline /g)||[]).length,2);assert(!labels(h).some(p=>p.week===d.trend[2].week));assert(h.includes('TREND_PRODUCTS'));
});
test('combo numbers include every visible total and every unique-kind line point',()=>{
 const d=fixture(12,10);for(const center of ['ALL','Flex','CTDI'])for(const language of ['ko','en']){const h=C.renderCombo(d,center,language),items=labels(h);assert.equal(items.length,12);assert.equal(items.filter(p=>p.series==='over45PartKinds').length,6);assert.equal(items.filter(p=>p.series==='over45RequiredQty').length,6);assert(items.filter(p=>p.series==='over45RequiredQty').every(p=>p.value===(center==='ALL'?20:10)));checkGeometry(items);assert(h.includes('data-ov-chart="OVERDUE"'));assert(h.includes('TREND_OVERDUE'));if(center!=='ALL')assert(!h.includes('data-ov-bar-center="'+(center==='Flex'?'CTDI':'Flex')+'"'));assert(!/NaN|undefined/.test(h));}
});
test('combo missing quantity or kinds remains a gap, never a numeric zero',()=>{
 const d=fixture();d.trend[1].availableByCenter.전체.wip=false;d.trend[1].availableByCenter.Flex.wip=false;
 const h=C.renderCombo(d,'ALL','ko');assert.equal(labels(h).length,6);assert(!labels(h).some(p=>p.week===d.trend[1].week));
});
test('only latest 6 calendar weeks render, with downloads and values retained',()=>{
 const d=fixture(16,8),before=JSON.stringify(d),h=render(d);assert.equal(labels(h).length,18);assert(!labels(h).some(p=>p.week===d.trend[0].week));assert(labels(h).some(p=>p.week===d.trend[15].week));assert(h.includes('TREND_ACTIONS'));assert(h.includes('ov-chart-values'));assert.equal(JSON.stringify(d),before);
});
test('empty trends are renderable in both charts and preserve accessibility labels',()=>{
 for(const h of [render({trend:[]}),C.renderCombo({trend:[]},'ALL','en')]){assert.equal(labels(h).length,0);assert(h.includes('role="img"'));assert(h.includes('aria-label='));assert(!/NaN|undefined/.test(h));}
});

test('calendar gaps are displayed without invented zeroes or prehistory, while stored reports stay untouched',()=>{
 const d=fixture(8,2);d.trend=d.trend.filter((_,i)=>[0,3,5,7].includes(i));const before=JSON.stringify(d),weeks=C.chartWeeks(d);
 assert.equal(weeks.length,6);assert.equal(weeks[0].week,'2026-10-05');assert.deepEqual(weeks.filter(w=>w.missingReport).map(w=>w.week),['2026-10-05','2026-10-19','2026-11-02']);
 const h=render(d);assert.equal(labels(h).length,9);assert(!h.includes('<polyline '));assert(h.includes('보고 없음'));assert(h.includes('산정 불가'));assert.equal(JSON.stringify(d),before);
 const short=fixture(2,0);assert.equal(C.chartWeeks(short).length,2);assert.equal(C.chartWeeks(short)[0].week,short.trend[0].week);
});
test('unavailable action inputs are gaps for that category and scope, genuine zero is preserved',()=>{
 const d=fixture(4,0);d.trend[1].availableByCenter.전체.actionAvailability={shortage:true,order:false,wait:false};
 const h=render(d),ls=labels(h);assert.equal(ls.length,10);assert.equal(ls.filter(p=>p.week===d.trend[1].week).length,1);assert.equal(ls.find(p=>p.week===d.trend[1].week).series,'shortageKinds');assert.equal(labels(render(d,'Flex')).length,12);
 assert.equal(C.trendValue(d.trend[1],'ALL','orderQty'),null);assert.equal(C.trendValue(d.trend[1],'ALL','shortageKinds'),0);
});
