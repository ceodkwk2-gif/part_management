'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm');
const Mail=require('../src/summary-mail.js'),Overdue=require('../src/overdue-mail.js');
function fixture(){
 const rows=['Flex','CTDI'].map(center=>({id:center+'|A',center,part:'A',name:'Fan',stock:1,india:2,hq:3,avg:.5,needed:4,shortage:3,poOrdered:10,open:15,proposed:2}));
 return {asof:'2026-10-12',rows,tasks:rows.map(r=>({id:r.id+'|SUPPLY',rowId:r.id,center:r.center,part:r.part,recipient:'INDIA',kind:'SUPPLY',textKo:'기존 PO 공급 일정 확인',textEn:'Check existing PO supply schedule'})),products:rows.map((r,i)=>({id:'P'+i,center:r.center,operator:'Jio',age:60,date:'2026-10-12',parts:[{part:'A',quantity:2,firstDate:'2026-09-28'}]})),pos:[{center:'Flex',part:'A',po:'CENTER-1',item:'10',poDate:'2026-10-01',ordered:10,shipped:2,pending:8,etd:'2026-10-16'}],sourceDates:[],issues:{po:[{center:'Flex',part:'A',open:15,detailPending:8,issues:['PO 잔량 불일치']}]},siel:{demo:true,rows:[{part:'A',po:'HQ-1',poDate:'2026-10-02',ordered:20,pending:null,eta:'2026-10-22',sourceDate:'2026-10-19',docs:[]}]}};
}
const records=model=>model.rows.map(values=>Object.fromEntries(model.columns.map((c,i)=>[c.key,values[i]])));
const first=(model)=>records(model)[0];
test('action and overdue mail preserve same-line PO quantities and distinguish dashboard mismatch in existing cells',()=>{
 const d=fixture(),before=JSON.stringify(d),action=Mail.buildActionTable({data:d,rowIds:['Flex|A']}),overdue=Overdue.build({data:d,rowIds:['Flex|A'],includeUnparsed:false});
 assert.equal(action.columns.length,12);assert.equal(overdue.columns.length,9);
 for(const value of [first(action).open,first(overdue).po]){
  assert(value.includes('대시보드 미입고 PO: 15개'));assert(value.includes('CENTER-1 / 항목 10 · 발주일 2026-10-01'));
  assert(value.includes('기발주 10개 / 법인 출고(Shipped) 2개 / Pending 8개'));
  assert(value.includes('ETD 2026-10-16'));assert(value.includes('수량 확인: 대시보드 미입고 15개 / 상세 Pending 8개'));
  assert(!value.includes('법인 출고(Shipped) 7개'));assert(!value.includes('센터 입고 2개'));
 }
 assert.equal(JSON.stringify(d),before);
});
test('shared HQ PO and planned India ETA repeat per center with unknown allocation and no invented pending quantity',()=>{
 const d=fixture(),notes={'Flex|A':{eta:'2026-10-25',plan:'Local confirmation'}};
 for(const model of [Mail.buildActionTable({data:d,notes}),Overdue.build({data:d,notes,includeUnparsed:false})]){
  for(const r of records(model)){const value=r.po||r.open;assert(value.includes('공용 법인 → 본사 PO · 센터 배정 미확인'));assert(value.includes('HQ-1 · 발주일 2026-10-02'));assert(value.includes('기발주 20개 / 실제 미입고 미확인'));assert(value.includes('법인 도착 예정(ETA) 2026-10-22'));assert(value.includes('데모 연결 자료 · 2026-10-19'));assert(!value.includes('실제 미입고 20개'));}
  assert.equal(first(model).eta,'2026-10-25');assert(model.notes.some(x=>x.includes('Shipped는 법인 출고량')));assert(model.notes.some(x=>x.includes('법인 도착 예정일')));
 }
});
test('zero open PO without details or shared orders stays concise while missing detail quantities remain unknown',()=>{
 const d=fixture();d.pos=[];d.siel.rows=[];d.issues.po=[];d.rows[0].open=0;
 assert.equal(first(Mail.buildActionTable({data:d,rowIds:['Flex|A']})).open,'미입고 PO 0개');
 assert.equal(first(Overdue.build({data:d,rowIds:['Flex|A']})).po,'미입고 PO 0개');
 d.rows[0].open=4;const text=first(Mail.buildActionTable({data:d,rowIds:['Flex|A']})).open;
 assert(text.includes('대시보드 미입고 PO: 4개'));assert(text.includes('상세 발주 내역 미확인'));assert(!text.includes('기발주 0'));assert(!text.includes('Shipped) 0'));
 d.rows[0].open=null;assert(first(Overdue.build({data:d,rowIds:['Flex|A']})).po.includes('대시보드 미입고 PO: 미확인'));
});
test('zero dispatch is retained but absent dispatch is not calculated from Ordered minus Pending',()=>{
 const d=fixture();d.siel.rows=[];d.pos[0].ordered=10;d.pos[0].pending=8;d.pos[0].shipped=null;
 let value=Mail.formatPoEvidence(d,d.rows[0]);assert(value.includes('법인 출고(Shipped) 미확인'));assert(!value.includes('법인 출고(Shipped) 2개'));
 d.pos[0].shipped=0;value=Mail.formatPoEvidence(d,d.rows[0]);assert(value.includes('법인 출고(Shipped) 0개'));
});
test('conflicting detail lines remain separate evidence with unconfirmed combined balance',()=>{
 const d=fixture();d.siel.rows=[];d.rows[0].poOrdered=null;d.pos.push({...d.pos[0],ordered:12,shipped:3,pending:9});d.issues.po[0]={center:'Flex',part:'A',detailPending:null,issues:['상세 PO 동일 식별키의 값 불일치']};
 const value=Mail.formatPoEvidence(d,d.rows[0]);assert(value.includes('기발주 10개 / 법인 출고(Shipped) 2개 / Pending 8개'));assert(value.includes('기발주 12개 / 법인 출고(Shipped) 3개 / Pending 9개'));assert(value.includes('상세 Pending 미확인'));assert(value.includes('동일 PO 식별키의 값 불일치 · 합산 잔량 미확인'));assert(!value.includes('기발주 22개'));assert(!value.includes('Shipped) 5개'));
});
test('known supplier pending and document evidence do not become confirmed India receipt',()=>{
 const d=fixture();d.siel.rows[0].pending=7;d.siel.rows[0].docs=[{delivery:'D1'}];
 const value=Mail.formatPoEvidence(d,d.rows[0]);assert(value.includes('기발주 20개 / 실제 미입고 7개'));assert(value.includes('공급 서류 1건 · 실제 법인 입고 미확인'));assert(!value.includes('법인 입고 완료'));
});
test('recipient and row filters remain unchanged and English distinguishes dispatch from receipt',()=>{
 const d=fixture();d.tasks.push({id:'CENTER',rowId:'Flex|A',recipient:'CENTER',kind:'ORDER',textEn:'Place additional PO'});
 for(const model of [Mail.buildActionTable({data:d,rowIds:['Flex|A'],recipient:'CENTER',language:'en'}),Overdue.build({data:d,rowIds:['Flex|A'],recipient:'CENTER',language:'en',includeUnparsed:false})]){
  assert.equal(model.rows.length,1);const r=first(model),value=r.open||r.po;assert(value.includes('India dispatch (Shipped) 2 pcs'));assert(value.includes('Actual open qty Unconfirmed'));assert(value.includes('Planned India arrival (ETA) 2026-10-22'));assert(value.includes('Center allocation unconfirmed'));assert(!JSON.stringify(model.rows).includes('CTDI'));assert(!/[가-힣]/.test(JSON.stringify(model.rows)));
 }
});
test('browser mail modules use the bundled dependency and exported source text stays escaped',()=>{
 const sandbox={};sandbox.self=sandbox;
 for(const file of ['summary-mail.js','overdue-mail.js'])vm.runInNewContext(fs.readFileSync(require.resolve('../src/'+file),'utf8'),sandbox);
 const d=fixture();d.pos[0].po='<script>unsafe</script>';const model=sandbox.PartsOverdueMail.build({data:d,rowIds:['Flex|A'],includeUnparsed:false}),html=sandbox.PartsExampleMail.toHtml(model);
 assert(html.includes('&lt;script&gt;unsafe&lt;/script&gt;'));assert(!html.includes('<script>unsafe</script>'));assert(first(model).po.includes('법인 출고(Shipped) 2개'));
});
