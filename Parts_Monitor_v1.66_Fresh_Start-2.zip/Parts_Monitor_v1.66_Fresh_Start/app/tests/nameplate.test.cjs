'use strict';
// Invented records. Generic plates are permanently excluded from material totals.
const test=require('node:test'),assert=require('node:assert/strict');
const C=require('../src/core.js'),R=require('../src/reporting.js'),T=require('../src/wip-tat.js');
const X=require('../vendor/xlsx.full.min.js');
const DATE='2024-08-12',MONTHS=['2024-02','2024-03','2024-04','2024-05','2024-06','2024-07'];
const CODED='TEST-000001',OTHER='TEST-000002';
function source(type,center,rows,extra={}){return {type,center,date:DATE,dateLabel:DATE,operator:'',file:`synthetic-${type}-${center}.xlsx`,sheet:'Synthetic',rows,...extra}}
function demand(required,index=1){return {key:`S${index}|R${index}`,sn:'S'+index,rma:'R'+index,row:index+1,status:'Waiting for Component',required,receipt:'2024-07-01',tokens:{parts:{},unparsed:required,assumed:false}}}
function fixture(){const state=C.empty();state.sources=[
 source('dashboard','Flex',[],{usageMonths:MONTHS,holdDate:null}),
 source('dashboard','CTDI',[
  {part:'NAME PLATE',rawPart:'Name Plate',description:'Generic plate',stock:2,po:0,row:4,usage:Object.fromEntries(MONTHS.map(m=>[m,3]))},
  {part:CODED,description:'NAME PLATE',stock:10,po:0,row:5,usage:Object.fromEntries(MONTHS.map(m=>[m,0]))}
 ],{usageMonths:MONTHS,holdDate:null}),
 source('wip','Flex',[demand('Serial# Plate Req')],{operator:'Jio',duplicates:[]}),
 source('wip','CTDI',[demand('HOLD FOR NAMEPLATE #5')],{operator:'Jio',duplicates:[]}),
 source('wip','CTDI',[],{operator:'Airtel',duplicates:[]}),
 source('wip','CTDI',[],{operator:'Vi',duplicates:[]}),
 source('po','Flex',[]),source('po','CTDI',[]),source('india','',[]),source('hq','',[])
 ];return state}


test('generic plates are explicitly excluded, preserving known quantity and source wording',()=>{
 for(const phrase of ['Name Plate','NAMEPLATE','Serial Plate','Serial# Plate Req','HOLD FOR NAMEPLATE','명판']){
  const t=C.partTokens(phrase);assert.deepEqual(t.parts,{});assert.equal(t.excludedNameplate,1);assert.equal(t.unparsed,'');
 }
 for(const [phrase,qty] of [['NAME PLATE#2',2],['Serial Plate x3',3],['Nameplate *4',4],['명판 (5)',5]]){
  const t=C.partTokens(phrase);assert.deepEqual(t.parts,{});assert.equal(t.excludedNameplate,qty);assert.equal(t.unparsed,'');
 }
});
test('a real material code survives description text; mixed requests exclude only the generic plate',()=>{
 assert.deepEqual(C.partTokens(`${CODED} NAME PLATE`).parts,{[CODED]:1});
 assert.deepEqual(C.partTokens(`NAMEPLATE ${CODED} #2`).parts,{[CODED]:2});
 const t=C.partTokens(`Nameplate #2 + ${CODED} #3`);assert.deepEqual(t.parts,{[CODED]:3});assert.equal(t.excludedNameplate,2);assert.equal(t.unparsed,'');
 const mixed=C.partTokens('HOLD FOR NAMEPLATE + TOP COVER');assert.deepEqual(mixed.parts,{});assert.equal(mixed.unparsed,'TOP COVER');
 for(const phrase of ['TOP COVER','RATING PLATE','BASEPLATE','OTHERNAMEPLATE','NAMEPLATEOTHER','Nameplate #0'])assert(C.partTokens(phrase).unparsed);
});
test('old cached tokens are excluded without modifying saved sources or unrelated parsing',()=>{
 const legacy=demand('Serial# Plate Req'),before=JSON.stringify(legacy);assert.deepEqual(C.resolvedPartTokens(legacy).parts,{});assert.equal(JSON.stringify(legacy),before);
 const cached={tokens:{parts:{'NAME PLATE':2,[CODED]:3},unparsed:''}},original=JSON.stringify(cached),t=C.resolvedPartTokens(cached);
 assert.deepEqual(t.parts,{[CODED]:3});assert.equal(t.excludedNameplate,2);assert.equal(JSON.stringify(cached),original);
 const custom={required:'CUSTOM UNRESOLVED',tokens:{parts:{[OTHER]:7},unparsed:'CUSTOM',custom:true}};assert.strictEqual(C.resolvedPartTokens(custom),custom.tokens);
});
test('all material and stock outputs exclude plates while WIP product count and TAT stay unchanged',()=>{
 const state=fixture(),before=JSON.stringify(state);state.sources.find(s=>s.type==='po'&&s.center==='Flex').rows=[{part:'NAME PLATE',po:'P',pending:1,row:2}];const raw=JSON.stringify(state);
 const result=C.calculate(state,DATE);assert(!result.parts.some(p=>C.isNameplate(p.part)));assert(!result.allParts.some(p=>C.isNameplate(p.part)));assert(!result.pos.some(p=>C.isNameplate(p.part)));assert(!result.masterAlerts.some(p=>C.isNameplate(p.part)));assert(!result.commonSupport.parts.some(p=>C.isNameplate(p.part)));
 assert.equal(result.parts.find(p=>p.part===CODED).stock,10);assert.equal(result.wip.length,2);assert.equal(JSON.stringify(state),raw);
 const t=T.evaluate(result.wip);assert.equal(t.summary.products,2);assert.equal(t.summary.overdueProducts,0);assert.equal(t.summary.quantity,0);assert.equal(t.summary.partKinds,0);assert.equal(t.summary.unresolvedPartProducts,0);
});
test('excluded-only demand is not an unknown part; mixed unknown text remains unknown',()=>{
 const state=fixture();state.sources.find(s=>s.type==='wip'&&s.center==='Flex').rows=[demand('NAMEPLATE + TOP COVER')];
 const t=T.evaluate(C.calculate(state,DATE).wip);assert.equal(t.summary.products,2);assert.equal(t.summary.unresolvedPartProducts,1);
});
test('new workbook preserves WIP products and raw text, excludes nameplate demand at import',()=>{
 const wb=X.utils.book_new();X.utils.book_append_sheet(wb,X.utils.aoa_to_sheet([
 ['Final Status','Required Part','Serial No','RMA No','Physical Receipt Date'],
 ['Waiting for Component','Serial# Plate Req','S1','R1','07/01/2024'],
 ['Waiting for Module',`Name Plate #2 + ${CODED} #3`,'S2','R2','07/01/2024']]),'Inhouse');
 const imported=C.importWorkbook(wb,'Synthetic_Flex_12082024.xlsx',X,{center:'Flex',type:'wip'}).sources.find(s=>s.type==='wip');
 assert.equal(imported.rows.length,2);assert.equal(imported.rows[0].required,'Serial# Plate Req');assert.equal(imported.rows[0].tokens.excludedNameplate,1);assert.deepEqual(imported.rows[1].tokens.parts,{[CODED]:3});
});
test('historical reports and trends apply the exclusion without rewriting archive identities',()=>{
 const H=require('../src/history.js');let state=R.normalizeState(fixture());const report=R.selectedReport(state),incoming=structuredClone(state.sources.find(s=>s.type==='wip'&&s.center==='Flex'));
 incoming.rows=[demand('Serial# Plate Req #2')];incoming.file='synthetic-corrected.xlsx';state=R.applySources(state,[incoming],'2024-08-19');const before=JSON.stringify(state),historical=R.reportState(state,report.id);
 for(const st of [historical,R.reportState(state)])assert(!C.calculate(st,'2024-08-19').parts.some(p=>C.isNameplate(p.part)));
 const trend=C.trend(historical,'Flex','전체');assert.equal(trend[0].count,1);assert.equal(trend[0].quantity,0);assert.equal(trend[0].unmapped,0);
 const h=H.snapshot(state,DATE);assert(h.centers.every(c=>!c.parts.some(p=>C.isNameplate(p.part))));assert.equal(JSON.stringify(state),before);
});
