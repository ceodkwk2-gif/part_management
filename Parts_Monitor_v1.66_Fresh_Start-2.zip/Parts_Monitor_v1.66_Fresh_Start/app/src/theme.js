(function(w){'use strict';function sync(){w.document.documentElement.dataset.theme='dark';}w.PartsTheme={sync,set:sync};sync();})(window);
