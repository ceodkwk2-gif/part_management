(function(root,factory){const api=factory(typeof module==='object'&&module.exports?require('../vendor/xlsx.full.min.js'):root.XLSX);if(typeof module==='object'&&module.exports)module.exports=api;else root.PartsPackage=api})(typeof self!=='undefined'?self:this,function(XLSX){
'use strict';
// The bundled CFB ZIP writer supports ASCII entry names. Contents use UTF-8,
// so Korean UI text and JSON survive without any filename/code-page guessing.
const SAFE_NAME=/^[A-Za-z0-9][A-Za-z0-9._-]{0,199}$/;
function createZip(files){
 if(!Array.isArray(files)||!files.length)throw Error('ZIP에 저장할 파일이 없습니다.');
 if(files.length>65535)throw Error('ZIP 파일 개수가 지원 범위를 초과했습니다.');
 const names=new Set(),entries=[];let uncompressedSize=22;
 for(const file of files){
  if(!file||typeof file.name!=='string'||!SAFE_NAME.test(file.name)||/[. ]$/.test(file.name))throw Error('ZIP 파일명은 경로 없는 영문·숫자·점·밑줄·하이픈만 사용할 수 있습니다.');
  const key=file.name.toLowerCase();
  if(names.has(key))throw Error('ZIP에 중복된 파일명이 있습니다: '+file.name);
  names.add(key);
  const bytes=typeof file.content==='string'?new TextEncoder().encode(file.content):file.content;
  if(!(bytes instanceof Uint8Array))throw Error('ZIP 파일 내용은 문자열 또는 Uint8Array여야 합니다: '+file.name);
  // CFB silently omits zero-byte entries. Refuse them explicitly so a failed
  // HTML/JSON generation can never look like a complete weekly backup.
  if(!bytes.length)throw Error('ZIP에 빈 파일을 저장할 수 없습니다: '+file.name);
  uncompressedSize+=bytes.length+76+file.name.length*2;
  if(uncompressedSize>=0xffffffff)throw Error('ZIP 데이터가 지원 범위인 4 GB를 초과했습니다.');
  entries.push({name:file.name,bytes});
 }
 const CFB=XLSX&&XLSX.CFB;
 if(!CFB||!CFB.utils||typeof CFB.write!=='function')throw Error('ZIP 저장 기능을 불러오지 못했습니다. 관리자 파일을 다시 열어 주세요.');
 const archive=CFB.utils.cfb_new();
 for(const entry of entries)CFB.utils.cfb_add(archive,entry.name,entry.bytes);
 const output=CFB.write(archive,{fileType:'zip',type:'buffer',compression:true});
 return output instanceof Uint8Array?output:Uint8Array.from(output);
}
return {createZip};
});
