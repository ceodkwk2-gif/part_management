(function(root,factory){const api=factory(typeof module==='object'&&module.exports?require('./summary-mail.js'):root.PartsExampleMail);if(typeof module==='object'&&module.exports)module.exports=api;else root.PartsOverdueMail=api;})(typeof self!=='undefined'?self:this,function(Mail){
'use strict';
const str=x=>x==null?'':String(x),uniq=a=>[...new Set(a.filter(x=>x!==''&&x!=null))],num=x=>typeof x==='number'&&Number.isFinite(x),english=x=>/^en/i.test(str(x));
const roles={ALL:['전체','All recipients'],CENTER:['수리센터','Repair center'],INDIA:['법인','India subsidiary'],HQ:['본사','HQ']};
const role=x=>Object.hasOwn(roles,x)?x:'ALL',label=(x,en)=>roles[role(x)][en?1:0];
const qty=(x,en)=>num(x)?String(x):en?'Unconfirmed':'미확인';
const choose=(x,key,en)=>str(x?.[key+(en?'En':'Ko')]);
const scoped=(x,center)=>center==='ALL'||x.center===center;
const identity=(p,i)=>str(p.id)||JSON.stringify([p.center,p.operator,p.sn,p.rma,p.receipt,i]);
const partLabel=(x,en)=>en&&x==='명판'?'Name plate':str(x);
function range(values,en){const a=values.filter(num);if(!a.length)return en?'Unconfirmed':'미확인';const min=Math.min(...a),max=Math.max(...a);return (min===max?String(min):min+'–'+max)+(en?' days':'일');}
function dates(values,en){const a=uniq(values.map(str)).sort();return a.length?a.join(', '):en?'Unconfirmed':'미확인';}
function collect(data,center){
 const members=new Map(),unknown=[];
 const metadata=new Map((data.overdue?.groups||[]).flatMap(group=>(group.centers||[]).map(member=>[str(member.rowId)||member.center+'|'+group.part,{...member,name:group.name}])));
 // Product records retain identity and observed age; never age carried WIP to
 // the report date or join each product to every same-part PO line.
 const seenProducts=new Set();
 for(const [i,p] of (data.products||[]).entries()){
  if(!scoped(p,center)||!num(p.age)||p.age<=45)continue;
  const pid=identity(p,i);if(seenProducts.has(pid))continue;seenProducts.add(pid);
  const byPart=new Map();
  for(const item of p.parts||[]){if(!str(item.part))continue;if(!byPart.has(item.part))byPart.set(item.part,[]);byPart.get(item.part).push(item);}
  for(const [part,items] of byPart){
   const key=str(p.center)+'|'+part;
   if(!members.has(key))members.set(key,{key,center:p.center,part,products:[],entries:[],metadata:metadata.get(key)});
   const group=members.get(key);group.products.push(p);group.entries.push(...items.map(item=>({...item,productSn:str(p.sn),productRma:str(p.rma)})));
  }
  if(p.hasUnresolvedParts||str(p.unparsed)||!byPart.size)unknown.push({p,pid});
 }
 return {members:[...members.values()],unknown};
}
function sourceContext(data,center,en){
 const sources=(Array.isArray(data.sourceDates)?data.sourceDates:[]).filter(s=>!s.center||scoped(s,center));
 const names={wip:'WIP',dashboard:en?'Center stock':'센터 재고',po:'PO',india:en?'India stock':'법인 재고',hq:en?'HQ stock':'본사 재고'};
 const wipIsReference=s=>{
  if(s.carriedForward)return true;
  const fresh=data.overdue?.freshByCenter?.[s.center];
  if(typeof fresh==='boolean')return !fresh;
  if(typeof data.overdue?.fresh==='boolean')return !data.overdue.fresh;
  return Boolean(s.date&&data.asof&&s.date<data.asof);
 };
 const lines=[];
 for(const type of ['wip','dashboard','po','india','hq']){
  const list=sources.filter(s=>s.type===type),keys=new Map();
  for(const s of list){const key=[s.center,s.date,s.carriedForward?'reference':''].join('|');if(!keys.has(key))keys.set(key,s);}
  if(keys.size)lines.push(names[type]+': '+[...keys.values()].map(s=>(s.center?s.center+' ':'')+(str(s.date)||(s.reportWeek?s.reportWeek+(en?' week':'주'):(en?'Unconfirmed':'미확인')))+((s.carriedForward||type==='wip'&&wipIsReference(s))?(en?' (reference)':' (참고)'):'')).join(' · '));
 }
 const carried=sources.some(s=>s.type==='wip'&&wipIsReference(s));
 return [(en?'Report date: ':'보고 기준일: ')+(str(data.asof)||(en?'Unconfirmed':'미확인')),...lines,...(carried?[en?'WIP has not been updated to the report date. Counts and TAT are observations at the WIP source date; continued waiting is unconfirmed.':'WIP가 보고 기준일까지 갱신되지 않았습니다. 대수·TAT는 WIP 원본일 기준이며 현재도 대기 중인지는 미확인입니다.']:[])].join('\n');
}
function relatedPos(data,group,row,en){
 return Mail.formatPoEvidence(data,row||{center:group.center,part:group.part,open:null},en);
}
function taskText(tasks,en){
 const uniqueTasks=new Map();for(const t of tasks){const key=str(t.id)||JSON.stringify(t);if(!uniqueTasks.has(key))uniqueTasks.set(key,t);}
 return uniq([...uniqueTasks.values()].map(t=>label(t.recipient,en)+': '+(choose(t,'text',en)||(en?'Action detail unconfirmed':'조치 상세 미확인'))+(choose(t,'schedule',en)?' · '+choose(t,'schedule',en):''))).join('\n');
}
function supplierText(data,group,en){
 const refs=new Set(group.entries.flatMap(e=>e.supplierRecordIds||[])),productIds=new Set(group.products.map(p=>p.id));
 const records=(data.supplierEvidence||[]).filter(e=>refs.has(e.id)||e.productId&&productIds.has(e.productId)&&e.part===group.part);
 return records.filter(e=>e.recordedNeedDate||e.recordedOrderDate||e.delayReason||e.delayCause).map(e=>{
  const facts=[];
  if(e.recordedNeedDate)facts.push((en?'need confirmed ':'필요확인일 ')+str(e.recordedNeedDate));
  if(e.recordedOrderDate)facts.push((en?'order date ':'발주일 ')+str(e.recordedOrderDate));
  if(e.delayReason)facts.push((en?'reason: ':'사유: ')+str(e.delayReason));
  if(e.delayCause)facts.push((en?'cause: ':'원인 기재: ')+str(e.delayCause));
  const source=[e.source,e.sheet,e.row!=null?'row '+e.row:'',e.date].filter(Boolean).join(' / ');
  return (en?'Supplier recorded (liability unconfirmed)':'업체 기재 (귀책 미확정)')+(e.historical?(en?' · prior record':' · 과거 기록'):'')+'\n'+(e.sn?'SN '+str(e.sn)+' · ':'')+facts.join(' · ')+(source?'\n'+source:'')+(e.dateIssue?'\n'+(en?'Recorded date requires verification':'기재 날짜 확인 필요'):'');
 }).join('\n\n');
}
function manualFields(manual,en){
 return {eta:str(manual?.eta).trim()||(en?'Unconfirmed':'미확인'),plan:[str(manual?.plan).trim()||(en?'Not provided':'미입력'),...Mail.confirmedProgress(manual||{},en?'en':'ko')].join('\n')};
}
function firstConfirmation(entries,en){
 const manual=entries.filter(e=>e.manualFirstConfirmedDate),automatic=entries.filter(e=>!e.manualFirstConfirmedDate),lines=[];
 if(automatic.length)lines.push((manual.length?(en?'WIP observation: ':'WIP 관찰: '):'')+dates(automatic.map(x=>x.firstDate||x.firstWeek),en)+(automatic.some(x=>x.baseline)?'\n'+(en?'Waiting since before first observation; actual onset unknown':'최초 부품대기 확인일 이전부터 대기 · 실제 발생일 미확인'):''));
 for(const e of manual){
  const applied=/^manual$/i.test(str(e.firstConfirmedSource));
  lines.push([(e.productSn?'SN '+e.productSn:'')+(e.productRma?' / RMA '+e.productRma:''),(applied?(en?'Manual confirmation: ':'수기 확인: '):(en?'Manual date (review needed): ':'수기 입력일 (검토 필요): '))+e.manualFirstConfirmedDate,(en?'WIP first observation: ':'WIP 최초 관찰: ')+(str(e.autoFirstDate)||(en?'Unconfirmed':'미확인')),...(!applied?[(en?'Applied date: ':'적용 날짜: ')+(str(e.firstDate)||(en?'Unconfirmed':'미확인'))]:[]),...(e.manualFirstConfirmedNote?[(en?'Evidence: ':'근거: ')+str(e.manualFirstConfirmedNote)]:[]),...(e.firstConfirmedConflict?[en?'Manual date conflicts with WIP evidence · review needed':'수기 입력과 WIP 관찰 근거 불일치 · 확인 필요']:[])].filter(Boolean).join('\n'));
 }
 return uniq(lines).join('\n\n')||(en?'Unconfirmed':'미확인');
}
function build({data={},center='ALL',recipient='ALL',language='ko',notes={},rowIds,includeUnparsed=true}={}){
 const en=english(language),target=role(recipient),scope=['Flex','CTDI'].includes(center)?center:'ALL';
 const {members,unknown}=collect(data,scope),rowMap=new Map((data.rows||[]).map(r=>[str(r.id)||r.center+'|'+r.part,r]));
 const columns=[
  {key:'part',label:en?'Part / center':'부품 / 센터'},
  {key:'products',label:en?'Products >45 days / TAT':'45일 초과 제품 / TAT'},
  {key:'first',label:en?'First confirmed / observed date':'최초 부품대기 확인일'},
  {key:'inventory',label:en?'Stock · Center / India / HQ':'재고 · 센터 / 법인 / 본사'},
  {key:'po',label:en?'Related PO records':'관련 PO 기록'},
  {key:'need',label:en?'Part requirement / shortage':'필요 수 / 부족 수'},
  {key:'action',label:en?'Action owner / next action':'조치 담당 / 필요 조치'},
  {key:'eta',label:en?'Expected center receipt':'센터 입고 예정'},
  {key:'plan',label:en?'Confirmed plan':'확인한 대책'},
 ];
 const records=[],allowed=Array.isArray(rowIds)?new Set(rowIds):null;
 for(const group of members){
  if(allowed&&!allowed.has(group.key))continue;
  const row=rowMap.get(group.key),allTasks=(data.tasks||[]).filter(t=>(t.rowId===group.key||!t.rowId&&t.center===group.center&&t.part===group.part)&&['CENTER','INDIA','HQ'].includes(t.recipient));
  const tasks=allTasks.filter(t=>target==='ALL'||t.recipient===target);
  if(target!=='ALL'&&!tasks.length)continue;
  const operators=new Map();for(const p of group.products){const op=str(p.operator)||(en?'Operator unconfirmed':'사업자 미확인');operators.set(op,(operators.get(op)||0)+1);}
  const requirements=group.entries.map(x=>x.quantity),confirmedQty=requirements.every(num)?requirements.reduce((s,x)=>s+x,0):null;
  const manual=manualFields(notes[group.key],en),name=partLabel(row?.name||group.metadata?.name,en),first=firstConfirmation(group.entries,en);
  const record={
   part:partLabel(group.part,en)+(name&&name!==partLabel(group.part,en)?'\n'+name:'')+'\n'+group.center,
   products:group.products.length+(en?' products':'대')+' · TAT '+range(group.products.map(p=>p.age),en)+'\n'+[...operators].map(([op,n])=>op+' '+n+(en?' products':'대')).join(' · '),
   first,
   inventory:(en?'Center ':'센터 ')+qty(row?.stock,en)+' · '+(en?'India ':'법인 ')+qty(row?.india,en)+' · '+(en?'HQ ':'본사 ')+qty(row?.hq,en),
   po:relatedPos(data,group,row,en),
   need:(en?'>45-day requirement: ':'45일 초과분 필요: ')+qty(confirmedQty,en)+(en?' pcs':'개')+'\n'+(en?'All repair need: ':'전체 현 수리 필요: ')+qty(row?.needed,en)+' / '+(en?'shortage: ':'현재 부족: ')+qty(row?.shortage,en)+'\n'+(en?'Additional PO needed: ':'추가 PO 필요: ')+qty(row?.proposed,en),
   action:[taskText(tasks,en)||(en?'No automatic action classification':'자동 조치 분류 없음'),supplierText(data,group,en)].filter(Boolean).join('\n\n'),
   ...manual,
  };
  records.push(record);
 }
 // Unresolved Required Part text is retained per product, separate from known
 // part groups. A product may have both known and unresolved requirements.
 if(includeUnparsed&&(target==='ALL'||target==='CENTER'))for(const {p,pid} of unknown){
  const manual=manualFields(notes[pid],en);
  records.push({part:(en?'Part identification needed':'필요 부품 확인 필요')+'\n'+p.center+' · '+str(p.operator)+'\nSN '+(str(p.sn)||(en?'unconfirmed':'미확인'))+' / RMA '+(str(p.rma)||(en?'unconfirmed':'미확인')),
   products:(en?'1 product':'1대')+' · TAT '+range([p.age],en),first:en?'Unconfirmed':'미확인',inventory:en?'Cannot match before part identification':'부품 확인 전 재고 연결 불가',
   po:en?'Cannot match before part identification':'부품 확인 전 PO 연결 불가',need:(en?'Required Part text: ':'Required Part 원문: ')+(str(p.unparsed)||str(p.required)||(en?'Blank':'공란'))+'\n'+(en?'Part quantity unconfirmed':'부품 수량 미확인'),
   action:label('CENTER',en)+': '+(en?'Confirm the actual part code and quantity, or correct the waiting reason if it is not a material requirement.':'실제 부품코드·수량 확인. 자재가 아닌 작업명이면 대기 사유 정정.'),...manual});
 }
 return {
  subject:(en?'Follow-up: parts waiting over 45 days':'45일 초과 자재대기 확인 요청')+' · '+label(target,en)+' · '+(str(data.asof)||(en?'Date unconfirmed':'기준일 미확인')),
  recipientLabel:label(target,en),context:sourceContext(data,scope,en),columns,rows:records.map(r=>columns.map(c=>r[c.key])),
  notes:en?[
   'TAT is measured from Physical Receipt Date at the WIP source date. Over 45 means 46+ days. First observed WIP is not the date the part was first needed; weekly snapshots only bound observation. Manually confirmed dates are labelled separately and retain automatic WIP evidence.',
   'POs are related by center and part, not allocated to individual products. Do not add PO quantities per product or total shared India/HQ stock across centers. A product requiring several parts can appear in several rows.',
   'Shipped is India dispatch, not center receipt. ETD is planned India→center dispatch; shared HQ PO ETA is planned India arrival, not actual arrival or center receipt. Expected center receipt and confirmed plans are manual entries. Action owners are follow-up contacts, not findings of liability.',
  ]:[
   'TAT는 Physical Receipt Date부터 WIP 원본일까지이며 45일 초과는 46일 이상입니다. WIP 최초 관찰은 실제 부품 필요확인일이 아니며 주간 자료로 확인한 시점입니다. 수기 확인일은 별도로 표시하고 WIP 자동 관찰 근거도 보존합니다.',
   'PO는 센터·부품 기준 관련 기록이며 제품별 배정 내역이 아닙니다. 제품마다 PO 수량을 더하거나 센터 간 공용 법인·본사 재고를 합산하지 마세요. 여러 부품이 필요한 제품은 여러 행에 표시될 수 있습니다.',
   'Shipped는 법인 출고량이며 센터 입고량이 아닙니다. ETD는 법인→센터 예정 출고일, 공용 본사 PO의 ETA는 법인 도착 예정일이며 실제 입고·센터 입고일이 아닙니다. 센터 입고 예정·확인한 대책은 직접 기록한 값입니다. 조치 담당은 후속 확인할 조직이며 지연 귀책 판정이 아닙니다.',
  ],
 };
}
return {build};
});
