(function(root,factory){
 if(typeof module==='object'&&module.exports)module.exports=factory(require('./core.js'),require('./reporting.js'),require('./wip-tat.js'));
 else root.PartsFirstConfirmed=factory(root.PartsCore,root.PartsReporting,root.PartsWipTat);
})(typeof self!=='undefined'?self:this,function(C,R,T){
'use strict';
// User-confirmed first observation dates are separate evidence. They never
// mutate source WIP dates, receipt-based TAT, quantities, or automatic history.
const text=value=>String(value??'').trim(),norm=value=>text(value).toUpperCase();
const own=(value,key)=>Object.prototype.hasOwnProperty.call(value||{},key);
function identityKey(row,part){
 const center=norm(row?.center),operator=norm(C.canonicalOperator(row?.center,row?.operator,'wip'));
 let sn=norm(row?.sn),rma=norm(row?.rma);
 if(!sn&&!rma&&typeof row?.key==='string'&&row.key.includes('|')){const split=row.key.indexOf('|');sn=norm(row.key.slice(0,split));rma=norm(row.key.slice(split+1));}
 const code=C.materialCode(part||row?.part);
 if(!center||!operator||(!sn&&!rma)||!code)return null;
 return JSON.stringify([JSON.stringify([JSON.stringify([center,operator]),'identity',sn,rma]),code]);
}
function validMap(map){
 if(map==null)return true;
 if(typeof map!=='object'||Array.isArray(map))return false;
 return Object.entries(map).every(([key,value])=>key.length<=2500&&value&&typeof value==='object'&&!Array.isArray(value)&&R.validDate(value.date)&&typeof (value.note??'')==='string'&&(value.note||'').length<=2000&&typeof (value.updatedAt??'')==='string');
}
function canEdit(entry){return !!entry&&identityKey(entry,entry.part)===entry.key&&R.validDate(entry.receipt)&&R.validDate(entry.date)&&entry.receipt<=entry.date;}
function validateChange(entry,change){
 if(!entry||!canEdit(entry))throw new Error('제품·부품 식별정보와 실제 입고일·WIP 기준일을 확인하세요.');
 if(!R.validDate(change?.date))throw new Error('최초 부품대기 확인일은 YYYY-MM-DD 형식으로 입력하세요.');
 if(change.date<entry.receipt)throw new Error('최초 부품대기 확인일은 제품 입고일보다 빠를 수 없습니다.');
 if(change.date>entry.date)throw new Error('최초 부품대기 확인일은 현재 WIP 기준일보다 늦을 수 없습니다.');
 if(change.note!=null&&(typeof change.note!=='string'||change.note.length>2000))throw new Error('확인 근거는 2,000자 이내로 입력하세요.');
 return {date:change.date,note:text(change.note)};
}
function decorate(entry,map={}){
 const saved=own(map,entry.key)?map[entry.key]:null,manualDate=R.validDate(saved?.date)?saved.date:null,issues=[];
 let usable=!!manualDate&&canEdit(entry);
 if(saved&&!manualDate){issues.push('INVALID_MANUAL_DATE');usable=false;}
 if(manualDate&&!canEdit(entry)){issues.push('IDENTITY_OR_DATES_UNCONFIRMED');usable=false;}
 if(manualDate&&R.validDate(entry.receipt)&&manualDate<entry.receipt){issues.push('BEFORE_RECEIPT');usable=false;}
 if(manualDate&&R.validDate(entry.date)&&manualDate>entry.date){issues.push('AFTER_WIP_DATE');usable=false;}
 // A recorded exit separates repair episodes even with the same serial/RMA.
 // Keep an old manual record visible but never move a new episode before it.
 if(manualDate&&R.validDate(entry.priorObservedWithoutDate)&&manualDate<=entry.priorObservedWithoutDate){issues.push('BEFORE_CONFIRMED_EPISODE_BOUNDARY');usable=false;}
 if(usable&&R.validDate(entry.firstSeenDate)&&manualDate>entry.firstSeenDate)issues.push('EARLIER_AUTOMATIC_OBSERVATION');
 const effective=usable?manualDate:entry.firstSeenDate||null;
 return {...entry,manualEditable:canEdit(entry),manualFirstConfirmedDate:manualDate,manualFirstConfirmedNote:text(saved?.note),manualFirstConfirmedUpdatedAt:text(saved?.updatedAt)||null,
  effectiveFirstSeenDate:effective,effectiveFirstSeenAgeDays:R.validDate(entry.receipt)&&R.validDate(effective)?T.ageAt(entry.receipt,effective).age:null,
  firstConfirmedSource:usable?'manual':'automatic',firstConfirmedConflict:issues.length>0,firstConfirmedIssues:issues};
}
function apply(trace,map={}){
 const entries=(trace.entries||[]).map(entry=>decorate(entry,map));
 return {...trace,entries,byKey:Object.fromEntries(entries.map(entry=>[entry.key,entry]))};
}
return {identityKey,validMap,canEdit,validateChange,decorate,apply};
});
