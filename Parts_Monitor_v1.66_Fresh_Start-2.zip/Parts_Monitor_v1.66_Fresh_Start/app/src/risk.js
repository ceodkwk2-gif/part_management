(function(root,factory){
 if(typeof module==='object'&&module.exports)module.exports=factory(require('./core.js'));
 else root.PartsRisk=factory(root.PartsCore);
})(typeof self!=='undefined'?self:this,function(Core){
'use strict';
const DAY=86400000;
const normPart=value=>String(value??'').trim().toUpperCase();
const known=value=>typeof value==='number'&&Number.isFinite(value);
const GROUPS=[
 {code:'CURRENT_SHORTAGE',label:'현재 수리부품 부족',description:'현 수리 필요 수이 센터 현재 재고보다 큽니다. 기존 PO는 현재 재고로 계산하지 않습니다.'},
 {code:'TARGET_GAP',label:'센터 보유 기준 미달',description:'현재 대기 필요량을 반영한 남은 재고이 설정된 센터 보유 기준에 미달합니다.'},
 {code:'NO_UPSTREAM_STOCK',label:'법인·본사 현재 재고 없음',description:'센터 현재 재고 대응이 필요한 부품의 법인·본사 재고가 모두 0입니다. 장납 확정을 의미하지 않습니다.'},
 {code:'HQ_ROUTE',label:'본사 경유 공급 확인',description:'센터 현재 재고 대응이 필요하고 법인 재고는 0, 본사 재고는 양수입니다. 실제 공급·배정 가능성을 확인합니다.'},
 {code:'PO_SCHEDULE',label:'기존 PO 입고 일정 확인',description:'센터 현재 재고 대응이 필요한 부품에 기존 PO가 있습니다. 추가 발주량이 0이어도 공급 일정 확인이 필요합니다.'},
 {code:'ETD_BEFORE_REPORT',label:'원본 보고일 이전 ETD',description:'미입고 잔량이 있는 상세 PO의 ETD가 해당 PO 원본 보고일보다 이전입니다. 실제 출고·입고 지연으로 확정하지 않습니다.'},
];
function latest(state,type,center,asof){
 return (state.sources||[]).filter(s=>s.type===type&&(center==null||s.center===center)&&(!s.date||s.date<=asof))
  .sort((a,b)=>(a.date||'').localeCompare(b.date||'')).at(-1)||null;
}
function elapsed(from,to){
 if(!from||!to)return null;
 const days=(Date.parse(to+'T00:00:00Z')-Date.parse(from+'T00:00:00Z'))/DAY;
 return Number.isFinite(days)?Math.floor(days):null;
}
function poEvidence(row){
 const etdStatus=!row.etd?'unknown':!row.date?'report-date-unknown':row.etd<row.date?'before-report':row.etd===row.date?'on-report':'after-report';
 return {po:row.po||'',item:row.item||'',pending:row.pending??null,ordered:row.ordered??null,shipped:row.shipped??null,
  poDate:row.poDate||null,reportDate:row.date||null,etd:row.etd||null,etdRaw:row.etdRaw||'',etdStatus,
  ageAtReport:elapsed(row.poDate,row.date),reportedAge:row.age??null,source:row.source||null,sheet:row.sheet||null,row:row.row??null};
}
function usageEvidence(source,selected,part){
 const months=[...(part.usageMonths||[])];
 const latestMonth=months.at(-1)||null,latestQty=latestMonth?(selected?.usage?.[latestMonth]??null):null;
 const previousMonths=months.slice(0,-1),previousValues=previousMonths.map(m=>selected?.usage?.[m]);
 const previousAvg=previousMonths.length&&previousValues.every(known)?previousValues.reduce((a,b)=>a+b,0)/previousValues.length:null;
 const change=known(latestQty)&&known(previousAvg)?latestQty-previousAvg:null;
 return {months,latestMonth,latestQty,previousMonths,previousAvg,change,changeRatio:change!=null&&previousAvg>0?change/previousAvg:null,
  source:source?.file||null,sheet:source?.sheet||null,row:selected?.row??null,note:'사용량 비교 통계입니다. 증가율 경보기준은 적용하지 않았습니다.'};
}
function evaluate(state,asof,center='전체',operator='전체'){
 const calculated=Core.calculate(state,asof,center,operator);
 const indiaSource=latest(state,'india',null,asof),hqSource=latest(state,'hq',null,asof);
 const dashboards=new Map(),dashboardRows=new Map(),poSources=new Map(),poGroups=new Map();
 for(const name of new Set(calculated.parts.map(part=>part.center))){
  const source=latest(state,'dashboard',name,asof);dashboards.set(name,source);
  dashboardRows.set(name,new Map(Core.selectDashboardRows(source).map(row=>[normPart(row.part),row])));
  poSources.set(name,latest(state,'po',name,asof));
 }
 for(const row of calculated.pos){const key=row.center+'|'+normPart(row.part);if(!poGroups.has(key))poGroups.set(key,[]);poGroups.get(key).push(row)}
 const allRows=calculated.parts.map(part=>{
  const pos=poGroups.get(part.center+'|'+part.part)||[];
  const poRows=pos.filter(p=>known(p.pending)&&p.pending>0).map(poEvidence);
  const poUnknownPendingRows=pos.filter(p=>!known(p.pending)).map(poEvidence);
  const physicalAfterWaiting=known(part.stock)&&known(part.needed)?part.stock-part.needed:null;
  const targetGap=known(physicalAfterWaiting)&&known(part.target)?Math.max(0,part.target-physicalAfterWaiting):null;
  const currentShortage=known(part.shortage)&&part.shortage>0;
  const targetBelow=targetGap!=null&&targetGap>0;
  const needsPhysicalSupply=currentShortage||targetBelow;
  const hasOpenPO=(known(part.open)&&part.open>0)||poRows.length>0;
  const noUpstream=needsPhysicalSupply&&part.india===0&&part.hq===0;
  const hqRoute=needsPhysicalSupply&&part.india===0&&known(part.hq)&&part.hq>0;
  const poSchedule=needsPhysicalSupply&&hasOpenPO;
  const etdBeforeReport=poRows.some(p=>p.etdStatus==='before-report');
  const reasonCodes=[],messages=[];
  const add=(condition,code,message)=>{if(condition){reasonCodes.push(code);messages.push(message)}};
  add(currentShortage,'CURRENT_SHORTAGE',part.shortageBasis==='wip-waiting'?`WIP 자재대기 ${part.shortage}개 · 센터 재고 ${part.stock??'미확인'}개와 대기 상태 확인`:`현 수리 필요 수 ${part.needed}개 대비 센터 현재 재고 ${part.stock}개로 ${part.shortage}개 부족`);
  add(targetBelow,'TARGET_GAP',`대기 반영 남은 재고 ${physicalAfterWaiting}개 / 보유 기준 ${part.target}개 — 현재 재고 기준 차이 ${targetGap}개`);
  add(noUpstream,'NO_UPSTREAM_STOCK','법인·본사 재고 모두 0 — 기존 조달 진행 여부와 확보 가능성 확인');
  add(hqRoute,'HQ_ROUTE','법인 재고 0, 본사 재고 있음 — 본사 경유 공급·배정 가능성 확인');
  if(poSchedule){
   const missing=poRows.length===0,unknown=poRows.filter(p=>p.etdStatus==='unknown').length;
   add(true,'PO_SCHEDULE','기존 PO 있음 — 센터 입고 일정 확인'+(missing?' (상세 미입고 PO 미매칭)':unknown?` (ETD 미정 ${unknown}행)`:' (ETD는 센터 입고예정일이 아님)'));
  }
  add(etdBeforeReport,'ETD_BEFORE_REPORT',`미입고 잔량이 있는 PO 중 원본 보고일 이전 ETD ${poRows.filter(p=>p.etdStatus==='before-report').length}행 — 일정·진행상태 갱신 확인`);
  let nextAction='현재 자료 기준 모니터링';
  const actions=[];
  if(noUpstream)actions.push('법인·본사의 기존 조달 진행 여부와 확보 가능성 확인');
  else if(hqRoute)actions.push('본사 재고의 공급·배정 가능성 및 센터까지 공급 일정 확인');
  else if(needsPhysicalSupply&&known(part.india)&&part.india>0)actions.push('법인 재고의 공급·배정 가능성 확인');
  else if(needsPhysicalSupply&&(part.india==null||part.hq==null))actions.push('법인·본사 재고 자료 확인');
  if(poSchedule)actions.push('기존 PO의 실제 센터 입고 일정 확인');
  if(etdBeforeReport)actions.push('원본 보고일 이전 ETD의 현재 진행상태 확인');
  if(known(part.proposed)&&part.proposed>0)actions.push(`기존 기준에 따른 추가 PO ${part.proposed}개 검토`);
  else if(needsPhysicalSupply&&!hasOpenPO&&part.proposed==null)actions.push('사용량·필요량·PO 잔량을 보완해 발주량 검토');
  if(actions.length)nextAction=actions.join(' / ');
  const dates={dashboard:part.dashboardDate||null,need:part.needDate||null,india:indiaSource?.date||null,hq:hqSource?.date||null,po:poSources.get(part.center)?.date||null};
  const evidence={physicalAfterWaiting,availableAfterWaiting:physicalAfterWaiting==null?null:Math.max(0,physicalAfterWaiting),targetGap,
   usage:usageEvidence(dashboards.get(part.center),dashboardRows.get(part.center)?.get(part.part),part),poRows,poUnknownPendingRows,poDetailsMissing:hasOpenPO&&poRows.length===0,
   dates,stockAssumedZero:!!part.stockAssumedZero,selectedSourceRow:part.selectedSourceRow??null,
   allocationConfirmed:false,arrivalPredictionAvailable:false,
   notes:['법인·본사 현재 재고은 공용재고이며 해당 센터 배정·공급이 확정된 수량이 아닙니다.','ETD는 법인→센터 예정 출고일이며 센터 ETA로 변환하지 않습니다.','PO 경과일은 원본 보고일 기준의 사실값이며 임의 지연 임계값을 적용하지 않습니다.']};
  return {...part,reasonCodes,messages,nextAction,evidence,level:currentShortage?'urgent':reasonCodes.length?'review':'normal'};
 });
 const rows=allRows.filter(row=>row.reasonCodes.length).sort((a,b)=>(b.shortage>0)-(a.shortage>0)||(b.shortage||0)-(a.shortage||0)||b.reasonCodes.length-a.reasonCodes.length||a.center.localeCompare(b.center)||a.part.localeCompare(b.part));
 const groups=GROUPS.map(group=>{const matching=rows.filter(row=>row.reasonCodes.includes(group.code));return {...group,count:matching.length,partCount:new Set(matching.map(p=>p.part)).size,rows:matching}});
 const count=code=>groups.find(g=>g.code===code).count;
 return {rows,allRows,groups,counts:{rows:rows.length,parts:new Set(rows.map(p=>p.part)).size,currentShortage:count('CURRENT_SHORTAGE'),targetGap:count('TARGET_GAP'),noUpstreamStock:count('NO_UPSTREAM_STOCK'),hqRoute:count('HQ_ROUTE'),poSchedule:count('PO_SCHEDULE'),etdBeforeReport:count('ETD_BEFORE_REPORT')},
  asof,center,operator,scopeNote:operator==='전체'?'센터 현재 재고·필요량 기준입니다.':'선택 사업자 관련 부품을 표시하며, 재고·필요량·위험 판단은 센터 전체 기준입니다. 사업자별로 공용재고를 배분하지 않습니다.',
  warnings:[...calculated.warnings,'여러 위험 조건에 동시에 해당할 수 있으므로 그룹별 종수를 합산하면 중복됩니다.','장납 여부·L/T 기반 경보·입고일 예측·귀책은 현재 자료로 자동 판단하지 않습니다.']};
}
return {evaluate,GROUPS};
});
