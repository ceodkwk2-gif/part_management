(function(root,factory){
 if(typeof module==='object'&&module.exports)module.exports=factory(require('./overview.js'),require('./summary-downloads.js'),require('./summary-mail.js'),require('./share-dialog.js'),require('./part-trace.js'));
 else root.PartsReportExport=factory(root.PartsOverview,root.PartsSummaryDownloads,root.PartsExampleMail,root.PartsShareDialog,root.PartsPartTrace);
})(typeof self!=='undefined'?self:this,function(O,D,M,S,Trace){
'use strict';
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const labels={WAIT_TRACE:['전체 대기 · 제품별 PO 이력','All waiting · Product PO history'],OVERDUE_TRACE:['45일 초과 · 제품별 PO 이력','Over 45 days · Product PO history'],SUMMARY:['금주 요약','Current summary'],OVERDUE:['45일 초과 · 부품별 조치','Over 45 days · Parts and actions'],OVERDUE_PRODUCTS:['45일 초과 · 제품 목록','Over 45 days · Products'],TREND_OVERDUE:['45일 초과 · 주간 추이','Over 45 days · Weekly trend'],AGING:['45일 초과 · TAT 분포','Over 45 days · TAT distribution'],TREND_ACTIONS:['자재 조치 · 주간 추이','Material actions · Weekly trend'],TREND_PRODUCTS:['자재대기 제품 · 주간 추이','Waiting products · Weekly trend'],SHORTAGE:['현재 수리분 부족','Current repair shortage'],ORDER:['추가 PO 필요','Additional PO needed'],WAIT:['PO 입고 대기','Awaiting PO'],PARTS:['전체 부품 · 재고·수요·PO','All parts · Stock, need and PO'],WAITING_PRODUCTS:['전체 자재대기 제품','All products waiting for parts']};
const chartIds={TREND_OVERDUE:'OVERDUE',TREND_ACTIONS:'ACTIONS',TREND_PRODUCTS:'PRODUCTS',AGING:'AGING'};
const lang=l=>l==='en'?'en':'ko',label=(type,l)=>labels[type]?.[lang(l)==='en'?1:0]||type;
const centerName=(center,l)=>center==='ALL'?(lang(l)==='en'?'All centers':'전체'):center;
function model(type,options={}){
 const {data={},center='ALL',language='ko',notes={}}=options;
 if(type==='WAIT_TRACE'||type==='OVERDUE_TRACE')return Trace.buildTable({...options,overdueOnly:type==='OVERDUE_TRACE'});
 if(['SHORTAGE','ORDER','WAIT'].includes(type)){
  const rowIds=O.exportRowIds(data,{center,kind:type}),m=M.buildActionTable({data,rowIds,recipient:'ALL',language,notes});
  return {...m,id:type,title:label(type,language),localized:true,reportDate:data.asof,context:[...(Array.isArray(m.context)?m.context:m.context?[m.context]:[]),(lang(language)==='en'?'Center: ':'센터: ')+centerName(center,language)],notes:m.notes||[]};
 }
 return D.buildTable(type,options);
}
function models(options={}){return Object.keys(labels).map(type=>model(type,options))}
function normalized(type,options){return S.normalize(model(type,options),{language:options.language,reportDate:options.data.asof})}
function allWorkbook(options,XLSX){return S.workbook(Object.keys(labels).map(type=>normalized(type,options)),XLSX)}
function chartSVG(type,{data,center='ALL',language='ko'}){
 const id=chartIds[type];if(!id)throw Error('No chart for this table.');
 const chart=[...O.render({data,center,language}).matchAll(/<svg\b[^>]*>[\s\S]*?<\/svg>/g)].map(m=>m[0]).find(s=>new RegExp('data-ov-chart=["\']'+id+'["\']').test(s));
 if(!chart)throw Error('Chart unavailable.');
 const box=chart.match(/viewBox=["']([^"']+)["']/i)?.[1]?.trim().split(/\s+/).map(Number),width=box?.[2]||640,height=box?.[3]||240;
 const content=chart.replace(/^<svg[^>]*>/,'').replace(/<\/svg>$/,'');
 const title=label(type,language)+' · '+centerName(center,language)+' · '+(data.asof||''),note=lang(language)==='en'?'Parts quantities are required quantities, not additional purchase quantities.':'필요 부품 수량이며 추가 구매 수량을 뜻하지 않습니다.';
 return '<svg xmlns="http://www.w3.org/2000/svg" width="'+width+'" height="'+(height+64)+'" viewBox="0 0 '+width+' '+(height+64)+'" role="img" aria-label="'+esc(title)+'"><rect width="100%" height="100%" fill="#ffffff"/><text x="12" y="22" font-family="Arial,Malgun Gothic,sans-serif" font-size="12" font-weight="700" fill="#20364b">'+esc(title)+'</text><g transform="translate(0,34)">'+content+'</g>'+(type==='TREND_OVERDUE'?'<text x="12" y="'+(height+54)+'" font-family="Arial,Malgun Gothic,sans-serif" font-size="9" fill="#607386">'+esc(note)+'</text>':'')+'</svg>';
}
async function png(svg){
 const url=URL.createObjectURL(new Blob([svg],{type:'image/svg+xml;charset=utf-8'}));
 try{return await new Promise((resolve,reject)=>{const image=new Image();image.onload=()=>{try{const canvas=document.createElement('canvas'),scale=2;canvas.width=image.naturalWidth*scale;canvas.height=image.naturalHeight*scale;const ctx=canvas.getContext('2d');if(!ctx)throw Error('Canvas unavailable');ctx.scale(scale,scale);ctx.drawImage(image,0,0);canvas.toBlob(blob=>blob?resolve(blob):reject(Error('PNG conversion failed')),'image/png')}catch(e){reject(e)}};image.onerror=()=>reject(Error('SVG rendering failed'));image.src=url})}finally{URL.revokeObjectURL(url)}
}
function summaryHTML({data,center='ALL',language='ko',notes={}}){
 const title=label('SUMMARY',language)+' · '+centerName(center,language)+' · '+data.asof;
 const holder=document.createElement('div');holder.innerHTML=O.render({data,center,language,notes,exportAll:true});
 for(const el of holder.querySelectorAll('[data-ov-export],.ov-focus-heading > button,.ov-trends-heading > button,.ov-summary-actions,.ov-chart-actions,.ov-peek-more'))el.remove();
 for(const button of holder.querySelectorAll('button')){const span=document.createElement('span');span.className=button.className;span.innerHTML=button.innerHTML;button.replaceWith(span)}
 const css=[...document.querySelectorAll('style')].map(s=>s.textContent).join('\n');
 return '<!doctype html><html lang="'+lang(language)+'"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>'+esc(title)+'</title><style>'+css+'\nbody{margin:0;padding:20px;background:#fff;font-family:Arial,"Malgun Gothic",sans-serif;color:#20364b}main{max-width:1240px;margin:auto}.ov-card{display:block}.ov-link{pointer-events:none}h1{font-size:20px;margin:0 0 16px}@media print{body{padding:0}.ov-root{break-inside:auto}}</style></head><body><main><h1>'+esc(title)+'</h1>'+holder.innerHTML+'</main></body></html>';
}
function open({type='SUMMARY',data,center='ALL',language='ko',notes={},download,XLSX}={}){
 const types=Object.keys(labels),base={data,center,notes},filename=(kind,l,ext)=>S.fileName(center+'_'+kind,l,data.asof,ext);
 return S.open({defaultLanguage:language,defaultTable:type,reportDate:data.asof,filePrefix:center,download,XLSX,
  tables:types.map(kind=>({id:kind,label:l=>label(kind,l),recipients:false,build:({language:l})=>model(kind,{...base,language:l}),extraActions:chartIds[kind]?[{id:'chart-png',label:l=>l==='en'?'Chart PNG':'그래프 PNG',run:async({language:l})=>download(filename(kind,l,'png'),await png(chartSVG(kind,{...base,language:l})),'image/png')},{id:'chart-svg',label:l=>l==='en'?'Chart SVG':'그래프 SVG',run:({language:l})=>download(filename(kind,l,'svg'),chartSVG(kind,{...base,language:l}),'image/svg+xml;charset=utf-8')}]:kind==='SUMMARY'?[{id:'summary-html',label:l=>l==='en'?'Summary report HTML':'요약 보고서 HTML',run:({language:l})=>download(filename('Summary_Report',l,'html'),summaryHTML({...base,language:l}),'text/html;charset=utf-8')}]:[]})),
  extraActions:[{id:'all-xlsx',label:l=>l==='en'?'All tables in Excel':'전체 표 Excel',run:({language:l})=>download(filename('All_Tables',l,'xlsx'),allWorkbook({...base,language:l},XLSX||globalThis.XLSX),'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')}]
 });
}
return {open,model,models,allWorkbook,chartSVG,summaryHTML,labels};
});
