(function(root,factory){
 if(typeof module==='object'&&module.exports)module.exports=factory();
 else root.PartsShareDialog=factory();
})(typeof self!=='undefined'?self:this,function(){
'use strict';
// Export is presentation-only: builders own scope and calculation semantics.
// No mail is sent and neither the application language nor source data is edited.
const WORDS={
 title:['표 내보내기','Export table'],close:['닫기','Close'],table:['표','Table'],
 language:['내보낼 언어','Export language'],recipient:['확인 대상','Contact'],
 all:['전체','All'],CENTER:['수리센터','Repair center'],INDIA:['법인','India'],HQ:['본사','HQ'],
 xlsx:['Excel 다운로드','Download Excel'],csv:['CSV 다운로드','Download CSV'],copy:['표 복사','Copy table'],html:['표 HTML 저장','Save table HTML'],detailed:['상세 CSV','Detailed CSV'],
 reportDate:['보고 기준일','Report date'],scope:['선택 범위','Selected scope'],
 notes:['참고','Notes'],empty:['선택한 범위에 내보낼 항목이 없습니다.','No items to export in this selection.'],
 help:['현재 선택한 범위의 전체 행을 내보냅니다. 표 복사 후 메일이나 문서에 붙여넣을 수 있습니다.','Exports all rows in the current selection. Copy the table and paste it into an email or document.'],
 copied:['전체 표를 복사했습니다. 메일이나 문서에 붙여넣으세요.','Full table copied. Paste it into your email or document.'],
 copyBlocked:['자동 복사가 차단됐습니다. 아래 전체 내용을 Ctrl+C 또는 ⌘C로 복사하거나 표 HTML을 저장하세요.','Automatic copying was blocked. Copy the full text below with Ctrl+C or ⌘C, or save the table HTML.'],
 fullText:['전체 표 텍스트','Full table text'],error:['표를 만들지 못했습니다. 창을 닫고 다시 선택해 주세요.','Could not build the table. Close this window and select again.'],
 saveError:['파일을 저장하지 못했습니다. 다시 시도해 주세요.','Could not save the file. Try again.'],
 saveStarted:['파일 다운로드를 시작했습니다.','File download started.']
};
const text=(key,language)=>WORDS[key]?.[language==='en'?1:0]||key;
const esc=value=>String(value==null?'':value).replace(/[&<>"']/g,ch=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
const cellHTML=value=>esc(value).replace(/\r\n|\r|\n/g,'<br>');
const languageOf=value=>value==='en'?'en':'ko';
function translate(value,language,translator){
 if(typeof value!=='string')return value;
 return translator&&typeof translator.text==='function'?translator.text(value,language):value;
}
function safeCell(value){
 if(value==null)return '';
 if(typeof value==='number')return Number.isFinite(value)?String(value):'';
 const output=String(value);
 // Spreadsheet imports may trim leading whitespace before evaluating formulas.
 return /^[\s\uFEFF]*[=+@-]/u.test(output)||/^[\t\r\n]/u.test(output)?"'"+output:output;
}
function csvCell(value){const output=safeCell(value);return '"'+output.replace(/"/g,'""')+'"'}
function tsvCell(value){return safeCell(value).replace(/\t/g,' ').replace(/\r\n|\r|\n/g,' / ')}
function normalize(model={},options={}){
 const language=languageOf(options.language),translator=options.translator;
 const columns=(model.columns||model.headers||[]).map((column,index)=>typeof column==='string'?{key:index,label:column}:{...column,label:column.label??column.key??index});
 const rows=(model.rows||[]).map(row=>columns.map((column,index)=>{
  const value=Array.isArray(row)?row[index]:row[column.key];
  if(value==null)return '';
  return model.localized||column.raw?value:translate(value,language,translator);
 }));
 const strings=(values)=>values.filter(value=>value!=null&&value!=='').map(value=>{
  if(typeof value==='object')return [translate(value.label||'',language,translator),value.raw?String(value.value??''):translate(String(value.value??''),language,translator)].filter(Boolean).join(': ');
  return translate(String(value),language,translator);
 });
 return {
  ...model,language,
  title:translate(model.title||options.title||text('title',language),language,translator),
  columns:columns.map(column=>({...column,label:translate(String(column.label),language,translator)})),rows,
  reportDate:String(options.reportDate??model.reportDate??''),
  context:strings([...(options.context||[]),...(model.context||[])]),
  notes:strings([...(options.notes||[]),...(model.notes||[])]),
  recipient:options.recipient||'all'
 };
}
function scope(model){return [...model.context,model.recipient&&model.recipient!=='all'?text('recipient',model.language)+': '+text(model.recipient,model.language):''].filter(Boolean).join(' · ')}
function csv(model){
 const headers=model.columns.map(column=>column.label).concat(model.compact?[]:[text('reportDate',model.language),text('scope',model.language),text('notes',model.language)]);
 const values=model.rows.map(row=>row.concat(model.compact?[]:[model.reportDate,scope(model),model.notes.join('\n')]));
 return '\uFEFF'+[headers,...values].map(row=>row.map(csvCell).join(',')).join('\r\n');
}
function tsv(model){
 const lines=[[model.title]];
 if(model.reportDate)lines.push([text('reportDate',model.language),model.reportDate]);
 if(scope(model))lines.push([text('scope',model.language),scope(model)]);
 for(const note of model.notes)lines.push([text('notes',model.language),note]);
 lines.push([],model.columns.map(column=>column.label),...model.rows);
 return lines.map(row=>row.map(tsvCell).join('\t')).join('\r\n');
}
function tableHTML(model,limit){
 const rows=Number.isInteger(limit)?model.rows.slice(0,limit):model.rows;
 return '<table style="border-collapse:collapse;font-family:Arial,sans-serif;font-size:12px"><thead><tr>'+model.columns.map(column=>'<th scope="col" style="border:1px solid #cbd5e1;padding:7px 9px;background:#edf2f7;text-align:left;vertical-align:top">'+cellHTML(column.label)+'</th>').join('')+'</tr></thead><tbody>'+rows.map(row=>'<tr>'+row.map(value=>'<td style="border:1px solid #d8e0e8;padding:7px 9px;text-align:left;vertical-align:top">'+cellHTML(value)+'</td>').join('')+'</tr>').join('')+'</tbody></table>';
}
function html(model,{standalone=false}={}){
 const content='<section lang="'+model.language+'" style="font-family:Arial,sans-serif;color:#20364b"><h2 style="font-size:18px;margin:0 0 10px">'+esc(model.title)+'</h2>'+(model.reportDate?'<p style="font-size:12px;margin:4px 0">'+esc(text('reportDate',model.language))+': '+esc(model.reportDate)+'</p>':'')+(scope(model)?'<p style="font-size:12px;margin:4px 0 12px">'+esc(text('scope',model.language))+': '+esc(scope(model))+'</p>':'')+tableHTML(model)+(model.notes.length?'<div style="font-size:11px;margin-top:12px">'+model.notes.map(note=>'<p style="margin:5px 0">'+cellHTML(note)+'</p>').join('')+'</div>':'')+'</section>';
 return standalone?'<!doctype html><html lang="'+model.language+'"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>'+esc(model.title)+'</title></head><body style="margin:24px">'+content+'</body></html>':content;
}
function fileName(tableId,language,reportDate,extension){if(String(tableId).startsWith('STATUS_')){const org=({ALL:language==='en'?'All':'전체',INDIA:language==='en'?'India':'법인',HQ:language==='en'?'HQ':'본사'})[tableId.slice(7)]||tableId.slice(7);return org+(language==='en'?'_Parts_Status_':'_자재현황_')+reportDate+'.'+extension;}return 'Parts_'+String(tableId||'Table').replace(/[^a-z0-9_-]/gi,'_')+'_'+language+(reportDate?'_'+String(reportDate).replace(/[^0-9-]/g,''):'')+'.'+extension}
// SheetJS provides cell serialization; its bundled ZIP support adds an actual
// Excel table, a frozen header and explicit reply-column styling offline.
function requestWorkbook(models,XLSX){
 const wb=XLSX.utils.book_new(),xml=esc,info=[],encode=new TextEncoder(),decode=new TextDecoder();
 models.forEach((model,index)=>{
  const sheet=XLSX.utils.aoa_to_sheet([model.columns.map(c=>c.label),...model.rows]);
  sheet['!cols']=model.columns.map(c=>({wch:c.width||(c.reply?22:/evidence|근거|유의|날짜|Source dates|기준일/.test(c.label)?42:/name|부품명|action|조치/i.test(c.label)?30:20)}));
  sheet['!rows']=[{hpt:42},...model.rows.map(row=>({hpt:Math.min(409,Math.max(36,...row.map((value,i)=>String(value??'').split('\n').reduce((lines,line)=>lines+Math.max(1,Math.ceil([...line].reduce((n,c)=>n+(c.charCodeAt(0)>255?2:1),0)/Math.max(8,sheet['!cols'][i].wch-2))),0)*14+8)))}))];
  const name=(model.sheetName||'Status').slice(0,26)+(index?' '+(index+1):'');XLSX.utils.book_append_sheet(wb,sheet,name);
  info.push([model.title,model.reportDate,...model.context],...model.notes.map(note=>[note]),[]);
 });
 const guide=XLSX.utils.aoa_to_sheet(info);guide['!cols']=[{wch:100},{wch:25},{wch:35}];if(models.some(m=>m.includeGuide!==false))XLSX.utils.book_append_sheet(wb,guide,'Read me');
 const zip=XLSX.CFB.read(new Uint8Array(XLSX.write(wb,{bookType:'xlsx',type:'array',compression:true})),{type:'array'});
 const read=name=>decode.decode(XLSX.CFB.find(zip,'/'+name).content),write=(name,value)=>XLSX.CFB.utils.cfb_add(zip,'/'+name,encode.encode(value));
 const styles='<?xml version="1.0" encoding="UTF-8" standalone="yes"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><fonts count="2"><font><sz val="11"/><name val="Calibri"/></font><font><b/><color rgb="FFFFFFFF"/><sz val="11"/><name val="Calibri"/></font></fonts><fills count="4"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FF24465F"/><bgColor indexed="64"/></patternFill></fill><fill><patternFill patternType="solid"><fgColor rgb="FFE8F3FF"/><bgColor indexed="64"/></patternFill></fill></fills><borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="4"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/><xf numFmtId="0" fontId="1" fillId="2" borderId="0" xfId="0" applyAlignment="1"><alignment vertical="center" wrapText="1"/></xf><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0" applyAlignment="1"><alignment vertical="top" wrapText="1"/></xf><xf numFmtId="0" fontId="0" fillId="3" borderId="0" xfId="0" applyAlignment="1"><alignment vertical="top" wrapText="1"/></xf></cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles><tableStyles count="0" defaultTableStyle="TableStyleMedium2" defaultPivotStyle="PivotStyleLight16"/></styleSheet>';
 write('xl/styles.xml',styles);let types=read('[Content_Types].xml');
 models.forEach((model,index)=>{
  const id=index+1,path='xl/worksheets/sheet'+id+'.xml',range='A1:'+XLSX.utils.encode_cell({r:model.rows.length,c:model.columns.length-1});let sheet=read(path);
  sheet=sheet.replace(/<sheetViews>[\s\S]*?<\/sheetViews>/,'<sheetViews><sheetView workbookViewId="0" showGridLines="0"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/><selection pane="bottomLeft" activeCell="A2" sqref="A2"/></sheetView></sheetViews>');
  sheet=sheet.replace(/<c\b([^>]*\br="([A-Z]+)(\d+)"[^>]*)>/g,(_,attrs,col,row)=>'<c'+attrs.replace(/\s+s="[^"]*"/g,'')+' s="'+(row==='1'?1:model.columns[XLSX.utils.decode_col(col)]?.reply?3:2)+'">');
  const statusColumn=model.columns.findIndex(c=>c.key==='replyStatus');if(statusColumn>=0&&model.rows.length){const col=XLSX.utils.encode_col(statusColumn),values=model.language==='en'?'Open,In progress,Replied,Completed,Needs review':'접수,진행 중,회신 완료,조치 완료,확인 필요';sheet=sheet.replace('</worksheet>','<dataValidations count="1"><dataValidation type="list" allowBlank="1" showErrorMessage="1" sqref="'+col+'2:'+col+(model.rows.length+1)+'"><formula1>&quot;'+values+'&quot;</formula1></dataValidation></dataValidations></worksheet>');}
  sheet=sheet.replace('</worksheet>','<tableParts count="1"><tablePart r:id="rIdTable"/></tableParts></worksheet>');write(path,sheet);
  write('xl/worksheets/_rels/sheet'+id+'.xml.rels','<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rIdTable" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/table" Target="../tables/table'+id+'.xml"/></Relationships>');
  write('xl/tables/table'+id+'.xml','<?xml version="1.0" encoding="UTF-8"?><table xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" id="'+id+'" name="PartsStatus'+id+'" displayName="PartsStatus'+id+'" ref="'+range+'" totalsRowShown="0"><autoFilter ref="'+range+'"/><tableColumns count="'+model.columns.length+'">'+model.columns.map((c,i)=>'<tableColumn id="'+(i+1)+'" name="'+xml(c.label)+'"/>').join('')+'</tableColumns><tableStyleInfo name="TableStyleMedium2" showFirstColumn="0" showLastColumn="0" showRowStripes="1" showColumnStripes="0"/></table>');
  types=types.replace('</Types>','<Override PartName="/xl/tables/table'+id+'.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.table+xml"/></Types>');
 });
 write('[Content_Types].xml',types);return XLSX.CFB.write(zip,{type:'array',fileType:'zip',compression:true});
}
function workbook(models,XLSX){
 if(!XLSX?.utils?.aoa_to_sheet||!XLSX?.write)throw Error('Excel export is unavailable.');
 if(models.length&&models.every(model=>model.tableFormat))return requestWorkbook(models,XLSX);
 const wb=XLSX.utils.book_new(),used=new Set();
 for(const [index,model] of models.entries()){
  let base=String(model.sheetName||model.title||('Table '+(index+1))).replace(/[\\/?*\[\]:]/g,' ').slice(0,31)||'Table',name=base,suffix=1;
  while(used.has(name)){const end=' '+(++suffix);name=base.slice(0,31-end.length)+end}used.add(name);
  const aoa=[[model.title],[text('reportDate',model.language),model.reportDate],[text('scope',model.language),scope(model)],...model.notes.map(note=>[text('notes',model.language),note]),[],model.columns.map(c=>c.label),...model.rows];
  const sheet=XLSX.utils.aoa_to_sheet(aoa);sheet['!cols']=model.columns.map((c,i)=>({wch:Math.min(48,Math.max(13,String(c.label).length*1.5,...model.rows.slice(0,80).map(r=>Math.min(48,String(r[i]??'').length))))}));
  XLSX.utils.book_append_sheet(wb,sheet,name);
 }
 return XLSX.write(wb,{bookType:'xlsx',type:'array',compression:true});
}
let activeClose=null;
function open(options={}){
 if(typeof document==='undefined')throw new Error('A browser document is required to open the export dialog.');
 if(activeClose)activeClose();
 const tables=(options.tables||[]).filter(table=>table&&typeof table.build==='function');
 if(!tables.length)throw new Error('At least one export table is required.');
 const previousFocus=document.activeElement,oldOverflow=document.body.style.overflow;
 let selected=tables.find(table=>table.id===options.defaultTable)||tables[0];
 let language=languageOf(options.defaultLanguage),recipient=['all','CENTER','INDIA','HQ'].includes(options.defaultRecipient)?options.defaultRecipient:'all';
 const scopeChoices=options.scopeChoices||[];let selectionScope=options.defaultScope||scopeChoices[0]?.id||'current';
 let current=null,disposed=false,buildError=false;
 const overlay=document.createElement('div');overlay.className='parts-share-overlay';overlay.setAttribute('data-i18n-skip','');
 document.body.appendChild(overlay);document.body.style.overflow='hidden';
 function close(){if(disposed)return;disposed=true;overlay.remove();document.body.style.overflow=oldOverflow;document.removeEventListener('keydown',keyDown,true);if(previousFocus&&previousFocus.isConnected&&previousFocus.focus)previousFocus.focus();if(activeClose===close)activeClose=null;if(typeof options.onClose==='function')options.onClose()}
 activeClose=close;
 function status(value,isError=false){const output=overlay.querySelector('.parts-share-status');if(output){output.textContent=value;output.classList.toggle('is-error',isError)}}
 function refresh(focusId){
  const canChooseRecipient=Boolean(selected.recipients||selected.allowRecipient);
  try{current=normalize(selected.build({recipient:canChooseRecipient?recipient:'all',language,selectionScope}),{language,translator:options.translator,title:selected.label,context:options.context,notes:options.notes,reportDate:options.reportDate,recipient:canChooseRecipient?recipient:'all'});buildError=false}
  catch(_){current=normalize({rows:[],columns:[]},{language});buildError=true}
  const count=current.rows.length,preview=Math.min(count,20),xlsx=options.XLSX||(typeof globalThis!=='undefined'?globalThis.XLSX:null);
  const extraActions=[...(options.extraActions||[]),...(selected.extraActions||[])].filter(a=>a&&typeof a.run==='function');
  const hasDetailed=(typeof selected.downloadDetailed==='function'||typeof options.downloadDetailed==='function')&&(!selected.detailedWhen||selected.detailedWhen({recipient:current.recipient,language}));
  const metrics=[];
  if(Number.isFinite(current.partCount))metrics.push(language==='en'?current.partCount.toLocaleString('en-US')+' part types':'부품 '+current.partCount.toLocaleString('ko-KR')+'종');
  if(Number.isFinite(current.productCount))metrics.push(language==='en'?current.productCount.toLocaleString('en-US')+' products':'제품 '+current.productCount.toLocaleString('ko-KR')+'대');
  if(Number.isFinite(current.taskCount))metrics.push(language==='en'?current.taskCount.toLocaleString('en-US')+' actions':'조치 '+current.taskCount.toLocaleString('ko-KR')+'건');
  metrics.push(language==='en'?count.toLocaleString('en-US')+' rows total':'전체 '+count.toLocaleString('ko-KR')+'행');
  overlay.innerHTML='<section class="parts-share-dialog" role="dialog" aria-modal="true" aria-labelledby="parts-share-title" aria-describedby="parts-share-help" lang="'+language+'"><header class="parts-share-header"><div><h2 id="parts-share-title">'+esc(text('title',language))+'</h2><p id="parts-share-help">'+esc(options.simple?(language==='en'?'Choose a target, scope and language, then download CSV or Excel.':'대상·범위·언어를 선택한 뒤 CSV 또는 Excel을 내려받습니다.'):text('help',language))+'</p></div><button type="button" class="parts-share-close" aria-label="'+esc(text('close',language))+'">×</button></header><div class="parts-share-content"><div class="parts-share-controls">'+(tables.length>1?'<label>'+esc(options.tableLabel?.[language==='en'?1:0]||text('table',language))+'<select id="parts-share-table">'+tables.map(table=>'<option value="'+esc(table.id)+'"'+(table===selected?' selected':'')+'>'+esc(translate(typeof table.label==='function'?table.label(language):table.label||table.id,language,options.translator))+'</option>').join('')+'</select></label>':'')+(scopeChoices.length?'<label>'+esc(language==='en'?'Scope':'범위')+'<select id="parts-share-selection-scope">'+scopeChoices.map(x=>'<option value="'+esc(x.id)+'"'+(selectionScope===x.id?' selected':'')+'>'+esc(x.label[language==='en'?1:0])+'</option>').join('')+'</select></label>':'')+'<label>'+esc(text('language',language))+'<select id="parts-share-language"><option value="ko"'+(language==='ko'?' selected':'')+'>한국어</option><option value="en"'+(language==='en'?' selected':'')+'>English</option></select></label>'+(canChooseRecipient?'<label>'+esc(text('recipient',language))+'<select id="parts-share-recipient">'+['all','CENTER','INDIA','HQ'].map(value=>'<option value="'+value+'"'+(recipient===value?' selected':'')+'>'+esc(text(value,language))+'</option>').join('')+'</select></label>':'')+'</div><div class="parts-share-scope"><strong>'+esc(current.title)+'</strong>'+(current.reportDate?'<span>'+esc(text('reportDate',language))+': '+esc(current.reportDate)+'</span>':'')+(scope(current)?'<span>'+esc(scope(current))+'</span>':'')+'</div><div class="parts-share-count"><b>'+esc(metrics.join(' · '))+'</b>'+(count>preview?'<span>'+(language==='en'?'Preview: first '+preview+(options.simple?' rows · Downloads include all rows':' rows · Downloads and copy include all rows'):'미리보기 '+preview+(options.simple?'행 · 다운로드는 전체 행':'행 · 다운로드와 복사는 전체 행'))+'</span>':'')+'</div><div class="parts-share-table-wrap" tabindex="0" aria-label="'+esc(current.title)+'">'+(count?tableHTML(current,20):'<p class="parts-share-empty">'+esc(text(buildError?'error':'empty',language))+'</p>')+'</div>'+(current.notes.length?'<details class="parts-share-notes"><summary>'+esc(text('notes',language))+'</summary>'+current.notes.map(note=>'<p>'+cellHTML(note)+'</p>').join('')+'</details>':'')+'<div class="parts-share-status" role="status" aria-live="polite"></div><div class="parts-share-copy-fallback" hidden><label>'+esc(text('fullText',language))+'<textarea readonly spellcheck="false"></textarea></label></div></div><footer class="parts-share-footer">'+(xlsx?'<button type="button" class="parts-share-button primary" data-share-action="xlsx"'+(!count?' disabled':'')+'>'+esc(text('xlsx',language))+'</button>':'')+'<button type="button" class="parts-share-button" data-share-action="csv"'+(!count?' disabled':'')+'>'+esc(text('csv',language))+'</button><button type="button" class="parts-share-button" data-share-action="copy"'+(!count?' disabled':'')+'>'+esc(text('copy',language))+'</button>'+(hasDetailed?'<button type="button" class="parts-share-button quiet" data-share-action="detailed"'+(!count?' disabled':'')+'>'+esc(text('detailed',language))+'</button>':'')+'<button type="button" class="parts-share-button quiet" data-share-action="html"'+(!count?' disabled':'')+'>'+esc(text('html',language))+'</button>'+extraActions.map((action,i)=>'<button type="button" class="parts-share-button" data-share-extra="'+i+'"'+(buildError?' disabled':'')+'>'+esc(typeof action.label==='function'?action.label(language):action.label||action.id)+'</button>').join('')+'</footer></section>';
  overlay.querySelector('.parts-share-close').onclick=close;
  overlay.querySelector('#parts-share-language').onchange=event=>{language=languageOf(event.target.value);refresh('parts-share-language')};
  const tableSelect=overlay.querySelector('#parts-share-table');if(tableSelect)tableSelect.onchange=event=>{selected=tables.find(table=>table.id===event.target.value)||tables[0];refresh('parts-share-table')};
  const scopeSelect=overlay.querySelector('#parts-share-selection-scope');if(scopeSelect)scopeSelect.onchange=event=>{selectionScope=event.target.value;refresh('parts-share-selection-scope')};
  if(options.simple)for(const action of ['copy','html']){const button=overlay.querySelector('[data-share-action="'+action+'"]');if(button)button.hidden=true;}
  const recipientSelect=overlay.querySelector('#parts-share-recipient');if(recipientSelect)recipientSelect.onchange=event=>{recipient=event.target.value;refresh('parts-share-recipient')};
  for(const button of overlay.querySelectorAll('[data-share-action]'))button.onclick=()=>perform(button.dataset.shareAction);
  for(const button of overlay.querySelectorAll('[data-share-extra]'))button.onclick=async()=>{button.disabled=true;try{await extraActions[Number(button.dataset.shareExtra)].run({language,recipient:current.recipient,model:current,tableId:selected.id});if(!disposed)status(text('saveStarted',language))}catch(_){if(!disposed)status(text('saveError',language),true)}finally{button.disabled=false}};
  if(focusId)overlay.querySelector('#'+focusId)?.focus();
 }
 function save(name,content,type){
  if(typeof options.download==='function')return options.download(name,content,type);
  const url=URL.createObjectURL(new Blob([content],{type})),link=document.createElement('a');link.href=url;link.download=name;document.body.appendChild(link);link.click();link.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);
 }
 function legacyCopy(rich,plain){
  let wrote=false;
  const handler=event=>{if(!event.clipboardData)return;event.clipboardData.setData('text/html',rich);event.clipboardData.setData('text/plain',plain);event.preventDefault();wrote=true};
  const textarea=document.createElement('textarea');textarea.value=plain;textarea.className='parts-share-clipboard-buffer';overlay.appendChild(textarea);textarea.focus();textarea.select();document.addEventListener('copy',handler);
  let copied=false;try{copied=Boolean(document.execCommand&&document.execCommand('copy'))}catch(_){}finally{document.removeEventListener('copy',handler);textarea.remove()}
  return copied&&wrote;
 }
 async function perform(action){
  if(!current||!current.rows.length)return;
  const model=current,outputLanguage=language,tableId=(options.filePrefix?options.filePrefix+'_':'')+selected.id;
  if(action==='xlsx'){try{await save(fileName(tableId,outputLanguage,model.reportDate,'xlsx'),workbook([model],options.XLSX||globalThis.XLSX),'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');if(!disposed)status(text('saveStarted',language))}catch(_){if(!disposed)status(text('saveError',language),true)}return;}
  if(action==='detailed'){
   const callback=selected.downloadDetailed||options.downloadDetailed;
   try{await callback({language:outputLanguage,recipient:model.recipient,tableId});if(!disposed)status(text('saveStarted',language))}catch(_){if(!disposed)status(text('saveError',language),true)}
   return;
  }
  if(action!=='copy'){
   try{await save(fileName(tableId,outputLanguage,model.reportDate,action==='csv'?'csv':'html'),action==='csv'?csv(model):html(model,{standalone:true}),action==='csv'?'text/csv;charset=utf-8':'text/html;charset=utf-8');if(!disposed)status(text('saveStarted',language))}
   catch(_){if(!disposed)status(text('saveError',language),true)}
   return;
  }
  const rich=html(model),plain=tsv(model);let copied=false;
  try{if(typeof navigator!=='undefined'&&navigator.clipboard&&navigator.clipboard.write&&typeof ClipboardItem!=='undefined'){await navigator.clipboard.write([new ClipboardItem({'text/html':new Blob([rich],{type:'text/html'}),'text/plain':new Blob([plain],{type:'text/plain'})})]);copied=true}}catch(_){}
  if(disposed)return;
  if(!copied)copied=legacyCopy(rich,plain);
  if(copied){status(text('copied',language));overlay.querySelector('[data-share-action="copy"]')?.focus()}
  else{status(text('copyBlocked',language),true);const fallback=overlay.querySelector('.parts-share-copy-fallback'),textarea=fallback.querySelector('textarea');fallback.hidden=false;textarea.value=plain;textarea.focus();textarea.select()}
 }
 function keyDown(event){
  if(event.key==='Escape'){event.preventDefault();event.stopPropagation();close();return}
  if(event.key!=='Tab')return;
  const focusable=[...overlay.querySelectorAll('button:not(:disabled),select,textarea,[tabindex="0"]')].filter(element=>!element.closest('[hidden]'));
  if(!focusable.length)return;
  const first=focusable[0],last=focusable[focusable.length-1];
  if(event.shiftKey&&(document.activeElement===first||!overlay.contains(document.activeElement))){event.preventDefault();last.focus()}
  else if(!event.shiftKey&&(document.activeElement===last||!overlay.contains(document.activeElement))){event.preventDefault();first.focus()}
 }
 overlay.addEventListener('click',event=>{if(event.target===overlay)close()});document.addEventListener('keydown',keyDown,true);refresh();overlay.querySelector('#parts-share-language').focus();
 return {close,getModel:()=>current};
}
return {open,normalize,csv,tsv,html,tableHTML,safeCell,fileName,workbook};
});
