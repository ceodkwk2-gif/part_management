(function(root,factory){
 if(typeof module==='object'&&module.exports)module.exports=factory(require('./core.js'));
 else root.PartsOperations=factory(root.PartsCore);
})(typeof self!=='undefined'?self:this,function(Core){
'use strict';
// Display-only operational context. Do not change Core demand, stock, targets,
// pending orders or proposed order quantities, and never allocate shared stock.
const DEFAULT_LOW_USAGE_MAX=2;
const ROLES=[{key:'CENTER',label:'수리센터'},{key:'INDIA',label:'법인'},{key:'INDIA_HQ',label:'법인·본사'},{key:'HQ',label:'본사'}];
const known=value=>typeof value==='number'&&Number.isFinite(value)&&value>=0;
const positive=value=>known(value)&&value>0;
const norm=value=>String(value??'').trim().toUpperCase();
const key=(center,part)=>center+'|'+norm(part);
const unique=values=>[...new Set(values)];
const total=values=>values.reduce((sum,value)=>sum+(known(value)?value:0),0);
function threshold(settings={}){
 const value=settings.lowUsageSixMonthMax;
 return typeof value==='number'&&Number.isInteger(value)&&value>0?value:DEFAULT_LOW_USAGE_MAX;
}
function completedMonths(source){
 if(!source?.date||Core.date(source.date)!==source.date)return [];
 const [year,month]=source.date.split('-').map(Number);
 return Array.from({length:6},(_,index)=>new Date(Date.UTC(year,month-7+index,1)).toISOString().slice(0,7));
}
function lowUsageFor(source,row,maximum){
 const months=completedMonths(source);
 let reason='';
 if(!source)reason='센터 대시보드 없음';
 else if(months.length!==6)reason='대시보드 기준일 미확인';
 else if(!row)reason='대시보드 부품 누락';
 else if(months.some(month=>!(source.usageMonths||[]).includes(month)))reason='최근 완료 6개월 사용량 기간 미충족';
 else if(months.some(month=>!known(row.usage?.[month])))reason='최근 완료 6개월 사용량 빈칸·오류';
 const valid=!reason,quantity=valid?total(months.map(month=>row.usage[month])):null;
 return {total:quantity,valid,flag:valid&&quantity>0&&quantity<=maximum,months,threshold:maximum,reason,
  file:source?.file||null,sheet:source?.sheet||null,sourceDate:source?.date||null,row:row?.row??null};
}
function groupByPart(rows){
 const groups=new Map();
 for(const row of rows){const part=norm(row.part);if(!part)continue;if(!groups.has(part))groups.set(part,[]);groups.get(part).push(row)}
 return groups;
}
function commonQuantity(rows,field){
 const values=rows.map(row=>row[field]);
 return values.length&&values.every(known)&&values.every(value=>value===values[0])?values[0]:null;
}
function orderNeed(row){
 return [row.stock,row.needed,row.open].every(known)?Core.orderBreakdown(row).currentOrderNeed:null;
}
// Use one total order instruction in every surface. The current-repair gap is
// an owner-selection input, not a second order to add to the proposed total.
function orderActionText(row,{targetMonths=1,format=value=>String(value),includeBasis=true}={}){
 if(positive(row.proposed)){
  const headline='추가 PO 총 '+format(row.proposed)+'개 필요';
  if(!includeBasis||![row.needed,row.target,row.stock,row.open].every(known))return headline;
  const months=positive(targetMonths)?targetMonths:1;
  const terms=['현 수리 필요 '+format(row.needed),format(months)+'개월 보유 '+format(row.target),
   '− 센터 재고 '+format(row.stock),'− PO 미입고 '+format(row.open)];
  return headline+' ('+terms[0]+' + '+terms.slice(1).join(' ')+')';
 }
 const currentNeed=orderNeed(row);
 if(!known(row.proposed)&&positive(currentNeed))
  return '현재 수리용 PO '+format(currentNeed)+'개 필요 (보유분·총 추가 PO 미계산)';
 return '';
}
// The shared stock comparison is made against all centers' shortage once.
// It selects a required task, not stock allocation, shipment progress or liability.
function supplyRoute(india,hq,globalShortage,complete){
 const checks=[];
 if(!complete)checks.push('전체 센터 부족량 일부 미확인');
 const result=(role,action,reason,status)=>({supplyRoleKey:role,supplyAction:action,supplyReason:reason,supplyStatus:status,
  supplyGap:complete&&known(india)&&known(hq)?Math.max(0,globalShortage-india-hq):null,
  supplyGapKnownLowerBound:known(india)&&known(hq)?Math.max(0,globalShortage-india-hq):null,checks});
 if(known(india)&&complete&&india>=globalShortage)
  return result('INDIA','센터 공급 진행','법인 재고가 전체 센터의 현재 부족량 이상 — 수량상 공급 가능, 배정·출고는 별도','INDIA_STOCK');
 if(!known(india))checks.push('법인 재고 미확인 — 공급 조치담당 판단 보류');
 if(!known(hq))checks.push('본사 재고 미확인 — 공급 조치담당 판단 보류');
 if(!known(india)||!known(hq))return result('INFORMATION_CHECK','공급 재고 자료 확인','법인·본사 재고 일부 미확인 — 0으로 간주하지 않음','UNKNOWN_STOCK');
 if(india===0&&hq===0&&globalShortage>0)
  return result('HQ','구매·입고 진행 및 자재 확보','법인·본사 재고 모두 0 — 본사 자재 확보 업무 필요. 기존 구매·입고 진행을 포함하며 신규 구매·귀책을 확정하지 않음','SECURE_PARTS');
 if(india<globalShortage){
  if(india+hq<globalShortage)return result('INDIA_HQ','보유분 공급 · 본사 부족분 확보',
   '법인·본사 재고 합계가 전체 센터의 확인된 현재 부족량보다 적음 — 보유분 공급과 본사 부족분 확보 필요','SHARED_SHORTFALL');
  if(complete)return result('INDIA_HQ','본사→법인→센터 공급 진행',
   '법인 재고만으로 부족하나 본사 재고를 합치면 전체 센터의 현재 부족량 충당 가능 — 실제 요청·출고 단계는 미확인','STOCK_TRANSFER');
  return result('INDIA_HQ','보유분 공급 · 추가 필요량 확인',
   '법인 재고 부족은 확인되나 전체 센터 필요량 일부 미확인 — 보유분 공급과 추가 필요량 확인','INCOMPLETE_DEMAND');
 }
 return result('INFORMATION_CHECK','전체 센터 부족량 확인','전체 센터 부족량이 완전하지 않아 법인 재고만으로 충당 가능한지 판단 보류','UNKNOWN_DEMAND');
}
// PO follow-up is independent of the center's additional-order task. This
// projection never changes Core balances or the existing shortage-owner partition.
function poFollowup(member,allRows=[]){
 const rows=allRows.filter(row=>row.center===member.center&&norm(row.part)===norm(member.part));
 const summary=Core.detailPoSummary(rows),open=known(member.open)?member.open:null;
 const datedRows=summary.rows.filter(row=>positive(row.pending)&&typeof row.etd==='string'&&Core.date(row.etd)===row.etd);
 const detailDatedQuantity=total(datedRows.map(row=>row.pending));
 const matched=rows.length>0&&known(summary.pending)&&known(open)&&summary.pending===open;
 const plannedQuantity=matched?detailDatedQuantity:0,unplannedQuantity=known(open)?Math.max(0,open-plannedQuantity):null;
 const reason=!rows.length?'상세 PO 미매칭':!known(summary.pending)?'상세 PO 잔량 오류·중복 확인':!known(open)?'계산 PO 잔량 미확인':summary.pending!==open?'대시보드·상세 PO 잔량 불일치':unplannedQuantity>0?'출고 예정일 미정':'';
 const tasks=[];
 if(positive(open)&&plannedQuantity>0)tasks.push({owner:'법인',quantity:plannedQuantity,action:'예정 출고 일정 관리',dates:unique(datedRows.map(row=>row.etd)).sort()});
 if(positive(unplannedQuantity))tasks.push({owner:'법인·본사',quantity:unplannedQuantity,action:'기존 PO 공급 진행',reason});
 const poDates=unique(rows.map(row=>row.date).filter(Boolean)),sourceDateNote=member.dashboardDate&&poDates.some(date=>date!==member.dashboardDate)?`센터 대시보드 ${member.dashboardDate} / 상세 PO ${poDates.join(', ')} — 수량이 같아도 같은 시점의 출고 상태로 확정하지 않음`:'';
 return {open,detailPending:summary.pending,sourceDateNote,matched,plannedQuantity,unplannedQuantity,detailDatedQuantity,datedRows,reason,tasks,
  dispatchConfirmed:false,receiptConfirmed:false,quantityPolicyConfirmed:false};
}
function sourceRef(source,row,field,quantity,extra={}){
 return {file:source?.file||null,sheet:source?.sheet||null,date:source?.date||null,dateLabel:source?.dateLabel||null,
  row:row?.row??null,field,quantity:known(quantity)?quantity:null,...extra};
}
function sourceEvidence(row,calculated,dashboards,dashboardRows,support){
 const part=norm(row.part),used=calculated?.used||[],dashboard=dashboards.get(row.center),selected=dashboardRows.get(row.center)?.get(part);
 const dashboardRefs=[sourceRef(dashboard,selected,'센터 재고',row.stock,{assumedZero:!!row.stockAssumedZero})];
 const need=row.needBasis==='dashboard'?[sourceRef(dashboard,selected,'Waiting/Hold',row.needed,{date:row.needDate||dashboard?.holdDate||null})]:
  used.filter(source=>source.type==='wip'&&source.center===row.center).flatMap(source=>(source.rows||[])
   .filter(item=>Object.keys(item.tokens?.parts||{}).some(code=>norm(code)===part))
   .map(item=>sourceRef(source,item,'Required Part',Object.entries(item.tokens.parts).filter(([code])=>norm(code)===part).reduce((sum,[,quantity])=>sum+quantity,0),{operator:source.operator||null})));
 const validDashboardPo=known(selected?.po),poSource=used.find(source=>source.type==='po'&&source.center===row.center);
 const detailSummary=validDashboardPo?null:Core.detailPoSummary((poSource?.rows||[]).filter(item=>norm(item.part)===part));
 const po=validDashboardPo?[sourceRef(dashboard,selected,'Open PO',selected.po,{basis:'dashboard',used:true})]:
  detailSummary.rows.map(item=>{
   const diagnostics=detailSummary.diagnostics.filter(issue=>(issue.rows||[]).includes(item.row));
   const ignoredRows=unique(diagnostics.flatMap(issue=>issue.ignoredRows||[]));
   const usable=known(detailSummary.pending),originalQuantity=known(item.pending)?item.pending:null;
   const reason=usable?diagnostics.map(issue=>issue.message).join(' · ')+(ignoredRows.length?' · 제외 원본 '+ignoredRows.join(', ')+'행':''):
    '상세 PO 잔량 미확인 — 합산·반영 보류'+(originalQuantity==null?' · 원본 Pending 빈칸·오류':' · 원본 Pending '+originalQuantity+'개')+' · '+unique(detailSummary.diagnostics.map(issue=>issue.message)).join(' · ');
   return sourceRef(poSource,item,'Pending',usable?item.pending:null,{basis:'detail',po:item.po||null,item:item.item??null,
    used:usable,originalQuantity,detailPending:detailSummary.pending,ignoredRows,diagnostics,reason});
  });
 if(!po.length)po.push(sourceRef(poSource,null,'PO 잔량',row.open,{basis:poSource?'detail-no-matching-row':'unknown'}));
 const inventory=type=>{
  const value=support?.inventorySources?.[type];
  if(value)return [{file:value.file||null,sheet:value.sheet||null,date:value.date||null,dateLabel:value.dateLabel||null,row:value.selectedRow??null,
   field:type==='india'?'법인 재고':'본사 재고',quantity:known(value.qty)?value.qty:null,reason:value.reason||'',ignoredRows:value.ignoredRows||[]}];
  const source=used.find(item=>item.type===type),match=Core.selectDashboardRows(source).find(item=>norm(item.part)===part);
  return [sourceRef(source,match,type==='india'?'법인 재고':'본사 재고',row[type],{reason:!source?'재고 원본 없음':!match?'전체 재고목록의 부품 매칭 확인':''})];
 };
 return {dashboard:dashboardRefs,need,po,india:inventory('india'),hq:inventory('hq')};
}
function actionGroups(calculated,visible,shortageGroups,memberInfo,dashboards,dashboardRows,common){
 const visibleByPart=groupByPart(visible),byKey=new Map();
 for(const [part,shortageMembers] of shortageGroups){
  const support=common.get(part),rows=visibleByPart.get(part)||shortageMembers;
  const members=rows.map(row=>{const info=memberInfo[key(row.center,row.part)]||{};return {center:row.center,needed:known(row.needed)?row.needed:null,stock:known(row.stock)?row.stock:null,
   shortage:known(row.shortage)?row.shortage:null,open:known(row.open)?row.open:null,currentOrderNeed:orderNeed(row),poKnown:known(row.open),
   roleKeys:[...(info.roleKeys||[])],nextOwner:info.nextOwner||null,reasons:[...(info.reasons||[])],
   pendingFollowup:!!info.pendingFollowup,pendingFollowupReason:info.pendingFollowupReason||'',
   supplyRoleKey:info.supplyRoleKey||null,supplyAction:info.supplyAction||'',supplyReason:info.supplyReason||'',supplyStatus:info.supplyStatus||null,
   supplyGap:info.supplyGap??null,supplyGapKnownLowerBound:info.supplyGapKnownLowerBound??null,nextAction:info.nextAction||'',checks:[...(info.checks||[])],
   needBasis:row.needBasis||null,needDate:row.needDate||null,dashboardDate:row.dashboardDate||null,wipDate:row.wipDate||null,
   sourceEvidence:sourceEvidence(row,calculated,dashboards,dashboardRows,support)};});
  const currentMembers=members.filter(member=>positive(member.shortage));
  // A shared part has one primary next step. Keep each center's actual step in
  // members. Shared stock selects one supply task without allocating it.
  const memberOwners=unique(currentMembers.map(member=>member.nextOwner));
  const primaryOwner=memberOwners.includes('CENTER')?'CENTER':
   memberOwners.includes('INFORMATION_CHECK')||memberOwners.length!==1?'INFORMATION_CHECK':memberOwners[0];
  const roleKeys=primaryOwner==='INFORMATION_CHECK'?[]:[primaryOwner];
  const roleDetails=ROLES.flatMap(role=>{const matched=currentMembers.filter(member=>member.nextOwner===role.key);if(!matched.length)return [];
   return [{key:role.key,label:role.label,part,centers:unique(matched.map(member=>member.center)),shortage:total(matched.map(member=>member.shortage)),
    reason:unique(matched.flatMap(member=>member.reasons)).join(' / '),poNeed:role.key==='CENTER'?total(matched.map(member=>member.currentOrderNeed)):null,
    status:role.key==='CENTER'?'CURRENT_ORDER':'EXISTING_PO_SUPPLY',nextAction:unique(matched.map(member=>member.nextAction)).join(' / ')}];});
  const checks=[];
  for(const member of currentMembers){
   checks.push(...member.checks);
   if(!member.poKnown)checks.push(member.center+' 기존 PO 잔량 미확인 — 다음 조치 담당 판단 보류');
   if(member.needed==null||member.stock==null)checks.push(member.center+' 현 수리 필요 수·재고 일부 미확인');
  }
  const globalRows=(calculated.allParts||visible).filter(row=>norm(row.part)===part);
  const globalShortage=known(support?.shortageKnownSubtotal)?support.shortageKnownSubtotal:total(globalRows.map(row=>row.shortage));
  const globalShortageComplete=support?!!support.shortageComplete:globalRows.every(row=>known(row.shortage));
  if(!globalShortageComplete)checks.push('전체 센터 부족량 일부 미확인');
  const row={part,description:rows.find(row=>row.description)?.description||'',centers:unique(shortageMembers.map(row=>row.center)),
   shortage:total(shortageMembers.map(row=>row.shortage)),globalShortage,globalShortageComplete,
   india:support?(known(support.india)?support.india:null):commonQuantity(globalRows,'india'),hq:support?(known(support.hq)?support.hq:null):commonQuantity(globalRows,'hq'),
   primaryOwner,roleKeys,roleDetails,members,
   supplyRoleKey:currentMembers[0]?.supplyRoleKey||null,supplyAction:currentMembers[0]?.supplyAction||'',supplyReason:currentMembers[0]?.supplyReason||'',
   supplyStatus:currentMembers[0]?.supplyStatus||null,supplyGap:currentMembers[0]?.supplyGap??null,supplyGapKnownLowerBound:currentMembers[0]?.supplyGapKnownLowerBound??null,
   nextAction:unique(currentMembers.map(member=>member.nextAction)).join(' / '),poKnown:currentMembers.every(member=>member.poKnown),
   currentOrderNeed:currentMembers.every(member=>member.currentOrderNeed!=null)?total(currentMembers.map(member=>member.currentOrderNeed)):null,
   currentOrderNeedKnownSubtotal:total(currentMembers.map(member=>member.currentOrderNeed)),checks:unique(checks),classificationComplete:checks.length===0,
   allocationConfirmed:false};
  const label=ROLES.find(role=>role.key===primaryOwner)?.label||'조치 정보 확인';
  if(!byKey.has(primaryOwner))byKey.set(primaryOwner,{key:primaryOwner,label,roleKeys,rows:[]});
  byKey.get(primaryOwner).rows.push(row);
 }
 const order={CENTER:0,INDIA:1,INDIA_HQ:2,HQ:3,INFORMATION_CHECK:4};
 const groups=[...byKey.values()].sort((a,b)=>order[a.key]-order[b.key])
  .map(group=>{const rows=group.rows.sort((a,b)=>b.shortage-a.shortage||a.part.localeCompare(b.part));return {...group,rows,partCount:rows.length,parts:rows.map(row=>row.part),quantity:total(rows.map(row=>row.shortage))}});
 const groupTotal=groups.reduce((sum,group)=>sum+group.partCount,0),groupedParts=groups.flatMap(group=>group.parts);
 return {groups,groupTotal,groupingComplete:groupTotal===shortageGroups.size&&new Set(groupedParts).size===groupTotal};
}
function evaluate(state,calculated){
 const maximum=threshold(state?.settings),visible=calculated?.parts||[],all=calculated?.allParts||visible;
 const dashboards=new Map((calculated?.used||[]).filter(source=>source.type==='dashboard').map(source=>[source.center,source]));
 const dashboardRows=new Map([...dashboards].map(([center,source])=>[center,new Map(Core.selectDashboardRows(source).map(row=>[norm(row.part),row]))]));
 const lowUsage=Object.create(null),memberInfo=Object.create(null);
 for(const row of all){const memberKey=key(row.center,row.part);lowUsage[memberKey]=lowUsageFor(dashboards.get(row.center),dashboardRows.get(row.center)?.get(norm(row.part)),maximum)}
 for(const row of visible){const memberKey=key(row.center,row.part);if(!lowUsage[memberKey])lowUsage[memberKey]=lowUsageFor(dashboards.get(row.center),dashboardRows.get(row.center)?.get(norm(row.part)),maximum);
  memberInfo[memberKey]={roleKeys:[],roles:[],reasons:[],nextOwner:null,nextAction:'',checks:[],supplyRoleKey:null,supplyAction:'',supplyReason:'',supplyStatus:null,supplyGap:null,supplyGapKnownLowerBound:null,pendingFollowup:false,pendingFollowupReason:'',lowUsage:lowUsage[memberKey]};}
 const common=new Map((calculated?.commonSupport?.parts||[]).map(row=>[norm(row.part),row]));
 const allByPart=groupByPart(all),shortageGroups=groupByPart(visible.filter(row=>positive(row.shortage)));
 for(const [part,rows] of shortageGroups){
  const globalRows=allByPart.get(part)||rows,support=common.get(part);
  const india=support?(known(support.india)?support.india:null):commonQuantity(globalRows,'india');
  const hq=support?(known(support.hq)?support.hq:null):commonQuantity(globalRows,'hq');
  const globalShortage=known(support?.shortageKnownSubtotal)?support.shortageKnownSubtotal:total(globalRows.map(row=>row.shortage));
  const globalShortageComplete=support?!!support.shortageComplete:globalRows.every(row=>known(row.shortage));
  const route=supplyRoute(india,hq,globalShortage,globalShortageComplete);
  for(const row of rows){
   const info=memberInfo[key(row.center,row.part)],gap=orderNeed(row);
   Object.assign(info,route,{checks:[...route.checks]});
   info.pendingFollowup=positive(row.open);
   const supplyLabel=ROLES.find(role=>role.key===route.supplyRoleKey)?.label;
   info.pendingFollowupReason=info.pendingFollowup?'기존 미입고 PO '+row.open+'개: '+(supplyLabel?supplyLabel+' — ':'')+route.supplyAction:'';
   if(row.shortageBasis==='wip-waiting'&&row.shortage>0&&known(row.stock)&&row.stock>=row.shortage){
    info.nextOwner='CENTER';info.nextAction='센터 재고 있음 · WIP 자재대기 확인 필요';info.roleKeys=['CENTER'];info.roles=['수리센터'];info.reasons.push('재고 수량만으로 WIP 자재대기를 해소하지 않음 · 실제 사용 가능 재고와 대기 상태 확인');info.supplyRoleKey='CENTER';info.supplyAction=info.nextAction;info.supplyStatus='WIP_STOCK_REVIEW';continue;
   }
   if(gap==null){
    info.nextOwner='INFORMATION_CHECK';info.nextAction='PO 잔량 자료 확인';info.reasons.push('기존 PO 잔량 미확인 — 다음 조치 담당 판단 보류');
   }else if(gap>0){
    info.nextOwner='CENTER';info.roleKeys=['CENTER'];info.roles=['수리센터'];
    info.nextAction=orderActionText(row,{targetMonths:Core.effectiveTargetMonths(state?.settings)})+(info.pendingFollowup?' · 기존 PO '+row.open+'개 공급 진행':'')+(route.supplyRoleKey==='HQ'?' · 본사 자재 확보 필요':'');
    info.reasons.push('현 수리 필요 수 중 센터 재고·미입고 PO로 충당하지 못하는 수량의 추가 발주 필요');
   }else{
    info.nextOwner=route.supplyRoleKey;info.nextAction=route.supplyAction;
    info.roleKeys=route.supplyRoleKey==='INFORMATION_CHECK'?[]:[route.supplyRoleKey];
    info.roles=info.roleKeys.map(roleKey=>ROLES.find(role=>role.key===roleKey).label);
    info.reasons.push('현재 수리용 PO 수량 확보 — '+route.supplyReason);
   }
  }
 }
 const grouped=actionGroups(calculated,visible,shortageGroups,memberInfo,dashboards,dashboardRows,common);
 const roles=ROLES.map(role=>{const rows=grouped.groups.find(group=>group.key===role.key)?.rows||[];return {...role,partCount:rows.length,parts:rows.map(row=>row.part),rows:rows.map(row=>{
  const detail=row.roleDetails.find(detail=>detail.key===role.key);return {...row,reason:detail?.reason||'',status:detail?.status||'',poNeed:detail?.poNeed??null};
 })}});
 return {threshold:maximum,lowUsage,roles,memberInfo,shortagePartCount:shortageGroups.size,...grouped,
  dataAlerts:grouped.groups.flatMap(group=>group.rows).filter(row=>row.checks.length),
  scopeNote:'현재 부족 부품은 수리센터 / 법인 / 법인·본사 / 본사 중 대표 담당 한 곳에만 집계합니다. 현재 수리용 PO 부족이면 센터 우선, 충분하면 전체 센터 부족량과 공용 재고를 한 번 비교해 필요한 공급·확보 업무를 표시합니다. 센터별 행동과 기존 PO 공급은 상세에 유지합니다.',
  hqAssignmentAvailable:true,hqAssignmentNote:'본사 표시는 양쪽 재고가 없어 자재 확보 업무가 필요하다는 뜻입니다. 법인→본사 요청·처리·출고 단계, 지연 귀책 또는 신규 구매를 확정하지 않습니다.',
  allocationConfirmed:false,liabilityConfirmed:false};
}
return {DEFAULT_LOW_USAGE_MAX,ROLES,threshold,completedMonths,orderActionText,supplyRoute,poFollowup,evaluate};
});
