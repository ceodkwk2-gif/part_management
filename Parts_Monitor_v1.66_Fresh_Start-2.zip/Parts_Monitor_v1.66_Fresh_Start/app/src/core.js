(function(root,factory){const api=factory(typeof module==='object'&&module.exports?require('./siel.js'):root.PartsSiel);if(typeof module==='object')module.exports=api;else root.PartsCore=api})(typeof self!=='undefined'?self:this,function(Siel){
'use strict';
const VERSION=1, DAY=86400000;
const CENTER_OPERATORS=Object.freeze({Flex:Object.freeze(['Jio']),CTDI:Object.freeze(['Jio','Airtel','Vi'])});
const str=v=>v==null?'':String(v).trim();
const norm=v=>str(v).toLowerCase().replace(/[^a-z0-9가-힣]/g,'');
const code=v=>str(v).toUpperCase();
const num=v=>v==null||str(v)===''?null:(Number.isFinite(Number(String(v).replace(/,/g,'')))?Number(String(v).replace(/,/g,'')):null);
const sum=a=>a.reduce((s,v)=>s+(Number(v)||0),0);
function iso(y,m,d){const t=new Date(Date.UTC(+y,+m-1,+d));return t.getUTCFullYear()===+y&&t.getUTCMonth()===+m-1&&t.getUTCDate()===+d?t.toISOString().slice(0,10):null}
function date(v,order='dmy'){
 if(v instanceof Date)return Number.isFinite(+v)?v.toISOString().slice(0,10):null;
 if(typeof v==='number'&&v>30000&&v<80000)return new Date(Date.UTC(1899,11,30)+Math.floor(v)*DAY).toISOString().slice(0,10);
 let s=str(v),m;if((m=s.match(/(20\d{2})[-/.](\d{1,2})[-/.](\d{1,2})/)))return iso(m[1],m[2],m[3]);
 if((m=s.match(/(\d{1,2})[-/.](\d{1,2})[-/.](20\d{2})/)))return order==='mdy'?iso(m[3],m[1],m[2]):iso(m[3],m[2],m[1]);
 const months=['jan','feb','mar','apr','may','jun','jul','aug','sep','oct','nov','dec'];
 if((m=s.match(/(\d{1,2})(?:st|nd|rd|th)?[-\s]([a-z]+)[-\s](20\d{2})/i)))return iso(m[3],months.indexOf(m[2].slice(0,3).toLowerCase())+1,m[1]);return null;
}
// Compact ETD values follow the source center's day/month convention, not
// the YYMMDD convention of some filenames. Never reinterpret Excel serials.
function scheduleDate(value,order='dmy'){
 const parsed=date(value,order);if(parsed)return parsed;
 const raw=str(value);let m=raw.match(/^(\d{2})(\d{2})(\d{2})$/)||raw.match(/^(\d{1,2})[-/.](\d{1,2})[-/.](\d{2})$/);
 if(m)return order==='mdy'?iso('20'+m[3],m[1],m[2]):iso('20'+m[3],m[2],m[1]);
 m=raw.match(/^(\d{1,2})[-\s]([A-Za-z]{3})[-\s](\d{2})$/);
 return m?date(m[1]+'-'+m[2]+'-20'+m[3],order):null;
}
function fileDate(name){
 const value=str(name);let parsed;
 // Test whole eight-digit tokens before six-digit YYMMDD. A 20th-day
 // DDMMYYYY value can resemble YYYYMMDD, so try both valid calendar forms.
 for(const match of value.matchAll(/(?:^|[^\d])(\d{8})(?!\d)/g)){
  const token=match[1];
  if(/^20\d{6}$/.test(token)&&(parsed=iso(token.slice(0,4),token.slice(4,6),token.slice(6,8))))return parsed;
  if(/^\d{4}20\d{2}$/.test(token)&&(parsed=iso(token.slice(4,8),token.slice(2,4),token.slice(0,2))))return parsed;
 }
 const full=date(value);if(full)return full;
 const dotted=value.match(/(?:^|[^\d])(\d{2})[.](\d{2})[.](\d{2})(?!\d)/);
 if(dotted&&(parsed=iso('20'+dotted[3],dotted[2],dotted[1])))return parsed;
 // Only a delimited filename token is evidence for compact YYMMDD;
 // never reinterpret a substring of an invalid eight-digit date or a code.
 for(const match of value.matchAll(/(?:^|[\s_.()\[\]-])(\d{2})(\d{2})(\d{2})(?=$|[\s_.()\[\]-])/g)){
  if((parsed=iso('20'+match[1],match[2],match[3])))return parsed;
 }
 return null;
}
function month(v){if(v instanceof Date)return date(v).slice(0,7);if(typeof v==='number')return date(v)?.slice(0,7);const s=str(v),m=s.match(/([a-z]+)[\s'’\-/.]*(\d{2,4})/i);if(m){const i=['jan','feb','mar','apr','may','jun','jul','aug','sep','oct','nov','dec'].indexOf(m[1].slice(0,3).toLowerCase());if(i>=0)return `${m[2].length===2?'20':''}${m[2]}-${String(i+1).padStart(2,'0')}`}return s.match(/^20\d{2}-\d{2}/)?.[0]||null}
// Generic name/serial plates are excluded from material management. Preserve
// the repair product and source text; never invent a shared material identity.
const NAMEPLATE='명판';
const NAMEPLATE_WORD=String.raw`(?:\b(?:NAME[\s_-]*PLATE|SERIAL\s*(?:\#|NO\.?|NUMBER)?[\s_-]*PLATE)\b|명판)`;
function isNameplate(value){return new RegExp('^'+NAMEPLATE_WORD+'$','i').test(str(value))}
function materialCode(value){return isNameplate(value)?NAMEPLATE:code(value)}
function codedPartTokens(value){
 // Whitespace around a valid code separator is formatting, not a missing
 // manufacturer character. Never guess malformed prefixes or suffixes.
 const raw=code(value).replace(/\b([A-Z0-9]{4})[ \t]*-[ \t]*([A-Z0-9]{6,8})\b/g,'$1-$2'),parts={},rx=/\b([A-Z0-9]{4}-[A-Z0-9]{6,8})\b\s*(?:(?:#|\*|[X×])\s*(\d+)|\(\s*(\d+)\s*\))?/g;let m,rests=raw;
 while((m=rx.exec(raw))){const q=Number(m[2]||m[3]||1);if(q>0)parts[m[1]]=(parts[m[1]]||0)+q;rests=rests.replace(m[0],' ')}
 rests=rests.replace(/[\s,;+/|]+/g,' ').trim();return {parts,unparsed:rests,assumed:!!Object.keys(parts).length&&!/[#*×]|\bX\s*\d|\(\s*\d/.test(raw)};
}
function partTokens(value){
 const raw=code(value);
 if(!new RegExp(NAMEPLATE_WORD,'i').test(raw))return codedPartTokens(value);
 const parts={},unparsed=[];let assumed=false,excludedNameplate=0;
 // Delimiters separate material requests. In a phrase containing a real code,
 // NAME PLATE is a description, never an extra generic plate to double count.
 for(const segment of raw.split(/[,;+/|\r\n]+/)){
  const parsed=codedPartTokens(segment),hasCode=Object.keys(parsed.parts).length>0;
  for(const [part,quantity] of Object.entries(parsed.parts))parts[part]=(parts[part]||0)+quantity;
  assumed ||= parsed.assumed;
  let residual=parsed.unparsed,recognized=false;
  if(hasCode){residual=residual.replace(new RegExp(NAMEPLATE_WORD,'gi'),()=>{recognized=true;return ' '})}
  else {
   const named=new RegExp('('+NAMEPLATE_WORD+')'+String.raw`(?:\s+(?:REQ(?:UIRED)?|NEEDED)\b)?\s*(?:(?:#|\*|[X×])\s*(\d+)|\(\s*(\d+)\s*\))?`,'gi');
   residual=residual.replace(named,(match,label,count,parenthesized)=>{
    const quantity=Number(count||parenthesized||1);if(quantity<=0)return match;
    recognized=true;excludedNameplate+=quantity;return ' ';
   });
  }
  // These describe the recognized request, not another unidentified material.
  // Other residue (e.g. TOP COVER) remains visible for source correction.
  if(recognized)residual=residual.replace(/\b(?:HOLD\s+FOR|WAITING\s+FOR|REQ(?:UIRED)?|NEEDED)\b/gi,' ').replace(/\(\s*\)|\[\s*\]|\{\s*\}/g,' ');
  residual=residual.replace(/\s+/g,' ').trim();if(residual)unparsed.push(residual);
 }
 return {parts,unparsed:unparsed.join(' '),assumed,...(excludedNameplate?{excludedNameplate}: {})};
}
function resolvedPartTokens(row={}){
 // Reinterpret only the approved category in old JSON backups. Stored source
 // records/tokens and reporting archive revisions remain unchanged.
 if(new RegExp(NAMEPLATE_WORD,'i').test(str(row.required)))return partTokens(row.required);
 const cached=row.tokens;
 if(!cached)return partTokens(row.required);
 const entries=Object.entries(cached.parts||{});
 if(!entries.some(([part])=>isNameplate(part)))return cached;
 const parts={};let excludedNameplate=cached.excludedNameplate||0;
 for(const [part,quantity] of entries){if(isNameplate(part)){excludedNameplate+=quantity;continue;}parts[part]=(parts[part]||0)+quantity}
 return {...cached,parts,excludedNameplate};
}
function materialRow(row){const part=materialCode(row.part);return part===row.part?row:{...row,part,rawPart:row.rawPart??row.part}}
// Confirmed service scope: Flex serves Jio; CTDI serves Jio, Airtel and Vodafone Idea.
// Canonical values stay compact for old backups; labels may show the full operator name.
function canonicalOperator(center,operator,type='wip'){
 if(type!=='wip')return str(operator);
 if(center==='Flex')return 'Jio';
 const value=norm(operator);return value==='vodafoneidea'||value==='vodafone'||value==='vi'?'Vi':value==='jio'?'Jio':value==='airtel'?'Airtel':str(operator);
}
function operatorLabel(operator){return operator==='Vi'?'Vodafone Idea':operator}
function normalizeOperators(state){
 const byKey=new Map();
 for(const original of state.sources||[]){const operator=canonicalOperator(original.center,original.operator,original.type),source={...original,operator};source.id=sourceKey(source);
  const previous=byKey.get(source.id),time=s=>s.revisedAt||s.importedAt||'';
  if(!previous||time(source)>=time(previous))byKey.set(source.id,source);
 }
 return {...state,sources:[...byKey.values()]};
}
function empty(){return {version:VERSION,settings:{months:6,targetMonths:1,indiaMonths:0,hqMonths:3,indiaDuplicates:'first'},sources:[],notes:{}}}
function effectiveTargetMonths(settings={}){const v=num(settings.targetMonths);return v!=null&&v>0?v:1}
function effectiveTargetDays(settings={}){return effectiveTargetMonths(settings)*30}
// Receipt-only follow-up is a center-specific condition. A different center's
// stock or order cannot satisfy this center's need, even for the same part code.
// Check the reserve remaining after current repair needs, not stock alone.
function waitingCovered(part){
 const valid=value=>typeof value==='number'&&Number.isFinite(value)&&value>=0;
 return ['stock','needed','target','open','proposed'].every(field=>valid(part[field]))&&
  part.stock<part.needed+part.target&&part.open>0&&part.proposed===0&&part.stock+part.open>=part.needed+part.target;
}
// Derived labels split the existing proposed quantity; they never alter inventory policy.
function orderBreakdown(part){
 const valid=v=>typeof v==='number'&&Number.isFinite(v);
 const currentOrderNeed=[part.stock,part.needed,part.open].every(valid)?Math.max(0,Math.ceil(part.needed-part.stock-part.open)):null;
 const futureOrderNeed=valid(part.proposed)&&currentOrderNeed!=null?Math.max(0,part.proposed-currentOrderNeed):null;
 const lowDemandOneUnit=part.proposed===1&&part.needed===0&&part.stock===0&&part.open===0&&part.avg>0&&part.avg<1;
 return {currentOrderNeed,futureOrderNeed,lowDemandOneUnit};
}
function poSchedule(row,reportDate=row.date){
 const previous=row.oldEtd||null,current=row.etd||null;
 const compared=!!previous||row.etdHistoryAvailable===true;
 const etdChange=previous?(current?(current>previous?'POSTPONED':current<previous?'EARLIER':'UNCHANGED'):'WITHDRAWN'):
  compared?(current?'ASSIGNED':'UNKNOWN'):(current?'DATED':'UNKNOWN');
 const daysPostponed=etdChange==='POSTPONED'?Math.round((Date.parse(current+'T00:00:00Z')-Date.parse(previous+'T00:00:00Z'))/DAY):null;
 const beforeReport=!!(current&&reportDate&&current<reportDate);
 const scheduleLabel=etdChange==='POSTPONED'?'출발예정일 연기':etdChange==='WITHDRAWN'?'출발예정일 삭제·미정':
  !current?'출발일 미정':beforeReport?'예정일 경과·상태 확인 필요':etdChange==='ASSIGNED'?'출발예정일 등록':etdChange==='EARLIER'?'출발예정일 앞당김':'출발 예정';
 return {etdChange,previousEtd:previous,daysPostponed,beforeReport,scheduleLabel,arrivalConfirmed:false,transitConfirmed:false};
}
function summarizePoSchedule(rows,reportDate){
 const pending=rows.filter(row=>typeof row.pending==='number'&&row.pending>0).map(row=>({...row,...poSchedule(row,reportDate)}));
 const postponed=pending.filter(row=>row.etdChange==='POSTPONED'),withdrawn=pending.filter(row=>row.etdChange==='WITHDRAWN'),unknown=pending.filter(row=>!row.etd),past=pending.filter(row=>row.beforeReport);
 return {rows:pending,postponedRows:postponed.length,withdrawnRows:withdrawn.length,unknownRows:unknown.length,beforeReportRows:past.length,
  earliestEtd:pending.map(row=>row.etd).filter(Boolean).sort()[0]||null,
  label:postponed.length?'출발예정일 연기':withdrawn.length?'출발예정일 삭제·미정':past.length?'예정일 경과·상태 확인 필요':unknown.length?'출발일 미정':pending.length?'출발 예정':'상세 PO 없음',
  arrivalConfirmed:false,transitConfirmed:false};
}
function detailPoSummary(rows){
 const groups=new Map(),diagnostics=[],selected=[];
 const item=v=>/^\d+$/.test(str(v))?str(v).replace(/^0+(?=\d)/,''):code(v);
 for(const [i,input] of rows.entries()){const row=materialRow(input),key=str(row.po)&&str(row.item)?JSON.stringify([materialCode(row.part),code(row.po),item(row.item),code(row.shipto)]):'unkeyed-'+i;(groups.get(key)||groups.set(key,[]).get(key)).push(row)}
 let conflict=false;
 for(const [key,group] of groups){const ordered=[...group].sort((a,b)=>(num(a.row)??Infinity)-(num(b.row)??Infinity));const signature=row=>{const value={...row};delete value.row;delete value.rawPart;value.item=item(value.item);return JSON.stringify(Object.keys(value).sort().map(k=>[k,value[k]]))};
  if(group.length===1){selected.push(group[0]);continue}
  const exact=new Set(group.map(signature)).size===1;
  diagnostics.push({type:exact?'identical-po-duplicate':'conflicting-po-duplicate',key,rows:ordered.map(r=>r.row),selectedRow:exact?ordered[0].row:null,ignoredRows:exact?ordered.slice(1).map(r=>r.row):[],message:exact?'상세 PO 동일 중복행 — 맨 위 행 1회 반영':'상세 PO 동일 식별키의 값 불일치 — 상세 잔량 미확인'});
  if(exact)selected.push(ordered[0]);else{selected.push(...ordered);conflict=true}
 }
 const invalid=selected.filter(r=>typeof r.pending!=='number'||!Number.isFinite(r.pending)||r.pending<0);
 if(invalid.length)diagnostics.push({type:'invalid-po-pending',rows:invalid.map(r=>r.row),message:'상세 PO 미입고 수량 빈칸·오류 — 상세 잔량 미확인'});
 // Order quantity is an independent source field, not Pending+Shipped or a PO count.
 // An empty row list has no report context here. calculate() may apply the
 // agreed full-report absence=0 rule, never to a matched invalid quantity.
 const invalidOrderedRows=selected.filter(r=>typeof r.ordered!=='number'||!Number.isFinite(r.ordered)||r.ordered<0),invalidOrdered=invalidOrderedRows.length>0;
 if(invalidOrdered)diagnostics.push({type:'invalid-po-ordered',rows:invalidOrderedRows.map(r=>r.row),message:'상세 PO 기발주 수량 빈칸·오류 — 원본 PO Qty 확인 필요'});
 const ordered=selected.length&&!conflict&&!invalidOrdered?sum(selected.map(r=>r.ordered)):null;
 const orderedReason=!selected.length?'상세 PO 목록에 해당 자재 없음':conflict?'동일 PO 식별키의 값 불일치':invalidOrdered?'원본 PO Qty 빈칸·오류':'';
 return {rows:selected,pending:conflict||invalid.length?null:sum(selected.map(r=>r.pending)),ordered,orderedReason,diagnostics};
}
// A reporting week is ordering evidence, never an exact measurement/event date.
function sourceSelectionDate(source={}){
 if(!source)return null;
 // Explicit weekly slot assignment controls eligibility only. Measurement,
 // PO, ETA and product aging calculations retain the original source dates.
 if(source.assignedWeek&&date(source.assignedWeek)===source.assignedWeek&&new Date(source.assignedWeek+'T00:00:00Z').getUTCDay()===1&&(!source.date||date(source.date)===source.date))return source.assignedWeek;
 const sielDemoDate=Siel?.selectionDate(source);if(sielDemoDate)return sielDemoDate;
 if(source.date)return typeof source.date==='string'&&/^\d{4}-\d{2}-\d{2}$/.test(source.date)&&date(source.date)===source.date?source.date:null;
 const week=source.reportWeek;
 return source.type!=='wip'&&source.datePrecision==='week'&&typeof week==='string'&&/^\d{4}-\d{2}-\d{2}$/.test(week)&&date(week)===week&&new Date(week+'T00:00:00Z').getUTCDay()===1?week:null;
}
function assignReportWeek(source,reportWeek){
 if(typeof reportWeek!=='string'||!/^\d{4}-\d{2}-\d{2}$/.test(reportWeek)||date(reportWeek)!==reportWeek)throw Error('자료의 보고 주차를 유효한 날짜로 지정해 주세요.');
 const d=new Date(reportWeek+'T00:00:00Z');d.setUTCDate(d.getUTCDate()-(d.getUTCDay()||7)+1);const week=d.toISOString().slice(0,10);
 if(source.date){if(!sourceSelectionDate(source))throw Error('잘못된 실제 원본 기준일을 주차로 대신할 수 없습니다.');return {...source,reportWeek:week,datePrecision:'day'};}
 if(source.type==='wip')throw Error('WIP는 TAT 계산을 위해 실제 원본 기준일이 필요합니다. 보고 주차로 대신할 수 없습니다.');
 if(!['india','hq','dashboard','po','siel'].includes(source.type))throw Error('보고 주차를 지정할 수 없는 자료입니다.');
 const out={...source,date:null,reportWeek:week,datePrecision:'week',dateBasis:'user-confirmed-week',dateLabel:week+'주 · 실제 기준일 미확인'};out.id=sourceKey(out);return out;
}
function sourceKey(source){return [source.type,source.center||'',canonicalOperator(source.center,source.operator,source.type)||'',source.date||(sourceSelectionDate(source)?'week:'+source.reportWeek:null)||source.dateLabel||source.file||''].join('|')}
function firstOriginalRow(rows){return rows.map((r,i)=>({r,i})).sort((a,b)=>(num(a.r.row)??Infinity)-(num(b.r.row)??Infinity)||a.i-b.i)[0]?.r}
function selectDashboardRows(source,rows=source?.rows||[]){return Object.values(group(rows)).map(rows=>materialRow(firstOriginalRow(rows)))}
function sourceDuplicateDiagnostics(source){
 if(!source||!['dashboard','india','hq'].includes(source.type))return [];
 return Object.entries(group(source.rows||[])).filter(([,rows])=>rows.length>1).map(([part,rows])=>{
  const selected=firstOriginalRow(rows),ordered=[...rows].sort((a,b)=>(num(a.row)??Infinity)-(num(b.row)??Infinity));
  return {type:source.type,center:source.center||'',part,file:source.file,sheet:source.sheet,date:source.date,rows:ordered.map(r=>r.row),selectedRow:selected.row,selectedQty:source.type==='dashboard'?selected.stock:selected.qty,policy:'first-row',ignoredRows:ordered.filter(r=>r!==selected).map(r=>r.row),originalRows:ordered};
 });
}
function duplicateDiagnostics(state,asof,center='전체'){
 const sources=[latest(state.sources,'hq',null,asof),latest(state.sources,'india',null,asof),...(center==='전체'?['Flex','CTDI']:[center]).map(c=>latest(state.sources,'dashboard',c,asof))];
 return sources.filter(Boolean).flatMap(sourceDuplicateDiagnostics);
}
function get(ws,r,c,X){return c==null?undefined:ws[X.utils.encode_cell({r,c})]?.v}
const rowCellCache=new WeakMap();
function cellsInRow(ws,r,X){let index=rowCellCache.get(ws);if(!index){index=new Map();for(const [k,v] of Object.entries(ws)){if(k[0]==='!'||v.v==null)continue;const p=X.utils.decode_cell(k);if(!index.has(p.r))index.set(p.r,[]);index.get(p.r).push([p.c,v.v])}for(const row of index.values())row.sort((a,b)=>a[0]-b[0]);rowCellCache.set(ws,index)}return index.get(r)||[]}
function rowsFor(ws,c,start,X){const col=X.utils.encode_col(c),rx=new RegExp('^'+col+'(\\d+)$');return Object.keys(ws).map(k=>[k,k.match(rx)]).filter(([k,m])=>m&&+m[1]>start&&str(ws[k].v)).map(([,m])=>+m[1]-1).sort((a,b)=>a-b)}
function header(ws,X,required,max=8){for(let r=0;r<max;r++){const h=Object.fromEntries(cellsInRow(ws,r,X).map(([c,v])=>[norm(v),c]));if(required.every(x=>x in h))return {r,h}}return null}
function wipSheetKind(name){
 const value=norm(name);
 // Auxiliary exports can repeat active products. Their schema alone is not
 // evidence that they are another current register to add to total demand.
 if(/delaycause|tefr|nameplate|serialplate/.test(value))return 'auxiliary';
 if(/history|historical|archive|closed|completed|shipped|dispatch/.test(value))return 'history';
 if(/summary|pivot|chart/.test(value)||/^wip(?:aging|ageing)$/.test(value))return 'summary';
 return /^inhouse$|^wip[ _-]/i.test(name)||['inhousefanrepair','faninhouse','cdu50shelf'].includes(value)?'supported':'other';
}
function wipWaiting(status){return /waitingfor(component|module)/.test(norm(status))}
// Derive impact from preserved evidence, including v1.60 imports. Never clear
// the original duplicate audit or select one conflicting demand as the truth.
function wipIntegrity(source={}){
 const details=source.duplicateDetails||[],affected=new Set(),conflicted=new Set(),informational=[];
 let globalBlocked=(source.sheetAudit||[]).some(a=>a.reviewRequired),unlocated=false;
 const covered=new Set(details.map(d=>d.key));
 if((source.duplicates||[]).some(key=>!covered.has(key)))globalBlocked=true;
 if(source.wipImportComplete===false&&!details.length)globalBlocked=true;
 for(const d of details){
  if(d.kind==='identical'||!wipWaiting(d.selected?.status)&&!wipWaiting(d.ignored?.status)){informational.push(d);continue;}
  conflicted.add(d.key);
  for(const row of [d.selected,d.ignored].filter(r=>wipWaiting(r?.status))){
   const tokens=partTokens(row.required),parts=Object.keys(tokens.parts);parts.forEach(p=>affected.add(p));
   if(!parts.length&&!tokens.excludedNameplate||tokens.unparsed)unlocated=true;
  }
 }
 globalBlocked ||= unlocated;
 return {globalBlocked,affectedParts:[...affected],conflictedKeys:[...conflicted],informational,
  demandComplete:!globalBlocked&&!affected.size,productsComplete:!globalBlocked&&!conflicted.size};
}
function importWorkbook(wb,name,X,options={}){
 const out=[],warnings=[],sheetAudit=[],wipGroups=new Map(),detectedFileDate=(/open[ _-]*po[ _-]*report[^0-9]*(\d{6})(?=[._ -]|$)/i.test(name)?scheduleDate(name.match(/open[ _-]*po[ _-]*report[^0-9]*(\d{6})(?=[._ -]|$)/i)[1],'dmy'):fileDate(name)),hasManualDate=options.date!=null&&str(options.date)!=='',manualDate=hasManualDate?date(options.date):null;
 if(hasManualDate&&(!manualDate||manualDate!==str(options.date)))throw Error(name+': 지정 기준일은 유효한 YYYY-MM-DD 날짜여야 합니다.');
 const detectedDate=manualDate||detectedFileDate,baseDateBasis=manualDate?'manual':detectedFileDate?'filename':'unconfirmed';
 const mk=(type,center,operator,sheet,rows,extra={})=>({type,center,operator:operator||'',file:name,sheet,date:detectedDate,dateLabel:detectedDate||name.match(/WK\s*\d+/i)?.[0]||'기준일 미확인',detectedFileDate,dateBasis:baseDateBasis,manualDate,importedAt:new Date().toISOString(),rows,...extra});
 const requested=options.type||null;
 const dashName=(!requested||requested==='dashboard')&&(wb.SheetNames.find(s=>/component[ _-]*dashboard/i.test(s))||(requested==='dashboard'?wb.SheetNames.find(s=>header(wb.Sheets[s],X,['samsungpart'],2)):null));let center=options.center||(dashName?/ctdi/i.test(dashName)?'CTDI':'Flex':/airtel|vodafone|samsung4g|ctdi/i.test(name)?'CTDI':null);
 if(dashName){const ws=wb.Sheets[dashName],h1=cellsInRow(ws,0,X),h2=cellsInRow(ws,1,X);const find1=fn=>h1.find(([c,v])=>fn(norm(v)))?.[0];const pcol=find1(s=>s==='samsungpart');const usage=find1(s=>s.startsWith('componentusage')),inflow=find1(s=>s.startsWith('monthlyinflow')),hold=find1(s=>s.startsWith('waitingcomponent')||s.startsWith('holdcomponent'));const own=find1(s=>center==='Flex'?s==='flex':s.startsWith('ctdi20'));const stock=h2.find(([c,v])=>c>=own&&norm(v)==='stock')?.[0],po=h2.find(([c,v])=>c>=own&&norm(v)==='openpo')?.[0];
  if([pcol,usage,inflow,stock,po].some(v=>v==null))throw Error(name+': 대시보드 핵심 헤더를 찾지 못했습니다.');
  const months=h2.filter(([c,v])=>c>=usage&&c<inflow&&month(v)).map(([c,v])=>({c,month:month(v)}));const holds=h2.filter(([c,v])=>c>=hold&&c<stock&&date(v)).sort((a,b)=>date(a[1]).localeCompare(date(b[1])));const hc=holds.at(-1);
  const inflowMonths=h2.filter(([c,v])=>c>=inflow&&(hold==null||c<hold)&&month(v)).map(([c,v])=>({c,month:month(v)}));
  const centerCodeCol=h1.find(([c,v])=>norm(v)==='ctdipart'||norm(v)==='flexpart')?.[0];
  const rows=rowsFor(ws,pcol,3,X).map(r=>({part:materialCode(get(ws,r,pcol,X)),rawPart:String(get(ws,r,pcol,X)??''),centerCode:str(get(ws,r,centerCodeCol,X)),description:str(get(ws,r,2,X)),stock:num(get(ws,r,stock,X)),po:num(get(ws,r,po,X)),usage:Object.fromEntries(months.map(m=>[m.month,num(get(ws,r,m.c,X))])),inflow:Object.fromEntries(inflowMonths.map(m=>[m.month,num(get(ws,r,m.c,X))])),hold:hc?num(get(ws,r,hc[0],X)):null,row:r+1}));
  // A center-labelled stock header is a snapshot date. Hold dates alone
  // describe demand and must never be promoted to the stock source date.
  const headerText=str(h1.find(([c])=>c===own)?.[1]),headerMatch=headerText.match(/^(?:CTDI|FLEX)[\s_-]*(20\d{2}[-/.]?\d{2}[-/.]?\d{2})(?:\s*\(or Latest date\))?$/i),headerDate=headerMatch?fileDate(headerMatch[1]):null,dashboardDate=detectedDate||headerDate;
  out.push(mk('dashboard',center,'',dashName,rows,{date:dashboardDate,dateLabel:dashboardDate||'기준일 미확인',dateBasis:detectedDate?baseDateBasis:headerDate?'dashboard-header':'unconfirmed',headerDate,headerDateCell:headerDate?X.utils.encode_cell({r:0,c:own}):null,holdDate:hc?date(hc[1]):null,usageMonths:months.map(m=>m.month)}));
 }
 for(const sn of wb.SheetNames){const ws=wb.Sheets[sn];if(sn===dashName){sheetAudit.push({sheet:sn,status:'other-source',kind:'dashboard',reason:'센터 대시보드로 반영'});continue}
  const siel=(!requested||requested==='siel')&&Siel?.parseSheet(ws,sn,X,{norm,materialCode,num,date});if(siel){warnings.push(...siel.warnings.map(message=>name+' / '+message));sheetAudit.push({sheet:sn,status:'other-source',kind:'siel',reason:'법인→본사 PO 상세 · 센터 재고/PO 합산 제외',headerRow:siel.headerRow,totalRows:siel.rows.length});out.push(mk('siel','','',sn,siel.rows,{sourceDate:detectedDate,receiptConfirmed:false,allocationConfirmed:false}));continue}
  const ih=(!requested||['india','hq'].includes(requested))&&header(ws,X,['material']);if(ih){const q=ih.h.qty??ih.h.unrstock;if(q!=null){const kind=ih.h.unrstock!=null?'india':'hq';const rows=rowsFor(ws,ih.h.material,ih.r+1,X).map(r=>({part:materialCode(get(ws,r,ih.h.material,X)),rawPart:String(get(ws,r,ih.h.material,X)??''),description:str(get(ws,r,ih.h.description??ih.h.materialdescription,X)),qty:num(get(ws,r,q,X)),prime:str(get(ws,r,ih.h.primematerial,X)),row:r+1}));sheetAudit.push({sheet:sn,status:'other-source',kind,reason:'재고 자료로 반영',headerRow:ih.r+1,totalRows:rows.length});out.push(mk(kind,'','',sn,rows));continue}}
  const ph=(!requested||requested==='po')&&header(ws,X,['pendingqty','partno']);if(ph){const h=ph.h,at=(r,k)=>get(ws,r,h[k],X);const centerName=str(at(ph.r+1,'shiptoname'));const pc=options.center||(/communications|ctdi/i.test(centerName)?'CTDI':/flex/i.test(centerName)?'Flex':center);if(!pc)throw Error(name+': PO 센터를 확인할 수 없습니다.');const labelled=/communications|ctdi/i.test(centerName)?'CTDI':/flex/i.test(centerName)?'Flex':null;if(options.center&&labelled&&options.center!==labelled)throw Error(name+': 선택한 센터와 Ship-to 센터가 다릅니다.');const etdcols=Object.entries(h).filter(([k])=>k.startsWith('etd')).map(([,c])=>c).sort((a,b)=>a-b);const order=pc==='Flex'?'mdy':'dmy';const rows=rowsFor(ws,h.partno,ph.r+1,X).map(r=>({part:materialCode(at(r,'partno')),rawPart:str(at(r,'partno')),description:str(at(r,'description')),po:str(at(r,'pono')),item:str(at(r,'itemno')??at(r,'item')),shipto:str(at(r,'shipto')),ordered:num(at(r,'poqty')),shipped:num(at(r,'shippedqty')),pending:num(at(r,'pendingqty')),poDate:date(at(r,'podate'),order),age:num(at(r,'pendingaging')),status:str(at(r,'status')),etd:scheduleDate(get(ws,r,etdcols.at(-1),X),order),etdRaw:str(get(ws,r,etdcols.at(-1),X)),oldEtd:etdcols.length>1?scheduleDate(get(ws,r,etdcols[0],X),order):null,etdHistoryAvailable:etdcols.length>1,row:r+1}));let inferred=[...new Set(rows.filter(r=>r.poDate&&Number.isInteger(r.age)&&r.age>=0&&r.age<=36500).map(r=>new Date(new Date(r.poDate).getTime()+r.age*DAY).toISOString().slice(0,10)))];const inferredDate=inferred.length===1?inferred[0]:null;sheetAudit.push({sheet:sn,status:'other-source',kind:'po',reason:'PO 자료로 반영',headerRow:ph.r+1,totalRows:rows.length});out.push(mk('po',pc,'',sn,rows,{date:detectedDate||inferredDate,dateLabel:detectedDate||inferredDate||'기준일 미확인',dateBasis:detectedDate?baseDateBasis:inferredDate?'po-aging':'unconfirmed',inferredDate}));continue}
  if(requested&&requested!=='wip')continue;
  let kind=wipSheetKind(sn);const requiredHeaders=['finalstatus','requiredpart','serialno','rmano'],wh=header(ws,X,requiredHeaders),partial=wh||header(ws,X,['finalstatus','requiredpart'])||header(ws,X,['finalstatus','serialno'])||header(ws,X,['finalstatus','rmano']);
  if(requested==='wip'&&kind==='other'&&wh)kind='supported';
  if(kind==='supported'&&!wh)throw Error(name+' / '+sn+': WIP 필수 헤더(Final Status, Required Part, Serial No, RMA No)를 찾지 못했습니다. 이 시트를 제외하고 필요량을 0으로 판단하지 않습니다.');
  const h=partial?.h,sourceRows=partial?rowsFor(ws,h.serialno??h.rmano??h.finalstatus,partial.r+1,X):[],details=sourceRows.map(r=>{const at=k=>get(ws,r,h[k],X),snr=str(at('serialno')),rma=str(at('rmano'));return {key:snr+'|'+rma,sn:snr,rma,status:str(at('finalstatus')),required:str(at('requiredpart')),tokens:partTokens(at('requiredpart')),receipt:date(at('physicalreceiptdate'),'mdy'),fert:str(at('fert')),family:str(at('family')),sheet:sn,row:r+1}}),waiting=details.filter(r=>wipWaiting(r.status));
  const audit={sheet:sn,kind,status:kind==='supported'?'included':'excluded',reason:kind==='supported'?'현재 WIP 상세 반영':kind==='auxiliary'?'보조·원인 분석 시트 — 제품 중복 합산 제외':kind==='history'?'출고·과거 이력 시트 — 현재 WIP 합산 제외':kind==='summary'?'요약·집계 시트 — 상세 제품 중복 합산 제외':partial?'등록되지 않은 WIP 상세 양식 — 반영 범위 확인':'WIP 상세 헤더 없음',headerRow:partial?partial.r+1:null,totalRows:details.length,waitingRows:waiting.length,requiredRows:details.filter(r=>r.required).length,waitingQuantity:sum(waiting.map(r=>sum(Object.values(r.tokens.parts)))),waitingUnparsedRows:waiting.filter(r=>r.tokens.unparsed||!Object.keys(r.tokens.parts).length).length,reviewRequired:kind==='other'&&waiting.length>0};sheetAudit.push(audit);
  if(kind!=='supported')continue;
  let op=options.operator||(/airtel/i.test(name+' '+sn)?'Airtel':/vodafone|(?:^|[\s_-])vi(?:$|[\s_.-])/i.test(name+' '+sn)?'Vi':/samsung4g|jio/i.test(name+' '+sn)?'Jio':center==='Flex'||/samsung wip/i.test(name)?'Jio':'');let wc=center||(/samsung wip/i.test(name)?'Flex':null);if(!wc)throw Error(name+': WIP 센터를 지정해 주세요.');if(wc==='CTDI'&&!op)throw Error(name+': CTDI WIP 사업자를 지정해 주세요.');
  op=canonicalOperator(wc,op);const key=wc+'|'+op;let bundle=wipGroups.get(key);if(!bundle){bundle={center:wc,operator:op,sheets:[],records:[],statuses:{},seen:new Map(),duplicates:[],duplicateDetails:[]};wipGroups.set(key,bundle)}bundle.sheets.push(sn);
  for(const record of details){const previous=bundle.seen.get(record.key);if(previous){const exact=['status','required','receipt','fert','family'].every(field=>previous[field]===record[field]),crossSheet=previous.sheet!==record.sheet;bundle.duplicateDetails.push({key:record.key,kind:exact?'identical':'conflicting',crossSheet,selected:{sheet:previous.sheet,row:previous.row,status:previous.status,required:previous.required,receipt:previous.receipt,fert:previous.fert,family:previous.family},ignored:{sheet:record.sheet,row:record.row,status:record.status,required:record.required,receipt:record.receipt,fert:record.fert,family:record.family}});if(!crossSheet||!exact)bundle.duplicates.push(record.key);continue}bundle.seen.set(record.key,record);bundle.statuses[record.key]=record.status;if(wipWaiting(record.status))bundle.records.push(record)}
 }
 for(const bundle of wipGroups.values()){
  const excluded=sheetAudit.filter(a=>a.reviewRequired),importWarnings=excluded.map(a=>`${name} / ${a.sheet}: 미지원 WIP 상세에 자재대기 ${a.waitingRows}행 — 반영 범위 확인 필요`);
  for(const issue of bundle.duplicateDetails)importWarnings.push(`${name}: WIP ${issue.kind==='identical'?'동일':'값 불일치'} 중복 — ${issue.selected.sheet} ${issue.selected.row}행 사용 / ${issue.ignored.sheet} ${issue.ignored.row}행 제외`);
  warnings.push(...importWarnings);out.push(mk('wip',bundle.center,bundle.operator,bundle.sheets.join(' + '),bundle.records,{sheets:bundle.sheets,sheetAudit,importWarnings,wipImportComplete:!excluded.length&&!bundle.duplicates.length,statuses:bundle.statuses,total:bundle.seen.size,duplicates:bundle.duplicates,duplicateDetails:bundle.duplicateDetails}));
 }
 if(requested&&out.some(s=>s.type!==requested||(options.center&&s.center!==options.center)||(options.operator&&s.type==='wip'&&s.operator!==canonicalOperator(options.center,options.operator))))throw Error(name+': 선택한 자료 칸과 원본 양식이 다릅니다.');
 if(!out.length)throw Error(name+': 지원 원본 시트/헤더를 찾지 못했습니다. 기존 양식 또는 WIP_<사업자> 탭을 확인하세요.');
 for(const s of out){
  if(options.reportWeek&&!s.date)Object.assign(s,assignReportWeek(s,options.reportWeek));
  const diagnostics=[];
  if(s.headerDate&&s.date&&s.headerDate!==s.date)diagnostics.push({type:'dashboard-header-date-conflict',sourceDate:s.date,headerDate:s.headerDate,cell:s.headerDateCell,message:`${name} / ${s.sheet}: 적용 기준일 ${s.date}, 센터 재고 헤더 ${s.headerDate} (${s.headerDateCell}) — 기준일 확인 필요`});
  if(s.manualDate&&s.detectedFileDate&&s.manualDate!==s.detectedFileDate)diagnostics.push({type:'manual-file-date-override',sourceDate:s.date,detectedFileDate:s.detectedFileDate,resolvedByManualDate:true,message:`${name}: 파일명 날짜 ${s.detectedFileDate}, 사용자 지정 기준일 ${s.manualDate} 적용`});
  if(s.type==='dashboard'&&s.date&&s.holdDate&&s.holdDate>s.date)diagnostics.push({type:'dashboard-hold-after-source-date',sourceDate:s.date,holdDate:s.holdDate,message:`${name} / ${s.sheet}: Hold 날짜 ${s.holdDate}가 적용 기준일 ${s.date} 이후 — 기준일 확인 필요`});
  if(s.type==='po'){
   if(s.inferredDate&&s.date&&s.inferredDate!==s.date)diagnostics.push({type:'po-aging-date-conflict',sourceDate:s.date,inferredDate:s.inferredDate,message:`${name} / ${s.sheet}: 적용 기준일 ${s.date}, PO 발주일+Aging 역산 ${s.inferredDate} — 기준일 확인 필요`});
   const futureRows=s.date?s.rows.filter(row=>row.poDate&&row.poDate>s.date):[];
   if(futureRows.length)diagnostics.push({type:'po-order-after-source-date',sourceDate:s.date,rows:futureRows.map(row=>row.row),message:`${name} / ${s.sheet}: 적용 기준일 ${s.date} 이후 발주 ${futureRows.length}행 (${futureRows.map(row=>row.row).join(', ')}) — 발주일·기준일 확인 필요`});
  }
  s.dateDiagnostics=diagnostics;warnings.push(...diagnostics.map(item=>item.message));
  if(!s.date)warnings.push(sourceSelectionDate(s)?`${name}: ${s.reportWeek}주 자료로 사용 · 정확한 측정일 미확인`:`${name}: 기준일 미확인 — 실제 날짜 또는 비WIP 자료의 보고 주차 지정`);
  s.id=sourceKey(s);for(const d of sourceDuplicateDiagnostics(s))warnings.push(`${name} / ${s.sheet}: ${d.part} 중복 원본행 ${d.rows.join(', ')} — 맨 위 ${d.selectedRow}행 사용, ${d.ignoredRows.join(', ')}행 제외`)
 }
 return {sources:out,warnings,sheetAudit};
}
function merge(state,sources){const s=JSON.parse(JSON.stringify(normalizeOperators(state)));for(const input of sources){const v=JSON.parse(JSON.stringify(input));v.operator=canonicalOperator(v.center,v.operator,v.type);v.id=sourceKey(v);v.revisedAt=new Date().toISOString();const i=s.sources.findIndex(x=>sourceKey(x)===v.id);if(i<0)s.sources.push(v);else s.sources[i]=v}return s}
function latest(sources,type,center,asof,operator){return sources.filter(s=>s.type===type&&(center==null||s.center===center)&&(operator==null||s.operator===operator)&&(!sourceSelectionDate(s)||sourceSelectionDate(s)<=asof)).sort((a,b)=>(sourceSelectionDate(a)||'').localeCompare(sourceSelectionDate(b)||'')).at(-1)}
function group(rows,key='part'){const m=Object.create(null);for(const r of rows){if(key==='part'&&isNameplate(r[key]))continue;const k=key==='part'?materialCode(r[key]):r[key];if(k)(m[k]??=[]).push(r)}return m}
function inventory(source){const out=Object.create(null);for(const [p,rs] of Object.entries(group(source?.rows||[]))){const selected=firstOriginalRow(rs);out[p]={qty:selected.qty??null,rows:rs.map(r=>r.row),duplicate:rs.length>1,selectedRow:selected.row,ignoredRows:rs.filter(r=>r!==selected).map(r=>r.row)}}return out}
function calculateCenters(state,asof,center='전체',operator='전체'){
 state=normalizeOperators(state);if(operator!=='전체')operator=canonicalOperator('',operator);
 const settings={...empty().settings,...state.settings},centers=center==='전체'?['Flex','CTDI']:[center],hqsource=latest(state.sources,'hq',null,asof),indiasource=latest(state.sources,'india',null,asof),hq=inventory(hqsource),india=inventory(indiasource);const parts=[],wip=[],pos=[],used=[],warnings=[],masterAlerts=[],duplicates=duplicateDiagnostics(state,asof,center);
 if(duplicates.length)warnings.push(`재고·대시보드 중복코드 ${duplicates.length}건 — 원본 맨 위 행만 사용. 상세 알림에서 파일·행 확인`);
 if(hqsource)used.push(hqsource);if(indiasource)used.push(indiasource);for(const source of [hqsource,indiasource].filter(Boolean)){if(!source.date)warnings.push(`${source.type==='india'?'법인':'본사'} 재고: ${source.dateLabel} / 정확한 기준일 미확인`)}
 for(const c of centers){const ds=latest(state.sources,'dashboard',c,asof),ps=latest(state.sources,'po',c,asof);let ops=[...new Set(state.sources.filter(s=>s.type==='wip'&&s.center===c).map(s=>s.operator))];const ws=ops.map(o=>latest(state.sources,'wip',c,asof,o)).filter(Boolean);[ds,ps,...ws].filter(Boolean).forEach(s=>used.push(s));
  if(!ds&&!ps&&!ws.length)continue;if(!ds)warnings.push(c+': 센터 재고·소요량 원본 없음');if(!ws.length)warnings.push(c+': WIP 원본 없음. 필요량 0으로 판단하지 않습니다.');
  const holdDateValid=!!(ds?.holdDate&&date(ds.holdDate)===ds.holdDate&&ds.holdDate<=asof&&(!ds.date||ds.holdDate<=ds.date));if(ds?.holdDate&&!holdDateValid)warnings.push(`${c}: Hold 기준일 ${ds.holdDate}가 원본·주간 기준일 이후이거나 잘못되어 제외 — 유효 WIP로 판단`);
  const completeWip=ws.length>0&&(c!=='CTDI'||['Jio','Airtel','Vi'].every(o=>ws.some(s=>s.operator===o)));const newestWip=ws.map(s=>s.date).filter(Boolean).sort().at(-1);const wipReady=completeWip&&ws.every(s=>s.date&&!wipIntegrity(s).globalBlocked)&&new Set(ws.map(s=>s.date)).size===1;const useHold=!!(holdDateValid&&(!wipReady||ds.holdDate>newestWip));const affectedParts=new Set(ws.flatMap(s=>wipIntegrity(s).affectedParts));
  if(!completeWip)warnings.push(c+': WIP 원본이 일부 누락되었습니다. WIP 기반 총수요·발주 확정 불가.');
  if(new Set(ws.map(s=>s.date)).size>1)warnings.push(c+': 사업자별 WIP 기준일이 서로 다릅니다.');
  if(useHold)warnings.push(`${c}: 센터 필요량은 대시보드 Hold ${ds.holdDate} 기준. 사업자별 상세는 WIP ${newestWip||'미확인'} 기준.`);
  for(const s of ws){const integrity=wipIntegrity(s);if(integrity.informational.length)warnings.push(`${c} ${s.operator}: WIP 중복 ${integrity.informational.length}건 — 동일 행 또는 자재대기 아님 · 수요 영향 없음`);if(!s.date)warnings.push(`${c} ${s.operator}: WIP 기준일 미확인`);warnings.push(...(s.importWarnings||[]));if(integrity.globalBlocked)warnings.push(`${c} ${s.operator}: WIP 반영 범위·중복 영향 품목 미확인 — 전체 필요량 확정 불가`);else if(integrity.affectedParts.length)warnings.push(`${c} ${s.operator}: 자재대기 중복 내용 충돌 — 해당 ${integrity.affectedParts.join(', ')} 필요량만 미확정`)}
  for(const s of ws){if(ds?.date&&s.date&&Math.abs(new Date(ds.date)-new Date(s.date))/DAY>7)warnings.push(`${c} ${s.operator}: WIP ${s.date} / 재고 ${ds.date} — 기준일 차이, 현재 실적 판단 주의`);}
  const wAll=ws.flatMap(s=>s.rows.map(r=>({...r,tokens:resolvedPartTokens(r),center:c,operator:s.operator,source:s.file,sheet:r.sheet||s.sheet,date:s.date,age:r.receipt&&s.date?Math.floor((new Date(s.date)-new Date(r.receipt))/DAY):null})));wip.push(...wAll.filter(r=>(operator==='전체'||r.operator===operator)&&!ws.some(s=>s.operator===r.operator&&wipIntegrity(s).conflictedKeys.includes(r.key))));
  const demand={},selectedDemand={};for(const r of wAll)for(const [p,q] of Object.entries(r.tokens.parts)){demand[p]=(demand[p]||0)+q;if(operator==='전체'||r.operator===operator)selectedDemand[p]=(selectedDemand[p]||0)+q}
  const dg=group(ds?.rows||[]),pg=group(ps?.rows||[]),poSummaries=Object.fromEntries(Object.entries(pg).map(([part,rows])=>[part,detailPoSummary(rows)]));pos.push(...Object.values(poSummaries).flatMap(x=>x.rows).map(p=>({...p,...poSchedule(p,ps.date),center:c,date:ps.date,source:ps.file,sheet:ps.sheet})));
  for(const summary of Object.values(poSummaries))for(const issue of summary.diagnostics)warnings.push(`${c} ${ps.file} / ${ps.sheet}: ${issue.message} (원본 ${issue.rows.join(', ')}행)`);
  if(ps?.inferredDate&&ps.date!==ps.inferredDate)warnings.push(`${c} PO: 파일 기준일 ${ps.date}, Aging 역산 ${ps.inferredDate} — 확인 필요`);
  const monthList=(ds?.usageMonths||[]).filter(m=>m<(ds?.date||sourceSelectionDate(ds)||asof).slice(0,7)).sort().slice(-settings.months);
  const monthAnchor=(ds?.date||sourceSelectionDate(ds)||asof).slice(0,7),[my,mm]=monthAnchor.split('-').map(Number),expectedMonths=Array.from({length:settings.months},(_,i)=>new Date(Date.UTC(my,mm-1-settings.months+i,1)).toISOString().slice(0,7));
  const usageWindowIssue=!!ds&&monthList.join('|')!==expectedMonths.join('|')?`사용량 기간 확인: 실제 ${monthList[0]||'없음'}~${monthList.at(-1)||'없음'} / 최근 완료 ${settings.months}개월 ${expectedMonths[0]}~${expectedMonths.at(-1)}와 다름`:'';if(usageWindowIssue)warnings.push(c+': '+usageWindowIssue);
  for(const p of new Set([...Object.keys(dg),...Object.keys(pg),...Object.keys(demand),...affectedParts])){
   const rows=dg[p]||[],d=firstOriginalRow(rows),poSummary=poSummaries[p],pRows=poSummary?.rows||[],pending=poSummary?poSummary.pending:null,poDiagnostics=poSummary?.diagnostics||[];
   const missingDashboardCode=!!ds&&!d,stockAssumedZero=missingDashboardCode,stock=d?d.stock??null:ds?0:null,rawPo=typeof d?.po==='number'&&Number.isFinite(d.po)&&d.po>=0?d.po:null,open=rawPo??(poSummary?pending:ps?0:null);
   const monthVals=d?monthList.map(m=>d.usage?.[m]):[],avg=d&&monthList.length===settings.months&&monthVals.every(v=>v!=null)?sum(monthVals)/monthList.length:null;
   const avgReason=avg!=null?'':!ds?'센터 대시보드 원본 없음':!d?'대시보드 누락 — 사용량 이력 보완 필요':monthList.length!==settings.months?'평균 계산기간 미충족':'월별 사용량 빈칸';
   const partUseHold=useHold&&!!d,needed=partUseHold?(d.hold??null):wipReady&&!affectedParts.has(p)?(demand[p]||0):null,selected=selectedDemand[p]||0;
   // WIP is an unresolved waiting status, not evidence of inventory consumption.
   const stockShortage=stock!=null&&needed!=null?Math.max(0,needed-stock):null;
   const wipWaitingQty=wipReady&&!affectedParts.has(p)?(demand[p]||0):null;
   const shortage=wipWaitingQty!=null?wipWaitingQty:stockShortage,shortageBasis=wipWaitingQty!=null?'wip-waiting':'inventory-gap',target=avg==null?null:Math.ceil(avg*effectiveTargetMonths(settings)),proposed=stock!=null&&needed!=null&&target!=null&&open!=null?Math.max(0,Math.ceil(needed+target-stock-open)):null;
   const indiaQty=india[p]?india[p].qty:indiasource?0:null,hqQty=hq[p]?hq[p].qty:hqsource?0:null;
   if(missingDashboardCode){const origins=[...pRows.map(x=>({type:'po',file:ps.file,sheet:ps.sheet,date:ps.date,row:x.row})),...wAll.filter(x=>Object.keys(x.tokens.parts).some(k=>materialCode(k)===p)).map(x=>({type:'wip',file:x.source,sheet:x.sheet,date:x.date,row:x.row,operator:x.operator}))];masterAlerts.push({type:'missing-dashboard-code',center:c,part:p,file:ds.file,sheet:ds.sheet,date:ds.date,stock:0,assumption:'센터 대시보드 누락 — 재고 0 가정',origins,reason:avgReason});}
   let issues=[];if(usageWindowIssue)issues.push(usageWindowIssue);if(ds?.holdDate&&!holdDateValid)issues.push('Hold 기준일 오류 — 유효 WIP 사용 또는 필요량 미확인');if(d?.po!=null&&rawPo==null)issues.push('대시보드 PO 수량 오류');issues.push(...poDiagnostics.map(x=>x.message));if(rows.length>1)issues.push('센터 중복코드');if(missingDashboardCode)issues.push('센터 대시보드 누락 — 재고 0 가정');if(stock==null)issues.push('센터 재고 미확인');if(avg==null)issues.push('월 소요량 미확인');if(rawPo!=null&&pending!=null&&rawPo!==pending)issues.push('PO 잔량 불일치');if(rawPo>0&&!pRows.length)issues.push('상세 PO 미매칭');if(india[p]?.duplicate)issues.push('법인 중복코드');if(hq[p]?.duplicate)issues.push('본사 중복코드');if(!wipReady&&!partUseHold)issues.push('WIP 누락·날짜·반영 범위 미확인');if(affectedParts.has(p)&&!partUseHold)issues.push('해당 부품 WIP 중복 내용 충돌');if(needed==null)issues.push('필요량 미확인');if(wipWaitingQty>0&&stock>0)issues.push('센터 재고 있음 · WIP 자재대기 확인 필요');
   const orderNeeds=orderBreakdown({stock,needed,open,proposed,avg}),schedule=summarizePoSchedule(pRows.map(row=>({...row,center:c,source:ps?.file,sheet:ps?.sheet,date:ps?.date})),ps?.date);
   let action=stock==null||needed==null?'—':shortage>0?(proposed>0?'부품 공급·추가 발주 필요':open>0?'기존 PO 긴급 입고 필요':'부품 공급 필요'):proposed>0?'추가 발주 필요':proposed==null?'—':waitingCovered({stock,needed,target,open,proposed})?'기존 PO 입고 대기':'현재 부족·추가 발주 없음';
   if(wipWaitingQty>0&&stock>0)action='센터 재고·WIP 자재대기 확인 필요';
   const etd=pRows.filter(r=>r.etd).map(r=>r.etd).sort()[0]||null;parts.push({center:c,part:p,description:d?.description||pRows[0]?.description||'',stock,stockAssumedZero,missingDashboardCode,needed,selected,wipNeeded:completeWip?(demand[p]||0):null,needBasis:partUseHold?'dashboard':'wip',needDate:partUseHold?ds.holdDate:ws.map(s=>s.date).filter(Boolean).sort()[0]||null,shortage,shortageBasis,wipWaitingQty,stockShortage,avg,avgReason,target,open,poOrdered:poSummary?poSummary.ordered:ps?0:null,poOrderedReason:poSummary?poSummary.orderedReason:(ps?'상세 PO 전체 목록에 해당 자재 없음 — 0개 적용':'상세 PO 원본 없음'),poSourceDate:ps?.date??null,poSourceFile:ps?.file??null,poSourceSheet:ps?.sheet??null,detailPending:pending,poDiagnostics,usageWindowIssue,proposed,...orderNeeds,poSchedule:schedule,india:indiaQty,hq:hqQty,coverage:stock!=null&&needed!=null&&avg>0?Math.max(0,stock-needed)/avg*30:null,etd,action,issues,dashboardHold:d?.hold??null,dashboardDate:ds?.date,wipDate:ws.map(s=>s.date).filter(Boolean).sort()[0]||null,sourceRows:rows.map(r=>r.row),selectedSourceRow:d?.row??null,ignoredSourceRows:rows.filter(x=>x!==d).map(x=>x.row),duplicatePolicy:rows.length>1?'first-row':null,usageMonths:monthList,poRows:pRows.length,score:(shortage>0?100000:0)+(proposed>0?10000:0)+(shortage||0)});
  }
 }
 if(masterAlerts.length)warnings.push(`센터 대시보드 누락 ${masterAlerts.length}종 — WIP·PO에만 있는 부품은 재고 0 가정, 사용량 이력 보완 필요`);
 const selectedParts=operator==='전체'?parts:parts.filter(p=>p.selected>0||(p.center==='Flex'&&operator==='Jio'));return {duplicateDiagnostics:duplicates,masterAlerts,parts:selectedParts.sort((a,b)=>b.score-a.score||a.part.localeCompare(b.part)),wip,pos,used:[...new Map(used.map(s=>[s.id,s])).values()],warnings:[...new Set(warnings)],allParts:parts};
}
function effectiveSupportMonths(settings={},type='india'){const v=num(settings[type+'Months']);return v!=null&&(type==='india'?v>=0:v>0)?v:type==='hq'?3:0}
function commonSupport(state,asof,centerParts){
 const settings={...empty().settings,...state.settings},count=Math.max(1,Math.floor(num(settings.months)||6)),centers=['Flex','CTDI'];
 const dashboards=Object.fromEntries(centers.map(c=>[c,latest(state.sources,'dashboard',c,asof)])),sources={india:latest(state.sources,'india',null,asof),hq:latest(state.sources,'hq',null,asof)},stocks={india:inventory(sources.india),hq:inventory(sources.hq)};
 const dated=centers.every(c=>sourceSelectionDate(dashboards[c])),availableDates=centers.map(c=>dashboards[c]?.date||sourceSelectionDate(dashboards[c])).filter(Boolean).sort(),cutoff=availableDates.length?availableDates[0].slice(0,7):null,months=[];
 if(cutoff){const [year,mo]=cutoff.split('-').map(Number);for(let i=count;i>0;i--)months.push(new Date(Date.UTC(year,mo-1-i,1)).toISOString().slice(0,7))}
 const rawParts=centerParts||calculateCenters(state,asof).allParts,byCenter=Object.fromEntries(centers.map(c=>[c,new Map(rawParts.filter(p=>p.center===c).map(p=>[p.part,p]))])),dashboardMaps=Object.fromEntries(centers.map(c=>[c,new Map(selectDashboardRows(dashboards[c]).map(r=>[materialCode(r.part),r]))]));
 const sourceDates={Flex:dashboards.Flex?.date||null,CTDI:dashboards.CTDI?.date||null,india:sources.india?.date||null,hq:sources.hq?.date||null};
 const warnings=[];if(!dated)warnings.push('두 센터 대시보드와 기준일이 모두 있어야 동일 기간 인도 소요량을 계산할 수 있습니다.');
 if(dated&&dashboards.Flex.date!==dashboards.CTDI.date)warnings.push('센터 대시보드 기준일이 다릅니다. 인도 소요량은 이른 기준일 직전의 동일 완결월로 비교합니다.');
 if(!sources.india)warnings.push('법인 재고 원본 없음 — 재고 0으로 판단하지 않습니다.');if(!sources.hq)warnings.push('본사 재고 원본 없음 — 재고 0으로 판단하지 않습니다.');
 const dateIssues=[];if(new Set(Object.values(sourceDates).filter(Boolean)).size>1)dateIssues.push('거점 재고 기준일이 다름 — 각 원본 기준일 확인');for(const type of ['india','hq'])if(sources[type]&&!sources[type].date)dateIssues.push((type==='india'?'법인':'본사')+' 재고 정확한 기준일 미확인');warnings.push(...dateIssues);
 const parts=[];
 for(const part of [...new Set(rawParts.map(p=>p.part))].sort()){
  const contributions=centers.map(center=>{const source=dashboards[center],row=dashboardMaps[center].get(part),inScope=byCenter[center].has(part);let avg=null,reason='';
   if(!source)reason='센터 대시보드 원본 없음';else if(!sourceSelectionDate(source)||!cutoff)reason='대시보드 기준일 미확인';else if(!inScope)avg=0;else if(!row)reason='대시보드 누락 — 사용량 이력 보완 필요';else if(months.some(m=>!(source.usageMonths||[]).includes(m)))reason='동일 완결월 사용량 이력 부족';else if(months.some(m=>row.usage?.[m]==null))reason='동일 완결월 사용량 빈칸';else avg=sum(months.map(m=>row.usage[m]))/months.length;
   return {center,inScope,scopeLabel:inScope?'현재 자료의 관리 대상':'현재 자료의 관리 대상 없음',avg,reason,source:source?.file||null,sheet:source?.sheet||null,selectedRow:row?.row??null,sourceDate:source?.date||null};
  });
  const complete=contributions.every(c=>c.avg!=null),known=sum(contributions.map(c=>c.avg)),demand=complete?known:null,india=stocks.india[part]?.qty??(stocks.india[part]?null:sources.india?0:null),hq=stocks.hq[part]?.qty??(stocks.hq[part]?null:sources.hq?0:null);
  const local=centers.map(c=>byCenter[c].get(part)).filter(Boolean),shortageComplete=centers.every(c=>!!dashboards[c])&&local.every(p=>p.shortage!=null),shortageKnownSubtotal=sum(local.map(p=>p.shortage)),immediateShortage=shortageComplete?shortageKnownSubtotal:null;
  const pendingComplete=centers.every(c=>!!dashboards[c])&&local.every(p=>p.open!=null),centerPendingKnownSubtotal=sum(local.map(p=>p.open)),centerPending=pendingComplete?centerPendingKnownSubtotal:null,proposedComplete=centers.every(c=>!!dashboards[c])&&local.every(p=>p.proposed!=null),centerProposed=proposedComplete?sum(local.map(p=>p.proposed)):null;
  const indiaTarget=demand==null?null:Math.ceil(demand*effectiveSupportMonths(settings,'india')),hqTarget=demand==null?null:Math.ceil(demand*effectiveSupportMonths(settings,'hq')),indiaGap=indiaTarget!=null&&india!=null?Math.max(0,indiaTarget-india):null,hqGap=hqTarget!=null&&hq!=null?Math.max(0,hqTarget-hq):null;
  const issues=[...dateIssues];for(const c of contributions)if(c.reason)issues.push(c.center+': '+c.reason);if(india==null)issues.push('법인 재고 미확인');if(hq==null)issues.push('본사 재고 미확인');if(!shortageComplete)issues.push('센터 현 수리 필요 수 일부 미확인');
  const indiaInsufficient=immediateShortage!=null&&india!=null?immediateShortage>india:null,commonInsufficient=immediateShortage!=null&&india!=null&&hq!=null?immediateShortage>india+hq:null;
  if(commonInsufficient)issues.push('공통재고 부족 — 필요에 따라 우선순위 결정');
  const active=known>0||local.some(p=>(p.needed||0)>0||(p.open||0)>0||(p.proposed||0)>0||p.missingDashboardCode||p.stock==null||p.avg==null);
  let action=active?'참고 기준 이상':'최근 사용·요청 없음',owner='모니터링',level='normal';
  if(shortageKnownSubtotal>0){level='urgent';if(india>0&&india<shortageKnownSubtotal){action='법인 공급·본사 추가 공급 확인';owner='법인·본사'}else if(india>0){action='법인 공급 확인';owner='법인'}else if(india===0&&hq>0){action='본사 공급 확인';owner='법인·본사'}else if(india===0&&hq===0){action='재고·조달 확인';owner='법인·본사'}else{action='상위 재고 확인';owner='법인·본사'}}
  else if(active&&(!complete||!shortageComplete||india==null||hq==null)){action='계산 근거 확인';owner='데이터 담당';level='data'}
  else if(centerProposed>0){action='센터 추가 PO 검토';owner='센터·법인';level='review'}
  else if(active&&indiaGap>0){action='법인 보충 진행 확인';owner='법인';level='reference'}
  else if(active&&hqGap>0){action='본사 공급 여유 확인';owner='본사';level='reference'}
  else if(centerPendingKnownSubtotal>0){action='기존 PO 공급 확인';owner='법인';level='review'}
  const centerBalances=local.map(p=>({center:p.center,stock:p.stock,stockAssumedZero:p.stockAssumedZero,needed:p.needed,needDate:p.needDate,needBasis:p.needBasis,shortage:p.shortage,open:p.open,dashboardDate:p.dashboardDate,wipDate:p.wipDate}));
  const inventorySources=Object.fromEntries(['india','hq'].map(type=>{const source=sources[type],item=stocks[type][part];return [type,{file:source?.file||null,sheet:source?.sheet||null,date:source?.date||null,dateLabel:source?.dateLabel||null,selectedRow:item?.selectedRow??null,ignoredRows:item?.ignoredRows||[],qty:type==='india'?india:hq,reason:!source?'재고 원본 없음':!item?'전체 재고목록에 코드 없음 — 0':item.qty==null?'선택행 수량 빈칸':item.duplicate?'중복코드 맨 위 행 사용':'원본 재고'}]}));
  parts.push({part,description:local.find(p=>p.description)?.description||'',centers:contributions,centerBalances,inventorySources,demand,demandKnownSubtotal:known,demandComplete:complete,india,hq,indiaTarget,hqTarget,indiaGap,hqGap,indiaCoverage:demand>0&&india!=null?india/demand:null,hqCoverage:demand>0&&hq!=null?hq/demand:null,immediateShortage,shortageKnownSubtotal,shortageComplete,centerPending,centerPendingKnownSubtotal,centerProposed,indiaInsufficient,commonInsufficient,active,action,owner,level,issues});
 }
 return {parts,months,windowStart:months[0]||null,windowEnd:months.at(-1)||null,demandComplete:dated&&parts.every(p=>p.demandComplete),sourceDates,settings:{months:count,indiaMonths:effectiveSupportMonths(settings,'india'),hqMonths:effectiveSupportMonths(settings,'hq')},warnings};
}
function calculate(state,asof,center='전체',operator='전체'){
 const result=calculateCenters(state,asof,center,operator);result.commonSupport=commonSupport(state,asof,center==='전체'?result.allParts:null);return result;
}
function trend(state,center,operator){state=normalizeOperators(state);if(operator!=='전체')operator=canonicalOperator('',operator);const groups={};for(const s of state.sources.filter(s=>s.type==='wip'&&(center==='전체'||s.center===center)&&(operator==='전체'||s.operator===operator)))(groups[s.center+'|'+s.operator]??=[]).push(s);const result=[];for(const arr of Object.values(groups)){arr.sort((a,b)=>(a.date||'').localeCompare(b.date||''));arr.forEach((s,i)=>{const prev=arr[i-1],now=new Set(s.rows.map(r=>r.key)),old=new Set(prev?.rows.map(r=>r.key)||[]);const exits=prev?prev.rows.filter(r=>!now.has(r.key)).map(r=>({key:r.key,status:s.statuses[r.key]||'이번 파일 없음'})):[];result.push({center:s.center,operator:s.operator,date:s.date,count:s.rows.length,component:s.rows.filter(r=>norm(r.status)==='waitingforcomponent').length,quantity:sum(s.rows.map(r=>sum(Object.values(resolvedPartTokens(r).parts)))),unmapped:s.rows.filter(r=>resolvedPartTokens(r).unparsed).length,entered:prev?s.rows.filter(r=>!old.has(r.key)).length:null,exited:prev?exits.length:null,exitStatuses:exits.map(r=>r.status).join(', '),previousDate:prev?.date||null})})}return result.sort((a,b)=>(b.date||'').localeCompare(a.date||''))}
return {scheduleDate,VERSION,CENTER_OPERATORS,canonicalOperator,operatorLabel,normalizeOperators,str,norm,num,date,fileDate,month,NAMEPLATE,isNameplate,materialCode,partTokens,resolvedPartTokens,empty,effectiveTargetMonths,effectiveTargetDays,effectiveSupportMonths,commonSupport,waitingCovered,orderBreakdown,poSchedule,summarizePoSchedule,detailPoSummary,sourceSelectionDate,assignReportWeek,sourceKey,wipIntegrity,wipWaiting,selectDashboardRows,sourceDuplicateDiagnostics,duplicateDiagnostics,importWorkbook,merge,calculate,trend,sum};
});
