(function(root,factory){if(typeof module==='object'&&module.exports)module.exports=factory(require('./core.js'),require('./reporting.js'));else root.PartsUploadFlow=factory(root.PartsCore,root.PartsReporting)})(typeof self!=='undefined'?self:this,function(C,R){
'use strict';
const baseName=name=>String(name||'').replace(/\\/g,'/').split('/').at(-1);
const isExcel=name=>/\.(xlsx|xls|xlsb)$/i.test(name||'')&&!/^~\$/.test(baseName(name));
const isZip=name=>/\.zip$/i.test(name||'');
function inspectSelection(input,{folder=false,language='ko'}={}){
 const files=[],issues=[],en=language==='en';
 for(const file of Array.from(input||[])){
  const path=String(file.partsImportPath||file.webkitRelativePath||file.name||'').replace(/\\/g,'/'),name=baseName(file.name||path);
  const unsafe=!path||path.includes('\0')||path.startsWith('/')||/^[A-Za-z]:/.test(path)||path.split('/').some(part=>part==='..');
  const temporary=/^~\$/.test(name)||path.split('/').includes('__MACOSX')||name.startsWith('._');
  if(unsafe||temporary||!isExcel(name)&&!isZip(name)){
   const reason=unsafe?'UNSAFE_PATH':temporary?'TEMPORARY_FILE':'UNSUPPORTED_FILE';
   issues.push({file:path||name,reason,excluded:true,message:en?(unsafe?'Invalid relative file path; skipped.':temporary?'Temporary file; skipped.':'Not an Excel or ZIP file; skipped.'):(unsafe?'올바르지 않은 상대 경로로 제외했습니다.':temporary?'임시 파일이라 제외했습니다.':'Excel·ZIP이 아닌 파일이라 제외했습니다.')});
   continue;
  }
  // Preserve the physical path so same-named workbooks in different folders
  // remain individually reviewable/cancellable. Never infer report dates from it.
  if(folder||file.webkitRelativePath||file.partsImportPath)file.partsImportPath=path;
  files.push(file);
 }
 return {files,issues};
}
async function collectDropFiles(dataTransfer,{limit=10000}={}){
 const items=Array.from(dataTransfer?.items||[]),entries=items.map(item=>typeof item.webkitGetAsEntry==='function'?item.webkitGetAsEntry():null);
 if(!entries.some(Boolean))return Array.from(dataTransfer?.files||[]);
 const files=[];
 async function visit(entry,parent=''){
  if(!entry)return;
  const path=parent?parent+'/'+entry.name:entry.name;
  if(entry.isFile){const file=await new Promise((resolve,reject)=>entry.file(resolve,reject));file.partsImportPath=path;files.push(file);if(files.length>limit)throw Error('폴더의 파일 수가 너무 많습니다. 한 주 자료만 선택하세요.');return;}
  if(entry.isDirectory){const reader=entry.createReader();for(;;){const batch=await new Promise((resolve,reject)=>reader.readEntries(resolve,reject));if(!batch.length)break;for(const child of batch)await visit(child,path);}}
 }
 for(let i=0;i<items.length;i++){if(entries[i])await visit(entries[i]);else{const file=items[i].getAsFile?.();if(file)files.push(file);}}
 return files;
}
function assignWeek(source,reportDate){
 const next={...source};
 if(!next.date&&next.type!=='wip'&&typeof C.assignReportWeek==='function')return C.assignReportWeek(next,R.weekStart(reportDate));
 return next;
}
function changeWeek(source,reportDate){
 if(source.datePrecision!=='week'||source.dateBasis!=='user-confirmed-week')return source;
 return C.assignReportWeek({...source},R.weekStart(reportDate));
}
function decodeEntry(entry,FileCtor,decode){
 if(!entry||!isExcel(entry.name)||typeof entry.base64!=='string')throw Error('ZIP의 Excel 항목을 읽을 수 없습니다.');
 const binary=decode(entry.base64),bytes=Uint8Array.from(binary,c=>c.charCodeAt(0));
 if(bytes.length!==entry.size)throw Error('ZIP 항목의 크기가 일치하지 않습니다.');
 const file=new FileCtor([bytes],entry.name,{type:'application/octet-stream'});
 file.partsImportPath=(entry.archiveName||'ZIP')+' / '+(entry.relativePath||entry.name);
 file.partsArchiveName=entry.archiveName||'';
 return file;
}
function sourceDateText(source,english=false){
 if(source?.date)return source.date;
 if(source?.reportWeek)return source.reportWeek+(english?' week (exact date unconfirmed)':'주 · 정확한 기준일 미확인');
 return english?'Source date required':'원본 기준일 필요';
}
return {isExcel,isZip,inspectSelection,collectDropFiles,assignWeek,changeWeek,decodeEntry,sourceDateText};
});
