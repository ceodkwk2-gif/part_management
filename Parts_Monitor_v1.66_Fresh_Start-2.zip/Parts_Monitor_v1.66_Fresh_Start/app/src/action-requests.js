(function(root,factory){
 if(typeof module==='object'&&module.exports)module.exports=factory(require('./stage-data.js'),require('./supply-stages.js'),require('./share-dialog.js'));
 else root.PartsActionRequests=factory(root.PartsStageData,root.PartsSupplyStages,root.PartsShareDialog);
})(typeof globalThis==='object'?globalThis:this,function(Data,Stages,Share){
'use strict';
const known=v=>typeof v==='number'&&Number.isFinite(v),sum=(a,k)=>a.reduce((s,r)=>s+(known(r[k])?r[k]:0),0);
const LABELS={ORDER:['수리센터 PO 부족','Center PO shortfall'],DISPATCH:['법인 재고 보유 · 센터 공급 대기','India stock available · awaiting center supply'],INDIA_ORDER:['법인 재고 부족 · 법인→본사 PO 미발주/부족','India stock shortfall · India-to-HQ PO missing/short'],HQ:['법인 재고 부족 · 본사 PO 발주됨','India stock shortfall · HQ PO placed'],WAIT:['센터 PO 잔량','Center PO balance'],OTHER:['수량·배정 미확정','Quantity / allocation unspecified']};
const role=code=>({ORDER:'CENTER',DISPATCH:'INDIA',INDIA_ORDER:'INDIA',HQ:'HQ',WAIT:'INDIA',OTHER:'REVIEW'})[code];
const text=(v,en)=>en?v[1]:v[0],number=(v,en)=>known(v)?v:en?'Unknown':'미확인';
const list=(rows,fn)=>rows.map(fn).filter(Boolean).join('\n');
function records(input,options={}){
 const data=Data.build(input),stages=Stages.classify(data.rows,data.siel),out=[];
 for(const r of data.rows){
  for(const a of Stages.statusRecords(r,stages.get(r.id)||[]))out.push({...a,row:r});
 }
 const ids=options.rowIds?new Set(options.rowIds):null;
 return out.filter(a=>(!options.center||options.center==='ALL'||a.center===options.center)&&(!ids||ids.has(a.rowId))&&(!options.action||['ALL','MULTI'].includes(options.action)||a.code===options.action)&&(!options.recipient||options.recipient==='all'||(a.basis==='center-stock-wip-review'?'CENTER':role(a.code))===options.recipient));
}
const REASONS={
 '센터 재고 있음 · WIP 자재대기 확인 필요':'Center stock reported · check WIP parts-waiting status',
 '센터 재고 미확인 · WIP 자재대기 확인 필요':'Center stock unknown · check WIP parts-waiting status',
 '법인 재고 없음 · 법인→본사 미발주':'No India stock · no India-to-HQ PO',
 '법인 재고 없음 · 법인→본사 PO 잔량 없음':'No India stock · no India-to-HQ PO balance',
 '법인 재고 없음 · 법인→본사 PO 수량 부족':'No India stock · India-to-HQ PO quantity shortfall',
 '법인 재고 부족 · 법인→본사 미발주':'India stock shortfall · no India-to-HQ PO',
 '법인 재고 부족 · 법인→본사 PO 잔량 없음':'India stock shortfall · no India-to-HQ PO balance',
 '법인 재고 부족 · 법인→본사 PO 수량 부족':'India stock shortfall · India-to-HQ PO quantity shortfall',
 '수리센터 PO 잔량 자료 없음':'Center PO balance unavailable',
 '재고표·상세 PO 잔량 차이 · 미발주 여부 미확인':'Dashboard / detailed PO balances differ',
 '재고표·상세 PO 잔량 차이 · 출고분 입고 여부 미확인':'Dashboard / detailed PO balances differ',
 '법인 재고 자료 없음·불일치':'India stock unavailable / inconsistent',
 '법인 공용 재고 있음 · 센터별 배정 없음':'Shared India stock available · center allocation unspecified',
 'SIEL PO Report 미제공':'SIEL PO Report unavailable',
 '법인 → 본사 PO 중복·수량 충돌':'India to HQ PO quantities conflict',
 '본사 PO 있음 · 발주 수량 미기재':'HQ PO exists · quantity missing',
 '본사 PO 발주됨 · 센터별 배정 없음':'HQ PO placed · center allocation unspecified',
 '재고표·상세 PO 잔량 불일치':'Dashboard / detailed PO balances differ'
};
const uniquePO=rows=>[...new Map(rows.map(p=>[JSON.stringify([p.po,p.item,p.part]),p])).values()];
function schedule(rows,key,qty,en){
 const groups=new Map();for(const p of rows){if(!p[key])continue;const old=groups.get(p[key]);groups.set(p[key],old===null||!known(p[qty])?null:(old||0)+p[qty]);}
 return [...groups].sort(([a],[b])=>a.localeCompare(b)).map(([date,q])=>date+(known(q)?' / '+q:'')).join('\n')||(en?'Not listed':'미기재');
}
function statusText(actions,en){
 const statuses=new Map();
 for(const a of actions){
  const label=a.code==='OTHER'?(en?REASONS[a.reason]||text(LABELS[a.code],en):a.reason):Stages.statusLabel(a,en);
  const key=label,old=statuses.get(key)||{quantity:0,repair:0,buffer:0,order:a.code==='ORDER',breakdown:true};
  old.quantity=known(a.quantity)&&known(old.quantity)?old.quantity+a.quantity:null;
  old.repair+=known(a.repairQuantity)?a.repairQuantity:0;old.buffer+=known(a.bufferQuantity)?a.bufferQuantity:0;
  old.breakdown &&= known(a.repairQuantity)&&known(a.bufferQuantity);statuses.set(key,old);
 }
 return [...statuses].map(([label,v])=>label+(known(v.quantity)?' '+v.quantity:'')+(v.order&&v.breakdown?' ('+(en?'repair ':'수리 ')+v.repair+' + '+(en?'buffer ':'보유 ')+v.buffer+')':'')).join('\n');
}
function etaSchedule(rows,en){
 if(!rows.length)return '—';
 const groups=new Map();for(const p of rows){const key=p.eta||'';const old=groups.get(key);groups.set(key,old===null||!known(p.ordered)?null:(old||0)+p.ordered);}
 return [...groups].sort(([a],[b])=>(a||'9999').localeCompare(b||'9999')).map(([date,q])=>(date||(en?'Arrival date not set':'도착 예정일 미정'))+(known(q)?' / '+q:'')).join('\n');
}

function build(input,options={}){
 const en=options.language==='en',t=(ko,english)=>en?english:ko,data=Data.build(input),scope=options.center||'ALL',recipient=options.recipient||'all';
 const selected=records(input,{...options,recipient:undefined}),groups=new Map();
 for(const a of selected){
  if(options.actionOnly&&recipient!=='all'&&(a.basis==='center-stock-wip-review'?'CENTER':role(a.code))!==recipient)continue;
  if(recipient==='INDIA'&&a.code==='ORDER')continue;
  if(['INDIA','HQ'].includes(recipient)&&a.basis==='center-stock-wip-review')continue;
  if(recipient==='HQ'&&a.code!=='HQ'&&!(a.code==='OTHER'&&a.row.siel.length))continue;
  const key=recipient==='HQ'?a.part:a.rowId;
  if(!groups.has(key))groups.set(key,{rows:new Map(),actions:[]});
  groups.get(key).rows.set(a.rowId,a.row);groups.get(key).actions.push(a);
 }
 // Explicit all-parts selections keep matching normal rows as status rows too.
 if(options.rowIds&&recipient==='all'&&['ALL','WAITING','OVERDUE','ORDER_ALL','UNKNOWN'].includes(options.kind))for(const r of data.rows){if(!options.rowIds.includes(r.id)||(scope!=='ALL'&&r.center!==scope)||groups.has(r.id))continue;groups.set(r.id,{rows:new Map([[r.id,r]]),actions:[]});}
 const defs={overdue:['45일 초과 필요 부품','Over-45-day required parts',21],center:['수리센터','Center',12],part:['자재코드','Part code',19],name:['부품명','Part name',27],needed:['수리 필요량','Repair need',13],stock:['센터 재고','Center stock',13],shortage:['수리 부족','Repair shortage',13],open:['센터 PO 잔량','Center open PO',15],proposed:['전체 추가 PO','Total additional PO',17],shipped:['센터행 출고누계','Shipped to center',16],etd:['출고 예정일 / 수량','ETD / qty',23],india:['법인 재고','India stock',13],hq:['본사 재고','HQ stock',13],hqPo:['법인→본사 발주량','India-to-HQ ordered qty',20],eta:['본사→법인 ETA / 수량','HQ-to-India ETA / qty',25],status:['필요 조치','Required action',35]};
 const centerOnly=recipient==='CENTER';
 const keys=recipient==='HQ'?['part','name','shortage','hq','hqPo','eta','status']:recipient==='INDIA'?['center','part','name','shortage','open','india','hqPo','eta','status']:centerOnly?['part','name','needed','stock','open','shipped','proposed','etd','status']:['center','part','name','needed','stock','shortage','open','india','hq','hqPo','eta','status'];
 if(centerOnly&&scope==='ALL')keys.unshift('center');
 if(options.kind==='OVERDUE')keys.splice(keys.indexOf(keys.includes('shortage')?'shortage':'needed')+1,0,'overdue');
 const columns=keys.map(key=>({key,label:text(defs[key],en),width:defs[key][2],raw:true}));
 const rows=[...groups.values()].map(g=>{
  const rs=[...g.rows.values()],r=rs[0],siel=uniquePO(rs.flatMap(r=>r.siel)),pos=rs.flatMap(r=>r.pos);
  const total=key=>rs.every(r=>known(r[key]))?sum(rs,key):null;
  const shared=key=>rs.every(r=>known(r[key])&&r[key]===rs[0][key])?rs[0][key]:null;
  const poQty=siel.length?siel.every(p=>known(p.ordered))?sum(siel,'ordered'):null:data.siel.available?0:null;
  return {overdue:number(total('over45Need'),en),center:rs.map(r=>r.center).join(' / '),part:r.part,name:r.name||'',needed:number(total('needed'),en),stock:number(total('stock'),en),shortage:number(total('shortage'),en),open:number(total('open'),en),proposed:number(total('proposed'),en),india:number(shared('india'),en),hq:number(shared('hq'),en),hqPo:number(poQty,en),shipped:number(pos.length&&pos.every(p=>known(p.shipped))?sum(pos,'shipped'):null,en),etd:schedule(pos.filter(p=>p.pending>0),'etd','pending',en),eta:etaSchedule(siel,en),status:(statusText(g.actions,en)||(rs.every(r=>known(r.shortage)&&r.shortage===0)?t('센터 재고로 충당','Covered by center stock'):t('센터 재고·수리 필요량 미확인','Center stock / repair need unavailable')))};
 }).sort((a,b)=>a.part.localeCompare(b.part)||a.center.localeCompare(b.center));
 const org=recipient==='HQ'?t('본사','HQ'):recipient==='INDIA'?t('법인','India'):scope==='ALL'?t('전체','All'):scope;
 return {title:org+t(' 자재 현황',' parts status'),sheetName:org+t(' 현황',' status'),localized:true,tableFormat:true,compact:true,includeGuide:false,columns,rows,reportDate:input.asof||'',partCount:new Set(rows.map(r=>r.part)).size,context:[t('보고 주차: ','Report week: ')+data.week],notes:[t('SIEL PO Report: ','SIEL PO Report: ')+(data.siel.sourceDate||t('미제공','unavailable')),t('법인·본사 재고와 PO는 공용 수량입니다. ETA는 본사→법인 도착 예정일이며 날짜 뒤 숫자는 발주량입니다. ETA 공란은 도착 예정일 미정입니다.','India / HQ stock and POs are shared. ETA is the planned arrival date from HQ to India; the number after each date is ordered quantity. Blank ETA means the arrival date has not been set.')]};
}
function open({data,center='ALL',rowIds,action='ALL',kind,scopeSelection=false,language='ko',download,XLSX}={}){
 const common={center,rowIds,action,kind};
 const tables=[['ALL','전체 현황','All status',{}],['CTDI','CTDI','CTDI',{center:'CTDI',recipient:'CENTER'}],['Flex','Flex','Flex',{center:'Flex',recipient:'CENTER'}],['INDIA','법인','India',{recipient:'INDIA'}],['HQ','본사','HQ',{recipient:'HQ'}]].filter(([id])=>center==='ALL'||!['Flex','CTDI'].includes(id)||id===center).map(([id,ko,en,filter])=>({id:'STATUS_'+id,label:l=>l==='en'?en:ko,recipients:false,build:({language:l,selectionScope='current'})=>{
  const full=scopeSelection&&selectionScope==='all',opts=full?{center}:common;
  const model=build(data,{...opts,...filter,actionOnly:scopeSelection,language:l});
  if(scopeSelection)model.context.push(l==='en'?(full?'Scope: all applicable parts in selected center':'Scope: current search / filter, all pages'):(full?'범위: 선택 센터의 전체 대상 품목':'범위: 현재 검색·필터, 모든 페이지'));
  return model;
 }}));
 return Share.open({tables,defaultLanguage:language,reportDate:data.asof||'',download,XLSX,tableLabel:scopeSelection?['대상','Organization']:undefined,scopeChoices:scopeSelection?[{id:'current',label:['현재 검색·필터 목록','Current search / filter']},{id:'all',label:['전체 대상 품목','All applicable parts']}]:undefined,defaultScope:'current',simple:scopeSelection});
}
function mountPanel(root,{data,center='ALL',language='ko',download,XLSX,state={}}={}){
 const en=language==='en',t=(a,b)=>en?b:a,esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const choices=[['ALL',t('전체','All'),{}],['CTDI','CTDI',{center:'CTDI',recipient:'CENTER'}],['Flex','Flex',{center:'Flex',recipient:'CENTER'}],['INDIA',t('법인','India'),{recipient:'INDIA'}],['HQ',t('본사','HQ'),{recipient:'HQ'}]].filter(([id])=>center==='ALL'||!['CTDI','Flex'].includes(id)||id===center);
 if(!choices.some(c=>c[0]===state.organization))state.organization=center==='ALL'?'ALL':center;
 state.page=state.page||1;let model;
 function render(){
  const choice=choices.find(c=>c[0]===state.organization);model=Share.normalize(build(data,{center,...choice[2],language}),{language});
  const pages=Math.max(1,Math.ceil(model.rows.length/20));state.page=Math.min(pages,state.page);
  root.innerHTML=`<section class="panel status-panel"><div class="panel-top"><h2>${t('업체별 자재 현황','Parts status by organization')}</h2></div><div class="panel-body"><div class="status-toolbar"><label>${t('업체','Organization')} <select id="status-organization">${choices.map(([id,label])=>`<option value="${id}" ${state.organization===id?'selected':''}>${esc(label)}</option>`).join('')}</select></label><button type="button" class="button primary" data-status-export="csv" ${model.rows.length?'':'disabled'}>CSV ${t('다운로드','download')}</button><button type="button" class="button" data-status-export="xlsx" ${model.rows.length?'':'disabled'}>Excel ${t('다운로드','download')}</button></div><p><b>${esc(model.title)} · ${model.partCount}${t('종',' types')} / ${model.rows.length}${t('행',' rows')}</b> · ${t('다운로드는 선택 업체의 전체 목록','Downloads include the entire selected list')}</p><div class="parts-share-table-wrap status-preview">${model.rows.length?Share.tableHTML({...model,rows:model.rows.slice((state.page-1)*20,state.page*20)}):t('해당 현황 없음','No matching status')}</div><div class="status-pager"><button type="button" class="button" data-status-step="-1" ${state.page===1?'disabled':''}>${t('이전','Previous')}</button><span>${state.page} / ${pages}</span><button type="button" class="button" data-status-step="1" ${state.page===pages?'disabled':''}>${t('다음','Next')}</button></div><p class="small">${model.notes.map(esc).join(' · ')}</p><p id="status-export-result" role="status"></p></div></section>`;
  root.querySelector('#status-organization').onchange=e=>{state.organization=e.target.value;state.page=1;render()};
 }
 async function click(e){const b=e.target.closest('button');if(!b||!root.contains(b)||b.disabled)return;
  if(b.dataset.statusStep){state.page+=Number(b.dataset.statusStep);render();return;}
  const kind=b.dataset.statusExport;if(!kind)return;
  try{await download(Share.fileName('STATUS_'+state.organization,language,data.week||data.asof,kind),kind==='csv'?Share.csv(model):Share.workbook([model],XLSX),kind==='csv'?'text/csv;charset=utf-8':'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');root.querySelector('#status-export-result').textContent=t('전체 목록 다운로드를 시작했습니다.','Full-list download started.');}
  catch(error){root.querySelector('#status-export-result').textContent=t('다운로드 실패: ','Download failed: ')+error.message;}
 }
 render();root.addEventListener('click',click);return {state,destroy(){root.removeEventListener('click',click)}};
}
return {build,records,open,mountPanel,LABELS,statusText};
});
