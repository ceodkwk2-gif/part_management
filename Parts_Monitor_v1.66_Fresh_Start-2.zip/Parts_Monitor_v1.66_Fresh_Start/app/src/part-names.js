(function(root,factory){
 if(typeof module==='object'&&module.exports)module.exports=factory();
 else root.PartsNames=factory();
})(typeof self!=='undefined'?self:this,function(){
'use strict';
// Display names only. Never change material identity, quantities or raw descriptions.
const VERSION=1,MISSING='명칭 없음';
const text=value=>value==null?'':String(value).trim();
const clean=value=>text(value).replace(/[\u00a0\t\r\n]+/g,' ').replace(/\s+/g,' ').trim();
const plate=value=>/^(?:NAME[\s_-]*PLATE|SERIAL\s*(?:#|NO\.?|NUMBER)?[\s_-]*PLATE|명판)$/i.test(clean(value));
const key=value=>plate(value)?'명판':clean(value).toUpperCase();
const escape=value=>String(value).replace(/[.*+?^${}()|[\]\\]/g,'\\$&');
const functional=/(?:\b(?:CAP|COVER|SCREW|LABEL|HANDLE|BRACKET|PLATE|HOUSING|FAN|CABLE|CONNECTOR|PAD|SHEET|BOARD|ASSY|MODULE|HEATSINK|FILTER|FUSE|SWITCH|RESISTOR|CAPACITOR|INDUCTOR|DIODE|TRANSISTOR|ORING|PISTON|NEEDLE|DISPENSER|HOSE|STAND)\b|(?:DUSTCAP|SCREW)$|명판)/i;
function genericName(part){
 const value=key(part);
 if(value==='명판')return '명판';
 if(/^THERMAL[\s_-]*PAD$/i.test(value))return 'THERMAL PAD';
 if(/^DUST[\s_-]*CAP$/i.test(value))return 'DUST CAP';
 return '';
}
function extractName(description,part=''){
 const original=clean(description),missing=()=>({name:MISSING,rule:'missing',usable:false});
 if(!original||/^(?:[-—–]+|N\/?A|NONE|NULL|UNKNOWN|미상|미확인|명칭 없음)$/i.test(original))return missing();
 let name=original.split(/[;,；，]/)[0].trim(),rule=name!==original?'before-specification':'source-name';
 if(!name)return missing();
 // Remove only this material's code when it is repeated at the end as an annotation.
 const material=key(part);
 if(material&&/^[A-Z0-9]{4}-[A-Z0-9]{6,8}$/.test(material)){
  const codePattern=escape(material).replace('-','\\s*-\\s*');
  const trimmed=name.replace(new RegExp('\\s*\\(\\s*'+codePattern+'\\s*\\)\\s*$','i'),'').trim();
  if(trimmed!==name){name=trimmed;rule='remove-repeated-code'}
 }
 if(plate(name))return {name:'명판',rule:'nameplate',usable:true};
 // These known families are explicit in the source. No component category is
 // inferred from a manufacturer model or a part-number prefix.
 const families=[
  [/^R[\s_-]*CHIP(?:\b|(?=\d))/i,'R-CHIP'],
  [/^THERMAL[\s_-]*PAD(?:\b|(?=\d))/i,'THERMAL PAD'],
  [/^FET[\s_-]*SILICON(?:\b|(?=[A-Z]*\d))/i,'FET-SILICON'],
  [/^IC[\s_-]*DC[\s_/-]*DC\s*CONVERTER\b/i,'IC-DC/DC CONVERTER'],
  [/^IC[\s_-]*DDR([2-5])\s*SDRAM\b/i,m=>'IC-DDR'+m[1]+' SDRAM'],
  [/^IC[\s_-]*CMOS\s*LOGIC\b/i,'IC-CMOS LOGIC'],
  [/^IC[\s_-]*RF\s*AMP\b/i,'IC-RF AMP'],
  [/^IC[\s_-]*PWM\s*CONTROLLER\b/i,'IC-PWM CONTROLLER']
 ];
 for(const [pattern,label] of families){
  const match=name.match(pattern);if(!match)continue;
  const family=typeof label==='function'?label(match):label,suffix=name.slice(match[0].length).trim();
  // Keep a functional variant such as ARRAY or SOFT; discard only an empty
  // suffix or one that starts with an explicit numeric spec/model annotation.
  const technical=!suffix||/^[([\s]*[+-]?(?:\d|[A-Z][A-Z0-9_./-]*\d)/i.test(suffix);
  return {name:family+(!technical?' '+suffix:''),rule:'explicit-family',usable:true};
 }
 // FAN assembly/vendor variants remain distinguishable; only model annotations
 // and separators are removed. Do not collapse control boards into fan assemblies.
 if(/^FAN[\s_-]/i.test(name)){
  const normalized=name.replace(/_/g,' ').replace(/\s*\([^)]*\)?\s*$/,'').replace(/\s+/g,' ').trim();
  if(normalized!==name){name=normalized;rule='fan-model-annotation'}
 }
 // Explicit trailing dimensions/electrical specs can be removed without losing
 // a functional suffix such as RF, TOP, BOTTOM, CONTROL BOARD or FRONT PANEL.
 if(functional.test(name)){
  const trimmed=name.replace(/\s+(?:\d+(?:\.\d+)?\s*(?:V|A|W|OHM|KOHM|MOHM|MM|CM|MHZ|GHZ|P)(?:\s|$).*|\d+(?:\.\d+)?\s*[X×]\s*\d.*)$/i,'').trim();
  if(trimmed!==name){name=trimmed;rule='trailing-specification'}
 }
 if(!/[A-Za-z가-힣]/.test(name)||/^\d+(?:\.\d+)?\s*(?:HZ|KHZ|MHZ|GHZ|V|A|W|OHM|KOHM|MM|CM)$/i.test(name))return missing();
 if(/^(?:[0-9]{4}|[A-Z]{2}[0-9]{2})\s*-\s*[A-Z0-9]{6,8}$/i.test(name))return missing();
 // A copied opaque code is not a name. Human-readable uncoded materials are
 // allowed when the source explicitly names the component itself.
 if(key(name)===material&&!functional.test(name)&&!genericName(name))return missing();
 return {name,rule,usable:true};
}
const typeRank=type=>({dashboard:0,india:1,hq:2,po:3})[type]??99;
const rowNumber=row=>typeof row.row==='number'&&Number.isFinite(row.row)?row.row:Infinity;
function buildNameIndex(selectedSources=[]){
 const candidates=Object.create(null),centers=new Set();
 // Caller supplies the sources selected for the report, including its cutoff.
 // This module must not bring newer or historical descriptions into that report.
 selectedSources.filter(source=>typeRank(source.type)<99).forEach((source,sourceOrder)=>{
  if(source.center)centers.add(source.center);
  const rows=(source.rows||[]).map((row,index)=>({row,index})).sort((a,b)=>rowNumber(a.row)-rowNumber(b.row)||a.index-b.index),seen=new Set();
  for(const {row,index} of rows){
   const part=key(row.part);if(!part)continue;
   // Dashboard and inventory duplicates follow the same topmost-row policy as
   // quantities. A lower duplicate's nicer description must not replace it.
   if(source.type!=='po'&&seen.has(part))continue;
   seen.add(part);
   const extracted=extractName(row.description,part);if(!extracted.usable)continue;
   (candidates[part]??=[]).push({part,partName:extracted.name,rawDescription:row.description==null?'':String(row.description),rule:extracted.rule,
    source:{type:source.type,center:source.center||'',file:source.file||'',sheet:row.sheet||source.sheet||'',row:row.row??null,date:source.date||null},
    sourceOrder,rowOrder:index});
  }
 });
 const select=(rows,center='')=>{
  const sorted=[...rows].sort((a,b)=>typeRank(a.source.type)-typeRank(b.source.type)||
   (a.source.type==='dashboard'&&center?Number(b.source.center===center)-Number(a.source.center===center):0)||
   a.source.center.localeCompare(b.source.center)||a.sourceOrder-b.sourceOrder||a.rowOrder-b.rowOrder);
  const {sourceOrder,rowOrder,...record}=sorted[0];return record;
 };
 const byPart=Object.create(null),byCenter=Object.create(null);
 for(const center of centers)byCenter[center]=Object.create(null);
 for(const [part,rows] of Object.entries(candidates)){
  byPart[part]=select(rows);
  for(const center of centers)byCenter[center][part]=select(rows,center);
 }
 return {version:VERSION,byPart,byCenter};
}
function resolve(index,part,center=''){
 const normalized=key(part),found=index?.byCenter?.[center]?.[normalized]||index?.byPart?.[normalized];
 if(found)return found;
 const generic=genericName(normalized);
 return {part:normalized,partName:generic||MISSING,rawDescription:'',rule:generic?'generic-material':'missing',source:null};
}
return {VERSION,MISSING,extractName,buildNameIndex,resolve};
});
