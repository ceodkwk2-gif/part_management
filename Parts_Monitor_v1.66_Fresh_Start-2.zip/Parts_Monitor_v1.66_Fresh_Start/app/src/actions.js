(function(root,factory){
 if(typeof module==='object'&&module.exports)module.exports=factory(require('./core.js'),require('./risk.js'));
 else root.PartsActions=factory(root.PartsCore,root.PartsRisk);
})(typeof self!=='undefined'?self:this,function(Core,Risk){
'use strict';
// An action-oriented projection of the approved Core values. No stock, demand,
// pending PO or proposed-order quantity is recalculated or allocated here.
const GROUPS=[
 {code:'SUPPLY_NOW',label:'현재 수리부품 부족',description:'WIP에 자재대기로 남은 부품을 관리합니다. 재고·PO가 있어도 대기 수량에서 자동 차감하지 않습니다.'},
 {code:'ORDER',label:'추가 발주 필요',description:'기존 PO까지 반영해도 현 수리 필요 수 또는 설정한 이후 보유 기준에 못 미칩니다.'},
 {code:'WAIT_PO',label:'기존 PO 입고 대기',description:'센터 재고가 현 수리 필요 수와 설정 보유분의 합보다 적지만 미입고 PO를 합하면 모두 충족하여 추가 발주가 필요 없습니다. 실제 운송 중임을 뜻하지 않습니다.'},
 {code:'PO_SCHEDULE',label:'PO 일정 확인 필요',description:'원본에서 출발예정일이 연기·삭제되었거나 보고일 이전 날짜여서 진행 상태 확인이 필요합니다. 실제 입고 지연으로 확정하지 않습니다.'},
 {code:'READY',label:'현재 부족·추가 발주 없음',description:'현 수리 필요 수 기준 부족은 없으며 기존 PO를 반영한 추가 발주량은 없습니다. 이후 보유 기준의 충족에는 기존 PO 입고가 필요할 수 있습니다. 데이터 이슈는 Alert에서 별도로 확인합니다.'}
];
const INACTIVE={code:'INACTIVE',label:'최근 소요·현 수리 필요 수·PO 없음',description:'최근 사용량, 현 수리 필요 수, 미입고 PO가 모두 없는 부품입니다. 원본 데이터 이슈는 별도 Alert에 유지합니다.'};
const UNASSESSED={code:'UNASSESSED',label:'—',description:'계산에 필요한 수량이 없어 판단을 표시하지 않습니다. 사유는 Alert에서 확인합니다.'};
const REQUIRED=['stock','needed','target','open','proposed'];
const FIELD_LABELS={stock:'센터 재고',needed:'현 수리 필요 수',target:'보유 기준 수량',open:'기존 PO 잔량',proposed:'추가 PO 수량'};
const known=value=>typeof value==='number'&&Number.isFinite(value);
const positive=value=>known(value)&&value>0;
const norm=value=>String(value??'').trim().toUpperCase();
const unique=values=>[...new Set(values)];
const number=value=>Number(value).toLocaleString('ko-KR',{maximumFractionDigits:2});
const rank=code=>{const n=GROUPS.findIndex(g=>g.code===code);return n<0?GROUPS.length+(code==='INACTIVE'?1:0):n};
function metric(rows,field){
 const values=rows.map(row=>row[field]),unknownCount=values.filter(value=>!known(value)).length;
 const knownSubtotal=values.reduce((sum,value)=>sum+(known(value)?value:0),0);
 return {value:unknownCount?null:knownSubtotal,knownSubtotal,unknownCount,
  unknownPartCount:new Set(rows.filter(row=>!known(row[field])).map(row=>norm(row.part))).size,complete:unknownCount===0,
  partCount:new Set(rows.filter(row=>positive(row[field])).map(row=>norm(row.part))).size};
}
function metrics(rows){return {shortage:metric(rows,'shortage'),proposed:metric(rows,'proposed'),open:metric(rows,'open'),currentOrderNeed:metric(rows,'currentOrderNeed'),futureOrderNeed:metric(rows,'futureOrderNeed')}}
function memberFrom(part,risk){
 const issues=unique([...(part.issues||[])]),dataFields=REQUIRED.filter(field=>!known(part[field]));
 const targetGap=known(risk?.evidence?.targetGap)?risk.evidence.targetGap:
  known(part.stock)&&known(part.needed)&&known(part.target)?Math.max(0,part.target-(part.stock-part.needed)):null;
 const orderNeeds=Core.orderBreakdown(part),schedule=part.poSchedule||Core.summarizePoSchedule(risk?.evidence?.poRows||[],risk?.evidence?.dates?.po);
 const reasonCodes=[...(risk?.reasonCodes||[])];
 const hasOpenPO=positive(part.open)||positive(part.detailPending)||!!risk?.evidence?.poRows?.some(row=>positive(row.pending));
 const oldETD=reasonCodes.includes('ETD_BEFORE_REPORT')||schedule.beforeReportRows>0;
 const needsScheduleCheck=oldETD||schedule.postponedRows>0||schedule.withdrawnRows>0;
 const needsPOFollowup=((positive(part.shortage)||positive(targetGap))&&hasOpenPO)||needsScheduleCheck;
 const waitingCovered=Core.waitingCovered(part);
 // A duplicate already resolved by first-row selection is evidence in Alert, not a task.
 const inactive=part.avg===0&&part.needed===0&&part.open===0&&part.target===0&&part.proposed===0&&!positive(part.shortage)&&!positive(part.detailPending)&&!hasOpenPO&&
  dataFields.length===0&&!part.missingDashboardCode&&!part.stockAssumedZero&&!needsScheduleCheck;
 const category=inactive?'INACTIVE':positive(part.shortage)?'SUPPLY_NOW':positive(part.proposed)?'ORDER':waitingCovered?'WAIT_PO':
  needsScheduleCheck?'PO_SCHEDULE':dataFields.length?'UNASSESSED':'READY';
 const label=(GROUPS.find(group=>group.code===category)||(category==='UNASSESSED'?UNASSESSED:INACTIVE)).label;
 const actions=[];
 if(positive(part.shortage))actions.push(`현재 부족 ${number(part.shortage)}개 공급 필요`);
 if(positive(part.proposed))actions.push(positive(orderNeeds.currentOrderNeed)?`추가 발주 ${number(part.proposed)}개 필요`:`보유 기준 보충 발주 ${number(part.proposed)}개 필요`);
 if(needsPOFollowup&&(positive(part.shortage)||positive(targetGap)))actions.push(positive(part.shortage)?'기존 PO 긴급 입고 필요':'기존 PO 입고 필요');
 if(needsScheduleCheck)actions.push('PO 출발예정일·진행 상태 확인 필요');
 if(positive(part.shortage)){
  if(positive(part.india))actions.push('법인 재고 공급 가능 여부 확인 필요');
  else if(part.india===0&&positive(part.hq))actions.push('본사 재고 공급 가능 여부 확인 필요');
  else if(part.india===0&&part.hq===0)actions.push('법인·본사 재고 없음 · 공급 진행 확인 필요');
 }
 if(!actions.length)actions.push(category==='INACTIVE'?INACTIVE.label:category==='UNASSESSED'?'—':label);
 return {...part,...orderNeeds,part:norm(part.part),category,label,targetGap,dataFields,dataFieldLabels:dataFields.map(field=>FIELD_LABELS[field]),
  issues,hasDataIssues:issues.length>0||dataFields.length>0,hasOpenPO,needsPOFollowup,waitingCovered,needsScheduleCheck,oldETD,reasonCodes,poSchedule:schedule,
  orderPurpose:positive(part.proposed)?positive(orderNeeds.currentOrderNeed)?'현재 수리 대응':'보유 기준 보충':null,
  nextAction:actions.join(' / '),riskEvidence:risk?.evidence||null,inactive};
}
function materialRows(members){
 const byPart=new Map();
 for(const member of members){if(!byPart.has(member.part))byPart.set(member.part,[]);byPart.get(member.part).push(member)}
 return [...byPart.entries()].map(([part,rows])=>{
  const category=rows.reduce((current,row)=>rank(row.category)<rank(current)?row.category:current,'INACTIVE');
  const label=(GROUPS.find(group=>group.code===category)||(category==='UNASSESSED'?UNASSESSED:INACTIVE)).label;
  const amounts=metrics(rows);
  return {part,description:rows.find(row=>row.description)?.description||'',category,label,members:rows,
   centers:unique(rows.map(row=>row.center)),...amounts,metrics:amounts,
   dataFields:unique(rows.flatMap(row=>row.dataFields)),dataFieldLabels:unique(rows.flatMap(row=>row.dataFieldLabels)),
   issues:unique(rows.flatMap(row=>row.issues.map(issue=>`${row.center}: ${issue}`))),
   hasDataIssues:rows.some(row=>row.hasDataIssues),alsoOrder:rows.some(row=>positive(row.proposed)),
   needsPOFollowup:rows.some(row=>row.needsPOFollowup),waitingCovered:rows.some(row=>row.waitingCovered),needsScheduleCheck:rows.some(row=>row.needsScheduleCheck),inactive:category==='INACTIVE',
   nextAction:rows.map(row=>`${row.center}: ${row.nextAction}`).join(' / ')};
 }).sort((a,b)=>rank(a.category)-rank(b.category)||b.shortage.knownSubtotal-a.shortage.knownSubtotal||
  b.proposed.knownSubtotal-a.proposed.knownSubtotal||a.part.localeCompare(b.part));
}
function summarize(members){
 const allRows=materialRows(members),rows=allRows.filter(row=>!row.inactive),inactiveRows=allRows.filter(row=>row.inactive);
 const groups=GROUPS.map(group=>{const classified=rows.filter(row=>row.category===group.code);
  const selected=group.code==='WAIT_PO'?materialRows(classified.flatMap(row=>row.members).filter(row=>row.waitingCovered)):classified;
  return {...group,rows:selected,partCount:selected.length,count:selected.length,metrics:metrics(selected.flatMap(row=>row.members))}});
 // A task contains only the center rows which qualify for that task. Keeping
 // every center under a matching material made a Flex receipt-only item show
 // CTDI's additional-order quantity inside the receipt-only list.
 const task=(predicate,field)=>{const matchingMembers=members.filter(predicate),selected=materialRows(matchingMembers);
  return {partCount:selected.length,rows:selected,members:matchingMembers,quantity:field?metric(matchingMembers,field):null}};
 return {allRows,rows,inactiveRows,groups,counts:{allParts:allRows.length,activeParts:rows.length,inactiveParts:inactiveRows.length,
  unassessedParts:rows.filter(row=>row.category==='UNASSESSED').length,...Object.fromEntries(groups.map(group=>[group.code,group.partCount]))},metrics:metrics(members),
  dataAlerts:{rows:allRows.filter(row=>row.hasDataIssues),partCount:allRows.filter(row=>row.hasDataIssues).length},
  tasks:{supply:task(row=>positive(row.shortage),'shortage'),order:task(row=>positive(row.proposed),'proposed'),
   orderCurrent:task(row=>positive(row.proposed)&&positive(row.currentOrderNeed),'proposed'),
   orderBuffer:task(row=>positive(row.proposed)&&row.currentOrderNeed===0,'proposed'),
   waitingCovered:task(row=>row.waitingCovered,'open'),
   poFollowup:task(row=>row.needsPOFollowup,'open'),schedule:task(row=>row.needsScheduleCheck,'open')}};
}
// Low use is a centre-level fact. A shared part is removed from the reference
// count only when EVERY relevant centre row has valid, positive low use.
// This never removes rows, changes an order quantity, or treats missing use as 0.
function lowUsagePartition(rows,lowUsageMap={}){
 const parts=new Map();
 for(const row of rows){const part=norm(row.part);if(!parts.has(part))parts.set(part,[]);parts.get(part).push(row)}
 const lowOnlyParts=[],mixedParts=[],unknownUsageParts=[],zeroUsageParts=[];
 const lookup=row=>lowUsageMap instanceof Map?lowUsageMap.get(row.center+'|'+norm(row.part)):lowUsageMap[row.center+'|'+norm(row.part)];
 for(const [part,members] of parts){
  const uses=members.map(lookup),low=use=>use?.valid===true&&known(use.total)&&use.total>0&&use.flag===true;
  if(uses.every(low))lowOnlyParts.push(part);
  else if(uses.some(low))mixedParts.push(part);
  if(uses.some(use=>use?.valid!==true||!known(use.total)))unknownUsageParts.push(part);
  if(uses.some(use=>use?.valid===true&&use.total===0))zeroUsageParts.push(part);
 }
 const excluded=new Set(lowOnlyParts),excludingLowOnlyParts=[...parts.keys()].filter(part=>!excluded.has(part));
 return {totalPartCount:parts.size,lowOnlyPartCount:lowOnlyParts.length,excludingLowOnlyPartCount:excludingLowOnlyParts.length,
  mixedPartCount:mixedParts.length,unknownUsagePartCount:unknownUsageParts.length,zeroUsagePartCount:zeroUsageParts.length,
  lowOnlyParts,excludingLowOnlyParts,mixedParts,unknownUsageParts,zeroUsageParts};
}
// Main status cards form one partition of unique part codes in the selected
// centre scope. The older overlapping task queues remain intact for diagnostics.
// Priority: current shortage -> replenishment order -> sufficiently ordered.
// A known task at another centre stays under the same parent; it is not lost just
// to make card totals exclusive. Unknown current quantities cannot prove that a
// part has no current shortage, and unknown order quantities cannot prove that
// all required ordering is complete.
function exclusiveStatus(summary,lowUsageMap={}){
 const valid=value=>known(value)&&value>=0,memberKey=m=>m.center+'|'+norm(m.part);
 const currentKnown=m=>m.shortageBasis==='wip-waiting'?valid(m.shortage):['stock','needed','shortage'].every(field=>valid(m[field]));
 const orderKnown=m=>REQUIRED.every(field=>valid(m[field]));
 const memberStatus=Object.create(null),byPart=Object.create(null),sourceMembers=summary?.members||summary?.allRows?.flatMap(row=>row.members)||[];
 const memberRows=sourceMembers.map(member=>{
  const currentAssessed=currentKnown(member),orderAssessed=orderKnown(member);
  const statusCategory=positive(member.shortage)?'SUPPLY_NOW':!currentAssessed?'UNASSESSED':positive(member.proposed)?'ORDER':
   member.waitingCovered&&orderAssessed?'WAIT_PO':!orderAssessed?'UNASSESSED':member.needsScheduleCheck?'PO_SCHEDULE':member.inactive?'INACTIVE':'READY';
  memberStatus[memberKey(member)]=statusCategory;
  return {...member,statusCategory,currentAssessed,orderAssessed,
   knownActionCodes:[...(positive(member.shortage)?['SUPPLY_NOW']:[]),...(positive(member.proposed)?['ORDER']:[]),...(member.waitingCovered?['WAIT_PO']:[])]};
 });
 const grouped=new Map();
 for(const member of memberRows){if(!grouped.has(member.part))grouped.set(member.part,[]);grouped.get(member.part).push(member)}
 const allRows=[];
 for(const [part,members] of grouped){
  const hasCurrent=members.some(m=>positive(m.shortage)),hasOrder=members.some(m=>positive(m.proposed)),hasWait=members.some(m=>m.waitingCovered);
  const currentAssessed=members.every(m=>m.currentAssessed),orderAssessed=members.every(m=>m.orderAssessed);
  const category=hasCurrent?'SUPPLY_NOW':!currentAssessed?'UNASSESSED':hasOrder?'ORDER':!orderAssessed?'UNASSESSED':hasWait?'WAIT_PO':
   members.some(m=>m.needsScheduleCheck)?'PO_SCHEDULE':members.every(m=>m.inactive)?'INACTIVE':'READY';
  const classificationIssues=[];
  if(!currentAssessed)classificationIssues.push('일부 센터의 현 수리 필요 수·재고·부족량 미확인: 현재 부족 없음으로 판단하지 않음');
  if(!orderAssessed)classificationIssues.push('일부 센터의 발주 계산 자료 미확인: 발주량 충족으로 판단하지 않음');
  const actionable=members.filter(m=>positive(m.shortage)||positive(m.proposed)||m.waitingCovered||m.needsPOFollowup||m.needsScheduleCheck||m.statusCategory==='UNASSESSED');
  const displayed=actionable.length?actionable:members;
  const base=materialRows(displayed)[0],label=(GROUPS.find(group=>group.code===category)||(category==='UNASSESSED'?UNASSESSED:INACTIVE)).label;
  const projected={...base,category,label,members:displayed.map(m=>({...m,parentStatus:category})),currentAssessed,orderAssessed,
   classificationIssues,hasDataIssues:base.hasDataIssues||classificationIssues.length>0,allCenterCount:members.length};
  byPart[part]=category;allRows.push(projected);
 }
 const definitions=GROUPS.filter(group=>['SUPPLY_NOW','ORDER','WAIT_PO'].includes(group.code)).map(group=>({...group,
  description:group.code==='ORDER'?'현재 확인된 수요 기준 부족 없음 · 설정 보유분 부족. 현 수리 필요 수가 없고 센터 재고도 없는 경우를 포함하며, 기존 PO를 반영해도 보유분을 위한 추가 발주가 필요합니다.':
   group.code==='WAIT_PO'?'현재 수리부품 부족과 추가 발주 필요가 없고, 현 수리 필요 수를 충당한 뒤 남을 재고가 설정 보유분보다 적은 센터는 기존 PO 입고를 기다립니다. 실제 운송 중임을 뜻하지 않습니다.':group.description}));
 const primaryPredicate={SUPPLY_NOW:m=>positive(m.shortage),ORDER:m=>positive(m.proposed),WAIT_PO:m=>m.waitingCovered},fields={SUPPLY_NOW:'shortage',ORDER:'proposed',WAIT_PO:'open'};
 const groups=definitions.map(definition=>{
  const rows=allRows.filter(row=>row.category===definition.code).sort((a,b)=>b[fields[definition.code]].knownSubtotal-a[fields[definition.code]].knownSubtotal||a.part.localeCompare(b.part));
  const members=rows.flatMap(row=>row.members),primaryMembers=members.filter(primaryPredicate[definition.code]);
  return {...definition,rows,members,primaryMembers,partCount:rows.length,count:rows.length,quantity:metric(primaryMembers,fields[definition.code]),
   metrics:metrics(members),lowUsage:lowUsagePartition(primaryMembers,lowUsageMap)};
 });
 const taskByCode=Object.fromEntries(groups.map(group=>[group.code,group]));
 const unassessedRows=allRows.filter(row=>row.category==='UNASSESSED'),unassessedMembers=unassessedRows.flatMap(row=>row.members);
 const alertRows=allRows.filter(row=>row.hasDataIssues),mainRows=groups.flatMap(group=>group.rows);
 return {groups,rows:mainRows,allRows,byPart,memberStatus,members:memberRows,
  tasks:{supply:taskByCode.SUPPLY_NOW,order:taskByCode.ORDER,waitingCovered:taskByCode.WAIT_PO},
  counts:{...Object.fromEntries(groups.map(group=>[group.code,group.partCount])),allParts:allRows.length,actionParts:mainRows.length,UNASSESSED:unassessedRows.length},
  unassessed:{rows:unassessedRows,members:unassessedMembers,partCount:unassessedRows.length,
   knownOrderPartCount:new Set(unassessedMembers.filter(m=>positive(m.proposed)).map(m=>m.part)).size,
   knownWaitingPartCount:new Set(unassessedMembers.filter(m=>m.waitingCovered).map(m=>m.part)).size},
  dataAlerts:{rows:alertRows,partCount:alertRows.length},
  legacyOrderLowUsage:lowUsagePartition(sourceMembers.filter(m=>positive(m.proposed)),lowUsageMap),
  scopeNote:'선택 센터 범위에서 같은 부품은 현재 부족 → 추가 발주 필요 → 기존 PO 입고 대기 순서로 한 곳에만 집계합니다. 다른 센터의 필요한 조치는 같은 부품 아래 유지합니다.'};
}
function inventoryScope(calculated,center='전체',operator='전체'){
 const selectedCenters=center==='전체'?['Flex','CTDI']:[center];
 const centers=selectedCenters.map(name=>{
  const source=(calculated.used||[]).find(source=>source.type==='dashboard'&&source.center===name);
  const registeredParts=unique(Core.selectDashboardRows(source).map(row=>norm(row.part)).filter(Boolean));
  return {center:name,available:!!source,registeredPartCount:source?registeredParts.length:null,registeredParts,
   file:source?.file||null,sheet:source?.sheet||null,date:source?.date||null};
 });
 const complete=centers.every(row=>row.available),registeredParts=unique(centers.flatMap(row=>row.registeredParts));
 const registered=new Set(registeredParts),allMembers=(calculated.allParts||calculated.parts||[]).filter(row=>selectedCenters.includes(row.center));
 const missingRows=unique(allMembers.filter(row=>row.missingDashboardCode).map(row=>row.center+'|'+norm(row.part))).map(key=>{
  const row=allMembers.find(row=>row.center+'|'+norm(row.part)===key);
  const source=centers.find(source=>source.center===row.center);
  const alert=(calculated.masterAlerts||[]).find(alert=>alert.center===row.center&&norm(alert.part)===norm(row.part));
  return {center:row.center,part:norm(row.part),file:source?.file||null,sheet:source?.sheet||null,date:source?.date||null,
   registeredAtOtherCenter:centers.some(source=>source.center!==row.center&&source.registeredParts.includes(norm(row.part))),
   origins:alert?.origins||[]};
 });
 const outsideParts=unique(allMembers.map(row=>norm(row.part))).filter(part=>!registered.has(part));
 return {complete,registeredPartCount:complete?registeredParts.length:null,knownRegisteredPartCount:registeredParts.length,
  registeredParts,centers,sharedPartCount:complete?registeredParts.filter(part=>centers.filter(source=>source.registeredParts.includes(part)).length>1).length:null,
  missingOwnDashboard:{partCount:unique(missingRows.map(row=>row.part)).length,centerPartCount:missingRows.length,rows:missingRows},
  outsideRegistered:{partCount:complete?outsideParts.length:null,knownPartCount:outsideParts.length,parts:outsideParts},
  operatorFiltered:false,scopeLabel:'등록 부품은 선택한 센터 대시보드의 고유 부품코드 기준입니다. 센터 간 공통 부품은 전체에서 한 번만 셉니다.'+
   (operator!=='전체'?' 사업자 선택과 관계없이 등록 종수는 선택 센터 전체 목록 기준이며, 조치 목록만 선택 사업자 관련 부품을 표시합니다.':' WIP·PO에서 발견한 미등록 부품은 등록 종수에 더하지 않고 조치와 원본 알림에 유지합니다.')};
}
function fromResults(calculated,risk,options={}){
 const riskRows=new Map((risk?.allRows||[]).map(row=>[row.center+'|'+norm(row.part),row]));
 const members=(calculated.parts||[]).map(part=>memberFrom(part,riskRows.get(part.center+'|'+norm(part.part))));
 const summary=summarize(members),centers=unique(members.map(row=>row.center)).map(center=>({center,...summarize(members.filter(row=>row.center===center))}));
 const unresolvedRows=(calculated.wip||[]).filter(row=>row.tokens?.unparsed||!Object.keys(row.tokens?.parts||{}).length);
 const unresolvedAffectsCurrent=unresolvedRows.some(row=>members.some(member=>member.center===row.center&&member.needBasis==='wip'));
 const warnings=unique([...(calculated.warnings||[])]);
 if(unresolvedRows.length)warnings.push(`WIP 부품코드·수량 확인 필요 ${unresolvedRows.length}대 — 확인된 부품 수량만 집계하며 전체 조치 없음으로 판단하지 않습니다.`);
 return {...summary,centers,members,inventoryScope:inventoryScope(calculated,options.center??risk?.center??'전체',options.operator??risk?.operator??'전체'),asof:options.asof??risk?.asof??null,center:options.center??risk?.center??'전체',
  operator:options.operator??risk?.operator??'전체',warnings,unresolvedWipProducts:unresolvedRows.length,unresolvedAffectsCurrent,
  scopeNote:'한 부품은 선택 범위에서 가장 먼저 필요한 조치 한 곳에만 집계합니다. 센터별 조치는 모두 유지하며, 추가 PO 전체 수량에는 현재 부족 부품의 추가 PO도 포함합니다.',
  allocationConfirmed:false,arrivalPredictionAvailable:false};
}
function evaluate(state,asof,center='전체',operator='전체'){
 return fromResults(Core.calculate(state,asof,center,operator),Risk.evaluate(state,asof,center,operator),{asof,center,operator});
}
return {GROUPS,INACTIVE,UNASSESSED,REQUIRED,FIELD_LABELS,evaluate,fromResults,exclusiveStatus,lowUsagePartition};
});
