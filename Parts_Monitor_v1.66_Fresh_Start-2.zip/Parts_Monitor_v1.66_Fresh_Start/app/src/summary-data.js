(function(root,factory){
 if(typeof module==='object'&&module.exports)module.exports=factory(require('./core.js'),require('./reporting.js'),require('./actions.js'),require('./operations.js'),require('./followups.js'),require('./wip-tat.js'),require('./wip-trace.js'),require('./part-names.js'),require('./leadtime.js'),require('./i18n.js'),require('./siel.js'));
 else root.PartsSummaryData=factory(root.PartsCore,root.PartsReporting,root.PartsActions,root.PartsOperations,root.PartsFollowups,root.PartsWipTat,root.PartsWipTrace,root.PartsNames,root.PartsLeadTime,root.PartsI18n,root.PartsSiel);
})(typeof self!=='undefined'?self:this,function(C,R,A,O,F,T,Trace,Names,L,I,Siel){
'use strict';
// Read-only adapter for the live overview and mail tables. No stored quantities,
// dates, source revisions or settings are changed. Call once per state/settings
// update, then reuse the result for view filters; no mutable-input global cache.
const finite=value=>typeof value==='number'&&Number.isFinite(value);
const positive=value=>finite(value)&&value>0;
const copy=value=>value==null?value:JSON.parse(JSON.stringify(value));
function reportContext(state,report){
 const resolved=R.reportState(state,report.id),scopes=new Map();
 function scope(center='전체'){
  if(scopes.has(center))return scopes.get(center);
  const calculated=C.calculate(resolved,report.cutoff,center),operations=O.evaluate(resolved,calculated);
  // Core already exposes approved quantities and PO schedule evidence. Avoid
  // Action.evaluate's repeated Core/Risk calculations for the same snapshot.
  const actions=A.fromResults(calculated,null,{asof:report.cutoff,center,operator:'전체'}),exclusive=A.exclusiveStatus(actions,operations.lowUsage),tat=T.evaluate(calculated.wip);
  const result={calculated,operations,actions,exclusive,tat};scopes.set(center,result);return result;
 }
 return {...scope('전체'),resolved,scope};
}
function commonProjection(common,names){
 if(!common)return null;
 const {months,windowStart,windowEnd,demandComplete,sourceDates,settings,warnings}=common;
 return {months:copy(months),windowStart,windowEnd,demandComplete,sourceDates:copy(sourceDates),settings:copy(settings),warnings:copy(warnings),parts:(common.parts||[]).map(row=>({
  part:row.part,name:Names.resolve(names,row.part).partName,demand:row.demand,demandComplete:row.demandComplete,
  india:row.india,hq:row.hq,indiaTarget:row.indiaTarget,hqTarget:row.hqTarget,indiaGap:row.indiaGap,hqGap:row.hqGap,active:row.active,issues:copy(row.issues||[])
 }))};
}
const SCOPES=['전체','Flex','CTDI'],unique=values=>[...new Set(values)],sum=values=>values.reduce((n,v)=>n+(typeof v==='number'?v:0),0);
// A confirmed reporting week is selection evidence, never an exact source date.
const fresh=(source,report)=>!!source&&(source.assignedWeek===report.id||(R.validDate(source.date)?source.date>=report.id&&source.date<=report.cutoff:
 source.datePrecision==='week'&&R.validDate(source.reportWeek)&&source.reportWeek===report.id&&source.reportWeek<=report.cutoff));
function sourceMeta(source,report){
 const exact=R.validDate(source.date),weekOnly=!exact&&source.datePrecision==='week'&&R.validDate(source.reportWeek);
 return {type:source.type,center:source.center||'',operator:source.operator||'',date:exact?source.date:null,
  reportWeek:source.reportWeek||null,assignedWeek:source.assignedWeek||null,datePrecision:exact?'day':weekOnly?'week':'unknown',dateBasis:source.dateBasis||null,
  dateLabel:source.dateLabel||null,hasExactDate:exact,file:source.file,sheet:source.sheet,
  carriedForward:!!report&&!!C.sourceSelectionDate(source)&&C.sourceSelectionDate(source)<report.id,fresh:!!report&&fresh(source,report)};
}
const ageRange=products=>{const ages=products.map(p=>p.age).filter(Number.isFinite);return {minAge:ages.length?Math.min(...ages):null,maxAge:ages.length?Math.max(...ages):null};};
const dates=(calculated,report)=>calculated.used.map(source=>sourceMeta(source,report));
function availability(calculated,report,scope='전체'){
 const centers=scope==='전체'?['Flex','CTDI']:[scope],used=calculated.used,source=(type,center)=>used.find(s=>s.type===type&&(!center||s.center===center));
 const centerStock=centers.every(center=>fresh(source('dashboard',center),report)),indiaStock=fresh(source('india'),report),hqStock=fresh(source('hq'),report);
 const po=centers.every(center=>fresh(source('po',center),report));
 const wip=centers.every(center=>{const ws=used.filter(s=>s.type==='wip'&&s.center===center),ops=center==='CTDI'?['Jio','Airtel','Vi']:['Jio'];return ops.every(op=>ws.some(s=>s.operator===op&&fresh(s,report)&&C.wipIntegrity(s).productsComplete))&&new Set(ws.map(s=>s.date)).size===1;});
 const scoped=calculated.parts.filter(row=>centers.includes(row.center));
 const repairDemand=scoped.length>0&&scoped.every(row=>typeof row.needed==='number'&&R.validDate(row.needDate)&&(row.needBasis==='wip'?used.some(s=>s.type==='wip'&&s.center===row.center&&s.date===row.needDate&&fresh(s,report)):fresh(source('dashboard',row.center),report)));
 const demandSources=centers.map(center=>{const rs=scoped.filter(row=>row.center===center),bases=unique(rs.map(row=>row.needBasis)),sourceDates=unique(rs.map(row=>row.needDate)).filter(Boolean);return {center,bases,sourceDates,fresh:rs.length>0&&rs.every(row=>typeof row.needed==='number'&&(row.needBasis==='wip'?used.some(s=>s.type==='wip'&&s.center===row.center&&s.date===row.needDate&&fresh(s,report)):fresh(source('dashboard',row.center),report))),label:bases.length===1&&bases[0]==='dashboard'?'센터 대시보드 Hold':bases.length===1&&bases[0]==='wip'?'WIP Required Part':'대시보드 Hold / WIP 혼합'};});
 // A missing source is different from an older, explicitly retained source.
 // Counts may use dated references, but never turn absent stock/demand into 0.
 // Dashboard Open PO is a valid basis even without a separate detail PO file.
 const actionChecks=centers.map(center=>{
  const ds=source('dashboard',center),rs=scoped.filter(row=>row.center===center),registered=rs.filter(row=>!row.missingDashboardCode);
  const ws=used.filter(s=>s.type==='wip'&&s.center===center),ops=center==='CTDI'?['Jio','Airtel','Vi']:['Jio'];
  const completeWip=ops.every(op=>ws.some(s=>s.operator===op&&R.validDate(s.date)&&C.wipIntegrity(s).productsComplete))&&new Set(ws.map(s=>s.date)).size===1;
  const usableDemand=rs.length?rs.every(row=>finite(row.needed)):completeWip||!!(ds&&R.validDate(ds.holdDate)&&ds.holdDate<=report.cutoff);
  const shortage=rs.length?rs.every(row=>row.shortageBasis==='wip-waiting'?finite(row.shortage):!!ds&&usableDemand&&finite(row.stock)&&finite(row.shortage)):!!ds&&usableDemand;
  const order=shortage&&rs.every(row=>finite(row.target)&&finite(row.open)&&finite(row.proposed));
  return {center,shortage,order,wait:order};
 });
 const actionAvailability=Object.fromEntries(['shortage','order','wait'].map(kind=>[kind,actionChecks.every(check=>check[kind])]));
 return {inventory:centerStock&&indiaStock&&hqStock,centerStock,indiaStock,hqStock,po,wip,repairDemand,demandSources,actionAvailability};
}
function quantityCoverage(calculated,scope='전체'){
 const rs=calculated.parts.filter(r=>scope==='전체'||r.center===scope),sources=calculated.used.filter(s=>s.type==='wip'&&(scope==='전체'||s.center===scope));
 const unresolved=calculated.wip.filter(r=>(scope==='전체'||r.center===scope)&&(r.tokens?.unparsed||!Object.keys(r.tokens?.parts||{}).length&&!r.tokens?.excludedNameplate));
 const missingCenters=(scope==='전체'?['Flex','CTDI']:[scope]).filter(c=>!calculated.used.some(s=>s.type==='dashboard'&&s.center===c));
 const conflicts=sources.flatMap(s=>C.wipIntegrity(s).conflictedKeys.map(key=>s.center+'|'+s.operator+'|'+key));
 const blocked=sources.filter(s=>C.wipIntegrity(s).globalBlocked).map(s=>s.center+' '+s.operator);
 const fields={shortage:'shortage',order:'proposed',wait:'proposed'};
 const noWip=(scope==='전체'?['Flex','CTDI']:[scope]).flatMap(center=>(center==='CTDI'?['Jio','Airtel','Vi']:['Jio']).filter(op=>!sources.some(s=>s.center===center&&s.operator===op)).map(op=>center+' '+op));
 const unknownAge=calculated.wip.filter(r=>(scope==='전체'||r.center===scope)&&!finite(r.age)),overdueUnresolved=unresolved.filter(r=>r.age>45);
 const result={unresolvedProducts:unresolved.length,conflictingProducts:conflicts.length,blockedSources:blocked,missingCenters,
  products:{partial:!!(conflicts.length||blocked.length||noWip.length),signature:JSON.stringify([conflicts,blocked,noWip])},
  overdue:{partial:!!(overdueUnresolved.length||unknownAge.length||conflicts.length||blocked.length||noWip.length),signature:JSON.stringify([overdueUnresolved.map(r=>r.center+'|'+r.key),unknownAge.map(r=>r.center+'|'+r.key),conflicts,blocked,noWip])}};
 for(const [kind,field] of Object.entries(fields)){
  const unknown=rs.filter(r=>!finite(r[field])),keys=unknown.map(r=>r.center+'|'+r.part).sort();
  result[kind]={knownRows:rs.length-unknown.length,unknownRows:unknown.length,unknownKinds:unique(unknown.map(r=>r.part)).length,
   partial:!!(unknown.length||unresolved.length||conflicts.length||blocked.length||missingCenters.length),
   signature:JSON.stringify([keys,unresolved.map(r=>r.center+'|'+r.key+'|'+r.required).sort(),conflicts.sort(),blocked.sort(),missingCenters]),
   reasons:unique(unknown.flatMap(r=>[!finite(r.needed)?'수리 필요량 미확정':'',!finite(r.stock)?'센터 재고 미확인':'',field==='proposed'&&!finite(r.target)?'월 사용량 이력 미확인':'',field==='proposed'&&!finite(r.open)?'센터 PO 잔량 미확인':'']).filter(Boolean))};
 }
 return result;
}
function waitingChanges(current,previous,scope,available,previousAvailable){
 const select=rows=>rows.filter(row=>scope==='전체'||row.center===scope);
 if(!available)return {available:false,newProducts:null,continuingProducts:null,notListedProducts:null,newPartNeeds:null,continuingPartNeeds:null,noLongerListedPartNeeds:null,reason:'해당 주 신규 WIP 자료 없음·불완전'};
 if(!previous)return {available:true,baseline:true,newProducts:null,continuingProducts:null,notListedProducts:null,newPartNeeds:null,continuingPartNeeds:null,noLongerListedPartNeeds:null,reason:'최초 보유 자료 · 이전 상태 비교 불가'};
 if(!previousAvailable)return {available:false,newProducts:null,continuingProducts:null,notListedProducts:null,newPartNeeds:null,continuingPartNeeds:null,noLongerListedPartNeeds:null,reason:'직전 주 신규 WIP 자료 없음·불완전 · 연속 주 비교 보류'};
 const now=select(current),old=select(previous),currentIds=new Set(now.map(p=>p.productId)),oldIds=new Set(old.map(p=>p.productId));
 const newIds=[...currentIds].filter(id=>!oldIds.has(id)),continuingIds=[...currentIds].filter(id=>oldIds.has(id)),notListedIds=[...oldIds].filter(id=>!currentIds.has(id));
 const needs=products=>new Set(products.flatMap(p=>p.partEntries.map(e=>JSON.stringify([p.productId,e.part])))),nowNeeds=needs(now),oldNeeds=needs(old);
 return {available:true,baseline:false,newProducts:newIds.length,continuingProducts:continuingIds.length,notListedProducts:notListedIds.length,
  newPartNeeds:[...nowNeeds].filter(id=>!oldNeeds.has(id)).length,continuingPartNeeds:[...nowNeeds].filter(id=>oldNeeds.has(id)).length,noLongerListedPartNeeds:[...oldNeeds].filter(id=>!nowNeeds.has(id)).length,
  newProductIds:newIds,continuingProductIds:continuingIds,notListedProductIds:notListedIds,reason:'WIP 자재대기 목록 비교 · 목록에서 사라짐은 수리 완료를 뜻하지 않음'};
}
function weekMetrics(state,report,context){
 const ctx=context||reportContext(state,report),calculated=ctx.calculated,tat=ctx.tat,metricsByCenter={},availableByCenter={};
 for(const scope of SCOPES){
  const scoped=ctx.scope(scope),c=scoped.calculated,a=scoped.actions,o=scoped.operations,ex=scoped.exclusive,w=scoped.tat,group=code=>ex.groups.find(g=>g.code===code),av=availability(calculated,report,scope);availableByCenter[scope]=av;
  // Demand-dependent cards are provisional if old sources are carried. Their
  // counts remain available as reference, while freshness is explicit.
  const metrics={shortageKinds:group('SUPPLY_NOW').partCount,shortageQty:group('SUPPLY_NOW').quantity.knownSubtotal,orderKinds:group('ORDER').partCount,orderQty:group('ORDER').quantity.knownSubtotal,waitKinds:group('WAIT_PO').partCount,waitQty:group('WAIT_PO').quantity.knownSubtotal,
   registeredKinds:a.inventoryScope.registeredPartCount,dashboardMissingKinds:a.inventoryScope.missingOwnDashboard.partCount,
   wip:w.summary.products,over45:w.summary.overdueProducts,over45PartKinds:w.summary.overduePartKinds,over45RequiredQty:w.summary.overdueQuantity,
   partKinds:w.summary.partKinds,neededQty:w.summary.quantity,fan:w.summary.fanProducts,general:w.summary.generalProducts,over45Fan:w.summary.overdueFanProducts,over45General:w.summary.overdueGeneralProducts,unparsedProducts:w.summary.unresolvedPartProducts,over45Unparsed:w.summary.unresolvedPartOverdueProducts};
  const explicitWeek=report.uploadPolicy==='slots-v160',scopedSources=c.used,hasKnownAction=kind=>scopedSources.some(s=>s.type==='dashboard')&&c.parts.some(r=>finite(r.needed)&&finite(r.stock)&&(kind==='shortage'?finite(r.shortage):finite(r.target)&&finite(r.open)&&finite(r.proposed))),hasCurrentWip=scopedSources.some(s=>s.type==='wip'&&fresh(s,report)&&s.rows?.length);
  // Keep the pre-v1.61 reference trend when only WIP-only, unregistered parts
  // lack monthly usage. Strict availability and quality still report the gap.
  // Missing registered stock/usage/PO must never become a healthy zero.
  const registered=c.parts.filter(r=>!r.missingDashboardCode);
  const registeredOrderKnown=av.actionAvailability.shortage&&registered.length>0&&registered.every(r=>finite(r.target)&&finite(r.open)&&finite(r.proposed));
  for(const kind of ['shortage','order','wait'])if(!av.actionAvailability[kind]&&!(explicitWeek&&hasKnownAction(kind))&&!(kind!=='shortage'&&registeredOrderKnown)){metrics[kind+'Kinds']=null;metrics[kind+'Qty']=null;}
  if(!av.wip&&!(explicitWeek&&hasCurrentWip))for(const key of ['wip','over45','over45PartKinds','over45RequiredQty','partKinds','neededQty','fan','general','over45Fan','over45General','unparsedProducts','over45Unparsed'])metrics[key]=null;
  metricsByCenter[scope]=metrics;
 }
 const qualityByCenter=Object.fromEntries(SCOPES.map(scope=>[scope,quantityCoverage(calculated,scope)]));const sourceDates=dates(calculated,report),notes=[];
 for(const source of sourceDates)if(!fresh(source,report))notes.push(`${source.center?source.center+' ':''}${source.operator?source.operator+' ':''}${source.type} ${source.date||(source.reportWeek?source.reportWeek+'주 · 실제 기준일 미확인':'기준일 미확인')} 참고`);
 if(!availableByCenter['전체'].wip)notes.push(report.uploadPolicy==='slots-v160'?'WIP 중복·미확인 항목 있음 · 그래프는 확인 가능한 제품·부품의 부분합계':'새 WIP가 없는 범위의 제품·45일 초과·부품 종수 추이는 표시하지 않음');
 if(!availableByCenter['전체'].repairDemand)notes.push('수요 기준일이 이전 주이거나 일부 수량 미확인 · 계산 가능한 부족/발주 수치는 적용 원본 기준 참고');
 if(Object.values(availableByCenter['전체'].actionAvailability).some(available=>!available))notes.push(report.uploadPolicy==='slots-v160'?'일부 품목 산정 불가 · 그래프는 확인 가능한 부족/발주 부분합계이며 전체 확정 수량이 아님':'센터 재고·수리 필요·보유 기준·PO 중 판단 근거가 없는 항목의 부족/발주 추이는 산정 불가');
 if(R.reports(state)[0]?.id===report.id){const actual=sourceDates.filter(s=>s.type==='wip').map(s=>`${s.center} ${s.operator} ${s.date||'일자 미확인'}`);notes.push(`최초 보유 보고 ${report.id}주, 마감 ${report.cutoff} · 실제 WIP ${actual.join(', ')}. 보고 주차와 원본 기준일은 다르며 다음 자료와의 간격이 반드시 7일은 아님`);}
 return {week:report.id,asof:report.cutoff,qualityByCenter,knownPartialCounts:report.uploadPolicy==='slots-v160'&&(!availableByCenter['전체'].wip||Object.values(availableByCenter['전체'].actionAvailability).some(v=>!v)),available:availableByCenter['전체'],availableByCenter,metricsByCenter,sourceDates,notes,_products:tat.rows};
}
function overdueData(output,state,selected,calculated){
 const overdue=output.products.filter(p=>typeof p.age==='number'&&p.age>45),rowMap=new Map(output.rows.map(row=>[row.id,row])),groups=new Map();
 const current=calculated||C.calculate(R.reportState(state,selected.id),selected.cutoff),sourceDates=output.sourceDates.filter(s=>s.type==='wip'),freshByCenter=Object.fromEntries(SCOPES.map(scope=>[scope,availability(current,selected,scope).wip]));
 const metricsByCenter={};for(const scope of SCOPES){const products=overdue.filter(p=>scope==='전체'||p.center===scope);metricsByCenter[scope]={products:products.length,partKinds:new Set(products.flatMap(p=>p.parts.map(e=>e.part))).size,requiredQty:sum(products.flatMap(p=>p.parts.map(e=>e.quantity))),unparsedProducts:products.filter(p=>p.hasUnresolvedParts).length,fan:products.filter(p=>p.fan).length,general:products.filter(p=>p.category==='GENERAL').length,...ageRange(products)};}
 for(const product of overdue)for(const entry of product.parts){if(!groups.has(entry.part))groups.set(entry.part,new Map());const centers=groups.get(entry.part);if(!centers.has(product.center))centers.set(product.center,[]);centers.get(product.center).push({product,entry});}
 const partGroups=[...groups].map(([part,byCenter])=>{const centers=[...byCenter].map(([center,pairs])=>{const id=center+'|'+part,row=rowMap.get(id),products=[...new Map(pairs.map(p=>[p.product.id,p.product])).values()],entries=pairs.map(p=>p.entry),baselineProducts=pairs.filter(p=>p.entry.baseline).length;
   const dates=unique(entries.map(e=>e.firstDate)).filter(Boolean).sort(),weeks=unique(entries.map(e=>e.firstWeek)).filter(Boolean).sort();return {rowId:id,center,productIds:products.map(p=>p.id),products:products.length,requiredQty:sum(pairs.map(p=>p.entry.quantity)),fan:products.filter(p=>p.fan).length,general:products.filter(p=>p.category==='GENERAL').length,...ageRange(products),firstWeek:weeks[0]||null,firstDate:dates[0]||null,firstWeeks:weeks,baselineProducts,
    continuityUncertainProducts:pairs.filter(p=>p.entry.continuityUncertain).length,stock:row?.stock??null,india:row?.india??null,hq:row?.hq??null,needed:row?.needed??null,shortage:row?.shortage??null,open:row?.open??null,proposed:row?.proposed??null,
    taskIds:row?.taskIds||[],poIndices:output.pos.flatMap((po,index)=>po.center===center&&po.part===part?[index]:[]),sourceDates:row?.sourceDates||{},wipDates:unique(products.map(p=>p.date)).sort()};});
  const products=[...new Map([...byCenter.values()].flatMap(pairs=>pairs.map(p=>[p.product.id,p.product]))).values()];return {part,name:rowMap.get(centers[0].rowId)?.name||'',products:products.length,requiredQty:sum(centers.map(c=>c.requiredQty)),fan:products.filter(p=>p.fan).length,general:products.filter(p=>p.category==='GENERAL').length,...ageRange(products),centers};
 }).sort((a,b)=>b.maxAge-a.maxAge||b.products-a.products||a.part.localeCompare(b.part));
 return {basis:'WIP_SOURCE_DATE',fresh:freshByCenter['전체'],freshByCenter,sourceDates,metricsByCenter,groups:partGroups,unparsedProductIds:overdue.filter(p=>p.hasUnresolvedParts).map(p=>p.id),
  notes:['45일 초과는 46일부터. TAT는 제품 실제 입고일에서 각 WIP 원본 기준일까지의 기간임.','최초 자료부터 대기인 경우 최초 부품대기 확인일 이전부터 대기. 실제 부품 필요 발생일·대기 시작일은 확정하지 않음.','한 제품에 여러 부품이 필요하면 부품별 제품 대수를 더한 값은 전체 제품 대수와 다를 수 있음.','관련 PO는 센터·부품 단위 자료. 제품별 주문 배정·부품별 공용재고 배정·지연 귀책을 확정하지 않음.']};
}
function attachSupplierEvidence(output,records=[]){
 const material=value=>C.materialCode(value),norm=value=>String(value??'').trim().toUpperCase();
 const key=(product,part)=>JSON.stringify([norm(product.center),norm(C.canonicalOperator(product.center,product.operator,'wip')),norm(product.sn),norm(product.rma),material(part)]);
 const eligible=records.filter(record=>R.validDate(record.date)&&record.date<=output.asof),hasValue=record=>!!(record.recordedNeedDate||record.recordedOrderDate||record.delayReason||record.delayCause);
 const byKey=new Map();for(const record of eligible){if(!record.sn||!record.rma||!record.part)continue;const id=key(record,record.part);if(!byKey.has(id))byKey.set(id,[]);byKey.get(id).push(record);}
 let matchedRows=0;const evidence=[];
 for(const product of output.products)for(const part of product.parts){const matched=byKey.get(key(product,part.part))||[];matchedRows+=matched.length;
  part.supplierRecordIds=[];
  for(const record of matched.filter(hasValue)){
   // Records from an earlier explicit episode may be inspected as historical
   // evidence, but must not set the current episode's start/need/order date.
   const historical=!!part.priorWithoutDate&&record.date<=part.priorWithoutDate;
   const id=JSON.stringify([record.source,record.sheet,record.row,product.id,part.part]);
   const dated=value=>R.validDate(value)&&value<=record.date?value:null;
   evidence.push({id,productId:product.id,part:part.part,center:product.center,operator:product.operator,sn:product.sn,rma:product.rma,
    recordedNeedDate:dated(record.recordedNeedDate),recordedOrderDate:dated(record.recordedOrderDate),delayReason:record.delayReason||'',delayCause:record.delayCause||'',
    source:record.source,sheet:record.sheet,row:record.row,date:record.date,historical,authority:'SUPPLIER_RECORDED',liabilityConfirmed:false,
    dateIssue:!!record.recordedNeedDate&&!dated(record.recordedNeedDate)||!!record.recordedOrderDate&&!dated(record.recordedOrderDate)});part.supplierRecordIds.push(id);
  }
 }
 output.supplierEvidence=evidence;
 output.supplierEvidenceStatus={reviewedRows:eligible.length,matchedRows,matchedPopulatedRows:evidence.length,available:evidence.length>0,
  recordedNeedDates:eligible.filter(r=>r.recordedNeedDate).length,recordedOrderDates:eligible.filter(r=>r.recordedOrderDate).length,recordedReasons:eligible.filter(r=>r.delayReason||r.delayCause).length,
  sourceDates:unique(eligible.map(r=>r.date)).sort(),note:eligible.length&&!eligible.some(hasValue)?'Delay Cause 시트는 있으나 부품 필요일·발주일·지연 사유가 모두 공란. Addeddate를 필요일로 사용하지 않음.':'업체 기재 자료는 제품·센터·사업자·부품이 모두 일치할 때만 연결하며 귀책을 확정하지 않음.'};
}
function enrich(output,state,options={}){
 const selected=R.reports(state).find(report=>report.id===output.week);if(!selected)throw Error('저장된 주간 보고를 찾지 못했습니다.');
 const reports=R.reports(state).filter(report=>report.id<=selected.id&&report.cutoff<=selected.cutoff),trend=[];let previous=null;
 for(const report of reports){const point=weekMetrics(state,report,options.contextFor?.(report)),changes={};for(const scope of SCOPES){const change=waitingChanges(point._products,previous?._products,scope,point.availableByCenter[scope].wip,previous?.availableByCenter[scope].wip);change.previousReportWeek=previous?.week||null;change.reportGapDays=previous?T.ageAt(previous.week,point.week).age:null;change.consecutiveReportingWeeks=change.reportGapDays===7;if(previous&&!change.consecutiveReportingWeeks&&change.available)change.reason+=' · 저장된 두 보고 사이에 빈 주가 있어 연속 주차 관찰을 뜻하지 않음';changes[scope]=change;}point.observedWaitingChanges=changes;trend.push(point);previous=point;}
 output.trend=trend.map(({_products,...point})=>point);output.overdue=overdueData(output,state,selected,options.contextFor?.(selected).calculated);
 attachSupplierEvidence(output,options.supplierRecords||[]);
 output.qualityByCenter=trend.at(-1)?.qualityByCenter||{};output.availability=trend.at(-1)?.available||{};output.availabilityByCenter=trend.at(-1)?.availableByCenter||{};
 output.checks.weeklyEvidence={reportCount:trend.length,sourceDatesPreserved:true,staleWipTrendNull:trend.every(point=>SCOPES.every(scope=>point.availableByCenter[scope].wip||point.metricsByCenter[scope].wip===null&&point.metricsByCenter[scope].over45===null)),overdueProducts:output.overdue.metricsByCenter['전체'].products,overduePartKinds:output.overdue.metricsByCenter['전체'].partKinds,overdueRequiredQty:output.overdue.metricsByCenter['전체'].requiredQty,poAllocationConfirmed:false};
 return output;
}

function build(input,options={}){
 const state=R.normalizeState(input||C.empty()),reports=R.reports(state);
 const selected=options.reportId!=null?reports.find(report=>report.id===options.reportId):reports.at(-1);
 if(options.reportId!=null&&!selected)throw Error('저장된 주간 보고를 찾지 못했습니다.');
 if(!selected)return emptyOutput(state);
 // Keep only the selected report's large calculations. Historical reports are
 // projected sequentially to small metric rows and can then be garbage-collected.
 let selectedContext=null;
 const contextFor=report=>report.id===selected.id?(selectedContext||(selectedContext=reportContext(state,report))):reportContext(state,report);
 const context=contextFor(selected),reportState=context.resolved,asof=selected.cutoff,calculated=context.calculated;
const operations=context.operations,actions=context.actions,exclusive=context.exclusive;
const followups=F.evaluate(reportState,calculated,{asof}),tat=context.tat,trace=options.traceResult||Trace.evaluate(state,{asof,reportId:selected.id});
const names=Names.buildNameIndex(calculated.used),registry=L.normalizeRegistry(state.partLeadTimes),lead=L.procurementReview(reportState,calculated.commonSupport);
const rowKey=row=>row.center+'|'+row.part;
const english=(text,fallback)=>{const translated=I.text(text||'','en');return /[가-힣]/.test(translated)?fallback||translated:translated;};
const sourceDates=dates(calculated,selected);
const commonDates={india:sourceDates.find(s=>s.type==='india')?.date||null,hq:sourceDates.find(s=>s.type==='hq')?.date||null};
const sourceFor=(type,center)=>sourceDates.find(s=>s.type===type&&(!center||s.center===center));
const sourceWeeksFor=center=>Object.fromEntries([['stock','dashboard',center],['po','po',center],['india','india'],['hq','hq']].map(([key,type,scope])=>[key,sourceFor(type,scope)?.reportWeek||null]));
const taskFallback=t=>({ORDER:`Additional PO needed: ${t.quantity} pcs`,SUPPLY:positive(t.row.open)?`Follow up existing PO supply and dispatch: ${t.row.open} pcs`:'Review supply of parts required for current repairs',HQ_SUPPLY:'Review HQ supply against India requests and existing orders',WIP_STOCK:'Check usable stock and current parts-waiting status',LT_REQUEST:'Review an advance supply request for this long-lead part',LT_REVIEW:'Review long-lead supply against India requests and existing purchasing plans'})[t.kind];
const tasks=followups.tasks.map(t=>({id:t.id,rowId:rowKey(t),part:t.part,center:t.center,recipient:t.recipient,kind:t.kind,
 textKo:t.text,textEn:english(t.text,taskFallback(t)),quantity:t.quantity,quantityBasis:t.quantityBasis,
 supplyRoleKey:t.supplyRoleKey||null,poFollowup:t.poFollowup?{matched:t.poFollowup.matched,plannedQuantity:t.poFollowup.plannedQuantity,unplannedQuantity:t.poFollowup.unplannedQuantity,detailPending:t.poFollowup.detailPending,reason:t.poFollowup.reason||'',dates:unique((t.poFollowup.tasks||[]).flatMap(task=>task.dates||[])).sort()}:null,
 scheduleKo:t.scheduleNote||'',scheduleEn:english(t.scheduleNote||'','Check the planned India-to-center dispatch schedule; actual dispatch and receipt are unconfirmed.'),
 priority:t.priority,tat:{products:t.tat.products,overdueProducts:t.tat.overdueProducts,maxAge:t.tat.maxAge},
 notesKo:t.notes||[],notesEn:(t.notes||[]).map(n=>english(n)),sourceDates:t.sourceDates,sourceWeeks:sourceWeeksFor(t.center)}));
const tasksByRow=new Map();for(const task of tasks){if(!tasksByRow.has(task.rowId))tasksByRow.set(task.rowId,[]);tasksByRow.get(task.rowId).push(task);}
const memberMap=new Map(exclusive.members.map(row=>[rowKey(row),row]));
const registeredByCenter=new Map(actions.inventoryScope.centers.map(scope=>[scope.center,new Set(scope.registeredParts)]));
const rows=calculated.parts.map(row=>{const id=rowKey(row),info=operations.memberInfo[id]||{},member=memberMap.get(id),rowTasks=tasksByRow.get(id)||[],reason=unique([...(info.reasons||[]),info.supplyReason].filter(Boolean)).join(' · ');return {
 id,part:row.part,name:Names.resolve(names,row.part,row.center).partName,center:row.center,registered:!!registeredByCenter.get(row.center)?.has(row.part),
 stock:row.stock,india:row.india,hq:row.hq,avg:row.avg,avgReason:row.avgReason,issues:row.issues,needed:row.needed,shortage:row.shortage,shortageBasis:row.shortageBasis,wipWaitingQty:row.wipWaitingQty,stockShortage:row.stockShortage,currentOrderNeed:row.currentOrderNeed,futureOrderNeed:row.futureOrderNeed,
 poOrdered:row.poOrdered,open:row.open,proposed:row.proposed,target:row.target,status:member?.statusCategory||'UNASSESSED',
 currentAssessed:!!member?.currentAssessed,orderAssessed:!!member?.orderAssessed,waitingCovered:!!member?.waitingCovered,
 lowUsage:!!operations.lowUsage[id]?.flag,longLead:!!registry[row.part],ownerRoles:unique(rowTasks.map(t=>t.recipient)),
 ownerReason:reason,ownerReasonEn:english(reason),sourceDates:{stock:row.dashboardDate||null,need:row.needDate||null,wip:row.wipDate||null,po:row.poSourceDate||null,...commonDates},sourceWeeks:sourceWeeksFor(row.center),taskIds:rowTasks.map(t=>t.id)};});
const products=tat.rows.map(row=>({id:row.productId,center:row.center,operator:row.operator,sn:row.sn||'',rma:row.rma||'',fert:row.fert||'',status:row.status,
 required:row.required||'',receipt:row.receipt||null,date:row.date||null,age:row.ageDays,fan:row.repairCategory==='FAN',category:row.repairCategory,
 parts:row.partEntries.map(part=>{const h=trace.byKey[Trace.rowKey(row,part.part)]||{continuityUncertain:true};return {part:part.part,quantity:part.quantity,
  traceKey:h.key,firstDate:h.effectiveFirstSeenDate||h.firstSeenDate,firstWeek:h.firstSeenWeek,firstAge:h.effectiveFirstSeenAgeDays??h.firstSeenAgeDays,autoFirstDate:h.firstSeenDate,autoFirstAge:h.firstSeenAgeDays,
  manualFirstConfirmedDate:h.manualFirstConfirmedDate||null,manualFirstConfirmedNote:h.manualFirstConfirmedNote||'',manualFirstConfirmedUpdatedAt:h.manualFirstConfirmedUpdatedAt||null,firstConfirmedSource:h.firstConfirmedSource||'automatic',firstConfirmedConflict:h.firstConfirmedConflict===true,firstConfirmedIssues:h.firstConfirmedIssues||[],
  baseline:h.baselinePresent,continuityUncertain:h.continuityUncertain,
  priorWithoutDate:h.priorObservedWithoutDate,observations:h.observationCount,consecutiveWeeks:h.consecutiveWeeks,
  firstReportWeek:h.firstSeenReportWeek||h.firstSeenWeek||null,episodeStartDate:h.episodeStartDate||null,lastSeenDate:h.lastSeenDate||null,episodeIndex:h.episodeIndex??null};}),
 unparsed:row.tokens?.unparsed||'',excludedNameplate:row.tokens?.excludedNameplate||0,hasUnresolvedParts:row.hasUnresolvedParts,source:row.source,sheet:row.sheet,row:row.row}));
const pos=calculated.pos.map(row=>{const age=T.ageAt(row.poDate,row.date).age;return {center:row.center,part:row.part,po:row.po||'',item:row.item||'',poDate:row.poDate||null,date:row.date||null,
 ordered:row.ordered,shipped:row.shipped,pending:row.pending,etd:row.etd||null,age,reportWeek:sourceFor('po',row.center)?.reportWeek||null,datePrecision:sourceFor('po',row.center)?.datePrecision||'unknown',source:row.source,sheet:row.sheet,row:row.row};});
function officialMetrics(center){const s=context.scope(center),c=s.calculated,o=s.operations,a=s.actions,ex=s.exclusive,w=s.tat,group=code=>ex.groups.find(g=>g.code===code);return {
 shortageKinds:group('SUPPLY_NOW').partCount,shortageQty:group('SUPPLY_NOW').quantity.knownSubtotal,
 orderKinds:group('ORDER').partCount,orderQty:group('ORDER').quantity.knownSubtotal,
 waitKinds:group('WAIT_PO').partCount,waitQty:group('WAIT_PO').quantity.knownSubtotal,
 wip:w.summary.products,over45:w.summary.overdueProducts,fan:w.summary.fanProducts,general:w.summary.generalProducts,
 over45Fan:w.summary.overdueFanProducts,over45General:w.summary.overdueGeneralProducts,partKinds:w.summary.partKinds,
 neededQty:w.summary.quantity,unparsedProducts:w.summary.unresolvedPartProducts,over45Unparsed:w.summary.unresolvedPartOverdueProducts,
 trackedKinds:ex.counts.allParts,registeredKinds:a.inventoryScope.registeredPartCount,dashboardMissingKinds:a.inventoryScope.missingOwnDashboard.partCount,
 outsideRegisteredKinds:a.inventoryScope.outsideRegistered.partCount,sharedRegisteredKinds:a.inventoryScope.sharedPartCount,unassessedKinds:ex.counts.UNASSESSED};}
const metricsByCenter=Object.fromEntries(['전체','Flex','CTDI'].map(center=>[center,officialMetrics(center)]));
function projectedMetrics(center){const scoped=rows.filter(r=>center==='전체'||r.center===center),byPart=new Map();for(const row of scoped){if(!byPart.has(row.part))byPart.set(row.part,[]);byPart.get(row.part).push(row);}const result={shortageKinds:0,shortageQty:0,orderKinds:0,orderQty:0,waitKinds:0,waitQty:0};for(const members of byPart.values()){
 let key=null,field=null,predicate=null;if(members.some(r=>positive(r.shortage))){key='shortage';field='shortage';predicate=r=>positive(r.shortage);}
 else if(!members.every(r=>r.currentAssessed))continue;
 else if(members.some(r=>positive(r.proposed))){key='order';field='proposed';predicate=r=>positive(r.proposed);}
 else if(!members.every(r=>r.orderAssessed))continue;
 else if(members.some(r=>r.waitingCovered)){key='wait';field='open';predicate=r=>r.waitingCovered;}
 if(key){result[key+'Kinds']++;result[key+'Qty']+=members.filter(predicate).reduce((sum,r)=>sum+r[field],0);}
 }return result;}
const issueRows=calculated.parts.filter(row=>row.poDiagnostics?.length||row.issues?.includes('PO 잔량 불일치')).map(row=>({center:row.center,part:row.part,open:row.open,detailPending:row.detailPending,issues:row.issues.filter(text=>/PO/.test(text))}));
const issues={duplicates:calculated.duplicateDiagnostics.map(d=>({type:d.type,center:d.center,part:d.part,file:d.file,sheet:d.sheet,date:d.date,selectedRow:d.selectedRow,ignoredRows:d.ignoredRows})),
 missingDashboardCodes:calculated.masterAlerts.map(a=>({center:a.center,part:a.part,file:a.file,date:a.date,stock:a.stock})),
 unresolvedProducts:products.filter(p=>p.hasUnresolvedParts).map(p=>({id:p.id,center:p.center,operator:p.operator,required:p.required,unparsed:p.unparsed,age:p.age,source:p.source,sheet:p.sheet,row:p.row})),
 po:issueRows,carriedSources:sourceDates.filter(s=>s.carriedForward),warnings:unique([...(calculated.warnings||[]),...R.reportWarnings(state,selected.id),...(trace.warnings||[])])};
const exclusiveMetricsMatch=SCOPES.every(center=>Object.entries(projectedMetrics(center)).every(([key,value])=>value===metricsByCenter[center][key]));
const translationIssues=tasks.filter(t=>/[가-힣]/.test([t.textEn,t.scheduleEn,...t.notesEn].join(' '))).map(t=>t.id);
const output={dataAvailable:true,asof,week:selected.id,sourceDates,settings:{targetMonths:C.effectiveTargetMonths(state.settings),indiaMonths:C.effectiveSupportMonths(state.settings,'india'),hqMonths:C.effectiveSupportMonths(state.settings,'hq'),lowUsageSixMonthMax:O.threshold(state.settings)},
 rows,tasks,products,pos,firstConfirmedEntries:trace.entries,metricsByCenter,issues,leadAlerts:lead.alerts,commonSupport:commonProjection(calculated.commonSupport,names),
 checks:{exclusiveMetricsMatch,traceKeysComplete:tat.rows.every(row=>row.partEntries.every(part=>!!trace.byKey[Trace.rowKey(row,part.part)])),
  rowCount:rows.length,taskCount:tasks.length,productCount:products.length,knownRequiredQuantity:tat.summary.quantity,unresolvedProductCount:tat.summary.unresolvedPartProducts,
  firstSeenNew:trace.entries.filter(e=>e.firstSeenDate===asof&&!e.baselinePresent).length,baselinePresent:trace.entries.filter(e=>e.baselinePresent).length,
  translationIssues,units:'Stock/need/PO quantities are pieces; WIP counts are unique products; part kinds are unique codes. Do not add shared India/HQ stock across center rows.',
  poAgeBasis:'PO source date minus PO order date; ETD is planned India-to-center dispatch, not receipt.',liabilityConfirmed:false}};

 const imported=copy(state.importDiagnostics||{weeks:[]});
 if(Array.isArray(imported.weeks))imported.weeks=imported.weeks.filter(week=>!week.reportWeek||week.reportWeek<=selected.id);
 output.importDiagnostics=imported;
 output.siel=Siel.build(reportState.sources,asof,selected.id,C.sourceSelectionDate);
 if(output.siel.available){const s=reportState.sources.filter(source=>source.type==='siel').sort((a,b)=>(C.sourceSelectionDate(a)||'').localeCompare(C.sourceSelectionDate(b)||'')).at(-1);output.sourceDates.push({type:'siel',center:'',operator:'',date:s.date,reportWeek:s.reportWeek||selected.id,datePrecision:s.datePrecision||'day',file:s.file,sheet:s.sheet,demo:s.demo===true,carriedForward:(C.sourceSelectionDate(s)||'')<selected.id});}
 enrich(output,state,{supplierRecords:state.supplierRecords||[],contextFor});
 // Import may retain an audit summary after intentionally omitting entirely
 // blank supplier rows. Preserve that audit, but never reuse a later audit's
 // counts when the caller explicitly asks for an earlier reporting week.
 const audit=state.supplierEvidenceStatus;
 if(!(state.supplierRecords||[]).length&&audit&&audit.available===false){
  const auditDates=audit.sourceDates||[];
  if(auditDates.length&&auditDates.every(date=>R.validDate(date)&&date<=asof))output.supplierEvidenceStatus={...copy(audit),available:false,matchedPopulatedRows:0};
  else if(Array.isArray(audit.bySource)){
   const sources=audit.bySource.filter(source=>R.validDate(source.date)&&source.date<=asof);
   output.supplierEvidenceStatus={...output.supplierEvidenceStatus,reviewedRows:sum(sources.map(source=>source.reviewedRows)),sourceDates:unique(sources.map(source=>source.date)).sort(),bySource:copy(sources),note:audit.note||output.supplierEvidenceStatus.note};
  }
 }
 output.checks.importAuditsMatch=(imported.weeks||[]).every(week=>(week.wipAudit||[]).every(audit=>audit.matches===true));
 return output;
}
function emptyOutput(state){
 const fake={id:'',cutoff:''},calculated={parts:[],wip:[],pos:[],used:[]},base={shortageKinds:0,shortageQty:0,orderKinds:0,orderQty:0,waitKinds:0,waitQty:0,wip:0,over45:0,fan:0,general:0,over45Fan:0,over45General:0,partKinds:0,neededQty:0,unparsedProducts:0,over45Unparsed:0,trackedKinds:0,registeredKinds:0,dashboardMissingKinds:0,outsideRegisteredKinds:0,sharedRegisteredKinds:0,unassessedKinds:0};
 const availableByCenter=Object.fromEntries(SCOPES.map(scope=>[scope,availability(calculated,fake,scope)]));
 const output={dataAvailable:false,asof:null,week:null,sourceDates:[],settings:{targetMonths:C.effectiveTargetMonths(state.settings),indiaMonths:C.effectiveSupportMonths(state.settings,'india'),hqMonths:C.effectiveSupportMonths(state.settings,'hq'),lowUsageSixMonthMax:O.threshold(state.settings)},rows:[],tasks:[],products:[],pos:[],firstConfirmedEntries:[],metricsByCenter:Object.fromEntries(SCOPES.map(scope=>[scope,{...base}])),issues:{duplicates:[],missingDashboardCodes:[],unresolvedProducts:[],po:[],carriedSources:[],warnings:[]},leadAlerts:[],trend:[],availability:availableByCenter['전체'],availabilityByCenter:availableByCenter,importDiagnostics:copy(state.importDiagnostics||{weeks:[]}),checks:{rowCount:0,taskCount:0,productCount:0,traceKeysComplete:true,exclusiveMetricsMatch:true,liabilityConfirmed:false}};
 output.siel=Siel.projection(null);output.overdue=overdueData(output,state,fake,calculated);attachSupplierEvidence(output,[]);return output;
}
return {build,availability,quantityCoverage,waitingChanges,weekMetrics,overdueData,attachSupplierEvidence};
});
