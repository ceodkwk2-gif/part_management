(function(root,factory){
 if(typeof module==='object'&&module.exports)module.exports=factory(require('./overview.js'),require('./summary-mail.js'),require('./overdue-mail.js'));
 else root.PartsSummaryDownloads=factory(root.PartsOverview,root.PartsExampleMail,root.PartsOverdueMail);
})(typeof self!=='undefined'?self:this,function(O,Mail,OverdueMail){
'use strict';
// Read-only export models. Presentation/download code owns CSV, HTML, clipboard
// and workbook I/O. Never recalculate stock, allocate shared stock or rewrite an
// observation date here. All rows (not preview/pagination slices) are retained.
const number=value=>typeof value==='number'&&Number.isFinite(value);
const value=x=>number(x)?x:null;
const scope=center=>['Flex','CTDI'].includes(center)?center:'ALL';
const key=center=>center==='ALL'?'전체':center;
const scopes=center=>scope(center)==='ALL'?['ALL','Flex','CTDI']:[scope(center)];
const pick=(language,ko,en)=>language==='en'?en:ko;
const centerLabel=(center,language)=>center==='ALL'?pick(language,'전체','All centers'):center;
const unique=values=>[...new Set(values.filter(x=>x!==null&&x!==undefined&&x!==''))];
const TITLES={
 SUMMARY:['요약','Summary'],TREND_OVERDUE:['45일 초과 추이','Over-45-day trend'],TREND_ACTIONS:['자재 조치 추이','Material action trend'],
 TREND_PRODUCTS:['자재대기 제품 추이','Waiting-product trend'],AGING:['45일 초과 TAT 분포','Over-45-day TAT bands'],
 OVERDUE:['45일 초과 부품별 조치','Over-45-day parts and actions'],OVERDUE_PRODUCTS:['45일 초과 제품 목록','Products over 45 days'],
 WAITING_PRODUCTS:['전체 자재대기 제품','All products waiting for parts'],SOURCES:['적용 원본 목록','Applied source files'],PARTS:['전체 자재 현황','All material details']
};
const TYPES=Object.keys(TITLES);
function title(type,language){return (TITLES[type]||[type,type])[language==='en'?1:0]}
function scopedSources(point,center){return (point.sourceDates||[]).filter(s=>center==='ALL'||!s.center||s.center===center)}
function wipSources(point,center){return scopedSources(point,center).filter(s=>s.type==='wip')}
function wipDates(point,center){return unique(wipSources(point,center).map(s=>[s.center,s.operator,s.date||''].filter(Boolean).join(' '))).join(' / ')}
function wipFresh(point,center){
 const a=(point.availableByCenter||point.availabilityByCenter)?.[key(center)]?.wip;
 if(typeof a==='boolean')return a;
 const b=point.overdue?.freshByCenter?.[key(center)];
 if(typeof b==='boolean')return b;
 if(center==='ALL'&&typeof point.overdue?.fresh==='boolean')return point.overdue.fresh;
 return null;
}
function wipState(point,center,language){
 const list=wipSources(point,center),fresh=wipFresh(point,center);
 if(!list.length)return pick(language,'WIP 자료 없음','No WIP source');
 if(fresh===true)return pick(language,'해당 주 신규 WIP','Fresh WIP for this week');
 if(fresh===false)return pick(language,'이전 WIP 참고 또는 일부 자료 미반영','Previous WIP reference or incomplete sources');
 return pick(language,'신규 관찰 여부 미확인','Observation freshness unconfirmed');
}
function sourceText(point,center,language){
 const names={wip:'WIP',dashboard:pick(language,'센터 재고','Center stock'),po:'PO',india:pick(language,'법인 재고','India stock'),hq:pick(language,'본사 재고','HQ stock')};
 return unique(scopedSources(point,center).map(s=>[names[s.type]||s.type,s.center,s.operator,s.date||(s.reportWeek?s.reportWeek+pick(language,' 주차 · 실제 날짜 미확인',' week · exact date unknown'):pick(language,'기준일 미확인','Source date unknown')),(s.carriedForward||s.fresh===false)?pick(language,'(참고)','(reference)'):''].filter(Boolean).join(' '))).join('\n');
}
function commonContext(data,center,language){return [
 pick(language,'센터: ','Center: ')+centerLabel(center,language),
 pick(language,'보고 주차: ','Report week: ')+(data.week||pick(language,'없음','none')),
 pick(language,'WIP 기준: ','WIP basis: ')+(wipDates(data,center)||pick(language,'미확인','unknown')),
 wipState(data,center,language)
]}
function commonNotes(language){return language==='en'?[
 'Part quantities are gross requirements before stock deduction, not additional purchase quantities. Unparsed requirements remain in product counts but cannot be added to known part quantities.',
 'Product counts, distinct part types and part quantities are different measures. All-center part types are deduplicated; do not add the All row to center rows.',
 'TAT is Physical Receipt Date to the actual WIP date. Over 45 means 46+ days. Blank numeric cells mean unassessed, not zero.',
 'A product disappearing from a later WIP does not establish repair completion, shipment or part receipt.'
 ]:[
 '필요 부품 수량은 재고 차감 전 수리 필요량이며 추가 구매 수량이 아닙니다. 미해석 요구사항은 제품 대수에 남고 확인된 부품 수량에는 더하지 않습니다.',
 '제품 대수·부품 종수·부품 개수는 다른 단위입니다. 전체 종수는 센터 간 중복 코드 제거 기준이며 전체 행과 센터별 행을 합산하지 않습니다.',
 'TAT는 Physical Receipt Date부터 각 WIP 실제 기준일까지입니다. 45일 초과는 46일부터이며 숫자 공란은 미산정이지 0이 아닙니다.',
 '다음 WIP에서 사라졌다는 사실만으로 수리 완료·출고·부품 입고를 확정하지 않습니다.'
 ]}
function model(id,{data,center,language},columns,records,extra={}){
 return {id,title:title(id,language),localized:true,language,reportDate:data.asof||'',context:commonContext(data,center,language),columns,
  rows:records.map(record=>Array.isArray(record)?record:columns.map(column=>record[column.key]??null)),notes:commonNotes(language),...extra};
}
function columns(spec,language){return spec.map(([key,ko,en])=>({key,label:pick(language,ko,en)}))}
function products(data,center,overdue=false){
 const seen=new Set();return (data.products||[]).filter((p,index)=>{
  if(center!=='ALL'&&p.center!==center||overdue&&(!number(p.age)||p.age<=45))return false;
  const id=p.id||JSON.stringify([p.center,p.operator,p.sn,p.rma,p.receipt,index]);
  if(seen.has(id))return false;seen.add(id);return true;
 });
}
function partStats(ps){
 const kinds=new Set();let quantity=0;
 for(const p of ps)for(const entry of p.parts||[])if(entry.part&&number(entry.quantity)&&entry.quantity>0){kinds.add(entry.part);quantity+=entry.quantity;}
 return {products:ps.length,parts:kinds.size,quantity,fan:ps.filter(p=>p.fan).length,general:ps.filter(p=>!p.fan).length,
  unparsed:ps.filter(p=>p.hasUnresolvedParts||p.unparsed||!(p.parts||[]).some(e=>e.part&&number(e.quantity)&&e.quantity>0)).length};
}
function hasWip(data,center){return wipSources(data,center).length>0||products(data,center).length>0}
function previousPoint(data){
 const latest=data.trend?.at(-1),stamp=Date.parse((latest?.week||'')+'T00:00:00Z');
 if(!Number.isFinite(stamp))return data.trend?.at(-2);
 const week=new Date(stamp-7*86400000).toISOString().slice(0,10);
 return data.trend.find(point=>point.week===week)||{week,missingReport:true};
}
function previousMetric(data,center,field,currentFresh=true){
 const point=previousPoint(data);if(!currentFresh||!point||point.missingReport)return null;
 const actionKind=/^(shortage|order|wait)(Kinds|Qty)$/.exec(field)?.[1];
 if(actionKind?point.availableByCenter?.[key(center)]?.actionAvailability?.[actionKind]===false:wipFresh(point,center)===false)return null;
 return value(point.metricsByCenter?.[key(center)]?.[field]);
}
function difference(now,before){return number(now)&&number(before)?now-before:null}
function summary(options){
 const {data,center,language}=options,records=[],months=data.settings?.targetMonths??1;
 for(const c of scopes(center)){
  const m=O.metrics(data,c),hasRows=(data.rows||[]).some(r=>c==='ALL'||r.center===c),has=hasWip(data,c),fresh=wipFresh(data,c)!==false;
  const base={center:centerLabel(c,language),week:data.week||'',asof:data.asof||'',previousWeek:previousPoint(data)?.week||'',wipState:wipState(data,c,language),wipDates:wipDates(data,c),sources:sourceText(data,c,language)};
  const definitions=[
   ['SHORTAGE',pick(language,'현재 수리분 부족','Current repair shortage'),'shortageKinds','shortageQty',pick(language,'현재 부족 수량','Current shortage quantity')],
   ['ORDER',pick(language,months+'개월분 부족 · 추가 PO 필요',months+'-month stock · Additional PO needed'),'orderKinds','orderQty',pick(language,'추가 PO 필요 수량','Additional PO quantity')],
   ['WAIT',pick(language,months+'개월분 부족 · PO 입고 대기',months+'-month stock · Awaiting PO'),'waitKinds','waitQty',pick(language,'PO 미입고 수량','Open PO quantity')]
  ];
  for(const [kind,label,kf,qf,basis]of definitions){
   const availability=data.availabilityByCenter?.[key(c)]?.actionAvailability?.[kind.toLowerCase()],assessed=availability===true||(availability!==false&&hasRows);
   const x=m[kind],parts=assessed?x.parts:null,quantity=assessed?x.quantity:null,pp=previousMetric(data,c,kf),pq=previousMetric(data,c,qf);
   records.push({...base,category:label,parts,quantity,quantityBasis:basis,priorParts:pp,partsChange:difference(parts,pp),priorQty:pq,qtyChange:difference(quantity,pq),zero:assessed?x.zero:null,low:assessed?x.low:null,long:assessed?x.long:null});
  }
  for(const over of [false,true]){
   const x=partStats(products(data,c,over)),parts=has?x.parts:null,quantity=has?x.quantity:null,count=has?x.products:null,kf=over?'over45PartKinds':'partKinds',qf=over?'over45RequiredQty':'neededQty',pf=over?'over45':'wip';
   const pp=previousMetric(data,c,kf,fresh),pq=previousMetric(data,c,qf,fresh),pr=previousMetric(data,c,pf,fresh);
   records.push({...base,category:pick(language,over?'45일 초과 자재대기':'전체 자재대기',over?'Parts waiting over 45 days':'All products waiting for parts'),parts,quantity,products:count,fan:has?x.fan:null,general:has?x.general:null,unparsed:has?x.unparsed:null,
    quantityBasis:pick(language,'재고 차감 전 필요 부품','Parts required before stock deduction'),priorParts:pp,partsChange:difference(parts,pp),priorQty:pq,qtyChange:difference(quantity,pq),priorProducts:pr,productsChange:difference(count,pr)});
  }
 }
 return model('SUMMARY',options,columns([
 ['center','센터','Center'],['category','항목','Metric'],['parts','부품 종수(종)','Part types'],['products','제품 수량(대)','Products'],['quantity','부품 수량(개)','Part quantity (pcs)'],['quantityBasis','수량 의미','Quantity meaning'],
 ['priorParts','전주 종수','Prior-week part types'],['partsChange','종수 증감','Part-type change'],['priorProducts','전주 제품 수','Prior-week products'],['productsChange','제품 증감','Product change'],['priorQty','전주 부품 수량','Prior-week part quantity'],['qtyChange','부품 수량 증감','Part-quantity change'],
 ['zero','센터 재고 0(종)','Zero center stock (types)'],['low','저소요(종)','Low use (types)'],['long','등록 장납(종)','Registered long LT (types)'],['fan','FAN(대)','FAN products'],['general','일반(대)','General products'],['unparsed','부품 표기 확인(대)','Unparsed products'],
 ['week','보고 주차','Report week'],['asof','보고 기준일','Report date'],['previousWeek','전주','Prior week'],['wipState','WIP 적용 상태','WIP observation status'],['wipDates','WIP 실제 기준일','Actual WIP dates'],['sources','적용 원본 기준일','Applied source dates']
 ],language),records);
}
const TREND_FIELDS={
 TREND_OVERDUE:[['over45','45일 초과 제품(대)','Products over 45 days'],['over45PartKinds','필요 부품(종)','Required part types'],['over45RequiredQty','필요 부품(개)','Required parts (pcs)'],['over45Fan','FAN(대)','FAN products'],['over45General','일반(대)','General products'],['over45Unparsed','부품 표기 확인(대)','Unparsed products']],
 TREND_ACTIONS:[['shortageKinds','수리분 부족(종)','Repair shortage (types)'],['shortageQty','수리분 부족(개)','Repair shortage (pcs)'],['orderKinds','추가 PO 필요(종)','Additional PO (types)'],['orderQty','추가 PO 필요(개)','Additional PO (pcs)'],['waitKinds','PO 입고 대기(종)','Awaiting PO (types)'],['waitQty','PO 입고 대기(개)','Open PO (pcs)']],
 TREND_PRODUCTS:[['wip','전체 자재대기(대)','All waiting products'],['over45','45일 초과(대)','Products over 45 days'],['partKinds','전체 필요 부품(종)','All required part types'],['neededQty','전체 필요 부품(개)','All required parts (pcs)'],['fan','FAN(대)','FAN products'],['general','일반(대)','General products'],['unparsedProducts','부품 표기 확인(대)','Unparsed products']]
};
function trend(id,options){
 const {data,center,language}=options,records=[];
 for(const point of data.trend||[])for(const c of scopes(center)){
  const metrics=point.metricsByCenter?.[key(c)]||{},availability=point.availableByCenter?.[key(c)]||{},isWip=id!=='TREND_ACTIONS';
  const record={week:point.week||'',asof:point.asof||'',center:centerLabel(c,language),wipState:wipState(point,c,language),wipDates:wipDates(point,c),sources:sourceText(point,c,language),actionState:availability.actionAvailability?Object.entries(availability.actionAvailability).map(([kind,available])=>({shortage:pick(language,'수리분 부족','Repair shortage'),order:pick(language,'추가 PO','Additional PO'),wait:pick(language,'입고 대기','Awaiting PO')}[kind])+': '+(available?pick(language,'산정 가능 · 적용 원본 기준','Available · applied source basis'):pick(language,'산정 불가','Unavailable'))).join(' / '):pick(language,'미확인','Unconfirmed'),demandState:availability.repairDemand===true?pick(language,'해당 주 수요','Current-week demand'):availability.repairDemand===false?pick(language,'이전 수요 참고 또는 일부 미산정','Previous demand reference or partly unassessed'):pick(language,'미확인','Unconfirmed')};
  for(const [field]of TREND_FIELDS[id]){const actionKind=/^(shortage|order|wait)(Kinds|Qty)$/.exec(field)?.[1],unavailable=isWip?wipFresh(point,c)===false:actionKind&&availability.actionAvailability?.[actionKind]===false;record[field]=unavailable?null:value(metrics[field]);}
  records.push(record);
 }
 return model(id,options,columns([['week','보고 주차','Report week'],['asof','보고 기준일','Report date'],['center','센터','Center'],...TREND_FIELDS[id],['wipState','WIP 적용 상태','WIP observation status'],['wipDates','WIP 실제 기준일','Actual WIP dates'],['demandState','수요 적용 상태','Demand status'],...(id==='TREND_ACTIONS'?[['actionState','부족·발주 산정 상태','Action calculation status']]:[]),['sources','적용 원본 기준일','Applied source dates']],language),records,{notes:[...commonNotes(language),pick(language,'보고가 없는 주를 임의로 생성하지 않습니다. 새 WIP가 없거나 불완전한 주의 WIP 추이는 공란입니다. 재고·수요·PO 판단 근거가 없는 부족/발주 항목도 공란이며 0이 아닙니다.','Missing reporting weeks are not invented. WIP trend cells stay blank when fresh WIP is absent or incomplete. Action cells also stay blank, not zero, when required stock/demand/PO evidence is unavailable.')]});
}
function aging(options){
 const {data,center,language}=options,records=[];
 for(const c of scopes(center)){
  const ps=products(data,c,true),has=hasWip(data,c);
  for(const [lo,hi,label]of [[46,90,'46–90'],[91,180,'91–180'],[181,Infinity,'181+']]){
   const x=partStats(ps.filter(p=>p.age>=lo&&p.age<=hi));records.push({center:centerLabel(c,language),band:label+pick(language,'일',' days'),products:has?x.products:null,percent:has&&ps.length?Math.round(x.products/ps.length*10000)/100:null,parts:has?x.parts:null,quantity:has?x.quantity:null,fan:has?x.fan:null,general:has?x.general:null,unparsed:has?x.unparsed:null,wipState:wipState(data,c,language),wipDates:wipDates(data,c)});
  }
 }
 return model('AGING',options,columns([['center','센터','Center'],['band','제품 TAT','Product TAT'],['products','제품 수량(대)','Products'],['percent','45일 초과 제품 중 비중(%)','Share of over-45-day products (%)'],['parts','필요 부품(종)','Required part types'],['quantity','필요 부품(개)','Required parts (pcs)'],['fan','FAN(대)','FAN products'],['general','일반(대)','General products'],['unparsed','부품 표기 확인(대)','Unparsed products'],['wipState','WIP 적용 상태','WIP observation status'],['wipDates','WIP 실제 기준일','Actual WIP dates']],language),records,{notes:[...commonNotes(language),pick(language,'경과일 구간은 제품 대수를 기준으로 서로 겹치지 않습니다. 같은 부품이 여러 구간에 필요할 수 있으므로 구간별 종수는 합산하지 않습니다. 비중은 반올림으로 100%와 소폭 다를 수 있습니다.','Age bands partition product counts. The same part may occur in several bands, so do not sum band-specific part types. Rounded shares may differ slightly from 100%.')]});
}
function waiting(id,options){
 const {data,center,language}=options,ps=products(data,center,id==='OVERDUE_PRODUCTS'),base=Mail.buildWaitingTable({data,products:ps,language});
 const extra=columns([['category','구분','Category'],['fert','제품 코드','Product code'],['requiredRaw','Required Part 원문','Original Required Part'],['unparsed','부품 표기 확인','Unparsed part notation'],['source','파일','File'],['sheet','시트','Sheet'],['sourceRow','원본 행','Source row']],language);
 return model(id,options,[...base.columns,...extra],base.rows.map((row,index)=>{const p=ps[index];return [...row,p.fan?'FAN':pick(language,'일반','General'),p.fert||'',p.required||'',p.unparsed||'',p.source||'',p.sheet||'',p.row??null]}),{productCount:ps.length,notes:[...commonNotes(language),...(base.notes||[])]});
}
function overdue(options){
 const {data,center,language,notes,recipient,rowIds}=options,base=OverdueMail.build({data,center,language,notes,recipient:recipient==='all'?'ALL':recipient||'ALL',rowIds,includeUnparsed:true});
 return model('OVERDUE',options,base.columns,base.rows,{context:[...commonContext(data,center,language),base.context],notes:[...commonNotes(language),...(base.notes||[])]});
}
function sources(options){
 const {data,center,language}=options,names={wip:'WIP',dashboard:pick(language,'센터 대시보드','Center dashboard'),po:'PO',india:pick(language,'법인 재고','India stock'),hq:pick(language,'본사 재고','HQ stock')};
 const records=scopedSources(data,center).map(s=>({type:names[s.type]||s.type,center:s.center||pick(language,'공용','Shared'),operator:s.operator||'',date:s.date||null,week:s.reportWeek||null,precision:s.date?pick(language,'일자 확인','Exact date'):s.reportWeek?pick(language,'주차만 확인','Week only'):pick(language,'미확인','Unknown'),state:s.carriedForward||s.fresh===false?pick(language,'이전 자료 참고','Previous source reference'):s.fresh===true?pick(language,'해당 주 자료','Current-week source'):pick(language,'적용 기준 확인','Check source basis'),file:s.file||'',sheet:s.sheet||''}));
 return model('SOURCES',options,columns([['type','자료 종류','Source type'],['center','센터','Center'],['operator','사업자','Operator'],['date','실제 기준일','Actual source date'],['week','확인된 주차','Confirmed source week'],['precision','날짜 확인 수준','Date precision'],['state','적용 상태','Source status'],['file','파일명','File'],['sheet','시트','Sheet']],language),records);
}
function parts(options){
 const {data,center,language,notes,rowIds}=options,allowed=Array.isArray(rowIds)?new Set(rowIds):null,months=data.settings?.targetMonths??1;
 const kinds={SHORTAGE:pick(language,'현재 수리분 부족','Current repair shortage'),ORDER:pick(language,months+'개월분 부족 · 추가 PO 필요',months+'-month stock · Additional PO needed'),WAIT:pick(language,months+'개월분 부족 · PO 입고 대기',months+'-month stock · Awaiting PO'),UNKNOWN:pick(language,'자료 확인','Check data'),NORMAL:pick(language,'정상','Normal')};
 const groupKinds=new Map(O.classify(data.rows||[],center).map(g=>[g.part,g.kind]));
 const selected=(data.rows||[]).filter(r=>(center==='ALL'||r.center===center)&&(!allowed||allowed.has(r.id)));
 const records=selected.map(r=>{const manual=notes[r.id]||{},tasks=(data.tasks||[]).filter(t=>t.rowId===r.id),kind=O.classify([r],r.center)[0]?.kind||'UNKNOWN';return {
  part:language==='en'&&r.part==='명판'?'Name plate':r.part,name:language==='en'&&r.name==='명판'?'Name plate':r.name||'',center:r.center,
  stock:value(r.stock),india:value(r.india),hq:value(r.hq),avg:number(r.avg)?Math.ceil(r.avg):null,needed:value(r.needed),shortage:value(r.shortage),poOrdered:value(r.poOrdered),open:value(r.open),proposed:value(r.proposed),category:kinds[kind],summaryCategory:kinds[groupKinds.get(r.part)]||kinds.UNKNOWN,
  actions:unique(tasks.map(t=>O.taskText(t,r,language))).join('\n'),low:r.lowUsage?pick(language,'저소요','Low use'):'',long:r.longLead?pick(language,'장납','Long LT'):'',eta:manual.eta||'',plan:[manual.plan||'',...Mail.confirmedProgress(manual,language)].filter(Boolean).join('\n'),
  sources:Object.entries(r.sourceDates||{}).map(([name,date])=>name+': '+(date||(r.sourceWeeks?.[name]?r.sourceWeeks[name]+pick(language,' 주차 · 실제 날짜 미확인',' week · exact date unknown'):pick(language,'미확인','unknown')))).join('\n')
 }});
 return model('PARTS',options,columns([
  ['part','부품코드','Part code'],['name','부품명','Part name'],['center','센터','Center'],['stock','센터 재고','Center stock'],['india','법인 재고','India stock'],['hq','본사 재고','HQ stock'],['avg','월 소요량(개/월)','Monthly usage (pcs/month)'],['needed','현 수리 필요 수','Current repair need'],['shortage','현재 부족 수','Current shortage'],['poOrdered','PO 기발주 수','PO ordered qty'],['open','PO 미입고 수','Open PO qty'],['proposed','추가 PO 필요 수','Additional PO needed'],
  ['category','센터별 상태','Center status'],['summaryCategory','선택 범위의 요약 분류','Summary classification in selection'],['actions','조치 담당 / 필요 조치','Action owner / next action'],['low','저소요 표시','Low-use tag'],['long','장납 표시','Long-LT tag'],['eta','확인된 센터 입고 예정','Confirmed center receipt ETA'],['plan','확인한 대책','Confirmed plan'],['sources','적용 원본 기준일','Applied source dates']
 ],language),records,{partCount:new Set(selected.map(r=>r.part)).size,notes:[...commonNotes(language),pick(language,'요약 분류는 선택 범위의 부품코드당 한 번이며 센터별 상태와 다를 수 있습니다. 법인·본사 재고는 공용이므로 행 간 합산하지 마세요. 월 소요량은 정수로 올림 표시하며 계산에는 원시 평균을 사용합니다.','Summary classification counts each part code once and may differ from an individual center status. India/HQ stocks are shared and must not be summed across rows. Monthly usage is displayed rounded up to whole units; calculations retain the raw average.')]});
}
function normalized(options={}){return {...options,data:options.data||{},center:scope(options.center),language:options.language==='en'?'en':'ko',notes:options.notes||{}}}
function buildTable(type,options={}){
 const o=normalized(options);if(type==='SUMMARY')return summary(o);if(TREND_FIELDS[type])return trend(type,o);if(type==='AGING')return aging(o);if(type==='OVERDUE')return overdue(o);if(type==='WAITING_PRODUCTS'||type==='OVERDUE_PRODUCTS')return waiting(type,o);if(type==='SOURCES')return sources(o);if(type==='PARTS')return parts(o);throw new Error('Unknown summary export table: '+type);
}
function buildAll(options={}){return TYPES.map(type=>buildTable(type,options))}
return {TYPES:TYPES.slice(),title,buildTable,buildAll};
});
