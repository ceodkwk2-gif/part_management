(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.PartsChartLabels=api;})(typeof self!=='undefined'?self:this,function(){
'use strict';
const number=v=>typeof v==='number'&&Number.isFinite(v),esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const en=l=>/^en/i.test(l||''),scope=c=>!c||c==='전체'?'ALL':c,key=c=>scope(c)==='ALL'?'전체':c,txt=(l,ko,eng)=>en(l)?eng:ko;
const n=v=>number(v)?v.toLocaleString('en-US',{maximumFractionDigits:0}):'—',shortWeek=w=>String(w.week||w.asof||'').slice(5).replace('-','/');
const centerLabel=(c,l)=>scope(c)==='ALL'?txt(l,'전체','All'):scope(c);
const WEEK=7*86400000,validWeek=value=>/^\d{4}-\d{2}-\d{2}$/.test(value||'')&&Number.isFinite(Date.parse(value+'T00:00:00Z'))&&new Date(value+'T00:00:00Z').toISOString().slice(0,10)===value;
// View-only calendar gaps: never append invented reports to stored/exported history.
function chartWeeks(data={}){
 const points=(data.trend||[]).filter(p=>validWeek(p.week)).slice().sort((a,b)=>a.week.localeCompare(b.week));
 if(!points.length)return (data.trend||[]).slice(-6);
 const latest=Date.parse(points.at(-1).week+'T00:00:00Z'),earliest=Date.parse(points[0].week+'T00:00:00Z'),start=Math.max(earliest,latest-5*WEEK),byWeek=new Map(points.map(p=>[p.week,p])),out=[];
 for(let stamp=latest;stamp>=start;stamp-=WEEK){const week=new Date(stamp).toISOString().slice(0,10);out.unshift(byWeek.get(week)||{week,asof:null,missingReport:true,sourceDates:[],metricsByCenter:{},availableByCenter:Object.fromEntries(['전체','Flex','CTDI'].map(c=>[c,{wip:false,actionAvailability:{shortage:false,order:false,wait:false}}]))});}
 return out;
}
function periodNote(data,l){return txt(l,'최근 6주 · 전체 이력 다운로드','Latest 6 weeks · Download full history');}
function actionAvailable(point,center,field){const kind=/^(shortage|order|wait)(Kinds|Qty)$/.exec(field)?.[1];return kind?point?.availableByCenter?.[key(center)]?.actionAvailability?.[kind]:undefined;}
const FONT='font-family="Arial,sans-serif" font-size="14" fill="#61758a"';
function trendValue(point,center,field){return point?.missingReport||actionAvailable(point,center,field)===false||/^(wip|over45|over45PartKinds|over45RequiredQty)$/.test(field)&&point?.availableByCenter?.[key(center)]?.wip===false?null:point?.metricsByCenter?.[key(center)]?.[field]}
function actualWipDates(point,center,l){if(point.missingReport)return txt(l,'보고 없음','No report');return [...new Set((point.sourceDates||[]).filter(s=>s.type==='wip'&&(scope(center)==='ALL'||s.center===scope(center))).map(s=>(s.center?s.center+' ':'')+(s.date||txt(l,'날짜 미확인','date unknown'))))].join(' / ')||txt(l,'WIP 날짜 미확인','WIP date unknown')}
function exportButton(kind,l){return '<button class="ov-download" data-ov-export="'+kind+'">'+txt(l,'다운로드','Download')+'</button>'}
function svgStart(id,label){return '<svg data-ov-chart="'+esc(id)+'" class="ov-labeled-chart" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 500 220" role="img" aria-label="'+esc(label)+'" style="font-family:Arial,sans-serif"><rect width="100%" height="100%" fill="#fff"/>'}
function valueTable(data,center,l,columns){const weeks=chartWeeks(data);return '<details class="ov-chart-values"><summary>'+txt(l,'그래프 수치 보기','View chart values')+'</summary><table><thead><tr><th>'+txt(l,'주차','Week')+'</th>'+columns.map(d=>'<th>'+esc(d.label)+'</th>').join('')+'<th>'+txt(l,'실제 WIP 기준일','Actual WIP dates')+'</th></tr></thead><tbody>'+weeks.map(w=>'<tr><td>'+esc(w.week)+'</td>'+columns.map(d=>'<td>'+(number(d.value(w))?n(d.value(w)):txt(l,'산정 불가','Unavailable'))+'</td>').join('')+'<td>'+esc(actualWipDates(w,center,l))+'</td></tr>').join('')+'</tbody></table></details>'}
function overlaps(a,b,gap=2){return a.x<b.x+b.width+gap&&a.x+a.width+gap>b.x&&a.y<b.y+b.height+gap&&a.y+a.height+gap>b.y}
function estimateWidth(text,fontSize=14){return Math.max(fontSize,[...String(text)].reduce((s,c)=>s+(/[0-9]/.test(c)?7.8:c===','?3.9:8),0)*(fontSize/14)+2)}
/** Keep every number in its own week column, beside its actual point.
 * Close values use nearby vertical positions only. No free-grid fallback,
 * connector, opaque label background, or unlabelled numeric point is used. */
function layoutLabels(points,{left=38,right=484,top=23,bottom=151}={}){
 const used=[],out=[],xs=[...new Set(points.map(p=>p.x))].sort((a,b)=>a-b),slot=xs.length>1?Math.min(...xs.slice(1).map((x,i)=>x-xs[i])):right-left;
 const widest=Math.max(1,...points.map(p=>estimateWidth(p.text??n(p.value)))),fontSize=Math.min(14,Math.floor(Math.max(7,(slot-3)/widest*14)*10)/10),height=fontSize+2;
 const sorted=points.map((p,index)=>({...p,index,text:String(p.text??n(p.value))})).sort((a,b)=>a.x-b.x||a.y-b.y||a.index-b.index);
 for(const p of sorted){const width=estimateWidth(p.text,fontSize),x=p.x-width/2,candidates=[];
  // The nearest unobstructed position wins; crowded columns can use up to
  // three nearby lanes. The x coordinate never leaves its data point.
  for(let distance=12;distance<=48;distance+=2){for(const direction of [-1,1]){const cy=p.y+distance*direction,y=cy-height/2,b={x,y,width,height};if(y<top||y+height>bottom||x<left||x+width>right)continue;if(number(p.labelCeiling)&&y+height>p.labelCeiling)continue;candidates.push(b)}}
  let box=candidates.find(b=>!used.some(q=>overlaps(b,q,2)));
  // Unsupported extreme density remains near its point rather than being
  // moved to an unrelated location. Values also remain in the exact table.
  if(!box)box=candidates.reduce((best,b)=>{const score=used.reduce((sum,q)=>sum+(overlaps(b,q,2)?1:0),0);return !best||score<best.score?{box:b,score}:best},null)?.box;
  if(!box){const y=Math.max(top,Math.min(bottom-height,p.y-height-6));box={x,y,width,height}}
  used.push(box);out.push({...p,box,cx:p.x,baseline:box.y+fontSize*.85,fontSize,displaced:false});
 }
 return out.sort((a,b)=>a.index-b.index);
}
function labelsHTML(points,options){
 return layoutLabels(points,options).map(p=>{const b=p.box;return '<g data-ov-data-label="'+esc(p.series)+'" data-ov-week="'+esc(p.week)+'" data-ov-value="'+esc(p.value)+'" data-label-box="'+[b.x,b.y,b.width,b.height].join(',')+'"><text class="ov-chart-data-label" x="'+p.cx+'" y="'+p.baseline+'" text-anchor="middle" font-family="Arial,sans-serif" font-size="'+p.fontSize+'" font-weight="700" fill="'+p.color+'">'+esc(p.text)+'</text></g>'}).join('');
}
function lineSVG(points,color,pointAttr,title){let html='',run=[];const flush=()=>{if(run.length>1)html+='<polyline points="'+run.join(' ')+'" fill="none" stroke="'+color+'" stroke-width="2.3"/>';run=[]};for(const p of points){if(!number(p.value)){flush();continue}run.push(p.x+','+p.y);html+='<circle '+pointAttr(p)+' cx="'+p.x+'" cy="'+p.y+'" r="3.4" fill="'+color+'" stroke="#fff" stroke-width="1"><title>'+esc(title(p))+'</title></circle>'}flush();return html}
function xPositions(length){const left=44,right=478,slot=(right-left)/Math.max(1,length);return i=>left+slot*(i+.5)}
function xAxis(weeks,x,l){return weeks.map((w,i)=>'<text x="'+x(i)+'" y="177" text-anchor="middle" '+FONT+'>'+esc(shortWeek(w))+'</text>').join('')}
function renderTrend(data,center,l,id,label,definitions,unit){
 const weeks=chartWeeks(data),ss=definitions.map(d=>({...d,values:weeks.map(w=>trendValue(w,center,d.key))})),max=Math.max(1,...ss.flatMap(s=>s.values.filter(number))),x=xPositions(weeks.length),y=v=>150-v/max*86,points=[];
 const lines=ss.map(s=>{const ps=s.values.map((value,i)=>({value,x:x(i),y:number(value)?y(value):null,index:i}));for(const p of ps)if(number(p.value))points.push({...p,series:s.key,week:weeks[p.index].week,value:p.value,color:s.color});return lineSVG(ps,s.color,()=> 'data-ov-point="'+esc(s.key)+'"',p=>(weeks[p.index].week||'')+' · '+centerLabel(center,l)+' · '+s.label+' '+n(p.value)+' '+unit+' · '+actualWipDates(weeks[p.index],center,l))}).join('');
 const legend=ss.map((s,i)=>'<circle cx="'+(16+i*162)+'" cy="204" r="4" fill="'+s.color+'"/><text x="'+(26+i*162)+'" y="209" '+FONT+'>'+esc(s.label)+'</text>').join('');
 return '<section class="ov-chart"><div class="ov-chart-heading"><h3>'+esc(label)+'</h3><small>'+esc(unit)+'</small>'+exportButton('TREND_'+id,l)+'</div>'+svgStart(id,label+' · '+centerLabel(center,l))+'<text x="8" y="16" '+FONT+'>'+esc(unit)+'</text><line x1="44" x2="478" y1="150" y2="150" stroke="#d8e1eb"/>'+lines+labelsHTML(points)+xAxis(weeks,x,l)+legend+'</svg><p class="ov-chart-note">'+periodNote(data,l)+' · '+txt(l,'빈 구간: 자료 없음·산정 불가','Gaps: no data or unavailable')+'</p>'+valueTable(data,center,l,definitions.map(d=>({label:d.label+' ('+unit+')',value:w=>trendValue(w,center,d.key)})))+'</section>';
}
function renderCombo(data,center,l){
 const c=scope(center),weeks=chartWeeks(data),centers=c==='ALL'?['Flex','CTDI']:[c],colors={Flex:'#7899b8',CTDI:'#315f84'},points=weeks.map(w=>({w,values:centers.map(s=>trendValue(w,s,'over45RequiredQty')),total:trendValue(w,c,'over45RequiredQty'),kinds:trendValue(w,c,'over45PartKinds')})),qtyMax=Math.max(1,...points.map(p=>p.total).filter(number)),kindsMax=Math.max(1,...points.map(p=>p.kinds).filter(number)),left=44,right=478,top=64,bottom=150,slot=(right-left)/Math.max(weeks.length,1),x=xPositions(weeks.length),barW=Math.min(40,slot*.48),qy=q=>bottom-q/qtyMax*(bottom-top),ky=k=>bottom-k/kindsMax*(bottom-top),labels=[];
 let bars='';for(const [i,p] of points.entries()){if(number(p.total)&&p.values.every(number)){let cumulative=0;for(let j=0;j<centers.length;j++){const v=p.values[j];cumulative+=v;bars+='<rect data-ov-bar-center="'+centers[j]+'" data-ov-value="'+v+'" x="'+(x(i)-barW/2)+'" y="'+qy(cumulative)+'" width="'+barW+'" height="'+((v/qtyMax)*(bottom-top))+'" rx="1" fill="'+colors[centers[j]]+'"><title>'+esc(p.w.week+' · '+centers[j]+' · '+txt(l,'필요 부품 ','Required parts ')+n(v)+txt(l,'개',' pcs')+' · '+actualWipDates(p.w,centers[j],l))+'</title></rect>'}labels.push({x:x(i),y:qy(p.total),value:p.total,text:n(p.total),series:'over45RequiredQty',week:p.w.week,color:'#315f84',labelCeiling:qy(p.total)-4})}else bars+='<text x="'+x(i)+'" y="145" text-anchor="middle" '+FONT+'>—</text>';if(number(p.kinds))labels.push({x:x(i),y:ky(p.kinds),value:p.kinds,text:n(p.kinds),series:'over45PartKinds',week:p.w.week,color:'#b44957',labelCeiling:number(p.total)?qy(p.total)-4:null})}
 const line=lineSVG(points.map((p,i)=>({value:p.kinds,x:x(i),y:number(p.kinds)?ky(p.kinds):null,index:i})),'#b44957',p=>'data-ov-line-kinds="'+p.value+'"',p=>(points[p.index].w.week||'')+' · '+centerLabel(c,l)+' · '+txt(l,'필요 부품 ','Required parts ')+n(p.value)+txt(l,'종',' kinds')+' · '+actualWipDates(points[p.index].w,c,l));
 const label=txt(l,'45일 초과 제품의 필요 부품 추이','Required parts for products over 45 days'),unitQty=txt(l,'필요 부품 수량 (개)','Required quantity (pcs)'),unitKinds=txt(l,'필요 부품 종수 (종)','Unique part kinds');
 const legend=centers.map((s,i)=>'<rect x="'+(16+i*142)+'" y="200" width="10" height="10" fill="'+colors[s]+'"/><text x="'+(32+i*142)+'" y="210" '+FONT+'>'+s+' '+txt(l,'수량','quantity')+'</text>').join('')+'<circle cx="'+(16+centers.length*142)+'" cy="205" r="4" fill="#b44957"/><text x="'+(28+centers.length*142)+'" y="210" '+FONT+'>'+txt(l,'부품 종수','Part kinds')+'</text>';
 return '<div class="ov-combo"><div class="ov-chart-heading"><h3>'+label+'</h3>'+exportButton('TREND_OVERDUE',l)+'</div>'+svgStart('OVERDUE',label+' · '+centerLabel(c,l))+'<text x="8" y="16" '+FONT+'>'+unitQty+'</text><text x="492" y="16" text-anchor="end" font-family="Arial,sans-serif" font-size="14" fill="#b44957">'+unitKinds+'</text><line x1="'+left+'" x2="'+right+'" y1="'+bottom+'" y2="'+bottom+'" stroke="#d8e1eb"/>'+bars+line+labelsHTML(labels)+xAxis(weeks,x,l)+legend+'</svg><p class="ov-chart-note">'+txt(l,'종수는 센터 간 동일 코드 중복 제외','Same code across centers counts once')+' · '+periodNote(data,l)+'</p>'+valueTable(data,c,l,[...centers.map(s=>({label:s+txt(l,' 필요 수량 (개)',' quantity (pcs)'),value:w=>trendValue(w,s,'over45RequiredQty')})),{label:txt(l,'필요 부품 (종)','Unique parts (kinds)'),value:w=>trendValue(w,c,'over45PartKinds')},{label:txt(l,'대기 제품 (대)','Waiting products'),value:w=>trendValue(w,c,'over45')}])+'</div>';
}
return {renderTrend,renderCombo,layoutLabels,overlaps,trendValue,chartWeeks,periodNote};
});
