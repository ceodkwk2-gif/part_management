(function(root,factory){if(typeof module==='object'&&module.exports)module.exports=factory(require('./first-confirmed-panel.js'));else root.PartsFirstConfirmedBulk=factory(root.PartsFirstConfirmedPanel);})(typeof self!=='undefined'?self:this,function(Panel){
'use strict';
const columns=['center','operator','sn','rma','part','date','note'];
const norm=v=>String(v??'').trim().toUpperCase();
function parse(text){
 text=String(text).replace(/^\uFEFF/,'');const sep=text.split(/\r?\n/)[0].includes('\t')?'\t':',';
 const rows=[];let row=[],cell='',quoted=false;
 for(let i=0;i<text.length;i++){const c=text[i];if(c==='"'){if(quoted&&text[i+1]==='"'){cell+='"';i++;}else if(quoted||cell==='')quoted=!quoted;else cell+=c;}else if(!quoted&&(c===sep||c==='\n'||c==='\r')){row.push(cell);cell='';if(c!==sep){if(row.some(x=>x.trim()))rows.push(row);row=[];if(c==='\r'&&text[i+1]==='\n')i++;}}else cell+=c;}
 if(quoted)throw Error('닫히지 않은 따옴표가 있습니다. Excel에서 표를 다시 복사하세요.');row.push(cell);if(row.some(x=>x.trim()))rows.push(row);return rows;
}
function preview(text,entries,{overwrite=false,language='ko'}={}){
 const rows=parse(text),header=rows.shift()||[];
 if(columns.some((x,i)=>norm(header[i])!==norm(x)))throw Error('첫 행은 center / operator / sn / rma / part / date / note 순서여야 합니다. 양식을 사용하세요.');
 const identity=e=>JSON.stringify(columns.slice(0,5).map(k=>norm(e[k]))),index=new Map();
 for(const entry of entries||[]){const key=identity(entry);if(!index.has(key))index.set(key,[]);index.get(key).push(entry);}
 const seen=new Set(),changes=[],results=[];
 for(const [i,row] of rows.entries()){
  const item=Object.fromEntries(columns.map((k,j)=>[k,String(row[j]??'').trim()]));if(!item.date)continue;
  const matches=index.get(identity(item))||[],entry=matches[0];let error='';
  if(matches.length!==1)error='현재 제품·부품과 유일하게 연결되지 않습니다.';
  else if(seen.has(entry.key))error='동일 제품·부품이 중복 입력됐습니다.';
  else if(entry.firstConfirmedConflict&&!overwrite)error='이력 충돌이 있습니다. 개별 근거 확인 후 덮어쓰기 여부를 선택하세요.';
  else if(entry.manualFirstConfirmedDate&&entry.manualFirstConfirmedDate!==item.date&&!overwrite)error='기존 수기 날짜가 있습니다. 덮어쓰기 여부를 확인하세요.';
  else error=Panel.validation(entry,item.date,item.note,language);
  if(entry)seen.add(entry.key);
  const unchanged=entry&&entry.manualFirstConfirmedDate===item.date&&(entry.manualFirstConfirmedNote||'')===item.note;
  results.push({line:i+2,...item,error,unchanged});
  if(!error&&!unchanged)changes.push({key:entry.key,date:item.date,note:item.note});
 }
 if(changes.length>500)throw Error('한 번에 500건까지 저장할 수 있습니다. 검색 조건으로 나눠 입력하세요.');
 return {results,changes,canSave:changes.length>0&&!results.some(r=>r.error)};
}
function template(entries){return {title:'First-confirmed import template',localized:true,columns:columns.map(key=>({key,label:key,raw:true})),rows:entries.map(e=>[e.center,e.operator,e.sn,e.rma,e.part,e.manualFirstConfirmedDate||'',e.manualFirstConfirmedNote||''])};}
return {parse,preview,template,columns};
});
