(function(root,factory){
 if(typeof module==='object'&&module.exports)module.exports=factory(require('./core.js'),require('./reporting.js'),require('./operations.js'));
 else root.PartsPipeline=factory(root.PartsCore,root.PartsReporting,root.PartsOperations);
})(typeof self!=='undefined'?self:this,function(C,R,O){
'use strict';
// Review whole source snapshots before calling Reporting.applySources. This
// module never merges workbook rows, allocates inventory or changes quantities.
const SLOTS=Object.freeze([
 {key:'flex:dashboard',label:'Flex 대시보드',type:'dashboard',center:'Flex'},
 {key:'flex:wip:Jio',label:'Flex Jio WIP',type:'wip',center:'Flex',operator:'Jio'},
 {key:'flex:po',label:'Flex Open PO',type:'po',center:'Flex'},
 {key:'ctdi:dashboard',label:'CTDI 대시보드',type:'dashboard',center:'CTDI'},
 {key:'ctdi:wip:Jio',label:'CTDI Jio WIP',type:'wip',center:'CTDI',operator:'Jio'},
 {key:'ctdi:wip:Airtel',label:'CTDI Airtel WIP',type:'wip',center:'CTDI',operator:'Airtel'},
 {key:'ctdi:wip:Vi',label:'CTDI Vodafone Idea WIP',type:'wip',center:'CTDI',operator:'Vi'},
 {key:'ctdi:po',label:'CTDI Open PO',type:'po',center:'CTDI'},
 {key:'india',label:'인도법인 재고',type:'india'},
 {key:'hq',label:'본사 재고',type:'hq'},
 {key:'siel',label:'법인→본사 PO',type:'siel',optional:true}
].map(slot=>Object.freeze(slot)));
const selectionDate=C.sourceSelectionDate;
const known=value=>typeof value==='number'&&Number.isFinite(value);
const unique=values=>[...new Set(values)];
const quantity=rows=>rows.reduce((sum,row)=>sum+(known(row)?row:0),0);
function slotKey(source){
 if(!source)return null;
 const operator=C.canonicalOperator(source.center,source.operator,source.type);
 return SLOTS.find(slot=>slot.type===source.type&&(!slot.center||slot.center===source.center)&&(!slot.operator||slot.operator===operator))?.key||null;
}
function normalizeSource(source){return {...source,operator:C.canonicalOperator(source.center,source.operator,source.type)}}
function stable(value){
 if(Array.isArray(value))return value.map(stable);
 if(value&&typeof value==='object')return Object.fromEntries(Object.keys(value).sort().map(key=>[key,stable(value[key])]));
 return value;
}
function content(source){
 const data={...normalizeSource(source)};
 // File provenance may differ for an exact copy. Row order/numbers remain in
 // identity so the original first-row rule is never silently changed.
 for(const key of ['id','file','sheet','path','relativePath','importPath','uploadId','importedAt','revisedAt','reportingRevision','dateLabel'])delete data[key];
 return JSON.stringify(stable(data));
}
function evaluate(state,incomingSources,reportDate,choices={}){
 const errors=[],warnings=[],incoming=Array.isArray(incomingSources)?incomingSources:[],validReport=R.validDate(reportDate);
 if(!validReport)errors.push('보고 기준일을 YYYY-MM-DD 형식의 실제 날짜로 지정해 주세요.');
 if(!Array.isArray(incomingSources))errors.push('업로드 자료 목록을 읽을 수 없습니다.');
 let existingSources=[],savedReports=[];
 if(validReport&&Array.isArray(state?.sources)){
  try{const normalized=R.normalizeState(state);existingSources=R.sourcesForReportDate(normalized,reportDate);savedReports=R.reports(normalized);}
  catch(_){errors.push('반영 대상 주간의 기존 원본 버전을 확인할 수 없습니다. 저장된 작업본을 확인해 주세요.');}
 }
 const staged=incoming.map((source,index)=>({id:'incoming:'+index,index,source:source&&normalizeSource(source),file:source?.file||'',date:source?.date||null,isIncoming:true}));
 for(const candidate of staged){
  if(!candidate.source||!Array.isArray(candidate.source.rows)||!slotKey(candidate.source))errors.push((candidate.file||'업로드 자료 '+(candidate.index+1))+': 자료 종류·센터·사업자 또는 원본 행을 확인해 주세요.');
 }
 const rows=SLOTS.filter(slot=>!slot.optional||staged.some(item=>slotKey(item.source)===slot.key)||existingSources.some(source=>slotKey(source)===slot.key)).map(slot=>{
  const candidates=staged.filter(item=>slotKey(item.source)===slot.key),prior=existingSources.filter(source=>slotKey(source)===slot.key&&(!selectionDate(source)||validReport&&selectionDate(source)<=reportDate));
  const existing=prior.sort((a,b)=>(selectionDate(a)||'').localeCompare(selectionDate(b)||'')).at(-1)||null;
  const row={key:slot.key,label:slot.label,status:existing?'retained':'missing',source:existing,existing,candidates,message:'',selectedIndex:null};
  if(choices[slot.key]==='exclude'){
   row.status='excluded';row.source=null;row.message='사용자 선택: 이번 주 계산에서 제외 · 미확인으로 유지';
   warnings.push(slot.label+': '+row.message);return row;
  }
  if(choices[slot.key]==='keep'){
   if(!existing){row.status='missing';row.message='이전 정상 자료가 없습니다. 미확인으로 유지합니다.';}
   else row.message='사용자 선택: 이전 정상 자료 참고 · 실제 원본 날짜 유지';
   warnings.push(slot.label+': '+row.message);return row;
  }
  if(existing&&!existing.date)warnings.push(slot.label+': 기존 원본 기준일 미확인 — 날짜를 새로 만들지 않고 기존 자료를 유지합니다.');
  const undated=candidates.filter(item=>!selectionDate(item.source));
  const future=candidates.filter(item=>selectionDate(item.source)&&validReport&&selectionDate(item.source)>reportDate);
  if(undated.length){row.status='date_required';row.message='WIP는 실제 기준일, 재고·PO는 실제 기준일 또는 확인한 보고 주차를 지정해 주세요.';errors.push(slot.label+': '+row.message);return row;}
  if(future.length){row.status='future';row.message='보고 기준일 이후 원본이 있습니다. 보고일·원본 날짜를 확인하거나 해당 자료를 제외해 주세요.';errors.push(slot.label+': '+row.message);return row;}
  if(!validReport){row.message='보고 기준일 확인 후 최신 자료를 선택합니다.';return row;}
  if(!candidates.length){
   row.message=existing?'이번 업로드 없음 · 이전 자료 유지':'이번 자료와 이전 자료가 모두 없습니다. 미확인을 0으로 바꾸지 않습니다.';
   warnings.push(slot.label+': '+row.message);return row;
  }
  const latestDate=candidates.map(item=>selectionDate(item.source)).sort().at(-1);
  if(selectionDate(existing)&&selectionDate(existing)>latestDate){
   row.message='업로드가 기존 자료보다 오래되어 기존 최신 자료를 유지합니다.';warnings.push(slot.label+': '+row.message);return row;
  }
  const newest=candidates.filter(item=>selectionDate(item.source)===latestDate),byContent=new Map(),duplicates=[];
  for(const candidate of newest){const signature=content(candidate.source);if(byContent.has(signature))duplicates.push(candidate);else byContent.set(signature,candidate);}
  if(duplicates.length)warnings.push(slot.label+': 동일 내용의 업로드 복사본 '+duplicates.length+'건은 한 번만 사용합니다.');
  const distinct=[...byContent.values()];
  // Explicit choice may point to a semantically identical copy: keep that
  // original provenance rather than changing the choice to another file.
  const choice=newest.find(item=>item.id===choices[slot.key]);
  const picked=choice||distinct.length===1&&distinct[0];
  if(!picked){
   row.status='conflict';row.source=null;row.message='같은 자료·기준일의 내용이 다른 수정본 '+distinct.length+'개입니다. 반영할 원본 하나를 선택해 주세요.';
   errors.push(slot.label+': '+row.message);return row;
  }
  if(existing&&content(existing)===content(picked.source)){
   row.message='이미 반영된 원본과 같은 내용 · 기존 자료 유지';return row;
  }
  row.status='new';row.source=picked.source;row.selectedIndex=picked.index;
  row.message=selectionDate(existing)===selectionDate(picked.source)?'같은 기준일 정정본 반영':existing?'새 자료 반영':'처음 반영';
  if(candidates.some(item=>selectionDate(item.source)<latestDate))warnings.push(slot.label+': 여러 기준일 중 최신 원본 '+latestDate+'만 이번 보고에 반영합니다.');
  return row;
 });
 const selectedIndices=rows.filter(row=>row.status==='new').map(row=>row.selectedIndex);
 const selectedSources=selectedIndices.map(index=>staged[index].source);
 const weekId=validReport?R.weekStart(reportDate):null,latestReport=savedReports.at(-1);
 // Carry-forward is a separate explicit action. A normal no-op upload must
 // never silently create reports or imply that old inventory was refreshed.
 const recordExistingReason=errors.length?errors[0]:incoming.length?'분석한 자료를 먼저 반영하거나 반영 취소한 뒤 기존 자료로 기록해 주세요.':!latestReport||!existingSources.length?'이어받을 저장된 보고 자료가 없습니다. 먼저 원본 자료를 반영해 주세요.':savedReports.some(report=>report.id===weekId)?'이 주의 보고는 이미 있습니다. 새 원본 정정은 자료 반영으로 진행하세요.':reportDate<=latestReport.reportDate?'기존 자료로 기록은 최신 보고 이후의 새 주에만 가능합니다.':'';
 const excludedSlots=rows.filter(row=>row.status==='excluded').map(row=>row.key);
 return {ok:errors.length===0,canApply:errors.length===0&&(selectedSources.length>0||rows.some(row=>row.status==='excluded'&&row.existing)),canRecordExisting:!recordExistingReason,recordExistingReason,reportDate,weekId,
  rows,selectedSources,selectedIndices,excludedSlots,errors:unique(errors),warnings:unique(warnings)};
}
function recordExistingWeek(state,reportDate){
 const plan=evaluate(state,[],reportDate);
 if(!plan.canRecordExisting)throw Error(plan.recordExistingReason||'기존 자료로 새 주 보고를 기록할 수 없습니다.');
 const next=R.applySources(state,[],reportDate),check=validate(next);
 if(!check.ok)throw Error(check.errors.join(' / '));
 next.reportingWeeks=next.reportingWeeks.map(report=>report.id===plan.weekId?{...report,carriedForward:true}:report);
 return next;
}
function validate(input){
 const errors=[],warnings=[],fail=message=>errors.push(message);
 if(!input||input.version!==1||!Array.isArray(input.sources)||!input.settings||typeof input.settings!=='object')return {ok:false,errors:['작업 데이터 형식이 올바르지 않습니다.'],warnings,summary:null};
 for(const source of input.sources){
  if(!source||!slotKey(source)||!Array.isArray(source.rows))fail('자료 종류·센터·사업자 또는 원본 행이 올바르지 않습니다.');
  if(source?.date&&!R.validDate(source.date))fail('잘못된 실제 원본 기준일이 있습니다.');
  if(source&&!source.date)warnings.push(selectionDate(source)?'정확한 측정일 없이 확인된 보고 주차로 사용하는 재고·PO 자료가 있습니다.':'기준일 미확인인 기존 원본이 있습니다.');
  if(source?.datePrecision==='week'&&!selectionDate(source))fail('주차 근거는 비WIP 자료의 유효한 보고 주차에만 사용할 수 있습니다.');
 }
 if(errors.length)return {ok:false,errors:unique(errors),warnings:unique(warnings),summary:null};
 let summary=null;
 try{
  const state=R.normalizeState(input),report=R.selectedReport(state);
  if(!report||!R.validDate(report.cutoff)){fail('검증할 주간 보고 기준일이 없습니다.');return {ok:false,errors,warnings:unique(warnings),summary};}
  const unresolved=R.reportWarnings(state,report.id);if(unresolved.length)fail('주간 보고가 참조하는 원본 버전 또는 기준일을 확인할 수 없습니다.');
  const active=R.reportState(state,report.id),calculated=C.calculate(active,report.cutoff),rows=calculated.allParts;
  if(!calculated.used.length)fail('주간 보고에 계산할 원본이 없습니다.');
  const waiting=new Map(),wipPolicy=new Map();
  for(const product of calculated.wip)for(const [part,qty] of Object.entries(product.tokens.parts)){const key=product.center+'|'+part;waiting.set(key,(waiting.get(key)||0)+qty);}
  for(const center of ['CTDI','Flex']){
   const sources=calculated.used.filter(source=>source.type==='wip'&&source.center===center),integrity=sources.map(source=>C.wipIntegrity(source));
   const complete=sources.length>0&&(center!=='CTDI'||['Jio','Airtel','Vi'].every(operator=>sources.some(source=>source.operator===operator)));
   wipPolicy.set(center,{ready:complete&&sources.every(source=>source.date)&&integrity.every(value=>!value.globalBlocked)&&new Set(sources.map(source=>source.date)).size===1,affected:new Set(integrity.flatMap(value=>value.affectedParts))});
  }
  for(const row of rows){
   for(const field of ['stock','needed','avg','target','open','shortage','wipWaitingQty','stockShortage','proposed','currentOrderNeed','futureOrderNeed','india','hq'])if(row[field]!=null&&(!known(row[field])||row[field]<0))fail('계산 수량에 음수 또는 숫자 오류가 있습니다: '+field);
   const policy=wipPolicy.get(row.center),wipQty=policy.ready&&!policy.affected.has(row.part)?waiting.get(row.center+'|'+row.part)||0:null;
   const stockShortage=[row.stock,row.needed].every(known)?Math.max(0,row.needed-row.stock):null;
   const shortage=wipQty!=null?wipQty:stockShortage;
   const target=known(row.avg)?Math.ceil(row.avg*C.effectiveTargetMonths(active.settings)):null;
   const proposed=[row.stock,row.needed,row.target,row.open].every(known)?Math.max(0,Math.ceil(row.needed+row.target-row.stock-row.open)):null;
   if(row.shortage!==shortage)fail('현재 부족 산식 검증에 실패했습니다.');
   if(row.wipWaitingQty!==wipQty||row.stockShortage!==stockShortage||row.shortageBasis!==(wipQty!=null?'wip-waiting':'inventory-gap'))fail('WIP 자재대기와 재고 차감 검토량의 구분 검증에 실패했습니다.');
   if(row.target!==target)fail('보유 목표 산식 검증에 실패했습니다.');
   if(row.proposed!==proposed)fail('추가 발주 산식 검증에 실패했습니다.');
   if([row.proposed,row.currentOrderNeed,row.futureOrderNeed].every(known)&&row.currentOrderNeed+row.futureOrderNeed!==row.proposed)fail('현재 수리·보충 발주 합계가 추가 발주와 다릅니다.');
   if(row.stockAssumedZero&&row.stock!==0)fail('대시보드 누락 재고의 0 가정이 유지되지 않았습니다.');
   if(row.missingDashboardCode&&row.avg!=null)fail('대시보드 누락 부품에 사용량이 임의 생성되었습니다.');
   if(row.needDate&&row.needDate>report.cutoff&&!active.sources.some(s=>s.type==='wip'&&s.center===row.center&&s.date===row.needDate&&s.assignedWeek===report.id))fail('보고 기준일 이후 필요량이 사용되었습니다.');
  }
  if(calculated.used.some(source=>selectionDate(source)&&selectionDate(source)>report.cutoff))fail('보고 기준일 이후 원본이 사용되었습니다.');
  for(const duplicate of calculated.duplicateDiagnostics||[])if(duplicate.type==='dashboard'&&rows.some(row=>row.center===duplicate.center&&row.part===duplicate.part&&row.selectedSourceRow!==duplicate.selectedRow))fail('대시보드 중복의 맨 위 행 규칙이 유지되지 않았습니다.');
  const shortage=rows.filter(row=>row.shortage>0),order=rows.filter(row=>row.proposed>0),expectedParts=new Set(shortage.map(row=>row.part));
  const operations=O.evaluate(active,calculated),groupedParts=operations.groups.flatMap(group=>group.parts);
  if(!operations.groupingComplete||operations.groupTotal!==expectedParts.size||groupedParts.length!==expectedParts.size||new Set(groupedParts).size!==expectedParts.size||groupedParts.some(part=>!expectedParts.has(part)))fail('조치담당 조합 종수 합계가 현재 부족 종수와 다릅니다.');
  if(quantity(operations.groups.map(group=>group.quantity))!==quantity(shortage.map(row=>row.shortage)))fail('조치담당 조합 부족 수량 합계가 전체 부족 수량과 다릅니다.');
  if(rows.some(row=>row.shortage==null||row.proposed==null))warnings.push('일부 부품 수량은 원본 누락·미확인으로 계산할 수 없습니다. 0으로 바꾸지 않았습니다.');
  warnings.push(...calculated.warnings);
  summary={reportId:report.id,reportDate:report.reportDate,sourceSnapshots:input.sources.length,selectedSources:calculated.used.length,
   shortagePartKinds:expectedParts.size,shortageKnownUnits:quantity(shortage.map(row=>row.shortage)),
   additionalOrderPartKinds:new Set(order.map(row=>row.part)).size,additionalOrderKnownUnits:quantity(order.map(row=>row.proposed)),actionGroupKinds:operations.groupTotal};
 }catch(_){fail('계산 검증을 끝내지 못했습니다. 원본 형식과 주간 보고 참조를 확인해 주세요.');}
 return {ok:errors.length===0,errors:unique(errors),warnings:unique(warnings),summary};
}
return {SLOTS,slotKey,evaluate,recordExistingWeek,validate};
});
