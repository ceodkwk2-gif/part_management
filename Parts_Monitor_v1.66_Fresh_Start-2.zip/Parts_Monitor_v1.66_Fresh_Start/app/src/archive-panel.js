(function(root,factory){if(typeof module==='object'&&module.exports)module.exports=factory();else root.PartsArchivePanel=factory();})(typeof self!=='undefined'?self:this,function(){
'use strict';
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function model(manifest={}){
 const state=manifest.state||{},sources=[...(state.sources||[]),...Object.values(state.reportingSourceArchive||{})],reports=state.reportingWeeks||[],catalog=state.archiveCatalog||{};
 const ref=s=>JSON.stringify([s.id||[s.type,s.center||'',s.operator||'',s.date||s.file].join('|'),s.reportingRevision]);
 return (manifest.raw||[]).map(raw=>{const aliases=new Set([raw.name,...(raw.names||[])]),entry=catalog[raw.id]||{};
  const matched=sources.filter(s=>s.rawId===raw.id||(!entry.storedOnly&&!s.rawId&&aliases.has(s.file))),refs=new Set(matched.map(ref));
  const weeks=reports.filter(r=>(r.sourceRefs||[]).some(x=>refs.has(JSON.stringify([x.key,x.revision]))&&!(r.excludedSourceRefs||[]).some(e=>e.key===x.key&&e.revision===x.revision))).map(r=>r.id);
  return {...raw,archive:/\.zip$/i.test(raw.name),parsed:matched.length>0,weeks,excluded:entry.excluded===true,note:entry.note||'',status:weeks.length?'APPLIED':entry.excluded?'EXCLUDED':matched.length?'PARSED':'STORED'};
 });
}
function render(manifest={},language='ko'){
 const en=language==='en',t=(a,b)=>en?b:a,rows=model(manifest),pending=rows.filter(r=>!r.archive&&r.status==='STORED'),zip=rows.filter(r=>r.archive),labels={APPLIED:t('보고 반영 이력 있음','Used in saved reports'),PARSED:t('분석됨 · 현재 보고 미적용','Parsed / not in report'),STORED:t('보관됨 · 분석·반영 전','Stored / not parsed or applied'),EXCLUDED:t('보관됨 · 손상 제외','Stored / excluded as corrupt')};
 const table=items=>'<table class="wf-table"><thead><tr>'+[t('원본 파일','Original file'),t('처리 상태','Processing status'),t('반영 주차·비고','Report weeks / note')].map(x=>'<th>'+x+'</th>').join('')+'</tr></thead><tbody>'+items.map(r=>'<tr><td><a href="/api/raw?id='+encodeURIComponent(r.id)+'" download>'+esc(r.name)+'</a><small>'+Math.ceil(r.size/1024).toLocaleString()+' KB</small></td><td>'+ (r.archive?t('업로드 ZIP 원본 보관','Original upload ZIP retained'):labels[r.status])+'</td><td>'+esc(r.weeks.join(' / '))+(r.note?'<small>'+esc(r.note)+'</small>':'')+'</td></tr>').join('')+'</tbody></table>';
 return '<section class="wf-panel"><h2>'+t('보관 원본과 보고 반영 상태','Archived originals and report application')+'</h2><p><b>'+t('Excel 원본 ','Excel originals ')+(rows.length-zip.length)+' · ZIP '+zip.length+' · '+t('분석·반영 전 ','Not yet parsed / applied ')+pending.length+'</b></p><p>'+t('보관만 한 자료는 계산에 사용하지 않습니다. 아래 원본과 ZIP도 서버 전체 백업에 포함됩니다. 최신 운영 자료로 쓰려면 해당 주차에서 파일을 검토·반영하세요.','Stored-only files do not enter calculations. These originals and ZIPs are included in the full server backup. Review and apply files to the correct report week before using them operationally.')+'</p>'+ (pending.length?'<h3>'+t('분석·반영 전 원본','Files awaiting analysis / application')+'</h3>'+table(pending):'')+'<details><summary>'+t('보관 원본 전체 보기','View all archived originals')+' · '+rows.length+'</summary>'+table(rows)+'</details></section>';
}
return {model,render};
});
