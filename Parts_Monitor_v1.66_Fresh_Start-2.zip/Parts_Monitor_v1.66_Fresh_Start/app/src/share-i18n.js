(function(root,factory){
 if(typeof module==='object'&&module.exports)module.exports=factory;
 else factory(root.PartsI18n);
})(typeof self!=='undefined'?self:this,function install(I){
'use strict';
if(!I||!I.extend||!I.extendPatterns)throw new Error('PartsI18n must be loaded before its sharing translations.');
// Generated presentation text only. The sharing layer bypasses translation for
// raw codes, names, source text and user-entered search values. Calling text with
// an explicit export language does not change the application's language.
I.extend([
 ['부품별 재고, 필요수량, 발주와 조치 담당. 수량 단위 개. 조치 담당은 오른쪽 고정, 나머지 열은 좌우 이동 가능.','Part stock, required quantities, POs and action owner. Quantities in pieces. Action owner stays on the right; other columns can scroll horizontally.'],
 ['표 내보내기','Export table'],['부품 표 내보내기','Export parts table'],['제품 표 내보내기','Export products table'],['제품별 표 내보내기','Export product table'],
 ['현재 표의 상세 조건','Current table filters'],['데이터 이슈','Data issues'],['대표 조치 담당','Primary action owner'],['범위','Scope'],
 ['대상 범위','Scope'],['현재 부품 표','Current parts table'],['선택 부품','Selected part'],['선택 센터의 전체 조치','All actions for the selected centers'],
 ['부품별 재고·필요 조치','Stock and required actions by part'],['조직별 필요 조치','Required actions by organization'],
 ['선택 센터의 전체 조치 · 요약 상태 선택과 무관','All actions for the selected centers · Independent of the Summary status filter'],
 ['자재대기 · 부품별 필요수량','Awaiting parts · Required quantities by part'],['자재대기 · 제품별 목록','Awaiting parts · Product list'],
 ['법인·본사 재고 기준','India / HQ stock targets'],
 ['센터 추가 PO 필요수','Additional center PO needed'],['원본 기준일','Source date'],['상세 PO','Detailed PO'],
 ['Flex 소요','Flex demand'],['CTDI 소요','CTDI demand'],['정확한 기준일 미확인','Exact source date unknown'],
 ['0~30일(개)','0–30 days (pcs)'],['31~45일(개)','31–45 days (pcs)'],['46~90일(개)','46–90 days (pcs)'],
 ['91~180일(개)','91–180 days (pcs)'],['181일 이상(개)','181+ days (pcs)'],['45일 초과 합계(개)','Over-45-day total (pcs)'],
 ['날짜 확인 필요(개)','Date needs checking (pcs)'],['필요 부품 · 개수','Required parts / quantities'],['확인사항','Items to check'],
 ['필요 부품 확인 필요','Check required parts'],
 ['빈칸은 0이 아닙니다. 미확인·해당 없음 또는 반복 생략 항목입니다.','Blank cells are not zero. They indicate unknown, not applicable or omitted repeated values.'],
 ['법인 기준 미달량','India target shortfall'],['본사 기준 미달량','HQ target shortfall'],
 ['법인 개월','India target months'],['본사 개월','HQ target months'],
 ['Flex 원본 기준일','Flex source date'],['CTDI 원본 기준일','CTDI source date'],
 ['법인 원본 기준일','India source date'],['본사 원본 기준일','HQ source date'],
 ['선택 부품의 센터별 내역·병행 조치 포함','Includes center details and parallel actions for the selected parts'],
 ['선택 부품의 센터별 내역·병행 조치를 포함합니다. 센터를 선택하면 해당 센터 범위만 내보냅니다.','Includes center details and parallel actions for the selected parts. Selecting a center limits the export to that center.'],
 ['법인·본사 재고는 공용재고이며 부품 첫 행에만 표시합니다.','India / HQ stock is shared and appears only in the first row for each part.'],
 ['총 필요수는 현 수리 필요 수와 설정 보유분의 합계입니다.','Total required is current repair need plus the configured stock target.'],
 ['조치는 확인 대상별 업무이며 지연 귀책 판정이 아닙니다.','Actions describe each contact’s tasks; they do not assign responsibility for delays.'],
 ['한 부품에 여러 조치가 있을 수 있으므로 조치 행의 재고·수량·제품 대수를 합산하지 않습니다.','A part may have several actions. Do not sum stock, quantities or product counts across action rows.'],
 ['수량은 재고 차감 전 필요 부품 개수이며 제품 대수가 아닙니다.','Quantities are required part pieces before stock deduction, not product counts.'],
 ['45일 초과 합계는 46~90일·91~180일·181일 이상 수량의 합계이며 다시 더하지 않습니다.','The over-45-day total is the sum of the 46–90, 91–180 and 181+ day quantities. Do not add it again.'],
 ['필요 부품을 해석하지 못한 제품은 제품 목록에 남기며 이 표의 부품 수량에 추정해 더하지 않습니다.','Products with unresolved required parts remain in the product list. No estimated quantities are added to this parts table.'],
 ['제품당 한 행이며 여러 필요 부품은 같은 행에 표시합니다.','Each product has one row, with all required parts shown in that row.'],
 ['입고 경과일은 각 WIP 원본 기준일에서 Physical Receipt Date를 뺀 값입니다.','Days since receipt equals each WIP source date minus Physical Receipt Date.'],
 ['Shipped는 법인 출고이며 센터 입고 완료를 뜻하지 않습니다. ETD는 법인→센터 예정 출고일입니다.','Shipped means dispatch from India, not confirmed receipt at the center. ETD is the planned India-to-center dispatch date.'],
 ['대시보드 PO 미입고 수와 더하지 않습니다.','Do not add these quantities to dashboard open PO quantities.'],
 ['기준 미달량은 재고와 참고 기준의 차이이며 구매 지시량이 아닙니다.','Target shortfall is the gap between stock and the reference target, not an instruction to buy.'],
 ['본사 기준은 인도 수요 참고값이며 글로벌 적정재고 판정이 아닙니다.','The HQ target is a reference for India demand, not an assessment of global stock adequacy.']
]);
const dateLabels={
 '센터 재고':'Center stock','현 수리 필요 수':'Current repair need','상세 PO':'Detailed PO',
 '법인 재고':'India stock','본사 재고':'HQ stock','Flex 소요':'Flex demand','CTDI 소요':'CTDI demand'
};
// Date strings can contain any combination of available and unknown sources.
// Match generated field labels at segment boundaries, leaving dates and values
// intact instead of hard-coding a fixture's date or translating raw columns.
I.extendPatterns([
 [/필요 부품 확인 필요:\s*([\d,.]+)대/g,(_,count)=>`Products with unresolved required parts: ${count}`],
 [/(^|\s·\s)(센터 재고|현 수리 필요 수|상세 PO|법인 재고|본사 재고|Flex 소요|CTDI 소요)(?=:\s)/g,
  (_,separator,label)=>separator+dateLabels[label]]
]);
I.extend([
 ['현 수리 필요 수보다 센터 재고가 적음','Center stock is below the quantity needed for current repairs.'],
 ['재고 0·저소요·장납은 중복 가능','Zero stock, low use and long lead time may overlap.'],
 ['아래 자료는 부족 여부나 전체 부족 수량을 계산할 수 없습니다. 계산 가능한 부품 수량만 합산했으며, 일부만 해석된 제품은 인식한 부품 수량만 반영했습니다.','The records below do not support a complete shortage calculation. Totals include only calculable part quantities; partially parsed products contribute only their recognized parts.']
]);
I.extendPatterns([
 [/저소요 제외 시 ([\d,]+)종/g,(_,n)=>`Excluding low-use-only parts: ${n} types`],
 [/현재 수리분 부족은 없으나, ([\d,.]+)개월 소요량 확보를 위해 추가 PO 필요/g,(_,n)=>`No shortage for current repairs; additional POs are needed to cover ${n} ${Number(n)===1?'month':'months'} of demand.`],
 [/현재 수리분 부족은 없으며, ([\d,.]+)개월 소요량 확보에 필요한 PO는 발주되어 입고 대기 중/g,(_,n)=>`No shortage for current repairs; POs to cover ${n} ${Number(n)===1?'month':'months'} of demand have been placed and are awaiting receipt.`],
 [/([\d,.]+)개월분 부족 · 추가 발주 필요/g,(_,n)=>`${n}-month stock shortfall · Additional POs needed`],
 [/총 필요수 = 현 수리 필요 수 \+ ([\d,.]+)개월 소요량\(올림\)/g,(_,n)=>`Total required = current repair need + ${n}-month demand (rounded up)`],
 [/부족 수량 계산 자료 확인/g,()=> 'Data needed for shortage calculation'],
 [/재고·필요량 미확인 ([\d,]+)종/g,(_,n)=>`Stock or repair need unknown: ${n} part types`],
 [/필요 부품 확인 필요 ([\d,]+)대/g,(_,n)=>`Required parts to clarify: ${n} products`]
]);
I.extend([
 [
  "자재대기 · PO · TAT 이력",
  "Awaiting parts · PO / TAT history"
 ],
 [
  "이력·PO 표 내보내기",
  "Export history / PO tables"
 ],
 [
  "현재 부족과 필요한 조치",
  "Current shortage and required actions"
 ],
 [
  "센터 전체 수리 필요",
  "Center-wide repair need"
 ],
 [
  "현재 수리분 부족",
  "Current repair shortage"
 ],
 [
  "수량 단위 개 · 위 재고·필요량은 해당 센터 전체 기준이며 선택한 제품이나 사업자에 배정한 수량이 아닙니다.",
  "Quantities in pieces. Stock and repair need above cover the whole center and are not allocated to selected products or operators."
 ],
 [
  "부품 재고·수요 판단 자료 없음",
  "Part stock / demand evidence unavailable"
 ],
 [
  "조치 담당은 현재 자료로 판단한 다음 업무이며 지연 귀책이 아닙니다. 법인→본사 요청일과 실제 센터 입고일은 미확인입니다.",
  "Action owners identify the next tasks based on available data, not responsibility for delays. India-to-HQ request dates and actual center receipt dates are unknown."
 ],
 [
  "관련 PO 발주 내역",
  "Related PO details"
 ],
 [
  "같은 센터·부품의 PO를 모두 표시합니다. 특정 제품에 배정된 주문은 확인되지 않았습니다.",
  "All POs for the same center and part are shown. Orders assigned to individual products are not identified."
 ],
 [
  "상세 PO 자료 없음 · 발주 여부를 확정하지 않습니다.",
  "Detailed PO source unavailable. Order placement cannot be determined."
 ],
 [
  "현재 상세 PO 목록에 해당 부품 없음 · 계산 PO 미입고 수와 함께 확인하세요.",
  "This part is absent from the current detailed PO list. Check the open PO quantity used in the calculation as well."
 ],
 [
  "PO 번호 없음",
  "PO number missing"
 ],
 [
  "발주일",
  "PO date"
 ],
 [
  "PO 경과일",
  "Days since PO"
 ],
 [
  "PO 원본 기준일",
  "PO source date"
 ],
 [
  "PO 경과일 = PO 원본 기준일 − 발주일 · 원본 기준일:",
  "Days since PO = PO source date − PO date · Source date:"
 ],
 [
  "제품별 TAT와 부품 필요 최초 관찰",
  "Product TAT and first observed part need"
 ],
 [
  "최초 관찰은 처음 받은 WIP에서 확인한 시점이며 실제 부품 필요 발생일이 아닙니다. TAT는 각 WIP 원본 기준일 − Physical Receipt Date입니다.",
  "First observation is when the need first appeared in received WIP data, not the actual need onset. TAT equals each WIP source date minus Physical Receipt Date."
 ],
 [
  "45일째부터 Alert · 기존 45일 초과 합계는 46일째부터 집계합니다.",
  "Alerts start on day 45. The existing over-45-day total still starts on day 46."
 ],
 [
  "현재 TAT",
  "Current TAT"
 ],
 [
  "부품 필요 최초 관찰",
  "First observed part need"
 ],
 [
  "TAT Alert",
  "TAT Alert"
 ],
 [
  "최초 자료부터 대기",
  "Waiting in earliest available data"
 ],
 [
  "최초 확인 주차 미확인",
  "First observed week unknown"
 ],
 [
  "이력 미확인",
  "History unavailable"
 ],
 [
  "TAT 미확인",
  "TAT unknown"
 ],
 [
  "날짜 미확인",
  "Date unknown"
 ],
 [
  "중간 관찰 공백 있음",
  "Gap in observations"
 ],
 [
  "재등장 · 이번 대기 첫 관찰",
  "Reappeared · Current episode first observed"
 ],
 [
  "45일째 Alert",
  "Day 45 alert"
 ],
 [
  "45일 미만",
  "Under 45 days"
 ],
 [
  "입고 45일 이상 Alert",
  "45+ days since receipt · Alert"
 ],
 [
  "45일 이상 Alert",
  "45+ day alert"
 ],
 [
  "원본 보기",
  "View source"
 ],
 [
  "부품을 누르면 최초 관찰 주차·관련 PO·조치 담당을 확인합니다.",
  "Select a part to view its first observed week, related POs and action owners."
 ],
 [
  "제품별 TAT·최초 관찰",
  "Product TAT / first observation"
 ],
 [
  "현재 부품 재고·필요 조치",
  "Current part stock / required actions"
 ],
 [
  "이 부품 현 수리 필요 수(개)",
  "Current repair need for this part (pcs)"
 ],
 [
  "최초 관찰 구분",
  "First observation type"
 ],
 [
  "최초 관찰 주차",
  "First observed week"
 ],
 [
  "최초 관찰일",
  "First observation date"
 ],
 [
  "최초 관찰 당시 TAT",
  "TAT at first observation"
 ],
 [
  "이전 자료에서 미관찰한 날짜",
  "Previous source date without this need"
 ],
 [
  "관찰 횟수",
  "Observation count"
 ],
 [
  "이번 대기 첫 관찰",
  "Current episode first observed"
 ],
 [
  "이력 확인사항",
  "History notes"
 ],
 [
  "주간 자료에서 최초 확인",
  "First observed in weekly data"
 ],
 [
  "제품별 해당 부품 한 행이며 PO와 제품을 임의 연결하지 않습니다.",
  "Each product has one row for the selected part. POs are not arbitrarily assigned to products."
 ],
 [
  "최초 자료부터 대기 중인 제품은 그 이전 발생 시점을 알 수 없습니다. 자료 누락·목록에서 사라짐만으로 수리 완료를 확정하지 않습니다.",
  "For products already waiting in the earliest data, the earlier onset is unknown. Missing data or disappearance from a list does not confirm repair completion."
 ],
 [
  "PO 경과일은 PO 원본 기준일에서 발주일을 뺀 값입니다.",
  "Days since PO equals the PO source date minus the PO date."
 ],
 [
  "9/28 주차 신규 본사 재고 미수신 · 9/22 재고 참고 사용",
  "No new HQ stock for the week of Sep 28 · Sep 22 stock retained as reference"
 ],
 [
  "수리 필요량:",
  "Repair need:"
 ]
]);
I.extendPatterns([
 [/Alert · 입고 45일 이상 ([\d,]+)대/g,(_,n)=>`Alert · 45+ days since receipt: ${n} products`],
 [/선택 범위: 필요 ([\d,]+)개 · 제품 ([\d,]+)대 · 입고 45일 초과 ([\d,]+)대/g,(_,q,n,o)=>`Selected scope: ${q} required pieces · ${n} products · ${o} over 45 days`],
 [/(\d{4}-\d{2}-\d{2}) 주차/g,(_,date)=>`Week of ${date}`],
 [/TAT ([\d,]+)일/g,(_,n)=>`TAT ${n} days`]
]);
return I;
});
