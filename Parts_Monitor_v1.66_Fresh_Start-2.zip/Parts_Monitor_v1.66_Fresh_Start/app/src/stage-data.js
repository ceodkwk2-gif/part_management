(function(root,factory){
 if(typeof module==='object'&&module.exports)module.exports=factory();
 else root.PartsStageData=factory();
})(typeof globalThis==='object'?globalThis:this,function(){
'use strict';
const known=v=>typeof v==='number'&&Number.isFinite(v),sum=(rows,key)=>rows.reduce((s,r)=>s+(known(r[key])?r[key]:0),0);
const scopes=['ALL','CTDI','Flex'];
// Read-only review signals. These never allocate stock, replace ETA, or change PO quantities.
function reviewFlags(row){
 const flags=[],pos=row.pos||[],orders=row.siel||[];
 if(row.shortageBasis==='wip-waiting'&&row.shortage>0&&row.stock>0)flags.push({code:'WIP_STOCK',label:'센터 재고·WIP 자재대기 확인',stock:row.stock,waiting:row.shortage,quantity:Math.min(row.stock,row.shortage)});
 if(pos.length&&pos.every(p=>known(p.pending))&&known(row.open)&&sum(pos,'pending')!==row.open)
  flags.push({code:'CENTER_PO',label:'센터 PO 수량 확인',open:row.open,detail:sum(pos,'pending')});
 const gap=known(row.needed)&&known(row.stock)?Math.max(0,row.needed+(known(row.target)?row.target:0)-row.stock):null;
 if(gap>0&&row.open>0&&known(row.india)&&row.india<gap&&row.hq>0&&orders.length)
  flags.push({code:'HQ_STOCK_ETA',label:'본사 재고·ETA 확인',hq:row.hq,india:row.india,gap,etas:[...new Set(orders.map(p=>p.eta).filter(Boolean))].sort(),hasMissingEta:orders.some(p=>!p.eta)});
 return flags;
}
function quantityChecks(input={},center='ALL'){
 const included=r=>center==='ALL'||r.center===center,rows=[];
 for(const r of (input.rows||[]).filter(included)){
  const missing=[['needed','수리 필요량'],['stock','센터 재고'],['open','센터 PO 잔량'],['target','보유 목표'],['proposed','추가 PO']].filter(([key])=>!known(r[key])).map(([,label])=>label);
  if(!missing.length)continue;
  const source=(input.sourceDates||[]).find(s=>s.type==='dashboard'&&s.center===r.center);
  rows.push({center:r.center,part:r.part,missing,reason:r.avgReason||(r.issues||[]).join(' · ')||'해당 원본 자료 없음',source:source?.file||'센터 재고·소요량 자료 없음',sheet:source?.sheet||'',row:null,knownShortage:known(r.shortage)?r.shortage:null});
 }
 for(const p of (input.issues?.unresolvedProducts||[]).filter(included))rows.push({center:p.center,part:p.required||p.unparsed||'부품코드 미해석',missing:['해당 제품의 부품코드·수량'],reason:'WIP 필요 부품 원문에서 유효 코드를 확인할 수 없음',source:p.source||p.file||'',sheet:p.sheet||'',row:p.row,knownShortage:null,unresolved:true});
 return rows;
}
function calendarTrend(points){
 const byWeek=new Map(points.map(p=>[p.week,{...p,metrics:p.metricsByCenter||p.metrics||{}}]));
 const dates=[...byWeek.keys()].sort();if(!dates.length)return [];
 const out=[],d=new Date(dates[0]+'T00:00:00Z');
 for(let i=0;i<5200&&d.toISOString().slice(0,10)<=dates.at(-1);i++,d.setUTCDate(d.getUTCDate()+7)){
  const week=d.toISOString().slice(0,10);out.push(byWeek.get(week)||{week,missing:true,metrics:{},notes:['자료가 없는 주차 · 0 또는 이전 수치로 채우지 않음']});
 }
 return out;
}
function build(input={}){
 const pos=new Map(),hq=new Map(),history=new Map();
 for(const p of input.pos||[]){const key=p.center+'|'+p.part;if(!pos.has(key))pos.set(key,[]);pos.get(key).push(p);}
 for(const p of input.siel?.rows||[]){if(!hq.has(p.part))hq.set(p.part,[]);hq.get(p.part).push(p);}
 for(const p of input.products||[])for(const part of p.parts||[]){
  const key=p.center+'|'+part.part;if(!history.has(key))history.set(key,[]);
  history.get(key).push({...part,sn:p.sn,rma:p.rma,operator:p.operator,receipt:p.receipt,tat:p.age,date:p.date,source:p.source,sheet:p.sheet,row:p.row});
 }
 const rows=(input.rows||[]).map(row=>{
  const histories=(history.get(row.id)||[]).sort((a,b)=>(b.tat??-1)-(a.tat??-1)),byDate=new Map();
  for(const h of histories){if(!h.firstDate)continue;if(!byDate.has(h.firstDate))byDate.set(h.firstDate,[]);byDate.get(h.firstDate).push(h);}
  const firstGroups=[...byDate].sort(([a],[b])=>a.localeCompare(b)).map(([date,rs])=>{const ages=rs.map(r=>r.firstAge).filter(known);return {date,quantity:sum(rs,'quantity'),products:rs.length,baseline:rs.filter(r=>r.baseline).length,ageMin:ages.length?Math.min(...ages):null,ageMax:ages.length?Math.max(...ages):null};});
  const ages=histories.map(h=>h.tat).filter(known),over=histories.filter(h=>h.tat>45);
  return {...row,sourceDates:row.sourceDates||{},sourceWeeks:row.sourceWeeks||{},histories,firstGroups,
   products:histories.length,over45Products:over.length,over45Need:sum(over,'quantity'),maxTat:ages.length?Math.max(...ages):null,minTat:ages.length?Math.min(...ages):null,
   pos:pos.get(row.id)||[],siel:hq.get(row.part)||[],actions:[],fullActions:[]};
 });
 const indexes={},reportMetrics={},charts={};
 for(const center of scopes){
  const rs=rows.filter(r=>center==='ALL'||r.center===center),parts=new Map();
  for(const row of rs){if(!parts.has(row.part))parts.set(row.part,[]);parts.get(row.part).push(row);}
  const groups={SHORTAGE:[],ORDER:[],WAIT:[],OVERDUE:[],ALL:[],ORDER_ALL:[],UNKNOWN:[]};
  for(const [part,members] of parts){
   groups.ALL.push({part,ids:members.map(r=>r.id)});const unknown=members.filter(r=>![r.needed,r.stock,r.proposed].every(known));if(unknown.length)groups.UNKNOWN.push({part,ids:unknown.map(r=>r.id)});
   const ordered=members.filter(r=>r.proposed>0);if(ordered.length)groups.ORDER_ALL.push({part,ids:ordered.map(r=>r.id)});
   let kind,selected=[];
   if(members.some(r=>r.shortage>0)){kind='SHORTAGE';selected=members.filter(r=>r.shortage>0);}
   else if(members.every(r=>[r.stock,r.needed,r.shortage].every(known))){
    if(members.some(r=>r.proposed>0)){kind='ORDER';selected=members.filter(r=>r.proposed>0);}
    else if(members.every(r=>[r.stock,r.needed,r.target,r.open,r.proposed].every(known))&&members.some(r=>r.waitingCovered)){kind='WAIT';selected=members.filter(r=>r.waitingCovered);}
   }
   if(kind)groups[kind].push({part,ids:selected.map(r=>r.id)});
   const overdue=members.filter(r=>r.over45Need>0);if(overdue.length)groups.OVERDUE.push({part,ids:overdue.map(r=>r.id)});
  }
  indexes[center]=groups;
  const byId=new Map(rs.map(r=>[r.id,r]));
  reportMetrics[center]=Object.fromEntries(Object.entries({SHORTAGE:'shortage',ORDER:'proposed',WAIT:'open',OVERDUE:'over45Need',ALL:'needed',ORDER_ALL:'proposed'}).map(([key,field])=>[key,{parts:groups[key].length,quantity:sum(groups[key].flatMap(g=>g.ids.map(id=>byId.get(id))),field)}]));
  const products=(input.products||[]).filter(p=>center==='ALL'||p.center===center);
  charts[center]={bands:[{label:'46–60',count:products.filter(p=>p.age>45&&p.age<=60).length},{label:'61–90',count:products.filter(p=>p.age>60&&p.age<=90).length},{label:'91+',count:products.filter(p=>p.age>90).length}]};
 }
 return {asof:input.asof||'',week:input.week||'',rows:rows.map(r=>({...r,reviewFlags:reviewFlags(r)})),indexes,reportMetrics,charts,trend:calendarTrend(input.trend||[]),sources:input.sourceDates||[],metrics:input.metricsByCenter||{},availability:input.availabilityByCenter||{},siel:input.siel||{available:false},quality:input.qualityByCenter||{},issues:input.issues||{},targetMonths:input.settings?.targetMonths||1};
}
return {build,calendarTrend,reviewFlags,quantityChecks};
});
