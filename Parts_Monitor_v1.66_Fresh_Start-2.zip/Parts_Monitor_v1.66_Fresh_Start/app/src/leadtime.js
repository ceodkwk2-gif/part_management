(function(root,factory){
 if(typeof module==='object'&&module.exports)module.exports=factory();
 else root.PartsLeadTime=factory();
})(typeof self!=='undefined'?self:this,function(){
'use strict';
// This is manually maintained part master data, not a PO processing-time log.
// It never changes inventory, demand, reorder quantities or shortage dates.
// The procurement review is an LT-only reference alert, not a purchase proposal.
const isRecord=value=>value!=null&&typeof value==='object'&&!Array.isArray(value);
function normalizePart(value){
 const part=String(value??'').trim().toUpperCase();
 if(!part)throw Error('장납 표시를 등록할 부품 코드를 입력해 주세요.');
 return part;
}
function normalizeMarker(value){
 if(!isRecord(value)||value.longLead!==true)throw Error('장납 여부는 직접 선택해 주세요. 예상 L/T만으로 자동 판단하지 않습니다.');
 let months=null;
 if(value.months!=null&&!(typeof value.months==='string'&&value.months.trim()==='')){
  if(!['number','string'].includes(typeof value.months))throw Error('예상 L/T는 0보다 큰 개월 수 또는 빈칸이어야 합니다.');
  months=Number(value.months);
  if(!Number.isFinite(months)||months<=0)throw Error('예상 L/T는 0보다 큰 개월 수 또는 빈칸이어야 합니다.');
 }
 if(value.note!=null&&typeof value.note!=='string')throw Error('장납 메모는 텍스트로 입력해 주세요.');
 return {longLead:true,months,note:(value.note||'').trim()};
}
function normalizeRegistry(registry){
 if(registry==null)return {};
 if(!isRecord(registry))throw Error('장납 부품 등록 정보의 형식이 올바르지 않습니다.');
 const normalized=new Map();
 for(const [rawPart,value] of Object.entries(registry)){
  const part=normalizePart(rawPart),marker=normalizeMarker(value),previous=normalized.get(part);
  if(previous&&JSON.stringify(previous)!==JSON.stringify(marker))throw Error(`${part}: 중복된 장납 등록 정보가 서로 다릅니다. 등록 내용을 확인해 주세요.`);
  normalized.set(part,marker);
 }
 return Object.fromEntries(normalized);
}
function normalizeState(state){
 if(!isRecord(state))throw Error('작업 데이터 형식이 올바르지 않습니다.');
 return {...state,partLeadTimes:normalizeRegistry(state.partLeadTimes)};
}
function get(state,part){
 const registry=normalizeRegistry(state?.partLeadTimes),key=normalizePart(part);
 return Object.prototype.hasOwnProperty.call(registry,key)?registry[key]:null;
}
function set(state,part,value){
 const next=normalizeState(state),key=normalizePart(part),marker=normalizeMarker(value);
 return {...next,partLeadTimes:{...next.partLeadTimes,[key]:marker}};
}
function remove(state,part){
 const next=normalizeState(state),key=normalizePart(part);
 delete next.partLeadTimes[key];
 return next;
}
function summarize(state,rows){
 if(!Array.isArray(rows))throw Error('부품 목록 형식이 올바르지 않습니다.');
 const registry=normalizeRegistry(state?.partLeadTimes);
 const parts=[...new Set(rows.map(row=>normalizePart(isRecord(row)?row.part:row)))];
 const taggedParts=parts.filter(part=>Object.prototype.hasOwnProperty.call(registry,part));
 return {partCount:parts.length,taggedPartCount:taggedParts.length,parts,taggedParts};
}
function procurementReview(state,commonSupport){
 const registry=normalizeRegistry(state?.partLeadTimes);
 const known=value=>typeof value==='number'&&Number.isFinite(value)&&value>=0;
 const support=new Map((commonSupport?.parts||[]).map(row=>[String(row.part??'').trim().toUpperCase(),row]));
 const rows=Object.entries(registry).sort(([a],[b])=>a.localeCompare(b)).map(([part,marker])=>{
  const source=support.get(part),months=marker.months;
  const demand=source?.demandComplete!==false&&known(source?.demand)?source.demand:null;
  const hq=known(source?.hq)?source.hq:null;
  const rawLeadDemand=months!=null&&demand!=null?demand*months:null;
  const leadDemand=known(rawLeadDemand)?rawLeadDemand:null;
  const rawCoverage=demand>0&&hq!=null?hq/demand:null;
  const coverageMonths=known(rawCoverage)?rawCoverage:null;
  let status,reason,nextAction;
  const missing=[];
  if(!source)missing.push('현재 비교 자료에 등록 부품이 없음');
  if(months==null)missing.push('예상 L/T 미입력');
  if(demand==null)missing.push('동일 기간 인도 월평균 사용량 미확인');
  if(hq==null)missing.push('본사 재고 미확인');
  if(months!=null&&demand!=null&&leadDemand==null)missing.push('L/T 참고 소요량 계산 범위 초과');
  if(missing.length){
   status='DATA_NEEDED';reason=missing.join(' · ');
   nextAction='부품 등록·사용량·본사 재고·예상 L/T 확인';
  }else if(demand===0){
   status='NO_USAGE';reason='확인된 인도 월평균 사용량이 0이므로 L/T 소요 기준 경보를 만들지 않음';
   nextAction='현 수리 필요 수는 기존 부족·PO 목록에서 별도 확인';
  }else if(hq<=leadDemand){
   status='CHECK_PROCUREMENT';reason='인도 소요 기준 재고 여력이 본사 조달 L/T 이하';
   nextAction='선행 확보 요청 검토';
  }else{
   status='ABOVE_REFERENCE';reason='본사 현재 재고이 인도 월평균 사용량 × 예상 L/T를 초과함. 공용재고 배정과 글로벌 수요가 없어 공급 안전을 확정하지 않음';
   nextAction='공급계획 변동 시 재확인';
  }
  return {part,description:source?.description||'',months,demand,hq,coverageMonths,leadDemand,status,reason,nextAction,requestOwner:'법인',purchaseOwner:'본사',note:marker.note};
 });
 return {rows,alerts:rows.filter(row=>row.status==='CHECK_PROCUREMENT'),reviewableCount:rows.filter(row=>row.status==='CHECK_PROCUREMENT'||row.status==='ABOVE_REFERENCE').length,unknownCount:rows.filter(row=>row.status==='DATA_NEEDED').length};
}
return {normalizePart,normalizeMarker,normalizeRegistry,normalizeState,get,set,remove,summarize,procurementReview};
});
