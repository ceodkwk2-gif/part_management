(function(root,factory){const api=factory(typeof module==='object'&&module.exports?require('./workflow.js'):root.PartsWorkflow);if(typeof module==='object'&&module.exports)module.exports=api;else root.PartsExampleMail=api;})(typeof self!=='undefined'?self:this,function(W){
'use strict';
const text=value=>value==null?'':String(value);
const unique=values=>[...new Set(values.filter(Boolean))];
const english=language=>/^en(?:g(?:lish)?)?\b/i.test(text(language));
const roles={ALL:['전체','All recipients'],CENTER:['수리센터','Repair center'],INDIA:['법인','India subsidiary'],HQ:['본사','HQ']};
const role=value=>Object.hasOwn(roles,value)?value:'ALL';
const label=(value,en)=>roles[role(value)][en?1:0];
const selectText=(item,base,en)=>text(item?.[base+(en?'En':'Ko')]||item?.[base+(en?'Ko':'En')]);
const qty=(value,en)=>typeof value==='number'&&Number.isFinite(value)?String(value):(en?'Unconfirmed':'미확인');
const noteLines=value=>Array.isArray(value)?value.map(text).filter(Boolean):text(value)?[text(value)]:[];
const confirmedProgress=(note,language)=>W?.progressLines(note,language)||[];
function dateText(value,en,centers,asof){
 const names={dashboard:en?'Center stock':'센터 재고',wip:'WIP',po:'PO',india:en?'India':'법인',hq:en?'HQ':'본사'};
 const sources=Array.isArray(value)?value:Object.entries(value||{}).filter(([type])=>Object.hasOwn(names,type)).map(([type,date])=>({type,date}));
 const compactDate=date=>/^\d{4}-\d{2}-\d{2}$/.test(text(date))?(text(date).slice(0,4)===text(asof).slice(0,4)?Number(text(date).slice(5,7))+'/'+Number(text(date).slice(8,10)):text(date)):(en?'Unconfirmed':'미확인');
 const dateLabel=source=>(source.date?compactDate(source.date):source.reportWeek?compactDate(source.reportWeek)+(en?' week':'주'):(en?'Unconfirmed':'미확인'))+(source.carriedForward?(en?' (reference)':'(참고)'):'');
 const groups=[];
 for(const type of ['dashboard','wip','po','india','hq']){
  const selected=sources.filter(source=>source.type===type&&(!source.center||!centers.size||centers.has(source.center)));
  if(!selected.length)continue;
  const byCenter=new Map();
  for(const source of selected){const key=text(source.center);if(!byCenter.has(key))byCenter.set(key,[]);byCenter.get(key).push(source);}
  const entries=[...byCenter].map(([center,items])=>{
   const dates=unique(items.map(dateLabel));
   if(dates.length===1)return (center?center+' ':'')+dates[0];
   return (center?center+' ':'')+unique(items.map(source=>(source.operator?text(source.operator)+' ':'')+dateLabel(source))).join(' · ');
  });
  groups.push(names[type]+' '+entries.join(' · '));
 }
 return groups.join(' / ');
}
function specificDateNote(value){
 return /원본|기준일|파일명|source|snapshot|report date|file date/i.test(value)&&/불일치|다름|상이|이후|미래|미확인|conflict|mismatch|differ|future|unknown|unconfirmed/i.test(value);
}
const comparable=value=>text(value).toLowerCase().replace(/[\s.,:;·→—()]+/g,'');
function formatPoEvidence(data,row,en=false){
 const center=text(row?.center),part=text(row?.part),lines=(data.pos||[]).filter(p=>p.center===center&&p.part===part),shared=(data.siel?.rows||[]).filter(p=>p.part===part);
 const issue=(data.issues?.po||[]).find(p=>p.center===center&&p.part===part),blocks=[];
 const piece=value=>typeof value==='number'&&Number.isFinite(value)&&value>=0?String(value)+(en?' pcs':'개'):(en?'Unconfirmed':'미확인'),date=value=>text(value)||(en?'Unconfirmed':'미확인');
 // Ordered / Shipped / Pending below always refer to the same source PO line.
 // They are not recomputed from dashboard Open PO, and Shipped is not receipt.
 const open=(en?'Dashboard open PO: ':'대시보드 미입고 PO: ')+piece(row?.open);
 if(lines.length){
  blocks.push(open);
  blocks.push((en?'Center → India PO records':'센터 → 법인 PO 내역')+'\n'+lines.map(p=>[
   (text(p.po)||(en?'PO number unconfirmed':'PO 번호 미확인'))+(text(p.item)?' / '+(en?'item ':'항목 ')+text(p.item):'')+' · '+(en?'Ordered on ':'발주일 ')+date(p.poDate),
   (en?'Ordered ':'기발주 ')+piece(p.ordered)+' / '+(en?'India dispatch (Shipped) ':'법인 출고(Shipped) ')+piece(p.shipped)+' / Pending '+piece(p.pending),
   'ETD '+date(p.etd),
  ].join('\n')).join('\n\n'));
  if(issue)blocks.push((en?'Quantity review: ':'수량 확인: ')+(en?'Dashboard open ':'대시보드 미입고 ')+piece(row?.open)+' / '+(en?'Detail Pending ':'상세 Pending ')+piece(issue.detailPending)+((issue.issues||[]).some(value=>/동일.*식별키.*불일치/.test(value))?'\n'+(en?'Conflicting duplicate PO values · Combined balance unconfirmed':'동일 PO 식별키의 값 불일치 · 합산 잔량 미확인'):''));
 }else if(row?.open===0)blocks.push(en?'Open PO 0 pcs':'미입고 PO 0개');
 else blocks.push(open+'\n'+(en?'Detailed order records unconfirmed':'상세 발주 내역 미확인'));
 if(shared.length){
  const demo=data.siel?.demo===true||shared.some(p=>p.demo===true),sourceDates=unique(shared.map(p=>p.sourceDate));
  const heading=(en?'Shared India → HQ PO · Center allocation unconfirmed':'공용 법인 → 본사 PO · 센터 배정 미확인')+(demo?'\n'+(en?'Demo-linked source':'데모 연결 자료')+(sourceDates.length?' · '+sourceDates.join(', '):''):'');
  blocks.push(heading+'\n'+shared.map(p=>[
   (text(p.po)||(en?'PO number unconfirmed':'PO 번호 미확인'))+(text(p.item)?' / '+(en?'item ':'항목 ')+text(p.item):'')+' · '+(en?'Ordered on ':'발주일 ')+date(p.poDate),
   (en?'Ordered ':'기발주 ')+piece(p.ordered)+' / '+(en?'Actual open qty ':'실제 미입고 ')+piece(p.pending),
   (en?'Planned India arrival (ETA) ':'법인 도착 예정(ETA) ')+date(p.eta),
   ...(p.docs?.length?[(en?'Supply documents ':'공급 서류 ')+p.docs.length+(en?' lines · Actual India receipt unconfirmed':'건 · 실제 법인 입고 미확인')]:[]),
  ].join('\n')).join('\n\n'));
 }
 return blocks.join('\n\n');
}
function buildActionTable({data={},rowIds,recipient='ALL',language='ko',notes={}}={}){
 const en=english(language),target=role(recipient),scope=Array.isArray(rowIds)?new Set(rowIds.map(text)):null;
 const members=new Map((data.rows||[]).map(row=>[text(row.id),row]));
 const groups=new Map();
 for(const task of data.tasks||[]){
  const row=members.get(text(task.rowId));if(!row||scope&&!scope.has(text(row.id)))continue;
  if(!['CENTER','INDIA','HQ'].includes(task.recipient)||target!=='ALL'&&task.recipient!==target)continue;
  const key=JSON.stringify([text(row.center),text(row.part),task.recipient]);
  if(!groups.has(key))groups.set(key,{row,recipient:task.recipient,tasks:[],seen:new Set()});
  const group=groups.get(key),taskKey=text(task.id)||JSON.stringify(task);
  if(!group.seen.has(taskKey)){group.tasks.push(task);group.seen.add(taskKey);}
 }
 const columns=[
  {key:'part',label:en?'Part code / name':'부품 코드 / 부품명'},
  {key:'center',label:en?'Center':'센터'},
  ...(target==='ALL'?[{key:'recipient',label:en?'Action owner':'조치 담당'}]:[]),
  {key:'action',label:en?'Required action / ETD':'필요 조치 / ETD'},
  {key:'inventory',label:en?'Stock · Center / India / HQ':'재고 · 센터 / 법인 / 본사'},
  {key:'needed',label:en?'Current repair need':'현 수리 필요 수'},
  {key:'shortage',label:en?'Current shortage':'현재 부족 수'},
  {key:'open',label:en?'Open PO / related records':'PO 미입고 / 관련 기록'},
  {key:'proposed',label:en?'Additional PO needed':'추가 PO 필요 수'},
  {key:'over45',label:en?'Products over 45 days':'45일 초과 제품'},
  {key:'eta',label:en?'Expected center receipt':'센터 입고 예정'},
  {key:'plan',label:en?'Confirmed plan / review status':'확정 대책 / 검토 상태'},
 ];
 const rows=[...groups.values()].map(group=>{
  const {row,tasks}=group,manual=notes[text(row.id)]||{};
  const actions=unique(tasks.map(task=>selectText(task,'text',en)||(en?'Action details unavailable':'조치 상세 미입력')));
  const schedules=unique(tasks.map(task=>selectText(task,'schedule',en)));
  const alreadyShown=[...actions,...schedules].map(comparable);
  const taskNotes=unique(tasks.flatMap(task=>noteLines(task[en?'notesEn':'notesKo']||task[en?'notesKo':'notesEn']))).filter(note=>specificDateNote(note)&&!alreadyShown.some(shown=>shown.includes(comparable(note))||comparable(note).includes(shown)));
  const action=[...actions,...schedules.map(item=>(en?'Schedule / ETD: ':'일정 / ETD: ')+item),...taskNotes].join('\n');
  // Each task refers to the same center-part scope. Never add its product
  // count repeatedly just because several organizations have parallel work.
  const overdue=tasks.map(task=>task.tat?.overdueProducts).filter(value=>typeof value==='number'&&Number.isFinite(value));
  const plans=[text(manual.plan).trim()||(en?'Not provided':'미입력')];
  plans.push(...confirmedProgress(manual,en?'en':'ko'));
  if(manual.updatedAt)plans.push((en?'Updated: ':'기록: ')+text(manual.updatedAt));
  const partLabel=en&&row.part==='명판'?'Name plate':text(row.part),nameLabel=en&&row.name==='명판'?'Name plate':text(row.name);
  const record={part:partLabel+(nameLabel&&nameLabel!==partLabel?'\n'+nameLabel:''),center:text(row.center),recipient:label(group.recipient,en),action,
   inventory:(en?'Center ':'센터 ')+qty(row.stock,en)+' · '+(en?'India ':'법인 ')+qty(row.india,en)+' · '+(en?'HQ ':'본사 ')+qty(row.hq,en),
   needed:qty(row.needed,en),shortage:qty(row.shortage,en),open:formatPoEvidence(data,row,en),proposed:qty(row.proposed,en),
   over45:overdue.length?String(Math.max(...overdue)):(en?'Unconfirmed':'미확인'),
   eta:text(manual.eta).trim()||(en?'Unconfirmed':'미확인'),plan:plans.join('\n')};
  return columns.map(column=>record[column.key]);
 });
 const contextRows=groups.size?[...groups.values()].map(group=>group.row):[...members.values()].filter(row=>!scope||scope.has(text(row.id)));
 const sourceDates=dateText(data.sourceDates,en,new Set(contextRows.map(row=>row.center).filter(Boolean)),data.asof);
 return {subject:en?`Repair parts follow-up · ${label(target,true)} · ${text(data.asof)||'Date unconfirmed'}`:`수리 자재 확인 요청 · ${label(target,false)} · ${text(data.asof)||'기준일 미확인'}`,
  recipientLabel:label(target,en),context:(en?'Report date: ':'보고 기준일: ')+(text(data.asof)||(en?'Unconfirmed':'미확인'))+(sourceDates?'\n'+(en?'Source dates: ':'원본 기준일: ')+sourceDates:''),columns,rows,
  notes:en?[
   'Shipped is India dispatch, not center receipt. ETD is planned India→center dispatch; shared HQ PO ETA is planned India arrival. Neither establishes actual receipt. Expected center receipt and confirmed plans are manual entries only.',
   'Do not total repeated quantities across recipient rows. Center stock is shared across operators; India/HQ stock is not allocated. Quantities are pieces; over-45-day counts are products aged 46+ days.',
   'These are required actions, not findings of liability. Manual review status does not prove the shortage is resolved or change source quantities.',
  ]:[
   'Shipped는 법인 출고량이며 센터 입고량이 아닙니다. ETD는 법인→센터 예정 출고일, 공용 본사 PO의 ETA는 법인 도착 예정일입니다. 실제 입고 완료를 뜻하지 않으며 센터 입고 예정·확정 대책은 직접 기록한 값만 표시합니다.',
   '담당별 반복 수량을 합산하지 마세요. 센터 재고는 사업자 공용이고 법인·본사 재고는 배정 수량이 아닙니다. 수량은 개, 45일 초과는 46일 이상 제품 대수입니다.',
   '현재 필요한 조치이며 귀책 판정이 아닙니다. 수기 검토 상태만으로 부족이 해결됐다고 판단하거나 원본 수량을 바꾸지 않습니다.',
  ]};
}
const GAP_ROWS=[
 {recipient:'CENTER',ko:['WIP 필요 부품 원문','EP1-00005A / MMU TOP COVER / BRACKET HANDLE / PWR PACK FUSING FILE / FLASH PROGRRAMMING','원문의 정확한 부품코드·필요 수량을 확인하고, 자재가 아닌 작업명이라면 실제 대기 사유와 상태를 정정해 주세요.','SN/RMA, 원문, 올바른 코드·수량 또는 정정 상태','다음 주 원본 또는 같은 주 수정본'],en:['WIP Required Part text','EP1-00005A / MMU TOP COVER / BRACKET HANDLE / PWR PACK FUSING FILE / FLASH PROGRRAMMING','Please confirm the actual part code and quantity. If the text describes work rather than material, correct the waiting reason and status.','SN/RMA, original text, correct part/quantity or corrected status','Next weekly file or same-week correction']},
 {recipient:'CENTER',ko:['대시보드 누락 부품','WIP·PO에는 있으나 Component Dashboard에 없는 코드','해당 코드를 대시보드에 추가하고 현재 재고·사용량·Open PO를 확인해 주세요.','부품코드, 현재 재고, 사용량, Open PO','다음 주 원본 또는 같은 주 수정본'],en:['Parts missing from dashboard','Codes present in WIP/PO but absent from Component Dashboard','Please add the codes and verify current stock, usage and Open PO.','Part code, stock, usage, Open PO','Next weekly file or same-week correction']},
 {recipient:'CENTER',ko:['미입고 수량과 출고·입고 구분','상세 Pending·Shipped와 대시보드 Open PO의 포함 범위','센터가 실제 받은 수량과 미입고 잔량을 구분하고 각 열의 기준을 확인해 주세요.','열 정의, PO별 잔량, 확인 가능한 실제 입고일·수량','기준은 최초 확인, 수량은 주간 원본'],en:['Pending versus dispatched/received quantities','Scope of detail Pending/Shipped and dashboard Open PO','Please distinguish physical receipts from outstanding quantities and confirm each column definition.','Column definitions, remaining qty per PO, actual receipt date/qty when available','Confirm definitions once; quantities in weekly files']},
 {recipient:'CENTER',ko:['제품 식별·TAT 기준','제품별 주간 이력은 SN/RMA와 Physical Receipt Date를 사용','입고일이 실제 센터 입고일인지 확인하고 같은 수리 건의 SN/RMA를 안정적으로 유지해 주세요.','센터·사업자, SN/RMA, Physical Receipt Date, 정정 사유','기존 주간 WIP 유지'],en:['Product identity and TAT basis','Weekly history uses SN/RMA and Physical Receipt Date','Please verify the actual physical receipt date and preserve stable SN/RMA identifiers for the same repair.','Center/operator, SN/RMA, Physical Receipt Date, correction reason','Continue the existing weekly WIP']},
 {recipient:'INDIA',ko:['센터 입고 예정','ETD는 법인 예정 출고일이며 센터 도착일이 아님','공급 후속 조치 대상 PO의 실제 진행 상태와 확인 가능한 센터 입고 예정일을 알려 주세요.','센터, PO, 부품코드, 잔량, 예정 출고일·입고일(확인 시)','주간 확인 또는 일정 변경 시'],en:['Expected center receipt','ETD is planned subsidiary dispatch, not center arrival','Please share the supply status and a confirmed expected center receipt date where available.','Center, PO, part, remaining qty, dispatch/receipt dates when confirmed','Weekly follow-up or a schedule change']},
 {recipient:'INDIA',ko:['PO 열 정의·수량 불일치','상세 Pending·Shipped와 대시보드 Open PO가 다를 수 있음','Pending에 출고 후 미입고가 포함되는지와 Shipped 누계 기준을 확인하고 불일치를 설명해 주세요.','Pending·Shipped·Open PO 정의, 해당 PO별 수량 근거','최초 정의 확인 후 원본 정정'],en:['PO definitions and quantity mismatch','Detail Pending/Shipped may differ from dashboard Open PO','Please confirm whether Pending includes dispatched-but-unreceived items, the Shipped accumulation basis and any mismatches.','Pending/Shipped/Open PO definitions and quantities per affected PO','Confirm definitions once, then correct source files']},
 {recipient:'INDIA',ko:['법인→본사 요청 이력','현재 요청일·수량 자료가 없어 요청 이후 단계는 확정 불가','기존 시스템에서 요청일·요청 수량·요청번호를 제공할 수 있는지 확인해 주세요.','부품코드, 법인→본사 요청일·수량·요청번호(가능 시)','제공 가능 여부부터 확인'],en:['Subsidiary-to-HQ requests','Request date/quantity is unavailable, so the subsequent stage is unconfirmed','Please check whether existing systems can supply request dates, quantities and request references.','Part, subsidiary-to-HQ request date/quantity/reference if available','First confirm whether the data is available']},
 {recipient:'HQ',ko:['본사 재고 기준일','9/28 보고에는 9/22 재고를 참고 사용','확인 가능한 최신 재고와 실제 기준일을 제공해 주세요.','부품코드, 재고 수량, 실제 기준일','기존 주간 재고 공유'],en:['HQ inventory date','The 9/28 report uses 9/22 inventory as reference','Please provide the latest available inventory with its actual snapshot date.','Part, stock quantity, actual snapshot date','Existing weekly inventory sharing']},
 {recipient:'HQ',ko:['주요 장납 자재','L/T는 본사 PO부터 제조사 공급 후 본사 입고까지의 기간','주요 장납 부품과 기존 경험상 대략적인 L/T를 확인해 주세요. 매주 다시 입력할 필요는 없습니다.','부품코드, 예상 L/T(개월), 변경 시 수정','최초 등록 후 변경 시'],en:['Major long-lead parts','L/T runs from HQ PO placement to manufacturer delivery into HQ stock','Please identify major long-lead parts and their approximate historical lead time. Weekly re-entry is not needed.','Part, approximate L/T in months, update when changed','Initial registration and changes only']},
 {recipient:'HQ',ko:['기존 확보·구매 진행','현재 재고만으로 향후 확보 일정은 확인 불가','요청된 부족 부품에 대해 확인 가능한 기존 구매 진행과 공급 가능 수량·일정을 공유해 주세요.','부품코드, 기존 구매 진행, 확정 가능 수량·날짜(있으면)','관련 요청이 있을 때 또는 변경 시'],en:['Existing procurement and supply plans','Current stock alone does not establish future supply dates','For requested shortage parts, please share existing procurement progress and confirmed available quantities/dates where known.','Part, existing procurement progress, confirmed quantity/date if available','When a related request or change occurs']},
];
function diagnosticRecords(data){
 const records=[],visit=value=>{
  if(Array.isArray(value)){value.forEach(visit);return;}if(!value||typeof value!=='object')return;
  if(value.reason&&value.file)records.push(value);
  for(const key of ['excluded','exclusions','sourceIssues','errors','files','items','weeks'])if(value[key])visit(value[key]);
 };
 visit(data.importDiagnostics);visit(data.sourceIssues);
 for(const warning of data.issues?.warnings||[]){
  const message=typeof warning==='string'?warning:text(warning.message),match=message.match(/([^\n:]+\.(?:xlsx|xlsb|xls))\s*:\s*(INVALID_SOURCE_FILE|DATE_UNCONFIRMED|SOURCE_AFTER_REPORT_DATE)/i);
  if(match)records.push({file:match[1].trim(),reason:match[2].toUpperCase(),type:/Network Stock/i.test(match[1])?'india':/SVC.*재고|HQ/i.test(match[1])?'hq':'dashboard'});
 }
 const selected=new Set((data.sourceDates||[]).map(s=>s.file));
 return [...new Map(records.filter(r=>!(r.reason==='SOURCE_AFTER_REPORT_DATE'&&selected.has(r.file))).map(r=>[[r.file,r.reason].join('|'),r])).values()];
}
function dynamicGapRows(data){
 const result=[],issues=data.issues||{},add=(recipient,ko,en)=>result.push({recipient,ko,en});
 const clone=(index,basisKo,basisEn)=>{const original=GAP_ROWS[index];add(original.recipient,original.ko.map((x,i)=>i===1&&basisKo!==undefined?basisKo:x),original.en.map((x,i)=>i===1&&basisEn!==undefined?basisEn:x));};
 const location=item=>[item.source||item.file,item.sheet,item.row!=null?'row '+item.row:''].filter(Boolean).join(' / ');
 const unresolved=issues.unresolvedProducts||[];
 if(unresolved.length){const detail=unresolved.map(p=>[p.center,p.operator,text(p.unparsed)||text(p.required),location(p)].filter(Boolean).join(' · ')).join('\n');clone(0,detail,detail);}
 const missing=issues.missingDashboardCodes||[];
 if(missing.length){const detail=missing.map(p=>[p.center,p.part,location(p)].filter(Boolean).join(' · ')).join('\n');clone(1,detail,detail.replace(/명판/g,'Name plate'));}
 const discrepancies=issues.po||[];
 if(discrepancies.length){
  const basis=en=>discrepancies.map(p=>text(p.center)+' · '+text(p.part)+' · '+(en?'Dashboard open ':'대시보드 미입고 ')+qty(p.open,en)+' / Pending '+qty(p.detailPending,en)).join('\n');
  for(const recipient of ['CENTER','INDIA'])add(recipient,
   ['PO 미입고 수량 대조',basis(false),'대시보드 미입고와 상세 Pending의 차이를 확인하고, 법인 출고분 중 센터가 실제 받은 수량을 구분해 원본을 정정해 주세요.','부품·PO, 대시보드 미입고, Pending, Shipped, 실제 입고 수량','해당 주 원본 정정'],
   ['Reconcile open PO quantities',basis(true),'Please reconcile dashboard outstanding quantities and detail Pending. Distinguish actual center receipts from subsidiary dispatches and correct the source records.','Part/PO, dashboard open, Pending, Shipped, actual center receipts','Correct the relevant weekly files']);
 }
 const dupByRole=new Map();
 for(const d of issues.duplicates||[]){const recipient=d.type==='india'?'INDIA':d.type==='hq'?'HQ':'CENTER';if(!dupByRole.has(recipient))dupByRole.set(recipient,[]);dupByRole.get(recipient).push(d);}
 for(const [recipient,list] of dupByRole){
  const basis=en=>list.map(d=>[d.center,d.part,d.file,d.sheet,(en?'Used row ':'사용 행 ')+text(d.selectedRow),(en?'Other rows ':'중복 행 ')+(d.ignoredRows||[]).join(', ')].filter(Boolean).join(' · ')).join('\n');
  add(recipient,['중복 부품코드',basis(false),'합산하지 않고 맨 위 행을 사용했습니다. 중복 행을 확인해 해당 주 원본을 정정해 주세요.','파일·시트·행, 올바른 부품별 재고/사용량','해당 주 원본 정정'],['Duplicate part codes',basis(true),'The first row was used without summing duplicates. Please verify the duplicate rows and correct the weekly source.','File/sheet/rows, correct stock or usage per part','Correct the relevant weekly file']);
 }
 clone(3);
 const evidence=data.supplierEvidenceStatus;
 if(evidence&&evidence.reviewedRows>0&&!evidence.available)add('CENTER',
  ['Delay Cause 기재 보완',`검토한 ${evidence.reviewedRows}개 기록의 필요확인일·발주일·지연 사유에 활용 가능한 기재가 없음`,'기존 Delay Cause 시트에 실제 확인 가능한 부품 필요확인일·발주일·지연 사유를 보완해 주세요. Addeddate나 센터 입고일을 필요확인일로 대체하지 않습니다.','SN/RMA, 부품, 실제 필요확인일·발주일·사유와 근거(확인 가능한 항목만)','다음 주 원본 또는 같은 주 수정본'],
  ['Complete Delay Cause records',`No usable need-confirmation date, order date or delay reason was recorded in ${evidence.reviewedRows} reviewed records`,'Please complete the existing Delay Cause sheet with verifiable part-need dates, order dates and reasons. Addeddate and physical receipt date are not substitutes for the need-confirmation date.','SN/RMA, part, verifiable need/order dates and reason with evidence where available','Next weekly file or same-week correction']);
 if((data.tasks||[]).some(t=>t.recipient==='INDIA'))clone(4);
 clone(6,'법인→본사 요청일·수량을 부품별로 연결하는 정형 자료가 아직 제공되지 않음','Structured part-level subsidiary-to-HQ request dates/quantities have not been supplied');
 const hq=(data.sourceDates||[]).filter(s=>s.type==='hq');
 if(!hq.length||hq.some(s=>!s.date||s.carriedForward||s.date<data.asof)){
  const basis=en=>hq.length?hq.map(s=>(s.file?text(s.file)+' · ':'')+(text(s.date)||(en?'Actual date unconfirmed':'실제 기준일 미확인'))).join('\n'):(en?'No HQ inventory source supplied':'본사 재고 원본 미제공');clone(7,basis(false),basis(true));
 }
 clone(8);
 if((data.tasks||[]).some(t=>t.recipient==='HQ'))clone(9);
 for(const d of diagnosticRecords(data)){
  const recipient=d.type==='india'||/Network Stock/i.test(d.file)?'INDIA':d.type==='hq'?'HQ':'CENTER';
  if(d.reason==='INVALID_SOURCE_FILE'){
   const zero=/0x00|zero bytes|all.?zero/i.test(text(d.detail));
   add(recipient,['원본 파일 재공유',d.file+' · '+(zero?'파일 내용이 모두 0값으로 채워져 재고 데이터를 읽을 수 없음':'엑셀 내용을 읽을 수 없어 반영 제외'),'정상적으로 열리는 원본 엑셀을 다시 공유해 주세요. 이 파일을 재고 0으로 판단하지 않습니다.','정상 원본, 실제 재고 기준일','같은 주 수정본으로 반영'],['Resend source workbook',d.file+' · '+(zero?'File content consists only of zero bytes; inventory data cannot be read':'Workbook could not be read and was excluded'),'Please resend a working original workbook with its actual snapshot date. This file is not evidence of zero stock.','Working source workbook, actual inventory snapshot date','Apply as a correction to the same week']);
  }else if(d.reason==='DATE_UNCONFIRMED')add(recipient,
   ['원본 기준일 확인',d.file+' · 실제 기준일 미확인으로 반영 보류','실제 재고·대시보드 기준일을 확인해 주세요. 파일명이나 업로드일을 실제 기준일로 임의 적용하지 않습니다.','원본 파일, 실제 기준일 또는 기준일이 있는 셀','확인 후 해당 주 자료로 반영'],
   ['Confirm source snapshot date',d.file+' · Excluded pending confirmation of the actual snapshot date','Please confirm the actual inventory/dashboard snapshot date. The filename or upload date is not treated as its actual date.','Source file, actual snapshot date or the cell containing it','Apply to the relevant week after confirmation']);
  else if(d.reason==='SOURCE_AFTER_REPORT_DATE')add(recipient,
   ['보고 주 이후 원본',d.file+' · '+text(d.sourceDate)+' / 보고 주 '+text(d.reportWeek),'실제 기준일을 확인해 해당 보고 주에 쓸 수 있는 자료인지 확인해 주세요. 이후 자료를 과거 보고 주에 소급 반영하지 않습니다.','원본 기준일, 적용할 보고 주','기준일 확인 후 반영'],
   ['Source dated after report week',d.file+' · '+text(d.sourceDate)+' / report week '+text(d.reportWeek),'Please verify the actual source date and applicable report week. Later observations are not backfilled as earlier-week facts.','Actual source date, applicable report week','Apply after date confirmation']);
 }
 return result;
}
function buildGapTable({data,recipient='ALL',language='ko'}={}){
 const en=english(language),target=role(recipient),columns=[...(target==='ALL'?[{key:'recipient',label:en?'Requested from':'확인 대상'}]:[]),
  {key:'item',label:en?'Item':'확인 항목'},{key:'basis',label:en?'Current information':'현재 확인된 내용'},
  {key:'request',label:en?'Request':'확인 요청 내용'},{key:'fields',label:en?'Information needed':'필요 정보'},{key:'when',label:en?'Update timing':'반영 시점'}];
 const dynamic=!!data,gaps=dynamic?dynamicGapRows(data):GAP_ROWS;
 return {subject:en?`Repair-parts data clarification · ${label(target,true)}`:`수리 자재 자료 보완 요청 · ${label(target,false)}`,recipientLabel:label(target,en),
  context:dynamic?((en?'Report date: ':'보고 기준일: ')+(text(data.asof)||(en?'Unconfirmed':'미확인'))+'\n'+(en?'Current source issues and information still needed. These are clarification requests, not findings of fault.':'현재 원본의 문제와 미제공 정보를 정리했습니다. 사실 확인·자료 보완 요청이며 귀책 지적이 아닙니다.')):(en?'Open information requests for the 9/28 example. These are clarification requests, not findings of fault.':'9/28 예시 기준의 미확인 사항입니다. 사실 확인·자료 보완 요청이며 귀책 지적이 아닙니다.'),columns,
  rows:gaps.filter(item=>target==='ALL'||item.recipient===target).map(item=>[...(target==='ALL'?[label(item.recipient,en)]:[]),...item[en?'en':'ko']]),
  notes:en?['Use existing weekly files and available records. Daily input is not required.','If information is unavailable, please identify what can be supplied; unknown dates or quantities must not be invented.',dynamic?'Any listed WIP text is from current unresolved source records, not a confirmed part-code correction. The app does not invent missing codes.':'The WIP strings are original examples from the 9/28 review, not confirmed material codes. The app does not automatically correct them.']:
   ['기존 주간 파일과 제공 가능한 기록을 우선 활용합니다. 매일 입력할 필요는 없습니다.','자료가 없으면 제공 가능한 범위부터 확인하며, 날짜·수량을 추정해 확정값으로 넣지 않습니다.',dynamic?'WIP 원문은 현재 미해석 기록이며 확정된 정정 부품코드가 아닙니다. 프로그램이 임의로 코드를 바꾸지 않습니다.':'WIP 원문은 9/28 검토에서 확인한 예시이며 확정 부품코드 목록이 아닙니다. 프로그램이 임의로 올바른 코드로 고치지 않습니다.']};
}
function buildWaitingTable({data={},products=[],language='ko'}={}){
 const en=english(language),labels=en?['Center / Operator','SN / RMA','Physical receipt date','WIP date','TAT (days)','Required parts / qty','Current actions']:['센터 / 사업자','SN / RMA','실제 입고일','WIP 기준일','TAT(일)','필요 부품 / 수량','현재 조치'];
 const columns=['center','identity','receipt','date','age','parts','actions'].map((key,i)=>({key,label:labels[i]}));
 const rows=products.map(p=>{
  const ids=new Set((p.parts||[]).map(item=>p.center+'|'+item.part));
  const actions=unique((data.tasks||[]).filter(t=>ids.has(t.rowId)).map(t=>label(t.recipient,en)+': '+selectText(t,'text',en)));
  const parts=(p.parts||[]).map(item=>(en&&item.part==='명판'?'Name plate':text(item.part))+' × '+qty(item.quantity,en));
  if(p.unparsed)parts.push('Alert: '+text(p.unparsed));
  return [p.center+' / '+(p.operator==='Vi'?'Vodafone Idea':p.operator),[p.sn,p.rma].filter(Boolean).join(' / '),p.receipt||'',p.date||'',p.age??'',parts.join('\n'),actions.join('\n')];
 });
 return {subject:en?'Parts-waiting products':'자재대기 제품',context:(en?'Report date: ':'보고 기준일: ')+text(data.asof),columns,rows,productCount:products.length,notes:en?['Each row is one product. Parts quantities may exceed the product count. TAT uses each original WIP date.','Actions are shared center/part follow-ups; they do not allocate a specific PO to a product.']:['한 행은 제품 1대입니다. 필요 부품 개수는 제품 대수와 다를 수 있으며 TAT는 각 WIP 원본 기준일로 계산합니다.','조치는 센터·부품 기준의 공통 업무이며 특정 PO를 해당 제품에 배정한 결과가 아닙니다.']};
}
function escapeHtml(value){return text(value).replace(/[&<>"']/g,char=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));}
function htmlLines(value){return escapeHtml(value).replace(/\r\n|\r|\n/g,'<br>');}
function toHtml(model={}){
 const columns=model.columns||[],rows=model.rows||[],cell='border:1px solid #cfd8e1;padding:6px 7px;vertical-align:top;text-align:left;line-height:1.4;';
 return '<div style="font-family:Arial,Malgun Gothic,sans-serif;font-size:11px;color:#1c2c3a;line-height:1.5;max-width:1200px">'+
  '<p style="font-size:15px;font-weight:bold;margin:0 0 8px">'+htmlLines(model.subject)+'</p>'+
  '<p style="margin:0 0 10px;color:#42576a">'+htmlLines(model.context)+'</p>'+
  '<table style="border-collapse:collapse;width:100%;table-layout:auto;font-size:11px"><thead><tr>'+columns.map(column=>'<th style="'+cell+'background:#edf3f8;font-weight:bold">'+htmlLines(column.label)+'</th>').join('')+'</tr></thead><tbody>'+
  rows.map(row=>'<tr>'+columns.map((column,index)=>'<td style="'+cell+(new Set(['needed','shortage','open','proposed','over45']).has(column.key)?'white-space:nowrap;text-align:right;':'overflow-wrap:anywhere;')+'">'+htmlLines(row[index])+'</td>').join('')+'</tr>').join('')+
  '</tbody></table><ul style="margin:10px 0 0;padding-left:18px;font-size:10px;color:#526476">'+(model.notes||[]).map(note=>'<li>'+htmlLines(note)+'</li>').join('')+'</ul></div>';
}
function csvCell(value){
 let content=text(value);
 // Prefix all formula-like strings, including hidden leading whitespace.
 if(/^[\t\r\n]/.test(content)||/^[\s\uFEFF]*[=+\-@]/.test(content))content="'"+content;
 return '"'+content.replace(/"/g,'""')+'"';
}
function toCsv(model={}){return '\uFEFF'+[(model.columns||[]).map(column=>column.label),...(model.rows||[])].map(row=>row.map(csvCell).join(',')).join('\r\n');}
function toText(model={}){
 const flatten=value=>text(value).replace(/\t/g,' ').replace(/\r\n|\r|\n/g,' / ');
 return [text(model.subject),text(model.context),'',[(model.columns||[]).map(column=>column.label),...(model.rows||[])].map(row=>row.map(flatten).join('\t')).join('\n'),'',...(model.notes||[]).map(note=>'• '+text(note))].join('\n');
}
return {confirmedProgress,buildActionTable,buildGapTable,buildWaitingTable,formatPoEvidence,toHtml,toCsv,toText};
});
