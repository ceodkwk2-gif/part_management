(function(root,factory){if(typeof module==='object'&&module.exports)module.exports=factory(require('./core.js'),require('./reporting.js'),require('./pipeline.js'));else root.PartsWeeklyPolicy=factory(root.PartsCore,root.PartsReporting,root.PartsPipeline)})(typeof self!=='undefined'?self:this,function(C,R,P){
'use strict';
const required=P.SLOTS.filter(s=>s.type==='wip');
function bind(sources,reportDate){const week=R.weekStart(reportDate);return sources.map(s=>({...s,assignedWeek:week}));}
function enforce(plan,state,sources,reportDate){
 const week=R.weekStart(reportDate),saved=R.reports(state).find(r=>r.id===week),errors=[];
 for(const slot of required){const row=plan.rows.find(r=>r.key===slot.key),incoming=sources.filter(s=>P.slotKey(s)===slot.key),own=saved?.ownSourceSlots?.includes(['wip',slot.center,slot.operator].join('|'));
  if(!row?.source||!R.validDate(row.source.date)||row.status==='excluded'||(!(incoming.length&&row.source.assignedWeek===week)&&!(saved&&own)))errors.push(slot.label+': 이 주차 WIP 필수 · 이전 주 자동 대체 불가');
  if(incoming.some(s=>(s.sheetAudit||[]).some(a=>a.reviewRequired)))errors.push(slot.label+': 읽지 못한 WIP 상세 시트가 있습니다.');
 }
 for(const s of sources)if(s.date&&R.weekStart(s.date)!==week)plan.warnings.push((P.SLOTS.find(x=>x.key===P.slotKey(s))?.label||s.type)+': '+week+'주에 '+s.date+' 자료 사용 · 원본 날짜 유지');
 plan.errors=[...new Set([...plan.errors,...errors])];plan.ok=!plan.errors.length;plan.canApply=plan.canApply&&plan.ok;plan.canRecordExisting=false;plan.recordExistingReason='새 주차에는 WIP 4종을 모두 지정해야 합니다.';return plan;
}
function assertWipPreserved(state,reportId){const entry=R.reports(state).find(r=>r.id===reportId);if(entry?.uploadPolicy!=='slots-v160')return;const sources=R.reportState(state,reportId).sources;for(const slot of required)if(!entry.ownSourceSlots?.includes(['wip',slot.center,slot.operator].join('|'))||!sources.some(s=>P.slotKey(s)===slot.key))throw Error('WIP 4종은 필수입니다. WIP를 교체하거나 이번 실행 전체를 되돌리세요.');}
function guardLegacyCommit(before,after,operation){
 if(operation==='restore')return;
 const prior=new Map(R.reports(before).map(r=>[r.id,r]));
 for(const entry of R.reports(after)){const old=prior.get(entry.id);if(old&&old.uploadPolicy!=='slots-v160')continue;
  const sources=R.reportState(after,entry.id).sources;
  for(const slot of required){const source=sources.find(s=>P.slotKey(s)===slot.key);if(!source||!R.validDate(source.date)||!entry.ownSourceSlots?.includes(['wip',slot.center,slot.operator].join('|'))||(!old&&(source.assignedWeek||R.weekStart(source.date))!==entry.id))throw Error('새 주차 WIP 4종이 필요합니다. 업로드 화면에서 각 칸에 지정한 뒤 실행하세요.');}
 }
}
return {bind,enforce,assertWipPreserved,guardLegacyCommit,required};
});
