(function(root,factory){
 if(typeof module==='object'&&module.exports)module.exports=factory();
 else root.PartsFirstConfirmedPanel=factory();
})(typeof self!=='undefined'?self:this,function(){
'use strict';
// Presentation only. Dates are committed through the server's firstConfirmed
// operation; this panel never edits source rows, inventory or product TAT.
const esc=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const str=value=>String(value??'').trim(),norm=value=>str(value).toUpperCase();
const valid=value=>typeof value==='string'&&/^\d{4}-\d{2}-\d{2}$/.test(value)&&!Number.isNaN(Date.parse(value+'T00:00:00Z'))&&new Date(value+'T00:00:00Z').toISOString().slice(0,10)===value;
const numeric=value=>typeof value==='number'&&Number.isFinite(value);
function entriesFor(options){return options.entries||options.data?.firstConfirmedEntries||[];}
function buildModel(options={}){
 const entries=entriesFor(options),search=norm(options.search),mode=['MANUAL','CONFLICT','UNRECORDED'].includes(options.mode)?options.mode:'ALL',seen=new Set();
 const all=entries.filter(entry=>{if(!str(entry.key)||seen.has(entry.key))return false;seen.add(entry.key);return true;});
 const rows=all.filter(entry=>(!search||norm([entry.part,entry.center,entry.operator,entry.sn,entry.rma].join(' ')).includes(search))&&(mode!=='MANUAL'||valid(entry.manualFirstConfirmedDate))&&(mode!=='CONFLICT'||entry.firstConfirmedConflict===true)&&(mode!=='UNRECORDED'||!valid(entry.manualFirstConfirmedDate)))
  .sort((a,b)=>Number(b.firstConfirmedConflict===true)-Number(a.firstConfirmedConflict===true)||(numeric(b.currentAgeDays)?b.currentAgeDays:-1)-(numeric(a.currentAgeDays)?a.currentAgeDays:-1)||str(a.part).localeCompare(str(b.part))||str(a.center).localeCompare(str(b.center))||str(a.sn).localeCompare(str(b.sn)));
 const pageSize=Math.max(1,Math.min(50,Math.floor(Number(options.pageSize)||25))),pages=Math.max(1,Math.ceil(rows.length/pageSize)),page=Math.max(1,Math.min(pages,Math.floor(Number(options.page)||1)));
 return {all,rows,visible:rows.slice((page-1)*pageSize,page*pageSize),page,pages,pageSize,search:str(options.search),mode,manualCount:all.filter(e=>valid(e.manualFirstConfirmedDate)).length,conflictCount:all.filter(e=>e.firstConfirmedConflict===true).length};
}
function validation(entry,date,note='',language='ko'){
 const en=language==='en',t=(ko,eng)=>en?eng:ko;
 if(date===null)return '';
 if(entry?.manualEditable!==true)return t('제품 식별정보·입고일·WIP 기준일을 확인한 뒤 입력할 수 있습니다.','Verify product identity, receipt date and WIP date before editing.');
 if(!valid(date))return t('유효한 최초 부품대기 확인일을 입력하세요.','Enter a valid first-confirmed date.');
 if(valid(entry.receipt)&&date<entry.receipt)return t('제품 입고일보다 앞선 날짜는 입력할 수 없습니다.','The date cannot precede product receipt.');
 if(valid(entry.date)&&date>entry.date)return t('현재 WIP 기준일보다 늦은 날짜는 입력할 수 없습니다.','The date cannot be later than the current WIP date.');
 if(str(note).length>2000)return t('메모는 2,000자 이내로 입력하세요.','Keep the note within 2,000 characters.');
 return '';
}
function render(options={}){
 const m=buildModel(options),en=options.language==='en',t=(ko,eng)=>en?eng:ko,readOnly=options.readOnly===true,busy=options.saving===true,fmt=value=>valid(value)?value:'—';
 const nameMap=new Map((options.data?.rows||[]).map(row=>[row.part,row.name]));
 const records=m.visible.map(entry=>{
  const editable=!readOnly&&!busy&&entry.manualEditable===true,manual=valid(entry.manualFirstConfirmedDate),appliedManual=entry.firstConfirmedSource==='manual',effective=entry.effectiveFirstSeenDate||entry.firstSeenDate,warning=entry.firstConfirmedConflict===true;
  const key=esc(entry.key),label=[entry.center,entry.operator,entry.sn||entry.rma,entry.part].filter(Boolean).join(' · '),name=nameMap.get(entry.part)||'',draft=options.drafts?.[entry.key],drafted=!!draft,inputDate=drafted?str(draft.date):(manual?entry.manualFirstConfirmedDate:''),inputNote=drafted?String(draft.note??''):String(entry.manualFirstConfirmedNote||'');
  const edit=readOnly?`<b>${esc(fmt(entry.manualFirstConfirmedDate))}</b>${entry.manualFirstConfirmedNote?`<small>${esc(entry.manualFirstConfirmedNote)}</small>`:''}`:
   `<label class="fc-sr-only" for="fc-date-${m.visible.indexOf(entry)}">${esc(label+' '+t('수기 최초 부품대기 확인일','manual first-confirmed date'))}</label><input id="fc-date-${m.visible.indexOf(entry)}" class="fc-date" data-fc-date type="date" value="${esc(inputDate)}" ${valid(entry.receipt)?`min="${esc(entry.receipt)}"`:''} ${valid(entry.date)?`max="${esc(entry.date)}"`:''} ${editable?'':'disabled'}><input data-fc-note class="fc-note" type="text" maxlength="2000" value="${esc(inputNote)}" placeholder="${t('근거 메모 (선택)','Evidence note (optional)')}" aria-label="${esc(label+' '+t('근거 메모','evidence note'))}" ${editable?'':'disabled'}>`;
  return `<tr data-fc-key="${key}" class="${warning?'fc-conflict':''}"><td data-label="${t('부품','Part')}"><b class="fc-code">${esc(entry.part)}</b>${name?`<small>${esc(name)}</small>`:''}</td><td data-label="${t('센터 · 사업자','Center · operator')}"><b>${esc(entry.center)}</b><small>${esc(entry.operator||'—')}</small></td><td data-label="${t('제품','Product')}"><span class="fc-id"><span>SN</span><b>${esc(entry.sn||'—')}</b></span><span class="fc-id"><span>RMA</span><b>${esc(entry.rma||'—')}</b></span></td><td class="fc-date-cell" data-label="${t('제품 입고','Product receipt')}"><b>${esc(fmt(entry.receipt))}</b><small>${numeric(entry.currentAgeDays)?'TAT '+entry.currentAgeDays+t('일',' days'):'TAT —'}</small></td><td class="fc-date-cell" data-label="${t('WIP 최초확인','First WIP observation')}"><b>${esc(fmt(entry.firstSeenDate))}</b><small>WIP ${esc(fmt(entry.date))}</small></td><td data-label="${t('수기 최초 부품대기 확인일','Manual first-confirmed date')}">${edit}</td><td data-label="${t('적용 · 저장','Applied · save')}"><div class="fc-applied"><b>${esc(fmt(effective))}</b><span class="fc-badge ${appliedManual?'fc-manual':''}">${t(appliedManual?'수기 확인':'자동 관찰',appliedManual?'Manual':'Automatic')}</span></div>${warning?`<p class="fc-warning">${t('날짜 확인 필요 · 더 이른 WIP 관찰 또는 이력 충돌','Review date · Earlier WIP evidence or history conflict')}</p>`:''}${!readOnly?`<div class="fc-row-actions"><button class="button primary" type="button" data-fc-save ${editable?'':'disabled'}>${t('저장','Save')}</button><button class="button" type="button" data-fc-clear ${!busy&&(manual||editable&&drafted)?'':'disabled'}>${t('자동으로 복귀','Use automatic')}</button></div>`:''}${!entry.manualEditable&&!readOnly?`<small>${t('제품 식별정보 또는 날짜 확인 필요','Verify product identity or dates')}</small>`:''}<p class="fc-row-status" role="status" aria-live="polite">${drafted?t('미저장','Unsaved'):''}</p></td></tr>`;
 }).join('');
 return `<section class="fc-panel" aria-label="${t('최초 부품대기 확인일 관리','First-confirmed dates')}"><div class="fc-heading"><div><h2>${t('최초 부품대기 확인일','First-confirmed dates')}</h2><p>${t('확인한 과거 날짜를 제품·부품별로 입력하면 대기 이력에 자동 반영됩니다. 재고·수량·제품 TAT는 바뀌지 않습니다.','Enter a verified date for each product and part. It updates waiting history, without changing stock, quantities or product TAT.')}</p></div><div class="fc-counts">${t('수기 입력 ','Manual ')}<b>${m.manualCount}</b> · ${t('날짜 확인 ','Review ')}<b>${m.conflictCount}</b></div></div>${readOnly?`<p class="fc-readonly">${t('현재 결과 조회본입니다. 날짜 입력·수정은 운영 주소에서 가능합니다.','This is a results viewer. Enter or edit dates at the operating server address.')}</p>`:''}<div class="fc-toolbar"><label>${t('제품·부품 검색','Search product / part')}<input type="search" data-fc-search value="${esc(m.search)}" placeholder="${t('부품 코드 · SN · RMA · 센터','Part code · SN · RMA · center')}" ${busy?'disabled':''}></label><label>${t('보기','View')}<select data-fc-mode ${busy?'disabled':''}><option value="ALL" ${m.mode==='ALL'?'selected':''}>${t('전체','All')}</option><option value="MANUAL" ${m.mode==='MANUAL'?'selected':''}>${t('수기 입력','Manual dates')}</option><option value="UNRECORDED" ${m.mode==='UNRECORDED'?'selected':''}>${t('수기 미입력','No manual date')}</option><option value="CONFLICT" ${m.mode==='CONFLICT'?'selected':''}>${t('날짜 확인 필요','Review dates')}</option></select></label><span>${m.rows.length}${t('건 · 제품별 부품대기 기록',' records · Product-level parts waits')}</span></div>${!readOnly?`<p><button type="button" class="button" data-fc-bulk>${t('일괄 입력 · 양식','Bulk entry / template')}</button></p>`:''}<div class="fc-table-wrap"><table class="fc-table"><colgroup><col class="fc-col-part"><col class="fc-col-center"><col class="fc-col-product"><col class="fc-col-date"><col class="fc-col-date"><col class="fc-col-edit"><col class="fc-col-action"></colgroup><thead><tr>${[t('부품','Part'),t('센터 · 사업자','Center · operator'),t('제품 SN · RMA','Product SN · RMA'),t('제품 입고','Product receipt'),t('WIP 최초확인','First WIP observation'),t('수기 최초 부품대기 확인일','Manual first-confirmed date'),t('적용 · 저장','Applied · save')].map(text=>`<th>${text}</th>`).join('')}</tr></thead><tbody>${records||`<tr><td colspan="7" class="fc-empty">${m.all.length?t('검색 조건에 맞는 제품이 없습니다.','No products match the search.'):t('WIP를 반영하면 현재 자재대기 제품이 여기에 표시됩니다.','Current parts-waiting products appear here after WIP is applied.')}</td></tr>`}</tbody></table></div><div class="fc-footer"><span>${t('최초 부품대기 확인일은 실제 대기 시작일을 자동 확정하지 않습니다.','A first-confirmed date does not automatically establish the actual start of waiting.')}</span><div class="fc-pagination"><button type="button" class="button" data-fc-page="${m.page-1}" ${m.page<=1||busy?'disabled':''}>${t('이전','Previous')}</button><b>${m.page} / ${m.pages}</b><button type="button" class="button" data-fc-page="${m.page+1}" ${m.page>=m.pages||busy?'disabled':''}>${t('다음','Next')}</button></div></div></section>`;
}
function bind(container,handlers={},options={}){
 if(!container?.querySelectorAll)return;
 const rows=new Map(entriesFor(options).map(entry=>[entry.key,entry])),language=options.language||'ko',en=language==='en',t=(ko,eng)=>en?eng:ko;
 const search=container.querySelector('[data-fc-search]'),mode=container.querySelector('[data-fc-mode]');
 if(search)search.onchange=()=>handlers.onFilter?.({search:search.value,page:1});
 if(mode)mode.onchange=()=>handlers.onFilter?.({mode:mode.value,page:1});
 for(const button of container.querySelectorAll('[data-fc-page]'))button.onclick=()=>handlers.onPage?.(Number(button.dataset.fcPage));
 for(const row of container.querySelectorAll('[data-fc-key]')){
  const key=row.getAttribute('data-fc-key'),entry=rows.get(key),input=row.querySelector('[data-fc-date]'),note=row.querySelector('[data-fc-note]'),status=row.querySelector('.fc-row-status'),save=row.querySelector('[data-fc-save]'),clear=row.querySelector('[data-fc-clear]');let pending=false;
  const submit=async remove=>{
   if(pending||options.readOnly||options.saving||!entry)return;
   const date=remove?null:input?.value||'',memo=remove?'':note?.value||'',error=validation(entry,date,memo,language);
   if(error){if(status){status.textContent=error;status.classList.add('fc-error')}return;}
   if(typeof handlers.onSave!=='function'){if(status){status.textContent=t('저장 기능에 연결되지 않았습니다. 운영 주소에서 다시 여세요.','Saving is unavailable. Reopen at the operating server address.');status.classList.add('fc-error')}return;}
   pending=true;const controls=[save,clear,input,note].filter(Boolean),disabled=controls.map(el=>el.disabled);controls.forEach(el=>el.disabled=true);
   if(status){status.textContent=t('저장 중…','Saving…');status.classList.remove('fc-error');}
   try{await handlers.onSave({changes:[{key,date,note:memo}]});if(status)status.textContent=t(remove?'자동 관찰일로 복귀했습니다.':'저장 완료 · 대기 이력 반영됨',remove?'Restored the automatic observation date.':'Saved · Waiting history updated');handlers.onSaved?.({key,date});}
   catch(error){if(status){status.textContent=error?.message||t('저장하지 못했습니다. 다시 시도하세요.','Could not save. Try again.');status.classList.add('fc-error')}handlers.onError?.(error);}
   finally{pending=false;controls.forEach((el,i)=>{el.disabled=disabled[i]});}
  };
  const changed=()=>{const date=input?.value||'',memo=note?.value||'',dirty=date!==(entry?.manualFirstConfirmedDate||'')||memo!==(entry?.manualFirstConfirmedNote||'');if(status){status.textContent=dirty?t('미저장','Unsaved'):'';status.classList.remove('fc-error')}if(clear)clear.disabled=options.saving===true||(!valid(entry?.manualFirstConfirmedDate)&&(entry?.manualEditable!==true||!dirty));handlers.onDirty?.({key,date,note:memo,dirty});};
  if(input)input.oninput=changed;if(note)note.oninput=changed;
  if(save)save.onclick=()=>submit(false);
  if(clear)clear.onclick=()=>submit(true);
  if(input)input.onkeydown=event=>{if(event.key==='Enter'){event.preventDefault();submit(false)}};
 }
}
return {buildModel,validation,render,bind};
});
