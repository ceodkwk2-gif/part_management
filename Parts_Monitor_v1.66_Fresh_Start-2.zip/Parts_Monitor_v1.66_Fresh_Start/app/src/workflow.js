(function(root,factory){
 if(typeof module==='object'&&module.exports)module.exports=factory(()=>require('./action-requests.js'));
 else root.PartsWorkflow=factory(()=>root.PartsActionRequests);
})(typeof self!=='undefined'?self:this,function(statusAPI){
'use strict';
// Shared presentation and validation. Confirmed follow-ups never change source
// inventory, PO quantities, observed waiting status or product TAT.
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const num=v=>typeof v==='number'&&Number.isFinite(v),n=v=>num(v)?v.toLocaleString('en-US'):'—';
const t=(l,a,b)=>l==='en'?b:a;
const validDate=v=>typeof v==='string'&&/^\d{4}-\d{2}-\d{2}$/.test(v)&&Number.isFinite(Date.parse(v+'T00:00:00Z'))&&new Date(v+'T00:00:00Z').toISOString().slice(0,10)===v;
const today=()=>new Date().toLocaleDateString('en-CA',{timeZone:'Asia/Seoul'});
const statuses={OPEN:['확인 전','Not checked'],REQUESTED:['요청 완료','Requested'],WAITING:['회신 대기','Awaiting reply'],CONFIRMED:['일정 확인','Schedule confirmed'],SHIPPED:['출고 확인','Dispatch confirmed'],RECEIVED:['입고 확인','Receipt confirmed'],CLOSED:['후속 업무 종료','Follow-up closed']};
const teams={CENTER:['수리센터','Repair center'],INDIA:['법인','India'],HQ:['본사','HQ'],JOINT:['법인·본사','India / HQ']};
const statusLabel=(value,l)=>statuses[value]?.[l==='en'?1:0]||t(l,'미기록','Not recorded');
const noteFields=['eta','plan','ownerTeam','owner','due','status','checkedOn','etaBasis','editor','poRef','allocatedQty','receivedQty','receivedDate','receiptLocation','evidence'];
function validateNote(input){
 if(!input||typeof input!=='object'||Array.isArray(input))throw Error('조치 기록 형식을 확인하세요.');
 const out={};for(const field of noteFields){const value=input[field];if(value==null||value===''){out[field]=field.endsWith('Qty')?null:'';continue;}if(field.endsWith('Qty')){const q=Number(value);if(!Number.isSafeInteger(q)||q<0)throw Error('확인 수량은 0 이상의 정수여야 합니다.');out[field]=q;}else{if(typeof value!=='string'||value.length>(['plan','evidence'].includes(field)?4000:500))throw Error('입력 내용의 길이·형식을 확인하세요.');out[field]=value.trim();}}
 for(const field of ['eta','due','checkedOn','receivedDate'])if(out[field]&&!validDate(out[field]))throw Error('유효한 날짜를 입력하세요.');
 if(out.status&&!statuses[out.status])throw Error('조치 상태를 확인하세요.');
 if(out.ownerTeam&&!teams[out.ownerTeam])throw Error('담당 조직을 확인하세요.');
 if(!out.editor)throw Error('변경 기록을 남길 작성자를 입력하세요.');
 if(out.eta&&!out.etaBasis)throw Error('센터 입고 ETA의 확인 근거를 입력하세요.');
 if(out.status==='CONFIRMED'&&!(out.eta&&out.etaBasis))throw Error('일정 확인에는 센터 입고 ETA와 확인 근거가 필요합니다.');
 if(out.status==='SHIPPED'&&!(out.checkedOn&&out.evidence))throw Error('출고 확인에는 확인일과 출고 근거가 필요합니다.');
 if(out.status==='RECEIVED'&&!(out.receivedQty>0&&out.receivedDate&&out.receiptLocation&&out.evidence))throw Error('입고 확인에는 실제 수량·입고일·입고 장소·근거가 필요합니다.');
 if(out.status==='CLOSED'&&!out.evidence)throw Error('후속 업무 종료 근거를 입력하세요.');
 if(out.allocatedQty!==null&&!out.evidence)throw Error('센터 배정 수량의 확인 근거를 입력하세요.');
 if(out.receivedQty!==null&&!(out.receivedDate&&out.receiptLocation&&out.evidence))throw Error('실제 입고 수량에는 입고일·장소·근거가 필요합니다.');
 return out;
}
function orderTotals(data,center='ALL'){
 const rows=(data.rows||[]).filter(r=>center==='ALL'||center==='전체'||r.center===center),short=new Set(rows.filter(r=>r.shortage>0).map(r=>r.part));
 const orders=rows.filter(r=>r.proposed>0),repair=orders.filter(r=>short.has(r.part)),buffer=orders.filter(r=>!short.has(r.part));
 const count=xs=>({parts:new Set(xs.map(r=>r.part)).size,quantity:xs.reduce((s,r)=>s+r.proposed,0)});
 return {all:count(orders),repair:count(repair),buffer:count(buffer),unknown:rows.filter(r=>!num(r.proposed)||r.orderAssessed===false).length};
}
function freshness(data,date=today()){
 const age=validDate(data.asof)&&validDate(date)?Math.max(0,Math.round((Date.parse(date)-Date.parse(data.asof))/86400000)):null;
 return {age,carried:(data.sourceDates||[]).filter(s=>s.carriedForward||!!data.week&&(s.date||s.reportWeek||data.week)<data.week),undated:(data.sourceDates||[]).filter(s=>!s.date)};
}
const issueLabels={po:['PO 수량 차이','PO quantity difference'],missingDashboardCodes:['대시보드 누락 코드','Missing dashboard code'],unresolvedProducts:['부품 표기 확인','Unparsed required part'],duplicates:['중복 원본 행','Duplicate source rows'],carriedSources:['이전 자료 참고','Previous source reference'],warnings:['자료 알림','Source notice']};
function qualityItems(data){return Object.entries(data.issues||{}).flatMap(([kind,items])=>Array.isArray(items)?items.map(x=>({kind,value:x,id:JSON.stringify([kind,typeof x==='string'?x:{type:x.type,identity:x.id,operator:x.operator,selectedRow:x.selectedRow,ignoredRows:x.ignoredRows,center:x.center,part:x.part,file:x.file||x.source,sheet:x.sheet,row:x.row,date:x.date||x.reportWeek,open:x.open,detailPending:x.detailPending,required:x.required||x.unparsed,message:x.message||x.reason}])})):[]);}
function issueText(item,l){const x=item.value;if(typeof x==='string')return x;return [x.center,x.operator,x.part,x.file||x.source,x.sheet,x.selectedRow!=null?t(l,'적용 행 ','selected row ')+x.selectedRow:'',x.ignoredRows?.length?t(l,'중복 행 ','duplicate rows ')+x.ignoredRows.join(', '):'',x.row!=null?t(l,'행 ','row ')+x.row:'',x.required||x.unparsed,x.date||x.reportWeek,item.kind==='po'?t(l,'적용 미입고 ','Open used ')+n(x.open)+' / Pending '+n(x.detailPending):'',x.message||x.reason].filter(Boolean).join(' · ');}
function noteSummary(note={},l='ko'){
 return [statusLabel(note.status,l),[teams[note.ownerTeam]?.[l==='en'?1:0],note.owner].filter(Boolean).join(' / '),note.due?t(l,'기한 ','Due ')+note.due:'',note.checkedOn?t(l,'확인 ','Checked ')+note.checkedOn:'',note.eta?'ETA '+note.eta:''].filter(Boolean).join(' · ');
}
function progressLines(note={},l='ko'){
 const legacy={IN_PROGRESS:['확인중','In progress'],DONE:['확인완료','Confirmed']},label=legacy[note.status]?.[l==='en'?1:0]||statusLabel(note.status,l);
 const lines=[];if(note.status)lines.push(t(l,'진행: ','Progress: ')+label);
 for(const [key,ko,en] of [['owner','담당자','Owner'],['due','다음 조치 기한','Next action due'],['checkedOn','확인일','Verified on'],['etaBasis','ETA 근거','ETA evidence'],['poRef','연결 PO·문서','Related PO / document'],['allocatedQty','확인된 센터 배정 수량','Verified center allocation'],['receivedQty','확인된 실제 입고 수량','Verified received quantity'],['receivedDate','실제 입고일','Actual receipt date'],['receiptLocation','입고 장소','Receipt location'],['evidence','확인 근거','Evidence']])if(note[key]!==null&&note[key]!==undefined&&note[key]!=='')lines.push(t(l,ko,en)+': '+note[key]);
 return lines;
}
function freshnessHTML(data,l='ko'){
 const f=freshness(data),labels={dashboard:t(l,'센터 재고','Center stock'),wip:'WIP',po:'PO',india:t(l,'법인 재고','India stock'),hq:t(l,'본사 재고','HQ stock'),siel:'SIEL'};
 return '<section class="wf-freshness"><div><b>'+t(l,'보고 기준 ','Report as of ')+esc(data.asof||'—')+'</b> <span>'+ (f.age!==null?t(l,'오늘 기준 '+f.age+'일 전 자료','Snapshot is '+f.age+' days old'):'')+'</span>'+ (f.carried.length?' · '+t(l,'이전 자료 참고 ','Prior-source references ')+f.carried.length:'')+'</div><div class="wf-source-chips">'+(data.sourceDates||[]).map(s=>'<span class="'+(s.carriedForward||!!data.week&&(s.date||s.reportWeek||data.week)<data.week?'wf-reference':'')+'">'+esc([s.center,s.operator,labels[s.type]||s.type].filter(Boolean).join(' '))+' <b>'+esc(s.date||(s.reportWeek?s.reportWeek+t(l,'주 · 실제일 미확인',' week · exact date unknown'):t(l,'날짜 미확인','date unknown')))+'</b>'+(s.demo?' '+t(l,'데모 · 보고주 '+data.week,'demo · report week '+data.week):'')+(s.carriedForward||!!data.week&&(s.date||s.reportWeek||data.week)<data.week?' '+t(l,'참고','reference'):'')+'</span>').join('')+'</div><small>'+t(l,'제품 TAT는 각 WIP 기준일로 계산합니다. 과거 추이도 현재 운영 설정으로 재계산됩니다.','Product TAT uses each WIP date. Historical trends are recalculated using the current operating settings.')+'</small></section>';
}
function insightsHTML(data,center,l='ko'){
 const m=orderTotals(data,center),changed=data.trend?.at(-1)?.observedWaitingChanges?.[center==='ALL'?'전체':center];
 const display=x=>n(x.parts)+t(l,'종 · ',' kinds · ')+n(x.quantity)+t(l,'개',' pcs');
 const warning=m.unknown?t(l,' · 수량 미산정 '+m.unknown+'행 별도',' · '+m.unknown+' rows have unassessed quantities'):'';
 return '<div class="wf-order-total"><b>'+t(l,'전체 추가 PO 필요','All additional PO needed')+' '+display(m.all)+'</b><span>'+t(l,'수리분 부족군에 속한 부품 ','Parts in repair-shortage group ')+display(m.repair)+' / '+t(l,'보유분 확보군 ','Buffer group ')+display(m.buffer)+'</span><small>'+t(l,'카드는 고유 부품별로 한 번 분류합니다. 위 총량은 모든 센터의 추가 발주 업무를 합산하며 수리용·보유분을 함께 포함합니다.','Cards classify each unique part once. This workload total sums additional orders across centers, including repair and buffer demand.')+warning+'</small><button data-wf-orders>'+t(l,'전체 추가 PO 목록','All additional PO rows')+'</button></div>'+(changed?.available?'<div class="wf-changes"><b>'+t(l,'직전 보고와 WIP 관찰 비교','WIP observations vs previous report')+'</b><span>'+esc(changed.reason||'')+'</span>'+Object.entries(changed).filter(([k,v])=>num(v)&&!['reportGapDays'].includes(k)).map(([k,v])=>'<span>'+esc(({newProducts:t(l,'새로 관찰','Newly observed'),continuingProducts:t(l,'계속 관찰 제품','Still observed products'),notListedProducts:t(l,'자료에서 사라진 제품','Products no longer listed'),newPartNeeds:t(l,'새로 관찰된 제품·부품','New product / part waits'),continuingPartNeeds:t(l,'계속 관찰된 제품·부품','Continuing product / part waits'),noLongerListedPartNeeds:t(l,'사라진 제품·부품 기록','Product / part waits no longer listed'),newWaiting:t(l,'새로 관찰','Newly observed'),continuingWaiting:t(l,'계속 관찰','Still observed'),disappearedWaiting:t(l,'자료에서 사라짐','No longer observed')})[k]||k)+' '+n(v)+'</span>').join('')+'<small>'+t(l,'자료에서 사라짐은 수리 완료·입고 완료를 뜻하지 않습니다.','Disappearance from WIP does not establish repair completion or parts receipt.')+'</small></div>':'');
}
function sortGroups(groups,data,mode='TAT',notes={},center='ALL'){
 const age=new Map(),impact=new Map();for(const p of (data.products||[]).filter(p=>center==='ALL'||p.center===center))for(const e of p.parts||[]){age.set(e.part,Math.max(age.get(e.part)||0,p.age||0));if(p.age>45){if(!impact.has(e.part))impact.set(e.part,new Set());impact.get(e.part).add(p.id);}}
 const score=g=>mode==='IMPACT'?(impact.get(g.part)?.size||0):mode==='ORDER'?(g.rows||[g.row]).filter(Boolean).reduce((a,r)=>a+(r.proposed||0),0):mode==='SHORTAGE'?(g.rows||[g.row]).filter(Boolean).reduce((a,r)=>a+(r.shortage||0),0):mode==='ETA'?(g.rows||[g.row]).filter(Boolean).filter(r=>!notes[r.id]?.eta).length:age.get(g.part)||0;
 return [...groups].sort((a,b)=>mode==='PART'?a.part.localeCompare(b.part):score(b)-score(a)||a.part.localeCompare(b.part));
}
function sortControl(value,l,attr){return '<label class="wf-sort">'+t(l,'정렬','Sort')+' <select '+attr+'>'+[['TAT',t(l,'최장 TAT순','Longest TAT')],['IMPACT',t(l,'45일 초과 대수순','Overdue product impact')],['ORDER',t(l,'추가 PO 수량순','Additional PO quantity')],['SHORTAGE',t(l,'부족 수량순','Shortage quantity')],['ETA',t(l,'ETA 미확인 우선','Unknown ETA first')],['PART',t(l,'부품 코드순','Part code')]].map(([v,label])=>'<option value="'+v+'" '+(v===value?'selected':'')+'>'+label+'</option>').join('')+'</select></label>';}
function render({data={},notes={},reviews={},center='ALL',language:l='ko',search='',status='ALL',page=1,readOnly=false}={}){
 const q=String(search).toLowerCase(),statusRows=statusAPI().build(data,{center,language:l}).rows,statusMap=new Map(statusRows.map(r=>[r.center+'|'+r.part,r.status])),taskIds=new Set(statusMap.keys()),date=today();
 const rows=(data.rows||[]).filter(r=>(taskIds.has(r.id)||notes[r.id])&&(center==='ALL'||r.center===center)).filter(r=>{const a=notes[r.id]||{};return (!q||[r.part,r.name,r.center,a.owner,a.plan].join(' ').toLowerCase().includes(q))&&(status==='ALL'||status==='OVERDUE'?(status!=='OVERDUE'||a.due&&a.due<date&&a.status!=='CLOSED'):status==='UNRECORDED'?!a.status:a.status===status);});
 rows.sort((a,b)=>Number(!!notes[b.id]?.due&&notes[b.id].due<date&&notes[b.id].status!=='CLOSED')-Number(!!notes[a.id]?.due&&notes[a.id].due<date&&notes[a.id].status!=='CLOSED')||(b.shortage||0)-(a.shortage||0)||a.part.localeCompare(b.part));
 const pages=Math.max(1,Math.ceil(rows.length/25)),p=Math.max(1,Math.min(pages,page)),visible=rows.slice((p-1)*25,p*25);
 return '<section class="wf-panel"><h2>'+t(l,'진행 기록','Progress records')+'</h2><p>'+t(l,'현재 재고·PO 현황과 직접 기록한 진행 상황을 함께 봅니다. 업무 종료·입고 기록은 재고나 WIP를 자동 수정하지 않습니다.','Review current stock / PO status and recorded progress. Closing a task or recording receipt does not edit inventory or WIP.')+'</p><div class="wf-toolbar"><label>'+t(l,'부품·담당자 검색','Part / owner')+' <input data-wf-search value="'+esc(search)+'"></label><label>'+t(l,'진행 상태','Status')+' <select data-wf-status>'+[['ALL',t(l,'전체','All')],['UNRECORDED',t(l,'미기록','Not recorded')],['OVERDUE',t(l,'조치 기한 초과','Follow-up overdue')],...Object.keys(statuses).map(v=>[v,statusLabel(v,l)])].map(([v,label])=>'<option value="'+v+'" '+(status===v?'selected':'')+'>'+label+'</option>').join('')+'</select></label><b>'+rows.length+t(l,'센터·부품 행',' center / part rows')+'</b></div><table class="wf-table"><thead><tr>'+[t(l,'부품·센터','Part / center'),t(l,'필요 조치','Required action'),t(l,'담당·상태·기한','Owner / status / due'),t(l,'확인 내용','Verified progress')].map(x=>'<th>'+x+'</th>').join('')+'</tr></thead><tbody>'+visible.map(r=>{const a=notes[r.id]||{},texts=[statusMap.get(r.id)||(num(r.shortage)&&r.shortage===0?t(l,'현재 부족 없음','No current shortfall'):t(l,'센터 재고·수리 필요량 미확인','Center stock / repair need unavailable'))];return '<tr><td><b>'+esc(r.part)+'</b><small>'+esc(r.center+' · '+(r.name||''))+'</small></td><td>'+texts.map(x=>'<div>'+esc(x)+'</div>').join('')+'</td><td>'+esc(noteSummary(a,l))+'</td><td>'+esc(a.plan||t(l,'미기록','Not recorded'))+(a.etaBasis?'<small>'+esc(a.etaBasis)+'</small>':'')+'<button data-wf-note="'+esc(r.id)+'">'+t(l,readOnly?'기록 보기':'진행 기록',readOnly?'View record':'Update progress')+'</button></td></tr>';}).join('')+'</tbody></table><div class="wf-toolbar"><button data-wf-page="'+(p-1)+'" '+(p===1?'disabled':'')+'>'+t(l,'이전','Previous')+'</button><span>'+p+' / '+pages+'</span><button data-wf-page="'+(p+1)+'" '+(p===pages?'disabled':'')+'>'+t(l,'다음','Next')+'</button></div></section>'+qualityHTML(data,reviews,l,readOnly);
}
function qualityHTML(data,reviews={},l='ko',readOnly=false){
 const items=qualityItems(data);
 return '<section id="wf-quality" class="wf-panel"><h2>'+t(l,'자료 확인 목록','Source checks')+' · '+items.length+'</h2><p>'+t(l,'확인 완료 기록은 원본 경고나 수량을 지우지 않습니다. 정정 원본을 반영하면 재평가됩니다.','A review record does not remove source warnings or change quantities. Corrected source files are reassessed.')+'</p>'+Object.entries(issueLabels).map(([kind,labels])=>{const xs=items.filter(x=>x.kind===kind);if(!xs.length)return '';return '<details><summary>'+labels[l==='en'?1:0]+' · '+xs.length+'</summary><ul>'+xs.map(item=>{const r=reviews[item.id]||{};return '<li><span>'+esc(issueText(item,l))+'</span><small>'+esc([r.status==='CONFIRMED'?t(l,'확인 기록 있음','Review recorded'):t(l,'확인 필요','Needs review'),r.owner,r.note,r.updatedAt?.slice(0,10)].filter(Boolean).join(' · '))+'</small>'+(!readOnly?'<button data-wf-review="'+esc(item.id)+'">'+t(l,'확인 기록','Record review')+'</button>':'')+'</li>';}).join('')+'</ul></details>';}).join('')+'</section>';
}
function compactMail(model,l='ko'){
 const columns=model.columns||[],keys=['part','center','recipient','action','proposed','eta','plan'];
 let indices=columns.map((c,i)=>({key:typeof c==='string'?String(i):c.key,i})).filter(c=>keys.includes(c.key)).map(c=>c.i);
 if(indices.length<3)return model;
 return {...model,columns:indices.map(i=>columns[i]),rows:(model.rows||[]).map(r=>indices.map(i=>Array.isArray(r)?r[i]:r[columns[i].key])),notes:[...(model.notes||[]),t(l,'요청용 간단 표입니다. 원본 PO와 재고 근거는 상세 표에서 확인하세요. 담당별로 반복되는 행의 수량을 합산하지 마세요.','Concise request table. Use the detailed table for PO / stock evidence. Do not sum repeated quantities across owner-specific rows.')]};
}
return {esc,n,validDate,today,statuses,teams,noteFields,validateNote,statusLabel,noteSummary,progressLines,orderTotals,freshness,freshnessHTML,insightsHTML,qualityItems,qualityHTML,sortGroups,sortControl,render,compactMail};
});
