(function(root,factory){const api=factory(typeof module==='object'?require('./core.js'):root.PartsCore);if(typeof module==='object')module.exports=api;else root.PartsReporting=api})(typeof self!=='undefined'?self:this,function(C){
'use strict';
const clone=value=>JSON.parse(JSON.stringify(value));
const validDate=value=>typeof value==='string'&&/^\d{4}-\d{2}-\d{2}$/.test(value)&&C.date(value)===value;
function weekStart(value){if(!validDate(value))throw Error('주간 기준일은 YYYY-MM-DD 형식이어야 합니다.');const d=new Date(value+'T00:00:00Z');d.setUTCDate(d.getUTCDate()-(d.getUTCDay()||7)+1);return d.toISOString().slice(0,10)}
// Content identity lets several report weeks reuse one source. Older replacements
// are archived only when needed; dated sources themselves are never re-dated.
function revision(source){const data={...source};delete data.reportingRevision;let a=2166136261,b=2246822519;const text=JSON.stringify(data);for(let i=0;i<text.length;i++){const c=text.charCodeAt(i);a=Math.imul(a^c,16777619);b=Math.imul(b^c,3266489917)}return (a>>>0).toString(16).padStart(8,'0')+(b>>>0).toString(16).padStart(8,'0')+'-'+text.length}
function normalizeSource(source){const operator=C.canonicalOperator(source.center,source.operator,source.type),out={...source,operator};out.id=C.sourceKey(out);out.reportingRevision=source.__reportingMetadata===true&&typeof source.reportingRevision==='string'?source.reportingRevision:revision(out);return out}
const archiveKey=(key,rev)=>JSON.stringify([key,rev]);
const selectionDate=C.sourceSelectionDate;
const slotKey=source=>[source.type,source.center||'',C.canonicalOperator(source.center,source.operator,source.type)||''].join('|');
const sourceRef=source=>({key:C.sourceKey(source),revision:source.reportingRevision||revision(source)});
const sameSource=(a,b)=>!a&&!b||!!a&&!!b&&archiveKey(C.sourceKey(a),a.reportingRevision||revision(a))===archiveKey(C.sourceKey(b),b.reportingRevision||revision(b));
const activeSource=(sources,slot)=>sources.filter(source=>slotKey(source)===slot).sort((a,b)=>(selectionDate(a)||'').localeCompare(selectionDate(b)||'')).at(-1)||null;
const eligible=(source,cutoff)=>!source.date&&!selectionDate(source)||!!selectionDate(source)&&selectionDate(source)<=cutoff;
function reports(state){return [...(state.reportingWeeks||[])].sort((a,b)=>a.reportDate.localeCompare(b.reportDate)||a.id.localeCompare(b.id))}
function selectedReport(state){const list=reports(state);return list.find(r=>r.id===state.selectedReportingWeek)||list.at(-1)||null}
function normalizeState(state){
 const next=C.normalizeOperators({...state,sources:state.sources||[]});next.sources=next.sources.map(normalizeSource);
 next.reportingSourceArchive={...state.reportingSourceArchive};
 next.reportingWeeks=Array.isArray(state.reportingWeeks)?state.reportingWeeks.map(r=>({...r,sourceRefs:(r.sourceRefs||[]).map(ref=>({...ref}))})):[];
 // Legacy daily raw evidence is not proof that earlier weekly reports existed.
 if(!next.reportingWeeks.length){const cutoff=next.sources.map(selectionDate).filter(validDate).sort().at(-1);if(cutoff)return recordWeek(next,cutoff,{bootstrap:true});}
 next.selectedReportingWeek=selectedReport(next)?.id||null;return next;
}
function sourceIndex(state){return new Map((state.sources||[]).map(s=>[archiveKey(C.sourceKey(s),s.reportingRevision||revision(s)),s]))}
function resolve(state,entry){const current=sourceIndex(state),archive=state.reportingSourceArchive||{},sources=[],warnings=[];if(!entry)return {sources,warnings};const excluded=new Set((entry.excludedSourceRefs||[]).map(ref=>archiveKey(ref.key,ref.revision)));for(const ref of entry.sourceRefs||[]){const key=archiveKey(ref.key,ref.revision);if(excluded.has(key))continue;const source=current.get(key)||archive[key];if(!source){warnings.push('주간 원본 버전을 찾지 못했습니다: '+ref.key);continue}if(!eligible(source,entry.cutoff)){warnings.push('주간 기준일 이후 또는 잘못된 날짜의 원본을 제외했습니다: '+source.file);continue}sources.push(source)}return {sources,warnings}}
function getReport(state,id){if(id!=null){const entry=reports(state).find(r=>r.id===id);if(!entry)throw Error('저장된 주간 보고를 찾지 못했습니다.');return entry}return selectedReport(state)}
function reportState(state,id=state.selectedReportingWeek){const entry=getReport(state,id);return {...state,sources:resolve(state,entry).sources,activeReportingWeek:entry?.id||null}}
function reportWarnings(state,id=state.selectedReportingWeek){return resolve(state,getReport(state,id)).warnings}
function selectReport(state,id){if(!reports(state).some(r=>r.id===id))throw Error('저장된 주간 보고를 찾지 못했습니다.');return {...state,selectedReportingWeek:id}}
function sourcesForReportDate(state,reportDate){
 const id=weekStart(reportDate),list=reports(state);
 // Corrections start from that report's saved versions. A new week inherits
 // the nearest earlier report, not whichever old week happened to be edited
 // last in the global source store.
 const entry=list.find(report=>report.id===id)||list.filter(report=>report.reportDate<=reportDate).at(-1);
 if(entry){const result=resolve(state,entry);if(result.warnings.length)throw Error('반영 대상 보고의 원본 버전을 확인할 수 없습니다. 기존 작업본을 확인해 주세요.');return result.sources.filter(source=>eligible(source,reportDate));}
 return list.length?[]:(state.sources||[]).filter(source=>eligible(source,reportDate));
}
function recordWeek(state,reportDate,options={}){
 const cutoff=options.cutoff||reportDate,id=weekStart(reportDate);if(!validDate(cutoff)||cutoff>reportDate)throw Error('원본 마감일은 주간 기준일 이후일 수 없습니다.');
 const sources=(state.sources||[]).map(s=>s.reportingRevision?s:normalizeSource(s)),now=options.now||new Date().toISOString(),previous=(state.reportingWeeks||[]).find(r=>r.id===id);
 const reportSources=options.sources||sources;
 const sourceRefs=reportSources.filter(s=>eligible(s,cutoff)).map(sourceRef),prior=reports(state).filter(r=>r.reportDate<reportDate&&r.id!==id).at(-1);
 const entry={...previous,id,weekStart:id,reportDate,cutoff,sourceRefs,excludedSourceRefs:previous?.excludedSourceRefs||prior?.excludedSourceRefs||[],ownSourceSlots:previous?.ownSourceSlots||[],createdAt:previous?.createdAt||now,updatedAt:now,bootstrap:options.bootstrap===true};
 const reportingWeeks=[...(state.reportingWeeks||[]).filter(r=>r.id!==id),entry].sort((a,b)=>a.reportDate.localeCompare(b.reportDate)),used=new Set(reportingWeeks.flatMap(r=>r.sourceRefs.map(ref=>archiveKey(ref.key,ref.revision))));
 // Keep replaced/cancelled revisions available for audit and explicit restore.
 const archive={...state.reportingSourceArchive};
 return {...state,sources,reportingSourceArchive:archive,reportingWeeks,selectedReportingWeek:id};
}
function archiveReferencedSources(state,keys){const archive={...state.reportingSourceArchive},referenced=new Set((state.reportingWeeks||[]).flatMap(r=>(r.sourceRefs||[]).map(ref=>archiveKey(ref.key,ref.revision))));for(const source of state.sources||[]){const key=C.sourceKey(source),rev=source.reportingRevision||revision(source),id=archiveKey(key,rev);if(keys.has(key)&&referenced.has(id)&&!archive[id])archive[id]=clone(source)}return archive}
function refSlot(state,ref){const source=sourceIndex(state).get(archiveKey(ref.key,ref.revision))||state.reportingSourceArchive?.[archiveKey(ref.key,ref.revision)];return source?slotKey(source):null;}
function replaceReportSlot(state,entry,slot,source,{exclude=null,restore=false}={}){
 let excluded=[...(entry.excludedSourceRefs||[])];
 if(exclude&&!excluded.some(ref=>archiveKey(ref.key,ref.revision)===archiveKey(exclude.key,exclude.revision)))excluded.push(exclude);
 if(restore&&source)excluded=excluded.filter(ref=>ref.key!==C.sourceKey(source));
 return {...entry,sourceRefs:[...(entry.sourceRefs||[]).filter(ref=>refSlot(state,ref)!==slot),...(source?[sourceRef(source)]:[])],excludedSourceRefs:excluded,updatedAt:new Date().toISOString()};
}
// Update only references that still depend on the old version. A later upload
// is independent; a subsequent cancellation can legitimately return to an
// older normal version and therefore depend on that version again.
function propagate(state,beforeState,targetId,changes){
 const pending=new Map(changes.map(change=>[change.slot,change])),affected=[];
 const reportingWeeks=reports(state).map(entry=>{
  if(entry.id<=targetId)return entry;let updated=entry;
  const original=reports(beforeState).find(report=>report.id===entry.id),priorSources=resolve(beforeState,original).sources;
  for(const [slot,change] of pending){
   if((original?.ownSourceSlots||[]).includes(slot)||!sameSource(activeSource(priorSources,slot),change.before))continue;
   if(change.after&&!eligible(change.after,entry.cutoff))continue;
   updated=replaceReportSlot(state,updated,slot,change.after,{...change,restore:false});affected.push(entry.id);
  }
  return updated;
 });
 return {...state,reportingWeeks,lastReportingChange:{reportId:targetId,affectedReportIds:[targetId,...new Set(affected)]}};
}
function applySources(state,incoming,reportDate){
 if(!validDate(reportDate))throw Error('반영할 주간 기준일을 지정해 주세요.');
 if(incoming.some(source=>selectionDate(source)>reportDate))throw Error('주간 기준일이 업로드 원본 기준일보다 이릅니다. 최신 원본 기준일 이후로 주간 기준일을 지정해 주세요.');
 if(incoming.some(source=>!selectionDate(source)))throw Error('실제 원본 기준일 또는 비WIP 자료의 확인된 보고 주차가 필요합니다.');
 const current=normalizeState(state),basis=sourcesForReportDate(current,reportDate),keys=new Set(incoming.map(C.sourceKey)),archive=archiveReferencedSources(current,keys);
 const next=C.merge(current,incoming);next.sources=next.sources.map(normalizeSource);next.reportingSourceArchive=archive;
 const slots=new Set(incoming.map(slotKey)),newSources=next.sources.filter(source=>keys.has(C.sourceKey(source))),reportSources=[...basis.filter(source=>!slots.has(slotKey(source))),...newSources];
 let result=recordWeek(next,reportDate,{sources:reportSources});const id=weekStart(reportDate);
 result.reportingWeeks=result.reportingWeeks.map(entry=>entry.id===id?{...entry,ownSourceSlots:[...new Set([...(entry.ownSourceSlots||[]),...slots])],explicitlyExcludedSlots:(entry.explicitlyExcludedSlots||[]).filter(slot=>!slots.has(slot)),excludedSourceRefs:(entry.excludedSourceRefs||[]).filter(ref=>!keys.has(ref.key))}:entry);
 return propagate(result,current,id,[...slots].map(slot=>({slot,before:activeSource(basis,slot),after:activeSource(newSources,slot),restore:true})));
}
// Unlike cancelling a bad replacement, an explicit weekly exclusion must not
// fall back to an older snapshot. Raw evidence remains stored for later review.
function excludeSlots(state,slots,reportId=state.selectedReportingWeek){
 const current=normalizeState(state),entry=getReport(current,reportId),selected=resolve(current,entry).sources,excluded=new Set(slots);
 let next={...current,reportingWeeks:current.reportingWeeks.map(report=>report.id!==entry.id?report:{...report,
  sourceRefs:(report.sourceRefs||[]).filter(ref=>!excluded.has(refSlot(current,ref))),
  ownSourceSlots:[...new Set([...(report.ownSourceSlots||[]),...excluded])],
  explicitlyExcludedSlots:[...new Set([...(report.explicitlyExcludedSlots||[]),...excluded])],updatedAt:new Date().toISOString()})};
 return propagate(next,current,entry.id,[...excluded].map(slot=>({slot,before:activeSource(selected,slot),after:null})));
}
function removalPlan(state,id,reportId){
 const current=normalizeState(state),entry=getReport(current,reportId),selected=resolve(current,entry).sources,source=selected.find(s=>s.id===id||C.sourceKey(s)===id);
 if(!source)return {state:current,source:null,fallback:null,affectedReportIds:[]};
 const slot=slotKey(source),before=activeSource(selected,slot),excluded=[...(entry.excludedSourceRefs||[]),sourceRef(source)],excludeKeys=new Set(excluded.map(ref=>archiveKey(ref.key,ref.revision)));
 let fallback=null;
 if(!sameSource(source,before))fallback=before;
 else for(const prior of reports(current).filter(report=>report.id<entry.id).reverse()){
  const candidates=resolve(current,prior).sources.filter(item=>slotKey(item)===slot&&!excludeKeys.has(archiveKey(C.sourceKey(item),item.reportingRevision||revision(item)))&&eligible(item,entry.cutoff));
  fallback=activeSource(candidates,slot);if(fallback)break;
 }
 const key=C.sourceKey(source),archive=archiveReferencedSources(current,new Set([key]));
 let next={...current,reportingSourceArchive:archive,reportingWeeks:current.reportingWeeks.map(report=>report.id===entry.id?{...replaceReportSlot(current,report,slot,fallback,{exclude:sourceRef(source)}),ownSourceSlots:(report.ownSourceSlots||[]).filter(value=>value!==slot),cancelledSourceSlots:[...new Set([...(report.cancelledSourceSlots||[]),slot])]}:report)};
 next=propagate(next,current,entry.id,[{slot,before,after:fallback,exclude:sourceRef(source)}]);
 // Remove the cancelled current store version; archived evidence still serves
 // earlier reports. A genuinely different later version of the same key stays.
 next.sources=next.sources.filter(item=>!sameSource(item,source));
 return {state:next,source,fallback,affectedReportIds:next.lastReportingChange.affectedReportIds};
}
function previewRemoveSource(state,id,reportId=state.selectedReportingWeek){const {source,fallback,affectedReportIds}=removalPlan(state,id,reportId);return {source,fallback,affectedReportIds};}
function removeSource(state,id,reportId=state.selectedReportingWeek){return removalPlan(state,id,reportId).state;}
return {validDate,weekStart,normalizeState,reports,selectedReport,selectReport,reportState,reportWarnings,sourcesForReportDate,recordWeek,applySources,excludeSlots,removeSource,previewRemoveSource};
});
