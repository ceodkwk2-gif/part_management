(function(root,factory){
 if(typeof module==='object'&&module.exports)module.exports=factory(require('./core.js'),require('./operations.js'),require('./wip-tat.js'),require('./leadtime.js'));
 else root.PartsFollowups=factory(root.PartsCore,root.PartsOperations,root.PartsWipTat,root.PartsLeadTime);
})(typeof self!=='undefined'?self:this,function(Core,Operations,WipTat,LeadTime){
'use strict';
// Read-only requests derived from the existing calculations. Task recipients
// are contacts for parallel work, not exclusive part categories or liability.
// evaluate(state, calculated, {asof, center}) requires center-level calculations
// and their WIP/PO evidence, without an operator stock-allocation filter.
// A task id is center|part|kind|recipient and is stable across weekly snapshots.
// task.row is the original calculation evidence (shared reference, never edited).
// quantity is contextual: ORDER=additional PO, SUPPLY=existing PO,
// WIP_STOCK=linked gross WIP need; HQ/LT quantity=null (not a buy qty).
// Never total quantities or related products across task rows. recipients use
// unique part counts, and tatSummary deduplicates related product identities.
const RECIPIENTS=Object.freeze([{key:'CENTER',label:'수리센터'},{key:'INDIA',label:'법인'},{key:'HQ',label:'본사'}].map(Object.freeze));
const KINDS=Object.freeze(['ORDER','SUPPLY','HQ_SUPPLY','WIP_STOCK','LT_REQUEST','LT_REVIEW']);
const known=v=>typeof v==='number'&&Number.isFinite(v)&&v>=0;
const positive=v=>known(v)&&v>0;
const norm=v=>String(v??'').trim().toUpperCase();
const unique=values=>[...new Set(values)];
const validDate=value=>typeof value==='string'&&Core.date(value)===value;
const number=value=>Number(value).toLocaleString('ko-KR');
const rowKey=row=>row.center+'|'+norm(row.part);
function summarizeTat(rows){
 const distinct=[...new Map(rows.map(row=>[row.productId,row])).values()],ages=distinct.map(row=>row.ageDays).filter(known);
 return {products:distinct.length,overdueProducts:distinct.filter(row=>row.overdue===true).length,
  maxAge:ages.length?Math.max(...ages):null,unknownAgeProducts:distinct.filter(row=>!known(row.ageDays)).length,
  sourceDates:unique(distinct.map(row=>row.wipDate||row.date||null))};
}
function compareTasks(a,b){
 return a.priority-b.priority||(a.priority<2?b.tat.overdueProducts-a.tat.overdueProducts||
  (b.tat.maxAge??-1)-(a.tat.maxAge??-1):0)||a.part.localeCompare(b.part)||
  a.center.localeCompare(b.center)||KINDS.indexOf(a.kind)-KINDS.indexOf(b.kind)||a.recipient.localeCompare(b.recipient);
}
function scheduleNote(info,asof){
 const dates=unique(info.tasks.flatMap(task=>task.dates||[])).filter(validDate).sort(),notes=[];
 if(dates.length)notes.push('법인 출고 예정 '+dates.join(', '));
 if(info.unplannedQuantity>0||!dates.length)notes.push(info.matched?'ETD 미정':'ETD 연결 확인 필요');
 if(validDate(asof)&&dates.some(date=>date<asof))notes.push('보고일 이전 예정일 · 실제 출고 여부 확인');
 return notes.join(' · ');
}
function evaluate(state,calculated,{asof,center='전체'}={}){
 const allRows=calculated?.allParts||calculated?.parts||[],rows=allRows.filter(row=>center==='전체'||row.center===center);
 // Keep all available center rows for the shared-stock comparison. A unique
 // dashboard category must never hide another center's requested work.
 const operations=Operations.evaluate(state,{...calculated,parts:allRows,allParts:allRows}),registry=LeadTime.normalizeRegistry(state?.partLeadTimes);
 const wip=WipTat.evaluate((calculated?.wip||[]).filter(row=>center==='전체'||row.center===center));
 const wipByPart=new Map(wip.parts.map(row=>[rowKey(row),row]));
 const source=type=>(calculated?.used||[]).find(row=>row.type===type),tasksById=new Map();
 const sourceDates=(row,related)=>({stock:row.dashboardDate||null,need:row.needDate||null,
  wip:unique(related.map(item=>item.wipDate||item.date||null)),po:row.poSourceDate||null,
  india:source('india')?.date||calculated?.commonSupport?.sourceDates?.india||null,
  hq:source('hq')?.date||calculated?.commonSupport?.sourceDates?.hq||null});
 const add=(row,kind,recipient,text,quantity,quantityBasis,extra={})=>{
  const taskCenter=extra.center||row.center,part=norm(row.part),related=extra.relatedRows||wipByPart.get(rowKey(row))?.rows||[];
  const lowUsage=extra.lowUsage??!!operations.lowUsage[rowKey(row)]?.flag;
  const task={id:[taskCenter,part,kind,recipient].join('|'),center:taskCenter,part,kind,recipient,
   recipientLabel:RECIPIENTS.find(item=>item.key===recipient).label,text,quantity:known(quantity)?quantity:null,quantityBasis,
   row,tat:summarizeTat(related),relatedProductIds:unique(related.map(item=>item.productId)),lowUsage,
   longLead:!!registry[part],sourceDates:extra.sourceDates||sourceDates(row,related),
   priority:kind.startsWith('LT_')?2:positive(row.shortage)?0:kind==='WIP_STOCK'?1:2,
   notes:[],...extra};
  delete task.relatedRows;
  tasksById.set(task.id,task);
 };
 for(const row of rows){
  const current=positive(row.shortage);
  const currentNeed=known(row.currentOrderNeed)?row.currentOrderNeed:
   [row.stock,row.needed,row.open].every(known)?Core.orderBreakdown(row).currentOrderNeed:null;
  if(positive(row.proposed))add(row,'ORDER','CENTER',Operations.orderActionText(row,{includeBasis:false,format:number}),row.proposed,'TOTAL_ADDITIONAL_PO');
  else if(!known(row.proposed)&&positive(currentNeed))add(row,'ORDER','CENTER',
   Operations.orderActionText({...row,currentOrderNeed:currentNeed},{includeBasis:false,format:number}),currentNeed,'CURRENT_REPAIR_ONLY');
  // No center PO means the next action is the center's order. Stock upstream
  // is context, not an instruction that India/HQ must already be processing it.
  const needsExisting=positive(row.open)&&(current||positive(row.proposed)||Core.waitingCovered(row));
  if(needsExisting){
   const followup=Operations.poFollowup(row,calculated?.pos||[]),timeline=scheduleNote(followup,asof);
   const planned=followup.plannedQuantity||0,unplanned=followup.unplannedQuantity;
   const noUpstreamStock=row.india===0&&row.hq===0;
   const dates=unique(followup.tasks.flatMap(task=>task.dates||[])).filter(validDate).sort();
   const awaiting=followup.matched?'ETD 미정':'ETD 연결 확인 필요';
   const notes=[...(followup.sourceDateNote?[followup.sourceDateNote]:[]),
    'ETD는 법인에서 센터로 보낼 예정일이며 실제 출고·센터 입고를 확정하지 않습니다.',
    '조치 담당은 다음 업무 담당이며 지연 귀책 판정이 아닙니다.'];
   // A valid ETD identifies the India-to-center schedule even if the earlier
   // shared stock snapshot is zero. Do not replace this with an HQ-delay claim.
   const indiaLines=[];
   if(planned>0)indiaLines.push('기존 PO '+number(planned)+'개 · 법인 출고 예정 '+dates.join(', '));
   if(positive(unplanned)&&!noUpstreamStock)indiaLines.push('기존 PO '+number(unplanned)+'개 입고 대기 ('+awaiting+') · 법인·본사 공급 일정 확인');
   if(indiaLines.length)add(row,'SUPPLY','INDIA',indiaLines.join(' / '),planned+(!noUpstreamStock?(unplanned||0):0),'EXISTING_PO',{
    poFollowup:followup,scheduleNote:timeline,supplyRoleKey:positive(unplanned)&&!noUpstreamStock?'INDIA_HQ':'INDIA',notes});
   if(positive(unplanned))add(row,'HQ_SUPPLY','HQ',
    noUpstreamStock?'기존 PO '+number(unplanned)+'개 · 본사 자재 확보·공급 일정 확인 ('+awaiting+')':
     '기존 PO '+number(unplanned)+'개 입고 대기 ('+awaiting+') · 법인·본사 공급 일정 확인',null,'SUPPLY_REVIEW_NOT_PURCHASE_QTY',{
     poFollowup:followup,scheduleNote:awaiting,supplyRoleKey:noUpstreamStock?'HQ':'INDIA_HQ',
     notes:[...notes,'기존 법인 요청·구매 진행을 확인하며 신규 구매수량을 자동 확정하지 않습니다.']});
  }
  const linked=wipByPart.get(rowKey(row));
  if(linked&&positive(linked.quantity)&&known(row.stock)&&((row.shortageBasis==='wip-waiting'&&row.stock>0)||(row.stock>=linked.quantity&&row.shortage===0))){
   const differing=linked.sourceDates.some(date=>!validDate(date)||!validDate(row.dashboardDate)||date!==row.dashboardDate);
   add(row,'WIP_STOCK','CENTER','재고 사용·자재대기 상태 확인',linked.quantity,'LINKED_WIP_GROSS_NEED',{
    notes:[differing?'재고와 WIP 기준일 차이·미확인이 있어 실제 사용 가능 재고와 현재 상태를 확인합니다.':'해당 부품의 사용 가능 재고와 자재대기 상태를 확인합니다.',
     '다른 필요부품·작업 조건이 있어 제품 전체의 즉시 수리 가능이나 센터 지연을 확정하지 않습니다.']});
  }
 }
 const linkedParts=new Set(rows.map(row=>norm(row.part))),commonByPart=new Map((calculated?.commonSupport?.parts||[]).map(row=>[norm(row.part),row]));
 const leadReview=LeadTime.procurementReview(state,calculated?.commonSupport);
 for(const review of leadReview.alerts){
  if(center!=='전체'&&!linkedParts.has(review.part))continue;
  const row=commonByPart.get(review.part);if(!row)continue;
  const related=wip.parts.filter(item=>item.part===review.part).flatMap(item=>item.rows),members=rows.filter(item=>norm(item.part)===review.part);
  const extra={center:'공통',relatedRows:related,leadTimeReview:review,
   lowUsage:members.length>0&&members.every(item=>operations.lowUsage[rowKey(item)]?.flag),
   sourceDates:{...calculated.commonSupport.sourceDates,wip:unique(related.map(item=>item.wipDate||item.date||null))},
   notes:['인도 소요와 본사 공용 재고를 비교한 참고 경보입니다. 기존 법인 요청·본사 구매잔량은 미반영입니다.',
    '센터별 수량에 더하거나 신규 구매수량으로 사용하지 않습니다.']};
  add(row,'LT_REQUEST','INDIA','장납자재 선행 확보 요청 검토',null,'LT_REFERENCE_NOT_PURCHASE_QTY',extra);
  add(row,'LT_REVIEW','HQ','법인 요청·기존 구매계획 기준 장납자재 확보 검토',null,'LT_REFERENCE_NOT_PURCHASE_QTY',extra);
 }
 const tasks=[...tasksById.values()].sort(compareTasks),ids=new Set(tasks.flatMap(task=>task.relatedProductIds));
 const recipients=RECIPIENTS.map(recipient=>{const selected=tasks.filter(task=>task.recipient===recipient.key);return {...recipient,
  taskCount:selected.length,partCount:new Set(selected.map(task=>task.part)).size,tasks:selected};});
 return {tasks,taskCount:tasks.length,partCount:new Set(tasks.map(task=>task.part)).size,recipients,
  tatSummary:summarizeTat(wip.rows.filter(row=>ids.has(row.productId))),asof:validDate(asof)?asof:null,center,
  quantityTotal:null,liabilityConfirmed:false,
  scopeNote:'요청 업무는 부품별로 병행될 수 있습니다. 담당별 종수나 업무 수량을 더해 전체 부족 종수·수량으로 사용하지 않습니다.'};
}
return {RECIPIENTS,KINDS,evaluate};
});
