(function(root,factory){
 if(typeof module==='object'&&module.exports)module.exports=factory(require('./core.js'),require('./reporting.js'),require('./wip-tat.js'),require('./first-confirmed.js'));
 else root.PartsWipTrace=factory(root.PartsCore,root.PartsReporting,root.PartsWipTat,root.PartsFirstConfirmed);
})(typeof self!=='undefined'?self:this,function(C,R,T,First){
'use strict';
// Observation history, not diagnosis/receipt history. Only WIP snapshots actually
// referenced by saved reports are evidence. This projection never changes demand.
const DAY=86400000;
const str=value=>String(value??'').trim();
const norm=value=>str(value).toUpperCase();
const valid=R.validDate;
const scopeOf=row=>JSON.stringify([norm(row.center),norm(C.canonicalOperator(row.center,row.operator,'wip'))]);
const waiting=status=>/waitingfor(component|module)/.test(C.norm(status));
function identity(row){
 if(str(row.sn)||str(row.rma))return ['identity',norm(row.sn),norm(row.rma)];
 const key=str(row.key);
 if(key.includes('|')){const split=key.indexOf('|');return ['identity',norm(key.slice(0,split)),norm(key.slice(split+1))];}
 if(key)return ['key',norm(key)];
 // A source row is not a stable repair identity across different snapshots.
 return ['anonymous',str(row.source),str(row.date),str(row.sheet),row.row??''];
}
function productKey(row){return JSON.stringify([scopeOf(row),...identity(row)]);}
function rowKey(row,part){return JSON.stringify([productKey(row),C.materialCode(part)]);}
function withSource(row,source){return {...row,center:source.center,operator:source.operator,source:source.file,sheet:row.sheet||source.sheet,date:source.date};}
function latestWips(sources,asof,warnings){
 const latest=new Map();
 for(const source of sources||[]){
  if(source.type!=='wip')continue;
  if(!valid(source.date)){warnings.push('WIP 이력: 원본 기준일 미확인 — '+source.file);continue;}
  if(C.sourceSelectionDate(source)>asof)continue;
  const key=scopeOf(source),old=latest.get(key);
  if(!old||source.date>=old.date)latest.set(key,source);
 }
 return latest;
}
function makeSnapshot(source,report){
 const products=new Map(),statuses=new Map();
 for(const [key,status] of Object.entries(source.statuses||{}))statuses.set(productKey(withSource({key},source)),status);
 for(const input of source.rows||[]){if(C.wipIntegrity(source).conflictedKeys.includes(input.key))continue;
  const row=withSource({...input,tokens:C.resolvedPartTokens(input)},source),id=productKey(row);
  // Import policy is first original row. Do not add duplicate products.
  if(products.has(id))continue;
  products.set(id,{row,...T.evaluate([row]).rows[0]});
  statuses.set(id,row.status);
 }
 return {source,date:source.date,week:R.weekStart(source.date),reportWeek:report.id,
  complete:C.wipIntegrity(source).productsComplete,products,statuses};
}
function observation(snapshot,id,part){
 const product=snapshot.products.get(id),status=snapshot.statuses.get(id);
 const quantity=product?.partEntries?.find(entry=>entry.part===part)?.quantity;
 if(product&&waiting(status)&&quantity>0)return {kind:'present',quantity,row:product};
 // A missing product, incomplete file, or unparsed part is NOT proof of exit.
 if(snapshot.complete&&snapshot.statuses.has(id)){
  if(!waiting(status)&&str(status))return {kind:'absent'};
  if(product&&waiting(status)&&!product.hasUnresolvedParts)return {kind:'absent'};
 }
 return {kind:'unknown'};
}
function dayDifference(from,to){return valid(from)&&valid(to)?(Date.parse(to+'T00:00:00Z')-Date.parse(from+'T00:00:00Z'))/DAY:null;}
function evaluate(inputState,options={}){
 const state=inputState.reportingWeeks?.length?inputState:R.normalizeState(inputState);
 const allReports=R.reports(state),selected=options.reportId?allReports.find(report=>report.id===options.reportId):R.selectedReport(state);
 const warnings=[];
 if(options.reportId&&!allReports.some(report=>report.id===options.reportId))throw Error('저장된 주간 보고를 찾지 못했습니다.');
 if(!selected)return {entries:[],byKey:{},warnings};
 const asof=options.asof||selected.cutoff||selected.reportDate;
 if(!valid(asof))throw Error('WIP 이력 기준일은 YYYY-MM-DD 형식이어야 합니다.');
 const end=allReports.findIndex(report=>report.id===selected.id),reports=allReports.slice(0,end+1).filter(report=>report.cutoff<=asof);
 const byScope=new Map(),reportScopes=[];
 for(const report of reports){
  warnings.push(...R.reportWarnings(state,report.id));
  const resolved=R.reportState(state,report.id),sources=latestWips(resolved.sources,report.cutoff,warnings);
  reportScopes.push({report,sources});
  for(const [scope,source] of sources){
   if(!byScope.has(scope))byScope.set(scope,new Map());
   // Reusing a source in another report is one observation. Corrected same-day
   // snapshots supersede that day's evidence; older report views remain intact.
   const dated=byScope.get(scope),old=dated.get(source.date),snapshot=makeSnapshot(source,report);
   if(old)snapshot.reportWeek=old.reportWeek;
   dated.set(source.date,snapshot);
  }
 }
 const selectedSources=latestWips(R.reportState(state,selected.id).sources,asof,warnings),entries=[];
 for(const [scope,source] of selectedSources){
  const snapshots=[...(byScope.get(scope)?.values()||[])].sort((a,b)=>a.date.localeCompare(b.date));
  const latest=snapshots.find(snapshot=>snapshot.date===source.date);
  if(!latest)continue;
  for(const [id,product] of latest.products){
   if(!waiting(product.status))continue;
   for(const item of product.partEntries){
    const part=item.part;let episode=null,priorAbsent=null,episodeIndex=0;
    for(const [index,snapshot] of snapshots.entries()){
     if(snapshot.date>latest.date)break;
     const seen=observation(snapshot,id,part);
     if(seen.kind==='absent'){
      priorAbsent=snapshot.date;
      if(episode)episode=null;
      continue;
     }
     if(seen.kind==='unknown'){
      if(episode){episode.continuityUncertain=true;episode.consecutiveWeeks=0;episode.lastPresentWeek=null;}
      continue;
     }
     if(!episode){
      episodeIndex++;
      episode={firstSeenDate:snapshot.date,firstSeenWeek:snapshot.week,firstSeenReportWeek:snapshot.reportWeek,
       firstSeenAgeDays:T.ageAt(seen.row.receipt,snapshot.date).age,baselinePresent:index===0,
       priorObservedWithoutDate:priorAbsent,observationCount:0,consecutiveWeeks:0,
       episodeStartDate:snapshot.date,lastSeenDate:snapshot.date,continuityUncertain:index>0&&!priorAbsent,
       lastPresentWeek:null};
     }
     const step=episode.lastPresentWeek?dayDifference(episode.lastPresentWeek,snapshot.week):null;
     if(step===0){/* Another observed date in the same source week is not a new week. */}
     else if(step===7)episode.consecutiveWeeks++;
     else{if(step>7)episode.continuityUncertain=true;episode.consecutiveWeeks=1;}
     if(!snapshot.complete)episode.continuityUncertain=true;
     episode.lastPresentWeek=snapshot.week;episode.lastSeenDate=snapshot.date;episode.observationCount++;
    }
    if(!episode)continue;
    // A carried snapshot in a new report is not another observed waiting week.
    const carried=R.weekStart(selected.reportDate)>latest.week;
    if(carried)episode.continuityUncertain=true;
    // Detect saved reports with no fresh evidence inside this episode, even
    // when later snapshots happen to fall in adjacent calendar weeks.
    const missingEvidence=reportScopes.some(({report,sources})=>report.reportDate>episode.firstSeenDate&&report.reportDate<latest.date&&
      (!sources.has(scope)||R.weekStart(sources.get(scope).date)<report.id));
    if(missingEvidence)episode.continuityUncertain=true;
    const {lastPresentWeek,...publicEpisode}=episode,key=rowKey(product,part);
    entries.push({...publicEpisode,key,part,quantity:item.quantity,center:product.center,operator:product.operator,
     sn:product.sn||'',rma:product.rma||'',receipt:product.receipt||null,source:product.source,sheet:product.sheet,row:product.row,date:latest.date,
     currentAgeDays:T.ageAt(product.receipt,latest.date).age,episodeIndex,carriedForward:carried,
     sourceComplete:latest.complete,identityComplete:!!(str(product.sn)||str(product.rma)||str(product.key)),
     actualNeedDate:null,actualArrivalDate:null,liabilityConfirmed:false});
   }
  }
 }
 return First.apply({entries,byKey:Object.fromEntries(entries.map(entry=>[entry.key,entry])),warnings:[...new Set(warnings)]},state.manualFirstConfirmed||{});
}
function relatedPO(calculated,center,part,asof){
 const code=C.materialCode(part),source=(calculated.used||[]).filter(item=>item.type==='po'&&item.center===center&&(!asof||!item.date||item.date<=asof)).at(-1);
 const rows=(calculated.pos||[]).filter(row=>row.center===center&&C.materialCode(row.part)===code&&(!asof||!row.date||row.date<=asof))
  .map(row=>{const sourceDate=valid(row.date)?row.date:valid(source?.date)?source.date:null,age=dayDifference(row.poDate,sourceDate);
   return {...row,sourceDate,poAgeDays:age!==null&&age>=0?age:null,poDateIssue:age!==null&&age<0?'PO_AFTER_SOURCE':!valid(row.poDate)?'MISSING_OR_INVALID_PO_DATE':!sourceDate?'MISSING_SOURCE_DATE':null,
    productOrderLinked:false,arrivalConfirmed:false};});
 return {rows,sourceDate:source?.date||rows[0]?.sourceDate||null,sourceFile:source?.file||rows[0]?.source||null,
  reportAvailable:!!source||rows.length>0,productOrderLinked:false,
  matchCaveat:'같은 센터·부품의 관련 PO 전체입니다. 해당 제품에 배정된 주문·실제 입고·지연 귀책은 확정하지 않습니다.'};
}
return {rowKey,evaluate,relatedPO};
});
