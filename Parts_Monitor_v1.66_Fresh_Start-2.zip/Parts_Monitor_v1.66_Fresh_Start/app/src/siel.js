(function(root,factory){const api=factory();if(typeof module==='object'&&module.exports)module.exports=api;else root.PartsSiel=api})(typeof self!=='undefined'?self:this,function(){
'use strict';
// SIEL purchase-order evidence is shared India -> HQ evidence. It does not
// create center PO balances, received stock or product-to-PO allocations.
const valid=value=>typeof value==='string'&&/^\d{4}-\d{2}-\d{2}$/.test(value)&&Number.isFinite(Date.parse(value+'T00:00:00Z'))&&new Date(value+'T00:00:00Z').toISOString().slice(0,10)===value;
const text=value=>value==null?'':String(value).trim();
const known=value=>typeof value==='number'&&Number.isFinite(value)&&value>=0;
const unique=values=>[...new Set(values)];
function parseSheet(ws,sheet,X,helpers){
 const {norm,materialCode,num,date}=helpers;
 const range=ws['!ref']?X.utils.decode_range(ws['!ref']):null;if(!range)return null;
 let headerRow=-1,header;
 for(let i=0;i<=Math.min(range.e.r,11);i++){
  const h={};for(let c=0;c<=Math.min(range.e.c,127);c++){const value=ws[X.utils.encode_cell({r:i,c})]?.v;if(value!=null)h[norm(value)]=c;}
  if(['purchdoc','podate','material','quantity'].every(key=>key in h)){headerRow=i;header=h;break;}
 }
 if(headerRow<0)return null;
 const matrix=X.utils.sheet_to_json(ws,{header:1,range:0,defval:null,blankrows:true});
 const warnings=[],rows=[];
 for(let i=headerRow+1;i<matrix.length;i++){
  const raw=matrix[i]||[],at=key=>raw[header[key]],rawPart=text(at('material'));
  if(!rawPart&&!text(at('purchdoc')))continue;
  const part=materialCode(rawPart),ordered=num(at('quantity'));
  const docs={delivery:text(at('delivery')),deliveryItem:text(at('ditem')),deliveryDate:date(at('ddodate')),deliveryQty:num(at('dqty')),
   shippingRequest:text(at('sr')),shippingRequestDate:date(at('srdate')),billing:text(at('billing')),billingItem:text(at('bitem')),
   billingDate:date(at('bpostingdate')),billingQty:num(at('bqty')),nego:text(at('nego'))};
  const row={part,rawPart,po:text(at('purchdoc')),item:text(at('item')),poDate:date(at('podate')),ordered,
   pending:null,eta:date(at('peta')),description:text(at('shorttext')),status:text(at('processstatus')),unit:text(at('bun')),
   vendor:text(at('vendor')),plant:text(at('plant')),storageLocation:text(at('sloc')),docs,received:null,receivedDate:null,sheet,row:i+1};
  if(!part||!row.po||!row.poDate||!known(ordered))warnings.push(`${sheet} ${i+1}행: 법인→본사 PO 코드·발주번호·발주일·수량 확인 필요`);
  rows.push(row);
 }
 return {rows,warnings,headerRow:headerRow+1};
}
function assignDemoWeek(source,reportWeek){
 if(source?.type!=='siel'||!valid(source.date)||!valid(reportWeek)||new Date(reportWeek+'T00:00:00Z').getUTCDay()!==1)throw Error('SIEL 데모는 실제 기준일과 월요일 보고 주차가 필요합니다.');
 return {...source,sourceDate:source.date,reportWeek,demo:true,datePrecision:'day',demoAssignment:'user-approved-report-week'};
}
function selectionDate(source){
 return source?.type==='siel'&&source.demo===true&&source.demoAssignment==='user-approved-report-week'&&valid(source.date)&&valid(source.reportWeek)&&new Date(source.reportWeek+'T00:00:00Z').getUTCDay()===1?source.reportWeek:null;
}
function projection(source,reportWeek){
 if(!source)return {available:false,rows:[],sourceDate:null,reportWeek:reportWeek||null,demo:false,allocationConfirmed:false,receiptConfirmed:false,issues:[]};
 const groups=new Map(),issues=[];
 for(const row of source.rows||[]){const key=JSON.stringify([row.po,row.item,row.part]);if(!groups.has(key))groups.set(key,[]);groups.get(key).push(row);}
 const rows=[...groups.values()].map(members=>{
  const first=members[0],same=key=>unique(members.map(row=>row[key])).length===1,ordered=same('ordered')&&known(first.ordered)?first.ordered:null;
  const allDocs=members.filter(row=>row.docs&&Object.values(row.docs).some(value=>value!==null&&value!==''&&value!==0&&value!=='0'));
  const docMap=new Map();for(const row of allDocs){const doc=row.docs,key=JSON.stringify([doc.delivery,doc.deliveryItem,doc.shippingRequest,doc.billing,doc.billingItem]);
   if(!docMap.has(key))docMap.set(key,{...doc,sourceRows:[row.row]});else{const previous=docMap.get(key);previous.sourceRows.push(row.row);if(JSON.stringify({...previous,sourceRows:undefined})!==JSON.stringify({...doc,sourceRows:undefined}))issues.push({type:'siel-document-conflict',part:first.part,po:first.po,item:first.item,rows:[...previous.sourceRows]});}}
  const docs=[...docMap.values()],deliveryDocs=docs.filter(doc=>doc.delivery),documentedQty=deliveryDocs.every(doc=>known(doc.deliveryQty))?deliveryDocs.reduce((n,doc)=>n+doc.deliveryQty,0):null;
  const conflict=!same('ordered')||!same('poDate')||!same('eta')||ordered===null||documentedQty!==null&&ordered!==null&&documentedQty>ordered||issues.some(issue=>issue.po===first.po&&issue.item===first.item&&issue.part===first.part);
  if(conflict)issues.push({type:'siel-order-conflict',part:first.part,po:first.po,item:first.item,rows:members.map(row=>row.row)});
  const documentPending=!conflict&&documentedQty!==null?Math.max(0,ordered-documentedQty):null;
  return {...first,statuses:unique(members.map(row=>text(row.status)).filter(Boolean)),status:unique(members.map(row=>text(row.status)).filter(Boolean)).join(' / '),ordered,pending:null,poDate:same('poDate')?first.poDate:null,eta:same('eta')?first.eta:null,
   docs,documentedQty,documentPending,stage:conflict?'review':docs.length?'supply-documents':'hq-order',
   sourceDate:source.date||null,reportWeek:source.reportWeek||reportWeek||null,demo:source.demo===true,
   source:source.file,sheet:first.sheet||source.sheet,row:first.row,sourceRows:members.map(row=>({sheet:row.sheet||source.sheet,row:row.row})),
   received:null,receivedDate:null,receiptConfirmed:false,allocationConfirmed:false};
 });
 return {available:true,rows,sourceDate:source.date||null,reportWeek:source.reportWeek||reportWeek||null,demo:source.demo===true,
  source:source.file,sheet:source.sheet,rawRowCount:(source.rows||[]).length,orderItemCount:rows.length,partKinds:unique(rows.map(row=>row.part)).length,
  allocationConfirmed:false,receiptConfirmed:false,issues,
  pendingBasis:'No physical India receipt quantities supplied; pending remains unknown. documentPending is ordered less delivery-document quantity only.'};
}
function build(sources,asof,reportWeek,getDate){
 const eligible=(sources||[]).filter(source=>source.type==='siel'&&getDate(source)&&getDate(source)<=asof).sort((a,b)=>getDate(a).localeCompare(getDate(b)));
 return projection(eligible.at(-1),reportWeek);
}
return {parseSheet,assignDemoWeek,selectionDate,projection,build};
});
