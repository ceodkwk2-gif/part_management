(function(root,factory){
 if(typeof module==='object'&&module.exports)module.exports=factory();
 else root.PartsWipTat=factory();
})(typeof self!=='undefined'?self:this,function(){
'use strict';
// This is a read-only projection of scoped Waiting for Component/Module rows.
// TAT starts at physical receipt, NOT at the start of the component-wait state.
// Each row uses its own WIP source date. The report date and wall clock are never
// substitutes for a missing source date; existing row.age is not trusted.
// User-confirmed boundary: 45 elapsed days is within TAT; overdue starts on 46.
const DAY=86400000,OVERDUE_DAYS=45;
const BUCKETS=Object.freeze([
 {code:'DAY0',label:'0일 · 입고 당일',min:0,max:0},
 {code:'D1_30',label:'1~30일',min:1,max:30},
 {code:'D31_45',label:'31~45일',min:31,max:45},
 {code:'D46_90',label:'46~90일',min:46,max:90},
 {code:'D91_180',label:'91~180일',min:91,max:180},
 {code:'D181_PLUS',label:'181일 이상',min:181,max:null},
 {code:'UNKNOWN',label:'입고 경과일 미확인',min:null,max:null}
].map(Object.freeze));
const str=value=>String(value??'').trim();
const norm=value=>str(value).toUpperCase();
const positive=value=>typeof value==='number'&&Number.isFinite(value)&&value>0;
const knownAge=value=>typeof value==='number'&&Number.isInteger(value)&&value>=0;
function dateValue(value){
 if(typeof value!=='string'||!/^\d{4}-\d{2}-\d{2}$/.test(value))return null;
 const [year,month,day]=value.split('-').map(Number);
 if(year<1||month<1||month>12||day<1||day>31)return null;
 const time=Date.parse(value+'T00:00:00.000Z'),date=new Date(time);
 return Number.isFinite(time)&&date.getUTCFullYear()===year&&date.getUTCMonth()+1===month&&date.getUTCDate()===day?time:null;
}
function ageAt(receipt,asOf){
 const received=dateValue(receipt),snapshot=dateValue(asOf);
 const issue=!str(receipt)?'MISSING_RECEIPT':received===null?'INVALID_RECEIPT':
  !str(asOf)?'MISSING_SOURCE_DATE':snapshot===null?'INVALID_SOURCE_DATE':
  received>snapshot?'RECEIPT_AFTER_SOURCE':null;
 return {age:issue?null:(snapshot-received)/DAY,issue};
}
function bucketFor(age){
 return BUCKETS.find(bucket=>knownAge(age)&&bucket.min!==null&&age>=bucket.min&&(bucket.max===null||age<=bucket.max))||BUCKETS[BUCKETS.length-1];
}
function productId(row,index){
 const scope=[norm(row.center),norm(row.operator)];
 if(str(row.sn)||str(row.rma))return JSON.stringify([...scope,'identity',norm(row.sn),norm(row.rma)]);
 if(str(row.key).replace(/\|/g,'').trim())return JSON.stringify([...scope,'key',norm(row.key)]);
 // No product identity: use the source row if supplied, otherwise keep each
 // anonymous input row. Never merge unrelated anonymous repair products.
 return JSON.stringify([...scope,'source',str(row.source),str(row.sheet),row.row??'input-'+index]);
}
function repairCategoryFor(row){
 // Classify the repair register, not the requested component: a normal
 // product needing a FAN component is not automatically a FAN repair unit.
 // The two explicitly supported FAN detail sheets are the source evidence.
 const sheet=str(row.sheet),compact=norm(sheet).replace(/[\s_-]+/g,'');
 if(compact==='INHOUSEFANREPAIR'||compact==='FANINHOUSE')return 'FAN';
 // Old merged snapshots can lack row-level provenance. Do not classify a
 // combined register name or an unfamiliar FAN variant as a general unit.
 if(!sheet||/[+|]/.test(sheet)||/FAN/i.test(sheet))return 'UNKNOWN';
 if(compact==='INHOUSE'||compact==='CDU50SHELF'||/^wip(?:$|[ _-])/i.test(sheet))return 'GENERAL';
 return 'UNKNOWN';
}
function partsOf(row){
 const quantities=new Map(),invalid=[];
 for(const [code,quantity] of Object.entries(row.tokens?.parts||{})){
  const part=norm(code);
  if(!part||!positive(quantity)){invalid.push({part,quantity});continue}
  quantities.set(part,(quantities.get(part)||0)+quantity);
 }
 const partEntries=[...quantities].map(([part,quantity])=>({part,quantity}));
 return {partEntries,invalidPartEntries:invalid,
  hasUnresolvedParts:!!row.tokens?.unparsed||invalid.length>0||partEntries.length===0&&!row.tokens?.excludedNameplate};
}
function counts(rows){
 const parts=rows.flatMap(row=>row.partEntries),overdue=rows.filter(row=>row.overdue===true),unknown=rows.filter(row=>row.age===null);
 const partKinds=selected=>new Set(selected.flatMap(row=>row.partEntries.map(entry=>entry.part))).size;
 const quantity=selected=>selected.reduce((sum,row)=>sum+row.partEntries.reduce((subtotal,entry)=>subtotal+entry.quantity,0),0);
 const unresolved=rows.filter(row=>row.hasUnresolvedParts);
 const categoryCount=(selected,category)=>selected.filter(row=>row.repairCategory===category).length;
 return {products:rows.length,partKinds:new Set(parts.map(entry=>entry.part)).size,quantity:quantity(rows),
  fanProducts:categoryCount(rows,'FAN'),generalProducts:categoryCount(rows,'GENERAL'),unknownCategoryProducts:categoryCount(rows,'UNKNOWN'),
  overdueFanProducts:categoryCount(overdue,'FAN'),overdueGeneralProducts:categoryCount(overdue,'GENERAL'),overdueUnknownCategoryProducts:categoryCount(overdue,'UNKNOWN'),
  overdueProducts:overdue.length,overduePartKinds:partKinds(overdue),overdueQuantity:quantity(overdue),
  unknownAgeProducts:unknown.length,unknownAgePartKinds:partKinds(unknown),unknownAgeQuantity:quantity(unknown),
  unresolvedPartProducts:unresolved.length,unresolvedPartOverdueProducts:unresolved.filter(row=>row.overdue===true).length,
  quantityComplete:unresolved.length===0};
}
function sourceRef(row){return {center:row.center,operator:row.operator,source:row.source,sheet:row.sheet,row:row.row,date:row.date}}
function evaluate(input=[]){
 const seen=new Map(),rows=[],duplicates=[],issues=[];
 for(const [index,inputRow] of input.entries()){
  const id=productId(inputRow,index);
  if(seen.has(id)){
   const duplicate={productId:id,selected:sourceRef(seen.get(id)),ignored:sourceRef(inputRow)};
   duplicates.push(duplicate);issues.push({type:'DUPLICATE_PRODUCT',...duplicate});continue;
  }
  seen.set(id,inputRow);
  const calculated=ageAt(inputRow.receipt,inputRow.date),bucket=bucketFor(calculated.age),parsed=partsOf(inputRow);
  const row={...inputRow,...parsed,productId:id,productKey:id,repairCategory:repairCategoryFor(inputRow),physicalDate:inputRow.receipt,wipDate:inputRow.date,
   age:calculated.age,ageDays:calculated.age,ageIssue:calculated.issue,bucket:bucket.code,bucketLabel:bucket.label,
   overdue:calculated.age===null?null:calculated.age>OVERDUE_DAYS};
  rows.push(row);
  if(row.ageIssue)issues.push({type:row.ageIssue,productId:id,...sourceRef(row),receipt:row.receipt});
  if(row.hasUnresolvedParts)issues.push({type:'UNRESOLVED_PARTS',productId:id,...sourceRef(row),required:row.required,
   unparsed:row.tokens?.unparsed||'',invalidPartEntries:row.invalidPartEntries,knownQuantity:row.partEntries.reduce((sum,entry)=>sum+entry.quantity,0)});
 }
 const groups=new Map();
 for(const row of rows)for(const entry of row.partEntries){
  const key=JSON.stringify([row.center,entry.part]);
  if(!groups.has(key))groups.set(key,{center:row.center,part:entry.part,rows:[]});
  groups.get(key).rows.push({...row,partQuantity:entry.quantity});
 }
 const partCounts=selected=>({quantity:selected.reduce((sum,row)=>sum+row.partQuantity,0),products:selected.length,
  overdueQuantity:selected.filter(row=>row.overdue===true).reduce((sum,row)=>sum+row.partQuantity,0),overdueProducts:selected.filter(row=>row.overdue===true).length});
 const parts=[...groups.values()].map(group=>({...group,...partCounts(group.rows),
  unknownAgeQuantity:group.rows.filter(row=>row.age===null).reduce((sum,row)=>sum+row.partQuantity,0),unknownAgeProducts:group.rows.filter(row=>row.age===null).length,
  operators:[...new Set(group.rows.map(row=>row.operator))],sourceDates:[...new Set(group.rows.map(row=>row.date))],
  buckets:BUCKETS.map(bucket=>({...bucket,...partCounts(group.rows.filter(row=>row.bucket===bucket.code))}))
 })).sort((a,b)=>b.overdueQuantity-a.overdueQuantity||b.quantity-a.quantity||a.part.localeCompare(b.part)||str(a.center).localeCompare(str(b.center)));
 const sources=new Map();
 for(const row of rows){const source={center:row.center,operator:row.operator,source:row.source,sheet:row.sheet,date:row.date};sources.set(JSON.stringify(source),source)}
 return {summary:counts(rows),buckets:BUCKETS.map(bucket=>({...bucket,...counts(rows.filter(row=>row.bucket===bucket.code))})),rows,parts,
  duplicates,issues,sourceDates:[...sources.values()],overdueDays:OVERDUE_DAYS,overdueInclusive:false,overdueStartsAt:OVERDUE_DAYS+1};
}
function productDistribution(evaluation){
 // Display projection only: keep the detailed DAY0 bucket and all original
 // quantities intact. Every scoped product, including unresolved Required
 // Part and unknown receipt dates, belongs to exactly one display group.
 const total=evaluation.summary.products;
 const byCode=new Map(evaluation.buckets.map(bucket=>[bucket.code,bucket.products]));
 const groups=[
  {code:'D0_30',label:'0~30일',bucketCodes:['DAY0','D1_30']},
  {code:'D31_45',label:'31~45일',bucketCodes:['D31_45']},
  {code:'D46_90',label:'46~90일',bucketCodes:['D46_90']},
  {code:'D91_180',label:'91~180일',bucketCodes:['D91_180']},
  {code:'D181_PLUS',label:'181일 이상',bucketCodes:['D181_PLUS']},
  {code:'UNKNOWN',label:'입고 경과일 미확인',bucketCodes:['UNKNOWN']}
 ].map(group=>({...group,products:group.bucketCodes.reduce((sum,code)=>sum+(byCode.get(code)||0),0)}))
  .filter(group=>group.code!=='UNKNOWN'||group.products>0);
 // Allocate 1,000 tenths of a percent using largest remainders. Independent
 // rounding would turn three equal groups into 99.9%; ties use age order.
 const tenths=groups.map(group=>total?Math.floor(group.products*1000/total):0);
 if(total>0){
  const remainderOrder=groups.map((group,index)=>({index,remainder:(group.products*1000)%total}))
   .sort((a,b)=>b.remainder-a.remainder||a.index-b.index);
  const remaining=1000-tenths.reduce((sum,value)=>sum+value,0);
  for(let index=0;index<remaining;index++)tenths[remainderOrder[index].index]++;
 }
 return groups.map((group,index)=>({...group,percentage:total?group.products/total*100:0,displayPercent:tenths[index]/10}));
}
return {BUCKETS,OVERDUE_DAYS,ageAt,bucketFor,repairCategoryFor,evaluate,productDistribution};
});
