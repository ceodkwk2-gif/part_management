/* Read-only supply-status projection. It never changes inventory or purchase orders.
 * Report evidence is not a confirmed centre allocation or a liability finding.
 * A partial common pool with multiple claimants stays unresolved rather than
 * inventing a centre allocation. Filtering never reassigns that pool.
 */
(function(root,factory){
  const api=factory();
  if(typeof module==='object'&&module.exports)module.exports=api;
  else root.PartsSupplyStages=api;
})(typeof globalThis==='object'?globalThis:this,function(){
  'use strict';
  const valid=v=>typeof v==='number'&&Number.isFinite(v)&&v>=0;
  const total=(xs,key)=>xs.reduce((s,x)=>s+(valid(x[key])?x[key]:0),0);
  function classify(rows,source={}){
    const result=new Map(),groups=new Map();
    const add=(r,code,quantity,reason,basis='reported')=>{
      if(quantity>0)result.get(r.id).push({id:r.id+'|'+code,rowId:r.id,
        part:r.part,center:r.center,code,quantity,reason,basis,
        reference:source.demo===true});
    };
    for(const r of rows){
      result.set(r.id,[]);
      if(!valid(r.shortage)||r.shortage===0)continue;
      let supplyNeed=r.shortage;
      if(r.shortageBasis==='wip-waiting'){
        if(!valid(r.stock)){add(r,'OTHER',supplyNeed,'센터 재고 미확인 · WIP 자재대기 확인 필요','center-stock-wip-review');continue;}
        const review=Math.min(supplyNeed,r.stock);
        add(r,'OTHER',review,'센터 재고 있음 · WIP 자재대기 확인 필요','center-stock-wip-review');
        supplyNeed-=review;
      }
      if(!supplyNeed)continue;
      if(!valid(r.open)){add(r,'OTHER',supplyNeed,'수리센터 PO 잔량 자료 없음');continue;}
      const order=Math.max(0,supplyNeed-r.open);
      let covered=supplyNeed-order;
      const detailed=r.pos?.length&&r.pos.every(p=>valid(p.pending))?total(r.pos,'pending'):null;
      const ambiguousOrder=valid(detailed)?Math.min(order,Math.max(0,detailed-r.open)):0;
      add(r,'ORDER',order-ambiguousOrder,r.open===0?'수리센터 미발주':'수리센터 일부 발주 · 부족분');
      add(r,'OTHER',ambiguousOrder,'재고표·상세 PO 잔량 차이 · 미발주 여부 미확인');
      if(valid(detailed)&&detailed<covered){
        add(r,'OTHER',covered-detailed,'재고표·상세 PO 잔량 차이 · 출고분 입고 여부 미확인');
        covered=detailed;
      }
      if(!covered)continue;
      if(!groups.has(r.part))groups.set(r.part,[]);
      groups.get(r.part).push({row:r,remaining:covered});
    }
    // Allocate only when the entire pool covers all claimants or there is a
    // single claimant. No priority/pro-rata policy is silently introduced.
    function allocate(claims,available,code,reason,basis){
      const active=claims.filter(c=>c.remaining>0),needed=total(active,'remaining');
      if(!active.length)return true;
      if(!valid(available))return false;
      if(available===0)return true;
      if(available<needed&&active.length>1)return false;
      for(const c of active){const q=Math.min(c.remaining,available);add(c.row,code,q,reason,basis);c.remaining-=q;available-=q;}
      return true;
    }
    for(const claims of groups.values()){
      const values=[...new Set(claims.map(c=>c.row.india))];
      if(values.length!==1||!valid(values[0])){
        for(const c of claims)add(c.row,'OTHER',c.remaining,'법인 재고 자료 없음·불일치');
        continue;
      }
      if(!allocate(claims,values[0],'DISPATCH','수리센터 PO 있음 · 법인 보유 재고')){
        for(const c of claims)add(c.row,'OTHER',c.remaining,'법인 공용 재고 있음 · 센터별 배정 없음');
        continue;
      }
      if(!claims.some(c=>c.remaining>0))continue;
      if(source.available!==true){
        for(const c of claims)add(c.row,'OTHER',c.remaining,'SIEL PO Report 미제공');
        continue;
      }
      const unique=new Map();let conflict=false;
      for(const c of claims)for(const p of c.row.siel||[]){
        const key=JSON.stringify([p.po,p.item,c.row.part]);
        if(unique.has(key)&&JSON.stringify(unique.get(key))!==JSON.stringify(p))conflict=true;
        unique.set(key,p);
      }
      const pos=[...unique.values()];
      if(conflict||pos.some(p=>p.stage==='review')){
        for(const c of claims)add(c.row,'OTHER',c.remaining,'법인 → 본사 PO 중복·수량 충돌');
        continue;
      }
      const confirmed=pos.length>0&&pos.every(p=>valid(p.pending));
      const reported=pos.every(p=>valid(p.ordered));
      if(pos.length&&!confirmed&&!reported){
        for(const c of claims)add(c.row,'OTHER',c.remaining,'본사 PO 있음 · 발주 수량 미기재');
        continue;
      }
      // SIEL PO Report is the source of placed orders and ETA. Delivery, S/R
      // and billing quantities do not establish receipt and are not deducted.
      // Reported order coverage is not a newly asserted physical open balance.
      const available=total(pos,confirmed?'pending':'ordered');
      if(!allocate(claims,available,'HQ',confirmed?'법인 재고 부족 · 본사 PO 미입고':'법인 재고 부족 · 본사 PO 발주됨',confirmed?'confirmed-pending':'siel-order')){
        for(const c of claims)add(c.row,'OTHER',c.remaining,'본사 PO 발주됨 · 센터별 배정 없음');
        continue;
      }
      for(const c of claims)add(c.row,'INDIA_ORDER',c.remaining,
        (values[0]===0?'법인 재고 없음':'법인 재고 부족')+' · 법인→본사 '+(!pos.length?'미발주':available===0?'PO 잔량 없음':'PO 수량 부족'),
        'report-coverage');
    }
    for(const r of rows){
      if(valid(r.shortage)&&r.shortage>0&&Math.abs(total(result.get(r.id),'quantity')-r.shortage)>1e-8)
        throw Error('Supply-stage reconciliation failed: '+r.id);
    }
    return result;
  }
  // One row-level status projection for summary, detail, progress and exports.
  // Repair classification remains a conserved partition of current shortage;
  // additional PO includes both repair and buffer, never a second demand.
  function statusRecords(r,repairRecords=[]){
    const gap=r.shortageBasis==='wip-waiting'?r.stockShortage:r.shortage;
    const result=[],repair=valid(gap)&&valid(r.open)?Math.max(0,gap-r.open):null;
    if(valid(r.proposed)&&r.proposed>0)result.push({id:r.id+'|ORDER',rowId:r.id,part:r.part,center:r.center,code:'ORDER',quantity:r.proposed,repairQuantity:repair,bufferQuantity:valid(repair)?Math.max(0,r.proposed-repair):null,reason:'전체 추가 PO 부족'});
    else if(!valid(r.proposed))result.push(...repairRecords.filter(a=>a.code==='ORDER').map(a=>({...a,repairQuantity:a.quantity,bufferQuantity:null,reason:'수리분 PO 부족 · 보유분 산정 불가'})));
    result.push(...repairRecords.filter(a=>a.code!=='ORDER').map(a=>({...a,repairQuantity:a.quantity,bufferQuantity:0,hasEta:(r.siel||[]).some(p=>!!p.eta)})));
    if(!(r.shortage>0)&&r.waitingCovered&&r.open>0)result.push({id:r.id+'|WAIT',rowId:r.id,part:r.part,center:r.center,code:'WAIT',quantity:r.open,repairQuantity:0,bufferQuantity:0,reason:'센터 PO 잔량'});
    return result;
  }
  function statusLabel(a,en=false){
    const labels={ORDER:['수리센터 → 법인 추가 PO 필요','Center → India additional PO needed'],DISPATCH:['법인 → 수리센터 공급 필요','India → center supply needed'],INDIA_ORDER:['법인 → 본사 추가 PO 필요','India → HQ additional PO needed'],HQ:['본사 → 법인 입고 대기','Awaiting HQ → India arrival'],WAIT:['수리센터 입고 대기','Awaiting center arrival']};
    if(a.code==='ORDER'&&a.bufferQuantity===null)return en?'Center → India repair PO needed · buffer unknown':'수리센터 → 법인 수리분 PO 필요 · 보유분 미산정';
    if(a.code==='HQ'&&a.hasEta===false)return en?'HQ → India ETA needed':'본사 → 법인 ETA 확인 필요';
    return labels[a.code]?.[en?1:0]||a.reason;
  }
  return {classify,statusRecords,statusLabel};
});
