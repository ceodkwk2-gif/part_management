(function(root,factory){const api=factory(typeof module==='object'?require('./core.js'):root.PartsCore);if(typeof module==='object')module.exports=api;else root.PartsHistory=api})(typeof self!=='undefined'?self:this,function(C){
'use strict';
const DAY=86400000, TYPES=new Set(['dashboard','wip','po','india','hq']);
const str=v=>v==null?'':String(v).trim(),code=v=>str(v).toUpperCase();
const validDate=v=>typeof v==='string'&&/^\d{4}-\d{2}-\d{2}$/.test(v)&&C.date(v)===v;
const qty=v=>{const n=C.num(v);return n!=null&&n>=0?n:null};
const unique=a=>[...new Set(a)];
// unknownCount counts null numeric inputs only. Unparsed WIP or missing whole sources
// can make complete=false through reasons even when unknownCount is zero.
// knownSubtotal is a partial sum, never a substitute for an unknown complete value.
const metric=(values,reasons=[])=>{const unknownCount=values.filter(v=>v==null).length,knownSubtotal=values.reduce((s,v)=>s+(v??0),0),complete=unknownCount===0&&reasons.length===0;return {value:complete?knownSubtotal:null,knownSubtotal,complete,unknownCount,reasons:unique(reasons)}};
function proof(s,asof){return s?{type:s.type,center:s.center||'',operator:s.operator||'',date:s.date||null,dateLabel:s.dateLabel||null,file:s.file||null,sheet:s.sheet||null,revisedAt:s.revisedAt||null,ageDays:validDate(s.date)&&validDate(asof)?Math.round((Date.parse(asof)-Date.parse(s.date))/DAY):null}:null}
function dedupeSources(state){const byKey=new Map();for(const s of state.sources||[])if(TYPES.has(s.type))byKey.set(C.sourceKey(s),s);return [...byKey.values()]}
function latest(sources,type,center,operator){return sources.filter(s=>s.type===type&&(center==null||s.center===center)&&(operator==null||s.operator===operator)).sort((a,b)=>a.date.localeCompare(b.date)).at(-1)||null}
function selectedSources(sources,center){return [latest(sources,'dashboard',center),latest(sources,'po',center),...unique(sources.filter(s=>s.type==='wip'&&s.center===center).map(s=>s.operator)).map(o=>latest(sources,'wip',center,o))].filter(Boolean)}
function safeState(state,asof){
 const undated=[],warnings=[];const sources=dedupeSources(state).filter(s=>{if(!validDate(s.date)){undated.push(proof(s,asof));return false}return s.date<=asof}).map(s=>{
  if(s.type==='dashboard'&&s.holdDate&&(!validDate(s.holdDate)||s.holdDate>asof)){warnings.push(`${s.file} / ${s.sheet}: Hold 기준일 ${s.holdDate}는 조회일에 사용할 수 없어 제외`);return {...s,holdDate:null}}
  return s;
 });
 return {state:{...state,sources},undated,warnings};
}
function aggregate(rows,field,reasons=[]){const missing=rows.filter(r=>r[field]==null);return metric(rows.map(r=>r[field]),[...reasons,...(missing.length?[`${missing.length}개 센터·부품의 ${field} 수량 미확인`]:[])])}
function stockRows(source){return C.selectDashboardRows(source).map(r=>({part:C.materialCode(r.part),qty:qty(r.qty),row:r.row}));}
function commonStock(sources,parts,asof,scopeComplete){
 const scope=unique(parts.map(p=>p.part)).sort(),out={scope:'선택 센터의 관리 부품코드 고유 합집합',partCount:scope.length,scopeComplete,parts:[],india:null,hq:null,sources:{}};
 for(const kind of ['india','hq']){
  const source=latest(sources,kind),selected=new Map(stockRows(source).map(r=>[r.part,r]));out.sources[kind]=proof(source,asof);
  const rows=scope.map(part=>{const row=selected.get(part);return {part,qty:source?(row?row.qty:0):null,selectedRow:row?.row??null,reason:!source?'일자가 확인된 재고 원본 없음':!row?'전체 재고목록에 코드 없음 — 0':row.qty==null?'선택행 수량 빈칸·오류':'원본 재고'}});
  out[kind]=metric(rows.map(r=>r.qty),[...(!scopeComplete?['센터 관리부품 범위 일부 미확인']:[]),...(!source?['일자가 확인된 재고 원본 없음']:[]),...(rows.some(r=>r.qty==null)&&source?['일부 재고 수량 미확인']:[])]);
  rows.forEach((r,i)=>{out.parts[i]??={part:r.part};out.parts[i][kind]=r.qty;out.parts[i][kind+'Evidence']={...out.sources[kind],row:r.selectedRow,reason:r.reason}});
 }
 return out;
}
function snapshot(state,asof,options={}){
 if(!validDate(asof))throw Error('기준일은 YYYY-MM-DD 형식이어야 합니다.');
 const centers=options.centers||['Flex','CTDI'],safe=safeState(state,asof),calc=C.calculate(safe.state,asof),sources=safe.state.sources,result=[];
 for(const center of centers){
  const chosen=selectedSources(sources,center),ds=chosen.find(s=>s.type==='dashboard'),ps=chosen.find(s=>s.type==='po'),ws=chosen.filter(s=>s.type==='wip');
  const dashboards=new Map(C.selectDashboardRows(ds).map(r=>[C.materialCode(r.part),r])),rawParts=calc.allParts.filter(p=>p.center===center);
  const parts=rawParts.map(p=>{
   const stock=qty(p.stock),needed=qty(p.needed),d=dashboards.get(p.part),poRows=(ps?.rows||[]).filter(r=>C.materialCode(r.part)===p.part),pendingMissing=poRows.some(r=>qty(r.pending)==null);
   const open=d?.po!=null?qty(d.po):pendingMissing?null:qty(p.open);
   return {...p,stock,needed,shortage:stock!=null&&needed!=null?Math.max(0,needed-stock):null,open,evidence:{dashboard:proof(ds,asof),po:proof(ps,asof),wip:ws.map(s=>proof(s,asof)),dashboardRow:p.selectedSourceRow,ignoredRows:p.ignoredSourceRows||[]}};
  });
  const missingDashboard=ds?[]:['센터 대시보드 원본 없음'];
  const needAvailable=parts.length?parts.some(p=>p.needed!=null):!!ds?.holdDate||(ws.length>0&&(center!=='CTDI'||['Jio','Airtel','Vi'].every(o=>ws.some(s=>s.operator===o)))&&ws.every(s=>validDate(s.date)&&C.wipIntegrity(s).demandComplete)&&unique(ws.map(s=>s.date)).length===1);
  const unmapped=ws.flatMap(s=>s.rows||[]).filter(r=>C.resolvedPartTokens(r).unparsed).length;
  const usingWip=parts.some(p=>p.needBasis==='wip')||(!parts.length&&!ds?.holdDate);
  const neededReasons=[...(!needAvailable?['현 수리 필요 수 원본 누락·불완전']:[]),...(usingWip&&unmapped?[`WIP 부품코드 미해석 ${unmapped}건 — 전체 필요량 확정 불가`]:[])];
  const shortageReasons=[...missingDashboard,...neededReasons];
  const shortageParts=metric(parts.map(p=>p.shortage==null?null:p.shortage>0?1:0),shortageReasons);
  const duplicatePO=ps?indexPO(ps).diagnostics.filter(d=>d.type==='duplicate-key'):[];
  const pendingReasons=[...(!ds&&!ps?['센터 PO 잔량 원본 없음']:[]),...((!ds||parts.some(p=>dashboards.get(p.part)?.po==null))&&duplicatePO.length?['상세 PO 식별키 중복 — 잔량 확정 불가']:[])];
  result.push({center,date:asof,parts,sources:chosen.map(s=>proof(s,asof)),updated:chosen.some(s=>s.date===asof),stock:aggregate(parts,'stock',missingDashboard),needed:aggregate(parts,'needed',neededReasons),shortage:aggregate(parts,'shortage',shortageReasons),shortageParts,pending:aggregate(parts,'open',pendingReasons),assumedZeroParts:parts.filter(p=>p.stockAssumedZero).length,unparsedWipRows:unmapped,partCount:parts.length});
 }
 const all=result.flatMap(c=>c.parts),combine=field=>metric(result.map(c=>c[field].value),result.flatMap(c=>c[field].reasons.map(r=>c.center+': '+r)));
 // Subtotals include known part quantities even when one center's complete total is unknown.
 const totals={};for(const field of ['stock','needed','shortage','pending','shortageParts']){totals[field]=combine(field);totals[field].knownSubtotal=result.reduce((s,c)=>s+c[field].knownSubtotal,0)}
 const complete=totals.shortageParts.complete,shortCodes=unique(all.filter(p=>p.shortage>0).map(p=>p.part));
 totals.shortageUniqueParts={value:complete?shortCodes.length:null,knownSubtotal:shortCodes.length,complete,unknownCount:all.filter(p=>p.shortage==null).length,reasons:totals.shortageParts.reasons};
 const undatedWarnings=safe.undated.map(s=>`${s.file||s.type}: 기준일 미확인으로 시계열 계산에서 제외`);
 return {date:asof,centers:result,totals,common:commonStock(sources,all,asof,result.every(c=>c.sources.some(s=>s.type==='dashboard'))),sources:unique(result.flatMap(c=>c.sources).map(s=>JSON.stringify(s))).map(s=>JSON.parse(s)),excludedUndated:safe.undated,warnings:unique([...safe.warnings,...undatedWarnings,...calc.warnings]),settings:{...C.empty().settings,...state.settings},calculationBasis:'현재 설정으로 해당 기준일 이전 원본을 재계산. 당시 발행 결과·설정의 복원이 아님.',shortageCountBasis:'shortageParts=센터·부품 조합 수; shortageUniqueParts=중복 제거 부품코드 수'};
}
function weekStart(value){const d=new Date(value+'T00:00:00Z'),day=d.getUTCDay()||7;d.setUTCDate(d.getUTCDate()-day+1);return d.toISOString().slice(0,10)}
function series(state,options={}){
 const grouping=options.grouping||'snapshot';if(!['snapshot','iso-week'].includes(grouping))throw Error('지원하지 않는 시계열 구분');
 const through=options.through||'9999-12-31';if(through!=='9999-12-31'&&!validDate(through))throw Error('최종 기준일은 YYYY-MM-DD 형식이어야 합니다.');
 const centers=options.centers||['Flex','CTDI'];let dates=unique(dedupeSources(state).filter(s=>validDate(s.date)&&s.date<=through&&(!s.center||centers.includes(s.center))).map(s=>s.date)).sort();
 if(grouping==='iso-week'){const weeks=new Map();for(const d of dates)weeks.set(weekStart(d),d);dates=[...weeks.values()]}
 return {grouping,weekDefinition:grouping==='iso-week'?'월요일~일요일, 해당 주의 가장 늦은 원본 기준일':'기준일별',points:dates.map(d=>({...snapshot(state,d,{centers}),weekStart:grouping==='iso-week'?weekStart(d):null})),excludedUndated:dedupeSources(state).filter(s=>!validDate(s.date)).map(s=>proof(s,null))};
}
function poKey(center,row){const po=code(row.po),part=C.materialCode(row.part),rawItem=str(row.item),item=/^\d+$/.test(rawItem)?rawItem.replace(/^0+(?=\d)/,''):code(rawItem);return center&&po&&item&&part?JSON.stringify([center,po,item,part]):null}
function indexPO(source){
 const groups=new Map(),diagnostics=[];for(const row of source.rows||[]){const key=poKey(source.center,row);if(!key){diagnostics.push({type:'missing-key',message:'센터·PO번호·item·부품코드 일부 누락 — 자동 이력 비교 제외',source:proof(source,source.date),rows:[row.row],originalRows:[row]});continue}if(!groups.has(key))groups.set(key,[]);groups.get(key).push(row)}
 const rows=new Map(),blocked=new Set();for(const [key,group]of groups){if(group.length>1){blocked.add(key);diagnostics.push({type:'duplicate-key',key,message:'동일 센터·PO·item·부품 식별키 중복 — 합산·자동 비교 제외',source:proof(source,source.date),rows:group.map(r=>r.row),originalRows:group})}else rows.set(key,group[0])}return {rows,blocked,diagnostics};
}
function poHistory(state,options={}){
 const through=options.through||'9999-12-31';if(through!=='9999-12-31'&&!validDate(through))throw Error('최종 기준일은 YYYY-MM-DD 형식이어야 합니다.');const centers=options.center&&options.center!=='전체'?[options.center]:(options.centers||['Flex','CTDI']);
 const all=dedupeSources(state).filter(s=>s.type==='po'&&centers.includes(s.center)),valid=all.filter(s=>validDate(s.date)&&s.date<=through),diagnostics=[],events=[];
 for(const s of all.filter(s=>!validDate(s.date)))diagnostics.push({type:'undated-source',message:'기준일 미확인 — PO 이력 비교 제외',source:proof(s,null)});
 for(const center of centers){const snapshots=valid.filter(s=>s.center===center).sort((a,b)=>a.date.localeCompare(b.date));let prev=null;
  for(const source of snapshots){const indexed=indexPO(source);diagnostics.push(...indexed.diagnostics);const keys=unique([...indexed.rows.keys(),...(prev?[...prev.indexed.rows.keys()]:[])]);
   for(const key of keys){if(indexed.blocked.has(key)||prev?.indexed.blocked.has(key))continue;const before=prev?.indexed.rows.get(key),after=indexed.rows.get(key),changes=[];let type;
    if(!prev)type='baseline';else if(!before)type='appeared';else if(!after)type='disappeared';else{type='unchanged';const oldPending=qty(before.pending),newPending=qty(after.pending);if(oldPending!=null&&newPending!=null&&oldPending!==newPending)changes.push('pending');if((oldPending==null)!==(newPending==null))changes.push('pending-completeness');if((before.etd&&after.etd)?before.etd!==after.etd:str(before.etd||before.etdRaw)!==str(after.etd||after.etdRaw))changes.push('etd');if(changes.length)type='changed'}
    const oldPending=before?qty(before.pending):null,newPending=after?qty(after.pending):null;
    events.push({key,center,part:code((after||before).part),po:str((after||before).po),item:str((after||before).item),date:source.date,previousDate:prev?.source.date||null,type,changes,pendingBefore:oldPending,pendingAfter:newPending,pendingChange:oldPending!=null&&newPending!=null?newPending-oldPending:null,etdBefore:before?.etd||null,etdAfter:after?.etd||null,etdRawBefore:before?.etdRaw||null,etdRawAfter:after?.etdRaw||null,before:before?{...proof(prev.source,source.date),row:before.row}:null,after:after?{...proof(source,source.date),row:after.row}:null,meaning:type==='disappeared'?'이번 PO 목록에서 사라짐 — 입고·취소 여부 미확인':type==='appeared'?'이번 목록에 새로 나타남 — 신규 발주 확정 아님':type==='baseline'?'첫 보유 원본 — 이전 상태 미확인':changes.includes('pending')?'원본 Pending 잔량 변화 — 출고·취소·정정 내역은 추가 확인':changes.includes('pending-completeness')?'원본 Pending 수량의 확인 가능 여부 변경 — 원본 수량 확인':changes.includes('etd')?'법인→센터 예정 출고일 변경 — 실제 출고·입고는 별도 확인':'동일 식별키 계속 존재',receiptConfirmed:false});
   }
   prev={source,indexed};
  }
 }
 return {events:events.sort((a,b)=>a.date.localeCompare(b.date)||a.center.localeCompare(b.center)||a.key.localeCompare(b.key)),diagnostics,keyBasis:'센터 + PO번호 + item + 부품코드. 숫자 item의 선행 0은 동일 취급.',snapshotCount:valid.length};
}
return {snapshot,series,poHistory,poKey,weekStart};
});
