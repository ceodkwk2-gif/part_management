(function(root,factory){
 if(typeof module==='object'&&module.exports)module.exports=factory();
 else root.PartsShareTables=factory();
})(typeof self!=='undefined'?self:this,function(){
'use strict';
// Read-only, compact projections for a request attachment or copied table.
// Callers supply the already-filtered dashboard/WIP scope. These functions do
// not assign responsibility, allocate shared stock, recalculate orders, or send
// anything. Language is applied by the presentation layer; raw columns remain
// unchanged. A WIP product is always one row, even when it needs several parts.
const RECIPIENTS=Object.freeze([{key:'CENTER',label:'수리센터'},{key:'INDIA',label:'법인'},{key:'HQ',label:'본사'}].map(Object.freeze));
const known=value=>typeof value==='number'&&Number.isFinite(value)&&value>=0;
const quantity=value=>known(value)?value:null;
const str=value=>String(value??'');
const unique=values=>[...new Set(values)];
const column=(key,label,extra={})=>({key,label,...extra});
const partColumn=()=>column('part','부품 코드',{raw:true});
const nameColumn=()=>column('name','부품명',{raw:true});
const centerColumn=()=>column('center','센터');
const qtyColumn=(key,label)=>column(key,label,{unit:'pieces'});
const stockColumns=()=>[qtyColumn('stock','센터 재고'),qtyColumn('india','법인 재고'),qtyColumn('hq','본사 재고')];
const defaultName=()=>'';
function defaultMonthly(value){
 if(!known(value))return null;
 return Math.ceil(value);
}
function totalRequired(row){return known(row.needed)&&known(row.target)?row.needed+row.target:null}
function recipientLabel(key){return RECIPIENTS.find(item=>item.key===key)?.label||str(key)}
function selectTasks(tasks,recipient){
 const seen=new Set();
 return (tasks||[]).filter(task=>{
  if(recipient!=='all'&&task.recipient!==recipient)return false;
  const id=task.id||JSON.stringify([task.center,task.part,task.kind,task.recipient,task.text]);
  if(seen.has(id))return false;seen.add(id);return true;
 });
}
function taskText(task){
 const text=str(task.text),schedule=str(task.scheduleNote);
 return text+(schedule&&!text.includes(schedule)?' · '+schedule:'');
}
function isShared(task){return task.center==='공통'||task.center==='COMMON'||task.center==='Common'||!task.center}
function datesText(value){
 if(value==null)return '';
 if(Array.isArray(value))return unique(value.map(datesText).filter(Boolean)).join(', ');
 if(typeof value==='object')return Object.entries(value).map(([key,item])=>
  (({stock:'센터 재고',need:'현 수리 필요 수',wip:'WIP',po:'상세 PO',india:'법인 재고',hq:'본사 재고',Flex:'Flex 소요',CTDI:'CTDI 소요'}[key]||key)+': '+(datesText(item)||'미확인'))).join(' · ');
 return str(value);
}
function model(columns,objects,extra={}){
 return {columns,headers:columns.map(item=>item.label),rows:objects.map(row=>columns.map(item=>row[item.key]??null)),
  partCount:new Set(objects.map(row=>row.part).filter(Boolean)).size,notes:[],...extra};
}
function summary({groups=[],tasks=[],nameFor=defaultName,monthlyValue=defaultMonthly,recipient='all',sourceDates={}}={}){
 const selected=selectTasks(tasks,recipient),objects=[],includedTasks=new Map();
 for(const group of groups){
  const part=group.part,partTasks=selected.filter(task=>task.part===part),members=[...(group.members||[])];
  // A part can have a different action at another center hidden by the card.
  // Keep that action with its own center's evidence, never another row's stock.
  for(const task of partTasks)if(!isShared(task)&&task.row&&!members.some(row=>row.center===task.center))
   members.push({...task.row,center:task.center,part});
  const shared=partTasks.filter(isShared),scoped=members.filter(row=>recipient==='all'||
   partTasks.some(task=>!isShared(task)&&task.center===row.center));
  // A common long-L/T action has no center quantity. Never borrow the first
  // center's proposed PO as though it were an HQ procurement request.
  if(!scoped.length&&shared.length)scoped.push({part,center:'공통',india:shared[0].row?.india,hq:shared[0].row?.hq});
  for(const [index,row] of scoped.entries()){
   const matching=partTasks.filter(task=>!isShared(task)&&task.center===row.center);
   if(index===0)matching.push(...shared);
   for(const task of matching)includedTasks.set(task.id||JSON.stringify(task),task);
   const taskDates=Object.assign({},...matching.map(task=>task.sourceDates||{}));
   const upstreamDate=key=>Object.prototype.hasOwnProperty.call(taskDates,key)?taskDates[key]:sourceDates[key]??null;
   const labels=unique(matching.map(task=>recipientLabel(task.recipient))),action=matching.map(task=>
    '['+(isShared(task)?'공통 · ':'')+recipientLabel(task.recipient)+'] '+taskText(task)).join('\n');
   objects.push({part,name:nameFor(part,row.center),center:row.center,stock:quantity(row.stock),
    // Shared stock is shown once per part, not summed once per center.
    india:index===0?quantity(row.india):null,hq:index===0?quantity(row.hq):null,
    avg:known(row.avg)?monthlyValue(row.avg):null,needed:quantity(row.needed),totalRequired:totalRequired(row),
    shortage:quantity(row.shortage),ordered:quantity(row.poOrdered),pending:quantity(row.open),proposed:quantity(row.proposed),
    recipients:labels.join(' / '),action,sourceDates:datesText({stock:row.dashboardDate,need:row.needDate,po:row.poSourceDate,
     india:upstreamDate('india'),hq:upstreamDate('hq')})});
  }
 }
 return model([partColumn(),nameColumn(),centerColumn(),...stockColumns(),qtyColumn('avg','월평균 소요량'),
  qtyColumn('needed','현 수리 필요 수'),qtyColumn('totalRequired','총 필요수'),qtyColumn('shortage','수리분 부족수'),
  qtyColumn('ordered','PO 기발주 수'),qtyColumn('pending','PO 미입고 수'),qtyColumn('proposed','센터 추가 PO 필요수'),
  column('recipients','확인 대상'),column('action','필요 조치'),column('sourceDates','원본 기준일')],objects,
  {taskCount:includedTasks.size,taskIds:[...includedTasks.values()].map(task=>task.id),recipient,
   notes:['선택 부품의 센터별 내역·병행 조치 포함','법인·본사 재고는 공용재고이며 부품 첫 행에만 표시합니다.','총 필요수는 현 수리 필요 수와 설정 보유분의 합계입니다.','조치는 확인 대상별 업무이며 지연 귀책 판정이 아닙니다.']});
}
function followups({tasks=[],nameFor=defaultName,recipient='all'}={}){
 const selected=selectTasks(tasks,recipient),objects=selected.map(task=>{const row=task.row||{};return {
  part:task.part,name:nameFor(task.part,task.center),center:task.center||'공통',recipient:recipientLabel(task.recipient),
  action:taskText(task),stock:quantity(row.stock),india:quantity(row.india),hq:quantity(row.hq),
  needed:quantity(row.needed),pending:quantity(row.open),proposed:quantity(row.proposed),
  overdueProducts:quantity(task.tat?.overdueProducts),sourceDates:datesText(task.sourceDates)
 }});
 return model([partColumn(),nameColumn(),centerColumn(),column('recipient','확인 대상'),column('action','필요 조치'),
  ...stockColumns(),qtyColumn('needed','현 수리 필요 수'),qtyColumn('pending','PO 미입고 수'),qtyColumn('proposed','센터 추가 PO 필요수'),
  column('overdueProducts','45일 초과 제품(대)',{unit:'products'}),column('sourceDates','원본 기준일')],objects,
  {taskCount:selected.length,taskIds:selected.map(task=>task.id),recipient,
   notes:['한 부품에 여러 조치가 있을 수 있으므로 조치 행의 재고·수량·제품 대수를 합산하지 않습니다.','조치는 확인 대상별 업무이며 지연 귀책 판정이 아닙니다.']});
}
function entries(row){return Array.isArray(row.partEntries)?row.partEntries:[]}
function wipParts({rows=[],nameFor=defaultName}={}){
 const grouped=new Map();
 for(const row of rows)for(const entry of entries(row)){
  if(!entry.part||!known(entry.quantity)||entry.quantity===0)continue;
  const key=JSON.stringify([row.center,entry.part]);
  if(!grouped.has(key))grouped.set(key,{part:entry.part,center:row.center,quantity:0,days0_30:0,days31_45:0,days46_90:0,
   days91_180:0,days181plus:0,unknownAge:0,overdue:0,operators:new Set(),dates:new Set()});
  const group=grouped.get(key),field=({DAY0:'days0_30',D1_30:'days0_30',D31_45:'days31_45',D46_90:'days46_90',D91_180:'days91_180',D181_PLUS:'days181plus'}[row.bucket]||'unknownAge');
  group.quantity+=entry.quantity;group[field]+=entry.quantity;
  if(row.overdue===true)group.overdue+=entry.quantity;
  group.operators.add(row.operator);group.dates.add(row.wipDate||row.date||'기준일 미확인');
 }
 const objects=[...grouped.values()].sort((a,b)=>b.overdue-a.overdue||b.quantity-a.quantity||str(a.center).localeCompare(str(b.center))||a.part.localeCompare(b.part))
  .map(group=>({...group,name:nameFor(group.part,group.center),operator:[...group.operators].map(value=>value==='Vi'?'Vodafone Idea':str(value)).join(' / '),
   sourceDates:[...group.dates].sort().join(' / ')}));
 const unresolved=rows.filter(row=>row.hasUnresolvedParts===true).length;
 const columns=[partColumn(),nameColumn(),centerColumn(),column('operator','사업자',{raw:true}),qtyColumn('quantity','현 수리 필요 수(개)'),
  qtyColumn('days0_30','0~30일(개)'),qtyColumn('days31_45','31~45일(개)'),qtyColumn('days46_90','46~90일(개)'),
  qtyColumn('days91_180','91~180일(개)'),qtyColumn('days181plus','181일 이상(개)'),qtyColumn('overdue','45일 초과 합계(개)')];
 if(objects.some(row=>row.unknownAge>0))columns.push(qtyColumn('unknownAge','날짜 확인 필요(개)'));
 columns.push(column('sourceDates','WIP 기준일'));
 return model(columns,objects,{productCount:rows.length,unresolvedProducts:unresolved,
  unitCount:objects.reduce((sum,row)=>sum+row.quantity,0),quantityComplete:unresolved===0,
  notes:['수량은 재고 차감 전 필요 부품 개수이며 제품 대수가 아닙니다.','45일 초과 합계는 46~90일·91~180일·181일 이상 수량의 합계이며 다시 더하지 않습니다.',
   ...(unresolved?['필요 부품 확인 필요: '+unresolved+'대','필요 부품을 해석하지 못한 제품은 제품 목록에 남기며 이 표의 부품 수량에 추정해 더하지 않습니다.']:[])]});
}
function wipProducts({rows=[],nameFor=defaultName}={}){
 const objects=rows.map(row=>({center:row.center,operator:row.operator==='Vi'?'Vodafone Idea':row.operator,
  category:row.repairCategory==='FAN'?'FAN':row.repairCategory==='GENERAL'?'일반 제품':'구분 확인',sn:row.sn,rma:row.rma,fert:row.fert,
  receipt:row.physicalDate||row.receipt||null,sourceDate:row.wipDate||row.date||null,age:quantity(row.ageDays??row.age),
  required:entries(row).map(entry=>entry.part+' × '+entry.quantity).join(' / '),
  rawRequired:row.required,unparsed:row.tokens?.unparsed||'',
  check:row.hasUnresolvedParts?'필요 부품 확인 필요':'',source:row.source,sheet:row.sheet,row:row.row}));
 const columns=[centerColumn(),column('operator','사업자',{raw:true}),column('category','수리 제품 구분'),
  column('sn','SN',{raw:true}),column('rma','RMA',{raw:true}),column('fert','제품 코드',{raw:true}),
  column('receipt','Physical Receipt Date',{raw:true}),column('sourceDate','WIP 기준일',{raw:true}),column('age','입고 경과일',{unit:'days'}),
  column('required','필요 부품 · 개수',{raw:true}),column('rawRequired','Required Part 원문',{raw:true}),column('unparsed','미해석 내용',{raw:true}),
  column('check','확인사항'),column('source','원본',{raw:true}),column('sheet','시트',{raw:true}),column('row','행',{raw:true})];
 return model(columns,objects,{partCount:new Set(rows.flatMap(row=>entries(row).map(entry=>entry.part))).size,
  productCount:rows.length,unresolvedProducts:rows.filter(row=>row.hasUnresolvedParts===true).length,
  notes:[...(rows.some(row=>row.hasUnresolvedParts)?['필요 부품 확인 필요: '+rows.filter(row=>row.hasUnresolvedParts).length+'대']:[]),'제품당 한 행이며 여러 필요 부품은 같은 행에 표시합니다.','입고 경과일은 각 WIP 원본 기준일에서 Physical Receipt Date를 뺀 값입니다.']});
}
// Trace exports keep product observations separate from PO rows. A shared part
// does not create a product-to-order assignment or multiply order quantities.
function wipTraceProducts({rows=[],part='',traceFor=()=>null}={}){
 const objects=rows.map(row=>{const trace=traceFor(row)||{},age=quantity(row.ageDays??row.age);return {
  part,center:row.center,operator:row.operator==='Vi'?'Vodafone Idea':row.operator,sn:row.sn,rma:row.rma,fert:row.fert,
  needed:quantity(row.partQuantity??entries(row).find(entry=>entry.part===part)?.quantity??row.tokens?.parts?.[part]),
  receipt:row.physicalDate||row.receipt||null,sourceDate:row.wipDate||row.date||null,age,
  alert:age===null?'날짜 확인 필요':age>=45?'45일 이상 Alert':'45일 미만',
  observation:trace.firstSeenDate?(trace.baselinePresent?'최초 자료부터 대기':'주간 자료에서 최초 확인'):'이력 미확인',
  firstWeek:trace.firstSeenWeek||null,firstDate:trace.firstSeenDate||null,firstAge:quantity(trace.firstSeenAgeDays),
  previousAbsent:trace.priorObservedWithoutDate||null,observations:quantity(trace.observationCount),
  currentEpisode:trace.episodeStartDate||null,continuity:trace.continuityUncertain?'중간 관찰 공백 있음':'',
  status:row.status,rawRequired:row.required,unparsed:row.tokens?.unparsed||'',source:row.source,sheet:row.sheet,row:row.row
 }});
 return model([partColumn(),centerColumn(),column('operator','사업자',{raw:true}),column('sn','SN',{raw:true}),column('rma','RMA',{raw:true}),
  column('fert','제품 코드',{raw:true}),qtyColumn('needed','이 부품 현 수리 필요 수(개)'),column('receipt','Physical Receipt Date',{raw:true}),
  column('sourceDate','WIP 기준일',{raw:true}),column('age','현재 TAT',{unit:'days'}),column('alert','TAT Alert'),
  column('observation','최초 관찰 구분'),column('firstWeek','최초 관찰 주차',{raw:true}),column('firstDate','최초 관찰일',{raw:true}),
  column('firstAge','최초 관찰 당시 TAT',{unit:'days'}),column('previousAbsent','이전 자료에서 미관찰한 날짜',{raw:true}),
  column('observations','관찰 횟수'),column('currentEpisode','이번 대기 첫 관찰',{raw:true}),column('continuity','이력 확인사항'),
  column('status','원본 상태',{raw:true}),column('rawRequired','Required Part 원문',{raw:true}),column('unparsed','미해석 내용',{raw:true}),
  column('source','원본',{raw:true}),column('sheet','시트',{raw:true}),column('row','행',{raw:true})],objects,
  {productCount:rows.length,notes:['제품별 해당 부품 한 행이며 PO와 제품을 임의 연결하지 않습니다.',
   '최초 관찰은 처음 받은 WIP에서 확인한 시점이며 실제 부품 필요 발생일이 아닙니다. TAT는 각 WIP 원본 기준일 − Physical Receipt Date입니다.',
   '45일째부터 Alert · 기존 45일 초과 합계는 46일째부터 집계합니다.',
   '최초 자료부터 대기 중인 제품은 그 이전 발생 시점을 알 수 없습니다. 자료 누락·목록에서 사라짐만으로 수리 완료를 확정하지 않습니다.']});
}
function wipTracePO({part='',center='',po={},nameFor=defaultName}={}){
 const objects=(po.rows||[]).map(row=>({part,center,name:nameFor(part,center),po:row.po,item:row.item,
  poDate:row.poDate,poAgeDays:quantity(row.poAgeDays),ordered:quantity(row.ordered),shipped:quantity(row.shipped),pending:quantity(row.pending),
  etd:row.etd||null,sourceDate:row.sourceDate||row.date||po.sourceDate||null,source:row.source||po.sourceFile||'',sheet:row.sheet,row:row.row}));
 return model([partColumn(),nameColumn(),centerColumn(),column('po','PO',{raw:true}),column('item','Item',{raw:true}),
  column('poDate','발주일',{raw:true}),column('poAgeDays','PO 경과일',{unit:'days'}),qtyColumn('ordered','주문(개)'),
  qtyColumn('shipped','Shipped · 법인 출고(개)'),qtyColumn('pending','Pending · 미처리 잔량(개)'),column('etd','법인 예정 출고일(ETD)',{raw:true}),
  column('sourceDate','PO 원본 기준일',{raw:true}),column('source','원본',{raw:true}),column('sheet','시트',{raw:true}),column('row','행',{raw:true})],objects,
  {notes:[!po.reportAvailable?'상세 PO 자료 없음 · 발주 여부를 확정하지 않습니다.':!objects.length?'현재 상세 PO 목록에 해당 부품 없음 · 계산 PO 미입고 수와 함께 확인하세요.':'같은 센터·부품의 PO를 모두 표시합니다. 특정 제품에 배정된 주문은 확인되지 않았습니다.',
   'PO 경과일은 PO 원본 기준일에서 발주일을 뺀 값입니다.',
   'Shipped는 법인 출고이며 센터 입고 완료를 뜻하지 않습니다. ETD는 법인→센터 예정 출고일입니다.',
   '대시보드 PO 미입고 수와 더하지 않습니다.']});
}
return {RECIPIENTS,summary,followups,wipParts,wipProducts,wipTraceProducts,wipTracePO};
});
