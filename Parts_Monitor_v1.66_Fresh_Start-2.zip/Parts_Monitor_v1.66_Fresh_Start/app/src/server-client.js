(function(root,factory){if(typeof module==='object'&&module.exports)module.exports=factory();else root.PartsServerClient=factory()})(typeof self!=='undefined'?self:this,function(){'use strict';
function shouldDeferRefresh({dirty=false,stagedCount=0,issueCount=0,pending=false,busy=false,formDirty=false,focused=false,dialogOpen=false}={}){return !!(dirty||stagedCount||issueCount||pending||busy||formDirty||focused||dialogOpen)}
function create(options={}){
 const boot=options.boot||{},fetcher=options.fetch||globalThis.fetch.bind(globalThis);
 let revision=Number(boot.revision)||0,updatedAt=boot.updatedAt||null,csrfToken=boot.csrfToken||null,authenticated=boot.noPasswordRequired===true||!!boot.authenticated,rawCount=Number(boot.rawCount)||0;
 const uploaded=new WeakMap();
 async function request(path,options={},retried=false){
  const mutating=options.method&&options.method!=='GET',headers={...(options.headers||{})};
  if(mutating){headers['X-Parts-Request']='1';if(csrfToken)headers['X-CSRF-Token']=csrfToken}
  let response;
  try{response=await fetcher(path,{...options,headers,credentials:'same-origin',cache:'no-store'})}
  catch(_){const error=Error('서버에 연결하지 못했습니다. 연결 후 다시 저장하세요.');error.code='NETWORK';throw error}
  let data;
  try{data=await response.json()}
  catch(_){const error=Error('서버 응답을 확인하지 못했습니다. 저장 상태를 확인한 뒤 다시 시도하세요.');error.status=response.status;throw error}
  if(!response.ok){
   // The write was rejected before mutation. A restart changes CSRF, not our editing revision.
   if(response.status===403&&(data.code||data.error?.code)==='SESSION_REFRESH_REQUIRED'&&mutating&&!retried){await session();return request(path,options,true)}
   const error=Error(typeof data.error==='string'?data.error:data.error?.message||data.message||'서버 저장을 완료하지 못했습니다.');error.status=response.status;error.code=data.code||data.error?.code;throw error;
  }
  return data;
 }
 function accept(data){if(Number.isInteger(data.revision))revision=data.revision;if(data.updatedAt!==undefined)updatedAt=data.updatedAt;if(data.rawCount!==undefined)rawCount=data.rawCount;return data}
 async function session(){const data=await request('/api/session');csrfToken=data.csrfToken||null;authenticated=data.noPasswordRequired===true||!!data.authenticated;return data}
 async function commit(state,{rawFiles=[],operation='settings',reportDate}={}){
  const baseRevision=revision,files=[...new Set(rawFiles)];
  for(let attempt=0;attempt<2;attempt++){
   const rawIds=[];
   try{
    for(const file of files){let saved=uploaded.get(file);if(!saved){saved=await request('/api/raw',{method:'POST',headers:{'Content-Type':'application/octet-stream','X-File-Name':encodeURIComponent(file.name)},body:file});uploaded.set(file,saved)}rawIds.push(saved.id)}
    const data=await request('/api/commit',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({state,baseRevision,rawIds,operation,reportDate})});
    if(!data.state||!Number.isInteger(data.revision))throw Error('서버 저장 응답에 데이터 또는 저장 번호가 없습니다.');
    return accept(data);
   }catch(error){for(const file of files)uploaded.delete(file);if(attempt===0&&files.length&&error.code==='RAW_NOT_STAGED')continue;throw error}
  }
 }

 return {request,session,commit,accept,status:()=>request('/api/status'),read:()=>request('/api/state'),load:async()=>accept(await request('/api/state')),get revision(){return revision},get updatedAt(){return updatedAt},get rawCount(){return rawCount},get authenticated(){return authenticated}};
}
return {create,shouldDeferRefresh};
});
// Presentation strings are registered only in fixed-address pages.
(function(){if(typeof PartsI18n==='undefined')return;PartsI18n.extend([
 ['공유 대시보드','Shared dashboard'],['사용 안내 · 새로 시작 · 매주 자료 넣기','User guide / start fresh / weekly uploads'],['사용 안내','User guide'],['새로 시작 · 매주 자료 넣기','Start fresh / weekly uploads'],['새 자료 올리기','Upload new sources'],['마지막 설정 탭에서 확인하고 변경할 수 있습니다.','Review and change these in the last Settings tab.'],['다른 담당자가 새 결과를 저장했습니다. 작성 중인 내용은 유지됩니다. 최신 결과를 불러온 뒤 다시 반영하세요.','Another updater saved a new result. Your pending edits are preserved. Load the latest result before applying changes.'],

 ['자료 담당자가 원본을 반영하면 최신 결과가 표시됩니다.','The latest result appears after an updater applies the source files.'],['확인한 운영 방식과 다음 조치를 기록하면 서버에 저장됩니다.','Record the confirmed operating approach and next actions; they are saved on the server.'],['자료 기준일과 서버 저장일은 다릅니다.','Source dates differ from the server save date.'],['팀원에게 이 주소를 공유하세요','Share this address with your team'],['주소 복사','Copy address'],['팀원은 같은 주소를 즐겨찾기해 사용합니다. 서버 PC와 실행 창은 켜 두세요.','Team members can bookmark this same address. Keep the server PC and its running window on.'],['주소를 복사했습니다. 팀원에게 전달하세요.','Address copied. Share it with your team.'],['자동 복사가 차단되었습니다. 표시된 주소를 직접 복사해 주세요.','Automatic copying was blocked. Copy the displayed address manually.'],['아직 저장 전','Not saved yet'],['저장 중…','Saving…'],['연결 끊김 · 마지막 저장 결과 표시','Disconnected · Showing the last saved result'],['마지막 저장','Last saved'],['다시 저장','Retry save'],['변경 취소','Cancel change'],['최신 결과 불러오기','Load latest result'],
 ['서버에 저장 중입니다. 이 창을 닫지 마세요.','Saving to the server. Keep this window open.'],['다른 담당자가 새 결과를 저장했습니다. 최신 결과를 불러온 뒤 다시 반영하세요. 현재 작성 중인 내용은 아직 저장되지 않았습니다.','Another updater saved a new result. Load the latest result before applying changes. Your current edits have not been saved.'],['저장하지 못했습니다.','Save unsuccessful.'],['기존 저장 결과는 유지됩니다. 선택한 파일과 변경 내용은 이 창에 남아 있습니다.','The saved result is unchanged. Selected files and pending changes remain in this window.'],
 ['최신 결과를 먼저 불러오세요. 다른 담당자의 저장 결과를 덮어쓰지 않습니다.','Load the latest result first. Another updater’s saved result will not be overwritten.'],['서버에 저장했습니다. 조회 화면도 자동 갱신됩니다.','Saved to the server. Viewer screens update automatically.'],['다른 저장 결과가 있습니다. 최신 결과를 불러오세요.','A newer saved result exists. Load it first.'],['저장을 완료하지 못했습니다. 다시 저장할 수 있습니다.','Save did not complete. You can retry.'],['저장하지 못한 변경을 먼저 다시 저장하거나 취소해 주세요.','Retry or cancel the pending change first.'],['작성 중인 변경과 선택한 파일을 취소하고 최신 결과를 불러올까요?','Discard pending edits and selected files and load the latest result?'],['최신 저장 결과를 불러왔습니다.','Latest saved result loaded.'],
 ['이번 원본을 선택하고 반영하면 끝입니다. 같은 주소에서 팀원이 최신 결과를 확인합니다.','Select this update’s source files and apply. Your team sees the latest result at this same address.'],['서버 저장 완료','Saved to server'],['보관 원본','Archived originals'],['원본·주간 이력·설정을 서버에 보관했습니다. 팀원 화면은 자동 갱신됩니다.','Originals, weekly history and settings are stored on the server. Viewer screens update automatically.'],['이번에 받은 Excel을 여기에 놓으세요','Drop the new Excel files here'],['Excel 파일 놓기','Drop Excel files'],['여러 파일을 한 번에 넣어도 됩니다. 파일 이름은 바꾸지 않아도 됩니다.','You can add several files at once. No need to rename them.'],['Excel 파일 선택','Select Excel files'],['폴더 선택','Select folder'],['이번에 올리지 않은 자료는 기존 자료와 실제 날짜를 유지합니다. 재고 수량을 지난주에 더하지 않습니다.','Sources not uploaded retain their previous data and actual dates. Stock quantities are not added to last week.'],['자동 인식 보완 · 필요할 때만','Recognition options · Only if needed'],['같은 주 정정은 갱신, 다음 주는 이력 추가','Same week: correction · Next week: new history'],['보고일 변경 · 지난 보고 정정','Change report date / correct a past report'],['보고를 기록할 날짜이며 원본 날짜는 바꾸지 않습니다.','This is the date of the report; source dates are unchanged.'],
 ['백업 · 복원 · 저장 이력','Backup / restore / save history'],['평소에는 다운로드할 필요가 없습니다. 담당 PC 이전이나 별도 백업 시 사용하세요.','No routine download is needed. Use this when moving the server PC or making a separate backup.'],['전체 백업 받기','Download full backup'],['저장 이력 보기','View save history'],['기존 JSON 데이터 가져오기','Import existing JSON data'],['기존 운영 데이터의 이력·설정·메모를 가져옵니다. 현재 서버 상태는 이전 버전으로 보관되며, 원본 Excel 자체는 JSON에 들어 있지 않습니다.','Import history, settings and notes from existing data. The current server state is retained as a prior version. Original Excel files are not included in JSON.'],['복원할 JSON 하나 선택','Select one JSON backup'],
 ['아직 저장되지 않은 변경을 취소할까요?','Cancel the change that has not been saved?'],['여기에는 Excel 파일만 넣어 주세요. JSON 복원은 아래 백업·복원 메뉴를 사용하세요.','Drop Excel files here. Use the Backup / restore section below for JSON restore.'],['저장 번호','Save number'],['저장 시각','Saved at'],['변경 종류','Change type'],['자료 반영','Source update'],['기존 자료 주간 기록','Week recorded with existing sources'],['설정 변경','Settings change'],['메모 변경','Notes change'],['데이터 복원','Data restore'],['원본 제외','Source excluded'],['최초 등록','Initial data'],['원본 파일','Original file'],['크기','Size'],['받기','Download'],
 ['자료 반영을 완료했습니다. 같은 주소에서 최신 결과를 확인하세요.','Update complete. View the latest result at this same address.'],['3. 확인한 자료를 반영하세요','3. Apply the reviewed sources'],['이번 주 자료 반영','Apply this week’s sources'],['계산·검증 후 서버에 원본과 주간 이력을 함께 보관합니다. 저장이 완료되면 모든 조회 화면이 자동 갱신됩니다.','After calculation and validation, originals and weekly history are saved together on the server. Viewer screens update after a successful save.'],['새로 반영할 자료가 없습니다. 저장된 결과는 그대로입니다. 새 주를 기존 자료로 기록하려면 ‘반영 취소’ 후 ‘새 자료가 없는 주도 기록하려면’을 여세요.','No new source to apply. The saved result is unchanged. To record a new week with existing sources, cancel the import and open “Record a week without new data”.'],
 ['각 항목의 반영 버튼을 누르면 서버에 저장됩니다.','Each Apply button saves the change to the server.'],['자료 담당자가 원본을 반영하면 이 화면에 표시됩니다.','Results appear here after an updater applies the source files.'],['장납 표시를 저장했습니다.','Long-L/T flag saved.'],['확인 기록을 저장했습니다.','Follow-up note saved.'],['이 주간에서 원본을 제외했습니다.','Source excluded from this reporting week.'],['JSON의 데이터·이력·설정으로 현재 결과를 바꿀까요? 현재 서버 상태는 이전 버전으로 보관됩니다.','Replace the current result with this JSON’s data, history and settings? The current server state will be retained as a prior version.'],['데이터 백업을 복원했습니다.','Data backup restored.'],['백업 복원을 취소했습니다.','Backup restore cancelled.'],
 ['서버에 연결하지 못했습니다. 연결 후 다시 저장하세요.','Could not connect to the server. Reconnect and retry saving.'],['서버 응답을 확인하지 못했습니다. 저장 상태를 확인한 뒤 다시 시도하세요.','Could not confirm the server response. Check the save status before retrying.'],['서버 저장을 완료하지 못했습니다.','Could not complete the server save.']
]);})();
