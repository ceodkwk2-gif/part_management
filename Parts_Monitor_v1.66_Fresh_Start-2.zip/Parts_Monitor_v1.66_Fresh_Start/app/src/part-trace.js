(function(root,factory){
 const api=factory(typeof module==='object'&&module.exports?require('./workflow.js'):root.PartsWorkflow,()=>typeof module==='object'&&module.exports?require('./action-requests.js'):root.PartsActionRequests);
 if(typeof module==='object'&&module.exports)module.exports=api;
 else root.PartsPartTrace=api;
})(typeof self!=='undefined'?self:this,function(W,statusAPI){
'use strict';
const str=v=>v==null?'':String(v),num=v=>typeof v==='number'&&Number.isFinite(v),en=l=>/^en/i.test(l||'');
const esc=v=>str(v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const text=(l,ko,eng)=>en(l)?eng:ko,number=v=>num(v)?v.toLocaleString('en-US',{maximumFractionDigits:1}):'—';
const scope=c=>!c||c==='전체'?'ALL':c,unique=a=>[...new Set(a.filter(v=>v!==''&&v!=null))];
function validDate(v){if(!/^\d{4}-\d{2}-\d{2}$/.test(str(v)))return false;const d=new Date(v+'T00:00:00Z');return !isNaN(d)&&d.toISOString().slice(0,10)===v;}
function days(from,to){return validDate(from)&&validDate(to)?Math.round((Date.parse(to+'T00:00:00Z')-Date.parse(from+'T00:00:00Z'))/86400000):null;}
const displayDate=(v,l)=>validDate(v)?v:text(l,'미확인','Unknown');
function selectedRows({data={},part,rowId,center='ALL',rowIds}={}){
 const ids=Array.isArray(rowIds)?new Set(rowIds):null;
 return (data.rows||[]).filter(r=>(!part||r.part===part)&&(!rowId||r.id===rowId)&&(scope(center)==='ALL'||r.center===scope(center))&&(!ids||ids.has(r.id)));
}
function noteFor(notes,row){return notes?.[row?.id]||{};}
function sourceLabel(row,l){return [row.source||'',row.sheet||'',row.row!=null?text(l,'행 ','row ')+row.row:''].filter(Boolean).join(' · ');}
function orderFacts(po,product){
 const tatAtOrder=days(product.receipt,po.poDate),futureOrder=validDate(po.poDate)&&validDate(product.date)&&po.poDate>product.date;
 return {...po,tatAtOrder,afterWipDate:futureOrder,sourceAfterWip:validDate(po.date)&&validDate(product.date)&&po.date>product.date,allocatedToProduct:false};
}
function buildRows(options={}){
 const {data={},part,rowId,center='ALL',overdueOnly=false,notes={},rowIds}=options,selected=selectedRows(options),rowMap=new Map(selected.map(r=>[r.id,r])),ids=Array.isArray(rowIds)?new Set(rowIds):null;
 const chosenCenter=rowId?rowId.split('|')[0]:scope(center),out=[],seen=new Set();
 for(const [i,p] of (data.products||[]).entries()){
  if(chosenCenter!=='ALL'&&p.center!==chosenCenter||overdueOnly&&!(num(p.age)&&p.age>45))continue;
  const productId=p.id||JSON.stringify([p.center,p.operator,p.sn,p.rma,p.receipt,i]);
  if(seen.has(productId))continue;seen.add(productId);
  const entries=new Map();
  for(const entry of p.parts||[]){
   if(!entry.part||part&&entry.part!==part||rowId&&p.center+'|'+entry.part!==rowId||ids&&!ids.has(p.center+'|'+entry.part))continue;
   if(!entries.has(entry.part))entries.set(entry.part,{...entry});
   else {const previous=entries.get(entry.part);previous.quantity=num(previous.quantity)&&num(entry.quantity)?previous.quantity+entry.quantity:null;}
  }
  // A product with an unparsed part remains in whole-WIP exports. Never invent a code or quantity.
  if(!part&&!rowId&&!ids&&(p.hasUnresolvedParts||p.unparsed||!(p.parts||[]).length))entries.set('',{part:'',quantity:null,unparsed:true});
  for(const entry of entries.values()){
   const id=p.center+'|'+entry.part,row=rowMap.get(id)||(data.rows||[]).find(r=>r.id===id),note=noteFor(notes,row);
   const firstDate=validDate(entry.firstDate)?entry.firstDate:null,firstAge=num(entry.firstAge)?entry.firstAge:days(p.receipt,firstDate);
   const elapsed=days(firstDate,p.date),episodeElapsed=days(entry.episodeStartDate,p.date);
   const relatedPOs=(data.pos||[]).filter(po=>po.center===p.center&&po.part===entry.part).map(po=>orderFacts(po,p));
   const supplierOrders=(data.siel?.rows||[]).filter(po=>po.part===entry.part).map(po=>({...po,shared:true,allocatedToCenter:false,afterWipDate:validDate(po.sourceDate)&&validDate(p.date)&&po.sourceDate>p.date}));
   out.push({productId,rowId:id,center:p.center,operator:p.operator||'',sn:p.sn||'',rma:p.rma||'',fert:p.fert||'',fan:!!p.fan,
    part:entry.part,partName:row?.name||'',quantity:num(entry.quantity)?entry.quantity:null,unparsed:!!entry.unparsed,required:p.required||'',
    receipt:validDate(p.receipt)?p.receipt:null,wipDate:validDate(p.date)?p.date:null,tat:num(p.age)?p.age:null,excessDays:num(p.age)?Math.max(0,p.age-45):null,
    firstDate,firstWeek:entry.firstWeek||entry.firstReportWeek||null,firstAge:num(firstAge)&&firstAge>=0?firstAge:null,observedDays:elapsed!==null&&elapsed>=0?elapsed:null,
    traceKey:entry.traceKey||null,autoFirstDate:validDate(entry.autoFirstDate)?entry.autoFirstDate:entry.manualFirstConfirmedDate?null:firstDate,autoFirstAge:num(entry.autoFirstAge)?entry.autoFirstAge:entry.manualFirstConfirmedDate?null:firstAge,
    manualFirstConfirmedDate:validDate(entry.manualFirstConfirmedDate)?entry.manualFirstConfirmedDate:null,manualFirstConfirmedNote:str(entry.manualFirstConfirmedNote),firstConfirmedSource:str(entry.firstConfirmedSource),firstConfirmedConflict:!!entry.firstConfirmedConflict,firstConfirmedIssues:entry.firstConfirmedIssues||[],
    baseline:!!entry.baseline,priorWithoutDate:validDate(entry.priorWithoutDate)?entry.priorWithoutDate:null,continuityUncertain:!!entry.continuityUncertain,
    episodeStartDate:validDate(entry.episodeStartDate)?entry.episodeStartDate:null,episodeObservedDays:episodeElapsed!==null&&episodeElapsed>=0?episodeElapsed:null,
    episodeIndex:entry.episodeIndex??null,observations:entry.observations??null,relatedPOs,supplierOrders,
    stock:row?.stock??null,india:row?.india??null,hq:row?.hq??null,needed:row?.needed??null,shortage:row?.shortage??null,open:row?.open??null,proposed:row?.proposed??null,
    confirmedEta:note.eta||'',plan:note.plan||'',source:p.source||'',sheet:p.sheet||'',row:p.row??null,
    taskIds:row?.taskIds||[],liabilityConfirmed:false,poAllocationConfirmed:false});
  }
 }
 return out.sort((a,b)=>(b.tat??-1)-(a.tat??-1)||a.center.localeCompare(b.center)||a.sn.localeCompare(b.sn)||a.part.localeCompare(b.part));
}
function manualApplied(r){return /^manual$/i.test(str(r.firstConfirmedSource));}
function confirmationText(r,l){
 if(!r.manualFirstConfirmedDate)return '';
 return [manualApplied(r)?text(l,'수기 확인일 적용','Manually confirmed date applied'):text(l,'수기 입력일 검토 필요 ','Manual date requires review ')+displayDate(r.manualFirstConfirmedDate,l),text(l,'WIP 최초 관찰 ','First observed in WIP ')+displayDate(r.autoFirstDate,l),r.manualFirstConfirmedNote?text(l,'근거: ','Evidence: ')+r.manualFirstConfirmedNote:'',r.firstConfirmedConflict?text(l,'수기 입력과 WIP 관찰 근거 불일치 · 확인 필요','Manual date conflicts with WIP evidence · review needed'):''].filter(Boolean).join(' · ');
}
function observationText(r,l){
 if(r.unparsed)return text(l,'부품 표기 확인 필요','Part notation needs review');
 if(r.manualFirstConfirmedDate)return [confirmationText(r,l),text(l,'실제 발생일·지연 귀책을 확정하지 않음','Does not establish actual onset or delay responsibility'),r.episodeIndex>1?text(l,'재등장 · 이번 자료에서 다시 확인 ','Reappeared · observed again on ')+displayDate(r.episodeStartDate,l):'',r.continuityUncertain?text(l,'중간 관찰 공백 있음','Observation gaps exist'):''].filter(Boolean).join(' · ');
 const base=r.baseline?text(l,'첫 보유자료부터 대기 · 실제 시작일 미확인','Already waiting in earliest available record · actual onset unknown'):r.firstDate?text(l,r.priorWithoutDate?'이전 자료 대비 처음 확인 · 실제 시작일 미확인':'보유자료에서 처음 확인 · 실제 시작일 미확인',r.priorWithoutDate?'Newly observed since previous record · actual onset unknown':'First observed in available records · actual onset unknown'):text(l,'최초 부품대기 확인일 미확인','First observed parts-waiting date unknown');
 return [base,r.priorWithoutDate?text(l,'직전 자료 ','Previous record ')+r.priorWithoutDate+text(l,'에는 해당 부품 대기 기록 없음',' did not list this part as waiting'):'',r.episodeIndex>1?text(l,'재등장 · 이번 자료에서 다시 확인 ','Reappeared · observed again on ')+displayDate(r.episodeStartDate,l):'',r.continuityUncertain?text(l,'중간 관찰 공백 있음','Observation gaps exist'):''].filter(Boolean).join(' · ');
}
function orderText(po,l){
 const tat=po.tatAtOrder===null?text(l,'당시 TAT 미확인','TAT at PO unknown'):po.tatAtOrder<0?text(l,'제품 입고 전 ','Before product receipt ')+number(-po.tatAtOrder)+text(l,'일',' days'):'TAT '+number(po.tatAtOrder)+text(l,'일','d');
 return [po.po||text(l,'PO 번호 미확인','PO no. unknown'),displayDate(po.poDate,l)+' · '+tat,'Pending '+number(po.pending)+text(l,'개',' pcs'),'ETD '+(po.etd||text(l,'미정','not set')),po.afterWipDate?text(l,'WIP 기준일 이후 발주','Ordered after WIP date'):'',po.sourceAfterWip?text(l,'WIP 이후 PO 자료 참고','PO source later than WIP'):''].filter(Boolean).join(' · ');
}
function actionText(data,row,l){
 return statusAPI().build(data,{rowIds:[row.id],kind:'ALL',language:l}).rows[0]?.status||text(l,'센터 재고로 충당','Covered by center stock');
}
function table(headers,body,klass=''){return '<div class="pt-table-wrap"><table class="pt-table '+klass+'"><thead><tr>'+headers.map(x=>'<th>'+x+'</th>').join('')+'</tr></thead><tbody>'+body+'</tbody></table></div>';}
function productRows(rows,l){return rows.map(r=>'<tr>'+[
 '<b>'+esc(r.sn||'—')+'</b><span>'+esc([r.center,r.operator,r.fan?'FAN':text(l,'일반','General')].filter(Boolean).join(' · '))+'</span><span>RMA '+esc(r.rma||'—')+'</span>',
 '<b class="pt-tat-value '+(r.tat>45?'pt-danger':'')+'">'+number(r.tat)+text(l,'일',' days')+'</b>'+(r.excessDays>0?'<span class="pt-overdue">'+text(l,'45일 기준보다 ','Beyond 45-day limit: ')+number(r.excessDays)+text(l,'일 초과',' days')+'</span>':'')+'<span>'+text(l,'입고일 ','Receipt date ')+displayDate(r.receipt,l)+'</span><span>'+text(l,'WIP 기준일 ','WIP source date ')+displayDate(r.wipDate,l)+'</span>',
 '<b class="pt-observed-date">'+displayDate(r.firstDate,l)+(manualApplied(r)?' · '+text(l,'수기 확인','Manual confirmation'):'')+'</b><span class="pt-first-tat">'+text(l,'최초 확인 당시 제품 TAT ','Product TAT at first observation: ')+number(r.firstAge)+text(l,'일',' days')+'</span><span class="pt-observation">'+esc(observationText(r,l))+'</span>',
 '<b>'+text(l,'최초 확인 후 ','Since first observation: ')+number(r.observedDays)+text(l,'일',' days')+'</b>'+(r.episodeIndex>1?'<span>'+text(l,'다시 확인한 후 ','Since observed again: ')+number(r.episodeObservedDays)+text(l,'일',' days')+'</span>':'')+'<span>'+text(l,'자료 확인 횟수 ','Record observations: ')+number(r.observations)+'</span>',
 r.relatedPOs.length?r.relatedPOs.map(po=>'<div class="pt-po-trace"><b>'+esc(po.po||'—')+' · '+displayDate(po.poDate,l)+'</b><span>'+esc(orderText(po,l).split(' · ').slice(2).join(' · '))+'</span></div>').join(''):text(l,'관련 PO 내역 0건','0 related PO rows'),
 '<b>'+number(r.quantity)+text(l,'개',' pcs')+'</b>'
 ].map((cell,i)=>'<td data-label="'+esc([text(l,'제품','Product'),text(l,'제품 입고 후 경과일(TAT)','Days since product receipt (TAT)'),text(l,'최초 부품대기 확인일','First observed parts-waiting date'),text(l,'최초 확인 후 경과','Time since first observation'),text(l,'관련 센터 PO','Related center PO'),text(l,'필요 수','Quantity')][i])+'">'+cell+'</td>').join('')+'</tr>').join('');}
function historyHTML(rows,l){
 const headers=[text(l,'제품','Product'),text(l,'제품 입고 후 경과일(TAT)','Days since product receipt (TAT)'),text(l,'최초 부품대기 확인일','First observed parts-waiting date'),text(l,'최초 확인 후 경과','Time since first observation'),text(l,'관련 센터 PO · 발주 당시 제품 TAT','Related center PO / product TAT at PO'),text(l,'필요 수','Qty')],first=rows.slice(0,8),rest=rows.slice(8);
 return rows.length?table(headers,productRows(first,l),'pt-products')+(rest.length?'<details class="pt-more"><summary>'+text(l,'나머지 ','Show remaining ')+number(rest.length)+text(l,'건 보기',' rows')+'</summary>'+table(headers,productRows(rest,l),'pt-products')+'</details>':''):'<p class="pt-empty">'+text(l,'해당 부품이 기재된 현재 WIP 제품이 없습니다. 수리 가능 여부를 뜻하지 않습니다.','No current WIP product lists this part. This does not establish repair readiness.')+'</p>';
}
function stockHTML(data,rows,l,notes){
 const labels=[text(l,'센터','Center'),text(l,'법인','India'),text(l,'본사','HQ'),text(l,'월평균 소요량','Monthly use'),text(l,'현 수리 필요 수','Current repair need'),text(l,'현재 수리분 부족','Repair shortage'),text(l,'PO 기발주 수','PO ordered'),text(l,'PO 미입고 수','Open PO'),text(l,'추가 PO 필요 수','Additional PO')];
 return rows.map(r=>{const note=noteFor(notes,r),month=num(r.avg)?number(Math.ceil(r.avg)):'—';
  return '<section class="pt-center"><h3>'+esc(r.center)+' · '+esc(en(l)&&r.part==='명판'?'Name plate':r.name||r.part)+'</h3><div class="pt-facts">'+[r.stock,r.india,r.hq,month,r.needed,r.shortage,r.poOrdered,r.open,r.proposed].map((v,i)=>'<div><span>'+labels[i]+'</span><b>'+ (i===3?v:number(v)) +'</b></div>').join('')+'</div><p class="pt-action">'+esc(actionText(data,r,l))+'</p><div class="pt-plan"><div><b>'+text(l,'확인된 센터 입고 예정일','Confirmed center receipt ETA')+'</b><span>'+esc(note.eta||text(l,'미확인','Unknown'))+'</span></div><div><b>'+text(l,'확인 메모','Confirmation note')+'</b><span>'+esc([note.plan||text(l,'미기록','Not recorded'),...(W?.progressLines(note,l)||[])].join(' · '))+'</span></div><button type="button" data-pt-note="'+esc(r.id)+'">'+text(l,'확인 메모','Confirmation note')+'</button></div></section>';
 }).join('');
}
function centerPOHTML(data,rows,l){
 const ids=new Set(rows.map(r=>r.id)),pos=(data.pos||[]).filter(po=>ids.has(po.center+'|'+po.part));
 const cells=pos.map(po=>'<tr>'+[esc(po.center),'<b>'+esc(po.po||'—')+'</b><span>'+esc(po.item||'')+'</span>',displayDate(po.poDate,l),number(po.ordered),number(po.shipped),number(po.pending),esc(po.etd||text(l,'미정','Not set')),'<span>'+esc(sourceLabel(po,l))+'</span><span>'+esc(po.date||po.reportWeek&&po.reportWeek+text(l,' 주차',' week')||text(l,'기준일 미확인','Source date unknown'))+'</span>'].map(v=>'<td>'+v+'</td>').join('')+'</tr>').join('');
 return '<details class="pt-source"><summary>'+text(l,'센터 PO 원본 내역','Center PO source rows')+' · '+number(pos.length)+text(l,'건',' rows')+'</summary><p>'+text(l,'Shipped는 법인 출고량, ETD는 법인→센터 출고 예정일입니다. 실제 센터 입고일은 별도 확인해야 합니다.','Shipped is India dispatch quantity; ETD is planned India-to-center dispatch. Actual center receipt requires separate evidence.')+'</p>'+table([text(l,'센터','Center'),'PO',text(l,'발주일','PO date'),text(l,'기발주','Ordered'),text(l,'법인 출고','India shipped'),'Pending','ETD',text(l,'출처','Source')],cells||'<tr><td colspan="8">'+text(l,'관련 PO 내역 0건','0 related PO rows')+'</td></tr>','pt-orders')+'</details>';
}
function supplierStage(po,l){return po.eta?text(l,'도착 예정일 확인됨','Arrival date provided'):text(l,'도착 예정일 미정','Arrival date not set');}
function supplierText(po,l){
 return ['SIEL PO Report',po.po||text(l,'PO 번호 미확인','PO no. unknown'),displayDate(po.poDate,l),text(l,'발주 ','Ordered ')+number(po.ordered),text(l,'센터 배정 미확인','Center allocation unconfirmed'),supplierStage(po,l),text(l,'원본 ETA ','Source ETA ')+(po.eta||text(l,'미기재','not listed')),po.sourceDate?text(l,'원본 ','Source ')+po.sourceDate:'',po.demo?text(l,'데모 주차 ','Demo week ')+(po.reportWeek||'—'):'',po.afterWipDate?text(l,'WIP 이후 자료 참고','Source later than WIP'):''].filter(Boolean).join(' · ');
}
function supplierHTML(data,part,l){
 const pos=(data.siel?.rows||[]).filter(po=>!part||po.part===part),demo=!!data.siel?.demo||pos.some(po=>po.demo||validDate(po.sourceDate)&&validDate(data.asof)&&po.sourceDate>data.asof);
 const progress=po=>'<b>'+supplierStage(po,l)+'</b>';
 return '<details class="pt-source"><summary>'+text(l,'SIEL PO Report · 법인 입고 예정','SIEL PO Report / planned India receipt')+' · '+number(pos.length)+text(l,'건',' rows')+'</summary>'+(pos.length?'<p class="pt-allocation">'+text(l,'센터 배정 미확인','Center allocation unconfirmed')+'</p>':'')+'<p>'+text(l,'동일 부품의 법인 공용 주문입니다. Flex·CTDI 및 개별 제품별 배정 수량은 확인되지 않았습니다. ETA는 법인 입고 예정일이며 실제 입고 완료가 아닙니다.','These are shared India orders for the same part. Allocation quantities for Flex, CTDI and individual products are unconfirmed. ETA is planned India receipt, not confirmed receipt.')+'</p>'+(demo?'<p class="pt-notice">'+text(l,'데모 연결 자료 · 원본 날짜를 유지하며 당시 지연 원인으로 확정하지 않습니다.','Demo-linked records · Original dates are retained; these do not prove the historical cause of delay.')+'</p>':'')+table(['PO',text(l,'법인 발주일','India PO date'),text(l,'발주 수','Ordered'),text(l,'본사→법인 도착 예정일','HQ-to-India arrival date'),text(l,'원본 기준일·출처','Source date / source')],pos.map(po=>'<tr>'+[esc(po.po||'—'),displayDate(po.poDate,l),number(po.ordered),esc(po.eta||text(l,'도착 예정일 미정','Arrival date not set')),'<span>'+esc(po.sourceDate||text(l,'미확인','Unknown'))+'</span>'+(po.demo?'<span>'+text(l,'데모 주차 ','Demo week ')+esc(po.reportWeek||data.siel?.reportWeek||'—')+'</span>':'')+'<span>'+esc(sourceLabel(po,l))+'</span>'].map(x=>'<td>'+x+'</td>').join('')+'</tr>').join('')||'<tr><td colspan="5">'+text(l,'연결된 법인→본사 PO 자료 없음 · 발주 여부 미확인','No linked India-to-HQ PO data · order status unknown')+'</td></tr>','pt-supplier')+'</details>';
}
function render(options={}){
 const {data={},part,rowId,center='ALL',language='ko',notes={}}=options,l=language,rows=selectedRows(options),trace=buildRows(options),products=new Set(trace.map(r=>r.productId)).size,overdue=new Set(trace.filter(r=>r.tat>45).map(r=>r.productId)).size;
 return '<div class="pt-root" data-i18n-skip><header class="pt-header"><div><h2>'+esc(en(l)&&part==='명판'?'Name plate':part||text(l,'제품별 부품대기 이력','Product parts-waiting history'))+'</h2><p>'+esc(unique(rows.map(r=>r.center)).join(' / ')||scope(center))+' · '+number(products)+text(l,'대 대기',' products waiting')+' · '+text(l,'45일 초과 ','Over 45 days ')+number(overdue)+text(l,'대',' products')+'</p></div><div class="pt-tools"><button type="button" data-pt-download="TRACE">'+text(l,'제품 이력 다운로드','Download product history')+'</button><button type="button" data-pt-download="STOCK_PO">'+text(l,'재고·PO 현황 다운로드','Download stock / PO status')+'</button></div></header><section class="pt-history"><h3>'+text(l,'제품 입고 → 부품대기 확인 → 관련 발주','Product receipt → observed parts waiting → related orders')+'</h3><p class="pt-context">'+text(l,'제품 TAT는 입고일부터 WIP 기준일까지의 경과일입니다. 최초 부품대기 확인일은 보유자료에서 처음 대기를 확인한 날짜입니다. 첫 보유자료부터 대기한 경우 그 이전부터 대기했을 수 있습니다. 이전 자료 대비 처음 확인된 경우에도 실제 대기 시작일은 미확인입니다. 관련 PO는 센터·부품 기준으로 연결하며 제품별 배정은 미확인입니다.','Product TAT runs from physical receipt to the WIP source date. The first observed parts-waiting date is the earliest observation in available records. Waiting in the earliest available record may have begun earlier. Newly observed waiting since a previous record also has an unknown actual onset. Related POs match center and part; product allocation is unconfirmed.')+(trace.some(r=>r.manualFirstConfirmedDate)?' '+text(l,'수기 확인일이 있으면 해당 날짜를 적용하고 WIP 자동 관찰일을 별도로 보존합니다.','A manually confirmed date is applied where valid; the automatic WIP observation remains separately recorded.'):'')+'</p>'+historyHTML(trace,l)+'</section><section class="pt-stock"><h3>'+text(l,'재고·수요·발주 현황','Stock, demand and PO status')+'</h3>'+stockHTML(data,rows,l,notes)+'</section>'+centerPOHTML(data,rows,l)+supplierHTML(data,part,l)+'</div>';
}
function buildTable(options={}){
 const {language='ko',data={}}=options,l=language,tr=buildRows(options),columns=[['center',text(l,'센터','Center')],['operator',text(l,'사업자','Operator')],['sn','SN'],['rma','RMA'],['part',text(l,'부품 코드','Part code')],['partName',text(l,'부품명','Part name')],['quantity',text(l,'현 수리 필요 수','Current repair need')],['receipt',text(l,'제품 입고일','Product receipt date')],['wipDate',text(l,'WIP 기준일','WIP source date')],['tat',text(l,'제품 입고 후 경과일(TAT)','Days since product receipt (TAT)')],['excessDays',text(l,'45일 초과 일수','Days over 45')],['firstDate',text(l,'최초 부품대기 확인일','First observed parts-waiting date')],['firstAge',text(l,'최초 확인 당시 제품 TAT','Product TAT at first observation')],['observedDays',text(l,'최초 확인 후 경과일','Days since first observed')],['observation',text(l,'관찰 구분','Observation basis')],['po',text(l,'관련 센터 PO · 발주 당시 TAT','Related center PO / TAT at PO')],['supplier',text(l,'법인→본사 공용 PO · ETA','Shared India-to-HQ PO / ETA')],['confirmedEta',text(l,'확인된 센터 입고 예정일','Confirmed center receipt ETA')],['plan',text(l,'확인 메모','Confirmation note')],['source',text(l,'WIP 출처','WIP source')]].map(([key,label])=>({key,label}));
 const values=tr.map(r=>({...r,part:r.unparsed?text(l,'부품 표기 확인 필요','Part notation needs review'):en(l)&&r.part==='명판'?'Name plate':r.part,observation:observationText(r,l),po:r.relatedPOs.map(p=>orderText(p,l)).join('\n')||text(l,'관련 PO 내역 0건','0 related PO rows'),supplier:r.supplierOrders.map(p=>supplierText(p,l)).join('\n')||text(l,'연결 자료 없음','No linked records'),source:sourceLabel(r,l)}));
 return {title:text(l,options.overdueOnly?'45일 초과 제품별 부품대기 이력':'제품별 부품대기 이력',options.overdueOnly?'Parts-waiting history of products over 45 days':'Product parts-waiting history'),localized:true,columns,rows:values.map(r=>columns.map(c=>r[c.key]??text(l,'미확인','Unknown'))),context:[text(l,'보고 기준일: ','Report date: ')+(data.asof||text(l,'미확인','Unknown'))],notes:[text(l,'제품×부품 단위입니다. 제품 대수는 제품 식별자로 중복 제거하며 부품 수량과 구분합니다.','One row per product and part. Product counts must be deduplicated by product identity and differ from part quantities.'),text(l,'관련 PO의 제품별·센터별 배정 수량은 확인되지 않았습니다. 반복 표시된 공용 주문 수량을 제품·센터 행별로 합산하지 마세요.','Product allocations of related center POs and center allocations of shared India-to-HQ POs are unconfirmed. Do not sum repeated shared orders across product or center rows.'),text(l,'최초 부품대기 확인일은 보유자료에서 처음 확인한 날짜입니다. 첫 보유자료부터 대기했거나 이전 자료 대비 처음 확인된 경우 모두 실제 대기 시작일은 미확인입니다. 지연 귀책을 확정하지 않습니다.','The first observed parts-waiting date is the first observation in available records. Actual onset is unknown both for waiting already in the earliest record and waiting newly observed since a previous record. This does not establish delay responsibility.')]};
}
function bind(container,callbacks={}){
 if(!container?.addEventListener)return;
 if(container.__partsTraceClick)container.removeEventListener('click',container.__partsTraceClick);
 const handler=e=>{const el=e.target?.closest?.('[data-pt-download],[data-pt-note]');if(!el||container.contains&&!container.contains(el))return;if(el.hasAttribute('data-pt-download'))callbacks.onDownload?.(el.dataset.ptDownload);else if(el.hasAttribute('data-pt-note'))callbacks.onNote?.(el.dataset.ptNote);};
 container.__partsTraceClick=handler;container.addEventListener('click',handler);
 return ()=>{container.removeEventListener('click',handler);if(container.__partsTraceClick===handler)delete container.__partsTraceClick;};
}
return {render,bind,buildRows,buildTable,days,observationText,orderText,confirmationText};
});
