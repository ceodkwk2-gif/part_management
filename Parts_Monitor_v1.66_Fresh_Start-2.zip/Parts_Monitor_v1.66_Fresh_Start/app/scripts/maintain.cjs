#!/usr/bin/env node
'use strict';
// Deterministic maintenance gates; never edits or restores live operating data.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),cp=require('node:child_process');
const {pipeline}=require('node:stream/promises'),{Readable}=require('node:stream');
const app=path.resolve(__dirname,'..'),root=path.dirname(app),work=path.join(root,'maintenance');
const sha=value=>crypto.createHash('sha256').update(typeof value==='string'||Buffer.isBuffer(value)?value:JSON.stringify(value)).digest('hex');
const read=file=>JSON.parse(fs.readFileSync(file,'utf8'));
const write=(file,value)=>fs.writeFileSync(file,JSON.stringify(value,null,2)+'\n');
function sourceFiles(base=root){
 const result=[];
 function walk(relative){const full=path.join(base,relative);if(!fs.existsSync(full))return;for(const item of fs.readdirSync(full,{withFileTypes:true})){const name=path.join(relative,item.name);if(item.isDirectory()){if(['src','server','scripts','tests','vendor'].includes(item.name)||relative.startsWith('app/tests'))walk(name);}else if(item.isFile()&&/\.(cjs|js|css|html|json|md|cmd|sh|txt)$|(?:^|\/)\.gitignore$/.test(name)&&!name.includes('server-config.local'))result.push(name);}}
 walk('');walk('app');for(const dir of ['src','server','scripts','tests','vendor'])walk('app/'+dir);
 return [...new Set(result)].filter(n=>!['package.json','preview.cjs'].includes(n)).sort();
}
function sourceDigest(){return sha(sourceFiles().map(n=>[n,sha(fs.readFileSync(path.join(root,n)))]));}
function fingerprints(state){
 const C=require('../src/core.js'),R=require('../src/reporting.js');
 return R.reports(state).map(report=>{const data=C.calculate(R.reportState(state,report.id),report.cutoff),rows=data.allParts;return {week:report.id,reportDate:report.reportDate,parts:rows.length,shortage:rows.reduce((n,r)=>n+(r.shortage||0),0),hash:sha(rows)};});
}
function compare(before,after){const a=new Map(after.map(r=>[r.week,r]));return before.filter(r=>!a.has(r.week)||r.hash!==a.get(r.week).hash).map(r=>({week:r.week,before:r,after:a.get(r.week)||null}));}
function reviewChanges(changes,review,baselineHead,base=root){
 if(!review||review.version!==1||review.baselineHead!==baselineHead||!review.reason?.trim()||!review.authorization?.trim())throw Error('계산 변경 근거·사용자 요청·기준 Git 커밋이 일치해야 합니다.');
 const expected=changes.map(c=>({week:c.week,beforeHash:c.before.hash,afterHash:c.after?.hash||null,shortageBefore:c.before.shortage,shortageAfter:c.after?.shortage??null}));
 if(!changes.length||changes.some(c=>!c.after)||JSON.stringify(expected)!==JSON.stringify(review.changes))throw Error('검토한 주차·전후 수량·해시와 실제 계산 변경이 다릅니다.');
 const test=review.regressionTest,relative=test?.path,full=relative&&path.resolve(base,relative);
 if(!relative||!/^app\/tests\/[\w./-]+\.test\.cjs$/.test(relative)||!full.startsWith(path.resolve(base,'app/tests')+path.sep)||!fs.existsSync(full)||sha(fs.readFileSync(full))!==test.sha256)throw Error('검토 근거에 지정한 회귀 테스트가 없거나 변경됐습니다.');
 return {test:full,changes:expected,reason:review.reason,authorization:review.authorization};
}
function git(args,{optional=false}={}){const r=cp.spawnSync('git',args,{cwd:root,encoding:'utf8',maxBuffer:32*1024*1024});if(r.status!==0&&!optional)throw Error('Git: '+(r.error?.message||r.stderr||'command failed'));return r.status===0?r.stdout.trim():null;}
function runStep(dir,name,command,args){
 const log=path.join(dir,name+'.log'),fd=fs.openSync(log,'w'),startedAt=new Date().toISOString();let result;
 try{result=cp.spawnSync(command,args,{cwd:app,stdio:['ignore',fd,fd],timeout:600000});}finally{fs.closeSync(fd);}
 const step={name,command:[command,...args],startedAt,finishedAt:new Date().toISOString(),exitCode:result.status,passed:result.status===0&&!result.error,log};
 if(result.error)step.error=result.error.message;return step;
}
async function captureData(config,dir){
 const lock=path.join(config.dataDir,'server.lock');let alive=false;
 if(fs.existsSync(lock)){const pid=read(lock).pid;try{process.kill(pid,0);alive=true}catch(e){if(e.code==='EPERM')alive=true;}}
 if(alive){
  const base='http://127.0.0.1:'+config.port;
  for(let attempt=0;attempt<3;attempt++){
   const response=await fetch(base+'/api/state',{signal:AbortSignal.timeout(120000)});if(!response.ok)throw Error('운영 데이터 읽기 실패: '+response.status);const saved=await response.json();
   const backup=await fetch(base+'/api/backup',{signal:AbortSignal.timeout(300000)});if(!backup.ok)throw Error('운영 백업 실패: '+backup.status);
   await pipeline(Readable.fromWeb(backup.body),fs.createWriteStream(path.join(dir,'data-backup.zip')));
   const status=await (await fetch(base+'/api/status',{signal:AbortSignal.timeout(10000)})).json();
   if(status.revision===saved.revision)return {state:saved.state,revision:saved.revision,mode:'server-snapshot'};
  }
  throw Error('백업 중 운영 데이터가 계속 변경됐습니다. 업로드가 끝난 뒤 begin을 다시 실행하세요.');
 }
 if(!['current.json','previous.json'].some(n=>fs.existsSync(path.join(config.dataDir,n))))return {state:require('../src/core.js').empty(),revision:0,mode:'empty'};
 // Work from a private copy: opening old storage must never migrate live data.
 const copy=path.join(dir,'data-copy');fs.cpSync(config.dataDir,copy,{recursive:true,filter:p=>!['server.lock','view-cache'].includes(path.basename(p))});
 const {createStore}=require('../server/store.cjs'),store=createStore({dataDir:copy}),Backup=require('../server/backup-stream.cjs');
 const saved=store.read();await Backup.writeZip(fs.createWriteStream(path.join(dir,'data-backup.zip')),Backup.snapshot(store,require('../package.json').version));store.close();
 return {state:saved.state,revision:saved.revision,mode:'offline-copy'};
}
async function begin(options){
 fs.mkdirSync(work,{recursive:true});const active=path.join(work,'active.json');
 if(fs.existsSync(active)){const prior=read(active),status=read(path.join(prior.directory,'session.json'));if(!status.finishedAt)throw Error('진행 중인 유지보수: '+prior.directory+' · status/finish로 이어서 진행하세요.');}
 const id=new Date().toISOString().replace(/[:.]/g,'-'),dir=path.join(work,id);fs.mkdirSync(dir);
 const session={id,task:options.task||'Maintenance',startedAt:new Date().toISOString(),baselineHead:git(['rev-parse','HEAD'],{optional:true}),sourceDigest:sourceDigest(),steps:[],status:'preparing'};
 write(path.join(dir,'session.json'),session);write(active,{directory:dir});
 try{
  for(const name of sourceFiles()){const dest=path.join(dir,'source-before',name);fs.mkdirSync(path.dirname(dest),{recursive:true});fs.copyFileSync(path.join(root,name),dest);}
  if(session.baselineHead)git(['bundle','create',path.join(dir,'source-before.bundle'),'--all']);
  const config=require('../server.cjs').configFor(options.dataDir?{dataDir:path.resolve(options.dataDir)}:{}),capture=await captureData(config,dir);
  write(path.join(dir,'baseline-state.json'),capture.state);write(path.join(dir,'baseline-results.json'),fingerprints(capture.state));
  Object.assign(session,{status:'ready-to-edit',dataRevision:capture.revision,dataMode:capture.mode,dataDir:config.dataDir});write(path.join(dir,'session.json'),session);
  console.log(JSON.stringify({status:session.status,directory:dir,next:'Implement the requested change, then run: node app/scripts/maintain.cjs finish --evidence <screenshot> --ui-note <verified behavior>',baselineHead:session.baselineHead},null,2));
 }catch(e){session.status='blocked';session.error=e.message;session.finishedAt=new Date().toISOString();write(path.join(dir,'session.json'),session);throw e;}
}
function finish(options){
 const dir=read(path.join(work,'active.json')).directory,session=read(path.join(dir,'session.json'));if(session.finishedAt&&session.status==='passed')throw Error('이 유지보수는 완료됐습니다. 새 변경은 begin으로 시작하세요.');
 const report={...session,status:'running',steps:[],checkedSourceDigest:sourceDigest()};delete report.finishedAt;
 const save=()=>{write(path.join(dir,'session.json'),report);write(path.join(dir,'result.json'),report);};save();
 try{
  const release=runStep(dir,'release-checks',process.execPath,['scripts/check-release.cjs']);report.steps.push(release);save();if(!release.passed)throw Error('자동 테스트 또는 빈 운영본 빌드 실패: '+release.log);
  const after=fingerprints(read(path.join(dir,'baseline-state.json'))),changes=compare(read(path.join(dir,'baseline-results.json')),after);write(path.join(dir,'calculation-comparison.json'),{changes,before:read(path.join(dir,'baseline-results.json')),after});
  let reviewed=null;
  if(changes.length&&options.reviewedChanges){
   const reviewFile=path.resolve(options.reviewedChanges),review=read(reviewFile);reviewed=reviewChanges(changes,review,session.baselineHead);
   const regression=runStep(dir,'reviewed-change-regression',process.execPath,['--test',reviewed.test]);report.steps.push(regression);save();if(!regression.passed)throw Error('검토한 계산 변경의 회귀 테스트 실패');
   write(path.join(dir,'accepted-calculation-changes.json'),review);report.calculationReview={...reviewed,test:path.relative(root,reviewed.test),file:reviewFile,sha256:sha(fs.readFileSync(reviewFile))};
  }
  report.steps.push({name:'historical-calculation-comparison',passed:changes.length===0||!!reviewed,reports:after.length,changedReports:changes.length,reviewed:!!reviewed});save();if(changes.length&&!reviewed)throw Error('기존 주차 계산이 달라졌습니다. calculation-comparison.json을 확인하고 사용자 요청에 포함된 보정만 전후 해시·예상 수량·회귀 테스트가 있는 --reviewed-changes 파일로 검토하세요.');
  if(options.evidence){const evidence=path.resolve(options.evidence);if(!/\.(png|jpg|jpeg)$/i.test(evidence)||!fs.existsSync(evidence)||!fs.statSync(evidence).size||!options.uiNote)throw Error('실제 화면 이미지와 --ui-note가 필요합니다.');const target=path.join(dir,'verified-ui'+path.extname(evidence));fs.copyFileSync(evidence,target);report.visual={status:'evidence-provided',note:options.uiNote,file:target,sha256:sha(fs.readFileSync(target))};}
  else throw Error('화면 증거가 없습니다. 실제 브라우저에서 작업 흐름을 확인하고 finish --evidence 이미지 --ui-note 확인내용으로 재개하세요. 자동 테스트를 화면 검증으로 보고하지 않습니다.');
  if(sourceDigest()!==report.checkedSourceDigest)throw Error('검증 도중 소스가 바뀌었습니다. finish를 다시 실행하세요.');
  if(git(['rev-parse','--is-inside-work-tree'],{optional:true})!=='true')throw Error('Git 저장소가 없습니다. 제공된 Source.bundle로 clone하거나 승인된 Git을 설치한 뒤 재개하세요.');
  git(['add','--',...sourceFiles()]);const staged=git(['diff','--cached','--name-only']);
  if(staged)git(['commit','-m',options.message||session.task]);report.commit=git(['rev-parse','HEAD']);
  report.status='passed';report.finishedAt=new Date().toISOString();save();
  const text=['작업: '+report.task,'결과: '+report.status,'자동 검사: '+report.steps.map(s=>s.name+'='+s.passed).join(', '),'기존 주차 비교: '+after.length+'주','화면: '+report.visual.note,'Git: '+report.commit,'백업/로그: '+dir,'실제 사내 Windows/Linux·LAN 검증은 이 로그로 대신하지 않습니다.'].join('\n');fs.writeFileSync(path.join(dir,'RESULT.txt'),text+'\n');console.log(text);
 }catch(e){report.status='blocked';report.error=e.message;report.finishedAt=null;save();console.error('미완료: '+e.message+'\n기존 운영 data는 변경하지 않았습니다. 로그: '+dir);process.exitCode=1;}
}
async function main(args=process.argv.slice(2)){const command=args.shift()||'status',options={};for(let i=0;i<args.length;i+=2){if(!args[i].startsWith('--')||!args[i+1])throw Error('옵션 값이 필요합니다: '+args[i]);const key=args[i].slice(2).replace(/-([a-z])/g,(_,s)=>s.toUpperCase());options[key]=args[i+1];}
 if(command==='begin')await begin(options);else if(command==='finish')finish(options);else if(command==='status'){const active=path.join(work,'active.json');console.log(fs.existsSync(active)?JSON.stringify(read(path.join(read(active).directory,'session.json')),null,2):'시작 전: node app/scripts/maintain.cjs begin --task "요청 내용"');}else throw Error('사용법: maintain.cjs begin|finish|status');}
module.exports={fingerprints,compare,reviewChanges,runStep,sourceFiles};
if(require.main===module)main().catch(e=>{console.error(e.message);process.exitCode=1;});
