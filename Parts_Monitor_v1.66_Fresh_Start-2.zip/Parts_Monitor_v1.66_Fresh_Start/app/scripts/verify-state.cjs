#!/usr/bin/env node
'use strict';

// Read-only verification of a local admin JSON backup. Never uploads anything.
// Stdout contains counts and a digest, not file names, part codes or repair IDs.
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const C = require('../src/core.js');
const O = require('../src/operations.js');

function validDate(value) {
  return typeof value === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(value) && C.date(value) === value;
}
const known = value => typeof value === 'number' && Number.isFinite(value);
const sum = values => values.reduce((total, value) => total + (known(value) ? value : 0), 0);
const kinds = rows => new Set(rows.map(row => row.part)).size;

function verify(input, options = {}) {
  const errors = {}, warnings = {};
  const add = (target, key, count = 1) => { if (count) target[key] = (target[key] || 0) + count; };
  if (!input || input.version !== 1 || !Array.isArray(input.sources) ||
      !input.settings || typeof input.settings !== 'object') {
    return { verifierVersion: 1, ok: false, errors: { invalid_state_shape: 1 }, warnings: {} };
  }
  const types = new Set(['dashboard', 'wip', 'po', 'india', 'hq', 'siel']);
  for (const source of input.sources) {
    if (!source || !types.has(source.type) || !Array.isArray(source.rows)) add(errors, 'invalid_source_shape');
    if (source?.date && !validDate(source.date)) add(errors, 'invalid_source_date');
    if (source && !source.date) add(warnings, 'undated_source');
    if (source && ['dashboard', 'wip', 'po'].includes(source.type) && !['Flex', 'CTDI'].includes(source.center)) add(errors, 'invalid_source_center');
  }
  if (Object.keys(errors).length) return { verifierVersion: 1, ok: false, errors, warnings };

  let state = C.normalizeOperators ? C.normalizeOperators(input) : input;
  let reportId = null, reportCutoff = null;
  const modulePath = path.join(__dirname, '../src/reporting.js');
  if (fs.existsSync(modulePath)) {
    const R = require(modulePath);
    const fullState = R.normalizeState(state);
    const entry = options.report ? R.reports(fullState).find(report => report.id === options.report) : R.selectedReport(fullState);
    if (options.report && !entry) throw Error('Requested report does not exist.');
    if (entry) {
      reportId = entry.id;
      reportCutoff = entry.cutoff;
      add(errors, 'unresolved_report_sources', R.reportWarnings(fullState, entry.id).length);
      state = R.reportState(fullState, entry.id);
    }
  } else if (options.report) throw Error('Report selection is unavailable in this source version.');
  const asof = options.asof || reportCutoff || state.sources.map(source => source.date).filter(Boolean).sort().at(-1);
  if (!validDate(asof)) throw Error('A valid source date or explicit --asof is required.');
  const result = C.calculate(state, asof);
  const rows = result.allParts;
  for (const source of result.used || []) {
    if (source.type === 'wip' && !(C.CENTER_OPERATORS?.[source.center] || ['Jio', 'Airtel', 'Vi']).includes(source.operator)) add(errors, 'unsupported_wip_operator');
  }
  for (const row of rows) {
    for (const field of ['stock', 'needed', 'avg', 'target', 'open', 'shortage', 'proposed', 'india', 'hq']) {
      if (row[field] != null && (!known(row[field]) || row[field] < 0)) add(errors, 'invalid_calculated_' + field);
    }
    const expectedShortage = [row.stock, row.needed].every(known) ? Math.max(0, row.needed - row.stock) : null;
    const expectedTarget = known(row.avg) ? Math.ceil(row.avg * C.effectiveTargetMonths(state.settings)) : null;
    const expectedProposed = [row.stock, row.needed, row.target, row.open].every(known)
      ? Math.max(0, Math.ceil(row.needed + row.target - row.stock - row.open)) : null;
    if (row.shortage !== expectedShortage) add(errors, 'shortage_formula_mismatch');
    if (row.target !== expectedTarget) add(errors, 'target_formula_mismatch');
    if (row.proposed !== expectedProposed) add(errors, 'order_formula_mismatch');
    if (known(row.proposed) && known(row.currentOrderNeed) && known(row.futureOrderNeed) &&
        row.currentOrderNeed + row.futureOrderNeed !== row.proposed) add(errors, 'order_breakdown_mismatch');
    if (row.stockAssumedZero && row.stock !== 0) add(errors, 'missing_dashboard_stock_not_zero');
    if (row.missingDashboardCode && row.avg != null) add(errors, 'missing_dashboard_usage_invented');
    if (row.needDate && row.needDate > asof) add(errors, 'future_need_used');
  }
  for (const source of result.used || []) if (source.date && source.date > asof) { if(source.type==='siel'&&source.demo===true&&source.demoAssignment==='user-approved-report-week'&&C.sourceSelectionDate(source)<=asof) add(warnings,'explicit_siel_demo_assignment'); else add(errors, 'future_source_used'); }
  for (const duplicate of result.duplicateDiagnostics || []) {
    const matches = rows.filter(row => row.center === duplicate.center && row.part === duplicate.part);
    if (duplicate.type === 'dashboard' && matches.some(row => row.selectedSourceRow !== duplicate.selectedRow)) add(errors, 'duplicate_first_row_not_used');
  }
  add(warnings, 'duplicate_groups_using_first_row', result.duplicateDiagnostics?.length || 0);
  add(warnings, 'missing_dashboard_codes', result.masterAlerts?.length || 0);
  add(warnings, 'shortage_quantity_unknown', rows.filter(row => row.shortage == null).length);
  add(warnings, 'additional_order_quantity_unknown', rows.filter(row => row.proposed == null).length);
  add(warnings, 'unparsed_wip_products', result.wip.filter(row => row.tokens?.unparsed).length);
  add(warnings, 'current_calculation_notices', result.warnings.length);
  const shortage = rows.filter(row => row.shortage > 0), order = rows.filter(row => row.proposed > 0);
  const operations = O.evaluate(state, result);
  const groupedParts = operations.groups.flatMap(group => group.rows.map(row => row.part));
  const expectedParts = new Set(shortage.map(row => row.part));
  if (!operations.groupingComplete || operations.groupTotal !== expectedParts.size ||
      groupedParts.length !== expectedParts.size || new Set(groupedParts).size !== expectedParts.size ||
      groupedParts.some(part => !expectedParts.has(part))) add(errors, 'action_owner_group_coverage_mismatch');
  if (sum(operations.groups.map(group => group.quantity)) !== sum(shortage.map(row => row.shortage))) {
    add(errors, 'action_owner_group_quantity_mismatch');
  }
  const ledger = rows.map(row => [row.center, row.part, row.stock, row.needed, row.avg, row.target, row.open,
    row.shortage, row.proposed, row.currentOrderNeed, row.futureOrderNeed, row.india, row.hq, row.needBasis,
    row.needDate, row.selectedSourceRow]).sort((a, b) => JSON.stringify(a).localeCompare(JSON.stringify(b)));
  const summary = {
    schemaVersion: input.version,
    reportId,
    asof,
    retainedSourceSnapshots: input.sources.length,
    sourceSnapshots: state.sources.length,
    selectedSources: result.used.length,
    selectedWipByOperator: Object.fromEntries(['Flex:Jio', 'CTDI:Jio', 'CTDI:Airtel', 'CTDI:Vi'].map(key => [key,
      result.used.filter(source => source.type === 'wip' && source.center + ':' + source.operator === key).length])),
    trackedPartKinds: kinds(rows),
    centerPartRows: rows.length,
    shortagePartKinds: kinds(shortage),
    shortageKnownUnits: sum(shortage.map(row => row.shortage)),
    additionalOrderPartKinds: kinds(order),
    additionalOrderKnownUnits: sum(order.map(row => row.proposed)),
    shortageUnknownRows: rows.filter(row => row.shortage == null).length,
    additionalOrderUnknownRows: rows.filter(row => row.proposed == null).length,
    calculationDigest: crypto.createHash('sha256').update(JSON.stringify(ledger)).digest('hex'),
  };
  if (options.baseline) {
    if (options.baseline.verifierVersion !== 1 || !options.baseline.summary) add(errors, 'invalid_baseline');
    else for (const [key, value] of Object.entries(summary)) {
      if (JSON.stringify(options.baseline.summary[key]) !== JSON.stringify(value)) add(errors, 'baseline_changed_' + key);
    }
  }
  return { verifierVersion: 1, ok: !Object.keys(errors).length, summary, errors, warnings,
    scope: 'Calculation and input consistency only. Known partial quantities are not certified complete. Does not verify source truth, DRM, transport or deployment.' };
}

function main(args) {
  const options = {};
  for (let i = 0; i < args.length; i++) {
    const key = args[i];
    if (!['--seed', '--asof', '--report', '--baseline'].includes(key) || !args[i + 1] || args[i + 1].startsWith('--')) {
      throw Error('Usage: node scripts/verify-state.cjs --seed LOCAL_JSON [--asof YYYY-MM-DD] [--report REPORT_ID] [--baseline PRIOR_VERIFICATION_JSON]');
    }
    options[key.slice(2)] = args[++i];
  }
  if (!options.seed) throw Error('Explicit --seed is required; empty or bundled data is never substituted.');
  if (!fs.existsSync(options.seed)) throw Error('Seed file not found.');
  const input = JSON.parse(fs.readFileSync(options.seed, 'utf8'));
  if (options.baseline) options.baseline = JSON.parse(fs.readFileSync(options.baseline, 'utf8'));
  const result = verify(input, options);
  process.stdout.write(JSON.stringify(result, null, 2) + '\n');
  return result.ok ? 0 : 1;
}
if (require.main === module) {
  try { process.exitCode = main(process.argv.slice(2)); }
  catch (_) {
    // File paths, raw records and parser context are intentionally not echoed.
    process.stderr.write('Verification could not run. Check explicit --seed, JSON format, --asof/report and baseline path.\n');
    process.exitCode = 2;
  }
}
module.exports = { verify, main };
