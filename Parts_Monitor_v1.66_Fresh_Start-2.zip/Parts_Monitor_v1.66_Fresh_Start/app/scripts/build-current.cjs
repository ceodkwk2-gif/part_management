
'use strict';
// Build a self-contained read-only result from the same durable server data.
// Routine weekly uploads do not need this script.
const fs=require('node:fs'),path=require('node:path');
const {createStore}=require('../server/store.cjs'),{createViewService}=require('../server/view-service.cjs');
const app=path.resolve(__dirname,'..'),args=process.argv.slice(2);
function option(key,fallback){const i=args.indexOf(key);if(i<0)return fallback;if(!args[i+1])throw Error(key+' needs a path');return path.resolve(args[i+1]);}
const dataDir=option('--data-dir',path.resolve(app,'../data'));
const output=option('--output',path.join(app,'dist/Parts_Monitor_Current.html'));
const viewJson=option('--view-json',null);
const store=viewJson?null:createStore({dataDir}),service=store?createViewService({store,cacheDir:path.join(dataDir,'view-cache')}):null;
const data=viewJson?JSON.parse(fs.readFileSync(viewJson,'utf8')):service.getView();
if(!Array.isArray(data.rows)||!Array.isArray(data.trend))throw Error('Invalid projected view data');
const read=file=>fs.readFileSync(path.join(app,file),'utf8'),safe=s=>s.replace(/<\/(script|body|head)/gi,'<\\/$1');
const styles=['stage-dashboard','current-view','overview','first-confirmed-panel','share-dialog','part-trace','workspace','workflow','theme'].map(n=>read('src/'+n+'.css')).join('\n');
const scripts=[['vendor','vendor/xlsx.full.min.js'],...['i18n','i18n-extra','first-confirmed-panel','workflow','chart-labels','overview','part-trace','summary-mail','overdue-mail','share-dialog','summary-downloads','report-export','supply-stages','stage-data','stage-dashboard','action-requests','current-view'].map(n=>[n,'src/'+n+'.js'])].map(([id,file])=>'<script id="'+id+'">'+safe(read(file))+'</script>').join('');
const themeScript='<script id="theme">'+safe(read('src/theme.js'))+'</script>';
const version=JSON.parse(read('package.json')).version;
const html='<!doctype html><html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Parts Monitor v'+version+' · Current results</title><style>'+styles+'</style>'+themeScript+'</head><body><div id="app"></div><script id="current-data" type="application/json">'+JSON.stringify(data).replace(/</g,'\\u003c')+'</script>'+scripts+'</body></html>';
fs.mkdirSync(path.dirname(output),{recursive:true});fs.writeFileSync(output,html);service?.close();
console.log(JSON.stringify({output,version,asof:data.asof,rows:data.rows.length,reportCount:data.trend.length,bytes:Buffer.byteLength(html)}));
