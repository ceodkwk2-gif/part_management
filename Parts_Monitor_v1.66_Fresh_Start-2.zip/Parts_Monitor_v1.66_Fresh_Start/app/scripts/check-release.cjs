#!/usr/bin/env node
'use strict';
// Portable release harness. Uses synthetic fixtures only; never opens operating data.
const fs=require('node:fs'),path=require('node:path'),{spawnSync}=require('node:child_process');
const app=path.resolve(__dirname,'..');
const tests=fs.readdirSync(path.join(app,'tests')).filter(n=>n.endsWith('.test.cjs')).sort().map(n=>'tests/'+n);
for(const args of [['--test',...tests],['build.cjs','--empty']]){
 const result=spawnSync(process.execPath,args,{cwd:app,stdio:'inherit'});
 if(result.error)throw result.error;
 if(result.status!==0)process.exit(result.status||1);
}
const html=fs.readFileSync(path.join(app,'dist/server-template.html'),'utf8');
const seed=JSON.parse(html.match(/<script id="seed" type="application\/json">([\s\S]*?)<\/script>/)[1]);
if(seed.sources.length)throw Error('Fresh-start template must have no sources.');
for(const file of ['src/current-view.js','src/server-app.js','src/stage-dashboard.js','src/action-requests.js','src/part-trace.js']){
 const source=fs.readFileSync(path.join(app,file),'utf8');
 if(/공급문서 미발행|공급 문서 있음|문서 기준 진행|현재 목록 요청서|업체 조치 요청 및 회신|資料確認/.test(source))throw Error('Obsolete report wording: '+file);
}
console.log('Release checks passed: synthetic tests, empty server build and current status terminology.');
