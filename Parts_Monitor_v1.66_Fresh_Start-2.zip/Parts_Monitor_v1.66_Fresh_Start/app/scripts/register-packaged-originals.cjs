'use strict';
// Offline, explicit preservation of recovered originals. Never parses, re-dates
// or applies a workbook to a report. Stop the server before running this script.
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const {createStore}=require('../server/store.cjs');
function register(root){
 const dataDir=path.join(root,'data');if(fs.existsSync(path.join(dataDir,'server.lock')))throw Error('Stop the server before registering packaged originals.');
 const store=createStore({dataDir}),manifest=store.compactManifest(),prior=new Set(store.listRaw().map(x=>x.id)),catalog={...(manifest.state.archiveCatalog||{})},ids=[];
 const visit=dir=>{if(!fs.existsSync(dir))return;for(const e of fs.readdirSync(dir,{withFileTypes:true})){const file=path.join(dir,e.name);if(e.isDirectory()){visit(file);continue}if(!e.isFile()||!/\.(xlsx?|xlsb|zip)$/i.test(e.name))continue;
  const bytes=fs.readFileSync(file),id='raw_'+crypto.createHash('sha256').update(bytes).digest('hex'),excluded=bytes.length>0&&bytes.every(b=>b===0),relative=path.relative(root,file).split(path.sep).join('/');
  if(!prior.has(id)){ids.push(store.addRaw({name:e.name,bytes}).id);catalog[id]={storedOnly:true,paths:[...(catalog[id]?.paths||[]),relative],note:/\.zip$/i.test(e.name)?'Original upload ZIP retained; Excel application is tracked separately.':'Recovered original retained; not yet parsed or applied to a weekly report.'};}
  if(excluded)catalog[id]={...(catalog[id]||{}),excluded:true,note:'All-zero damaged workbook. Retained as evidence; not used for calculations.'};
 }};
 visit(path.join(root,'RAW_DATA'));visit(path.join(root,'ORIGINAL_UPLOAD_ZIPS'));
 if(ids.length||JSON.stringify(catalog)!==JSON.stringify(manifest.state.archiveCatalog||{})){manifest.state={...manifest.state,archiveCatalog:catalog};store.saveManifest({manifest,baseRevision:manifest.revision,rawIds:[...new Set(ids)],operation:'archive-recovered-originals'});}
 return {...store.status(),newOriginals:new Set(ids).size};
}
if(require.main===module)console.log(JSON.stringify(register(path.resolve(process.argv[2]||path.join(__dirname,'../..')))));
module.exports={register};
