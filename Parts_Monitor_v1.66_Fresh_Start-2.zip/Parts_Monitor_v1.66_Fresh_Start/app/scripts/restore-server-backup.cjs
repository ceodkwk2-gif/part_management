'use strict';
// Offline recovery only: validate the complete backup before replacing any data.
const fs=require('node:fs');
const path=require('node:path');
const crypto=require('node:crypto');
const zlib=require('node:zlib');
const XLSX=require('../vendor/xlsx.full.min.js');
const {createStore}=require('../server/store.cjs');
const {createAuth}=require('../server/auth.cjs');
const sha=bytes=>crypto.createHash('sha256').update(bytes).digest('hex');
const GENERATION=/^\d{12}-[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}\.json\.gz$/;
const allowedPath=name=>['current.json','previous.json','admin-auth.json'].includes(name)||typeof name==='string'&&(name.startsWith('generations/')&&GENERATION.test(name.slice(12))||/^raw\/[a-f0-9]{64}\.bin$/.test(name)||/^sources\/[a-f0-9]{64}\.json\.gz$/.test(name));
const error=message=>new Error('백업 복원 중단: '+message);
function assertStopped(directory){
 const lock=path.join(directory,'server.lock');if(!fs.existsSync(lock))return;
 let value;try{value=JSON.parse(fs.readFileSync(lock,'utf8'));}catch{throw error('서버 잠금 파일을 읽을 수 없습니다. 서버를 종료한 뒤 지원 담당자에게 확인하세요.');}
 if(!Number.isSafeInteger(value.pid)||value.pid<1)throw error('서버 잠금 정보가 올바르지 않습니다.');
 try{process.kill(value.pid,0);}catch(e){if(e.code==='ESRCH')return;if(e.code!=='EPERM')throw e;}
 throw error('이 데이터 폴더의 서버가 실행 중입니다. 실행 창을 먼저 종료하세요.');
}
// Inspect the ZIP directory before CFB resolves names; duplicate ZIP entries
// must never be silently collapsed or selected according to parser order.
function zipEntries(input){
 const bytes=Buffer.from(input);let end=-1;
 for(let at=bytes.length-22;at>=Math.max(0,bytes.length-65557);at--)if(bytes.readUInt32LE(at)===0x06054b50&&at+22+bytes.readUInt16LE(at+20)===bytes.length){end=at;break;}
 if(end<0)throw error('완전한 ZIP 파일이 아닙니다.');
 const count=bytes.readUInt16LE(end+10),size=bytes.readUInt32LE(end+12),offset=bytes.readUInt32LE(end+16);
 if(bytes.readUInt16LE(end+4)||bytes.readUInt16LE(end+6)||bytes.readUInt16LE(end+8)!==count||count===65535||size===0xffffffff||offset+size!==end)throw error('지원하지 않는 ZIP 형식입니다.');
 const names=new Map();let at=offset;
 for(let i=0;i<count;i++){
  if(at+46>end||bytes.readUInt32LE(at)!==0x02014b50)throw error('ZIP 목록이 손상되었습니다.');
  const nameLength=bytes.readUInt16LE(at+28),extraLength=bytes.readUInt16LE(at+30),commentLength=bytes.readUInt16LE(at+32),next=at+46+nameLength+extraLength+commentLength;
  if(next>end||bytes.readUInt16LE(at+8)&1)throw error('손상되었거나 암호화된 ZIP입니다.');
  const name=bytes.subarray(at+46,at+46+nameLength).toString('utf8');
  if(!/^(Server_Backup\.json|Backup_\d{6}\.bin)$/.test(name))throw error('예상하지 않은 ZIP 항목이 있습니다: '+name);
  if(names.has(name.toLowerCase()))throw error('ZIP 파일명이 중복되었습니다: '+name);
  names.set(name.toLowerCase(),{name,size:bytes.readUInt32LE(at+24)});at=next;
 }
 if(at!==end||!names.has('server_backup.json'))throw error('ZIP 목록 또는 백업 설명 파일이 없습니다.');
 return names;
}
function decodeBackup(input){
 const entries=zipEntries(input);let archive,manifest;
 try{archive=XLSX.CFB.read(Buffer.from(input),{type:'buffer'});const found=XLSX.CFB.find(archive,'Server_Backup.json');if(!found)throw Error();manifest=JSON.parse(Buffer.from(found.content).toString('utf8'));}catch{throw error('백업 설명 파일을 읽을 수 없습니다.');}
 if(manifest.format!=='parts-monitor-server-backup'||manifest.version!==1||!Number.isSafeInteger(manifest.revision)||manifest.revision<0||!Array.isArray(manifest.files)||!manifest.files.length||manifest.files.length+1!==entries.size)throw error('백업 형식 또는 파일 개수가 올바르지 않습니다.');
 const paths=new Set(),names=new Set(),files=[];
 for(const item of manifest.files){
  if(!item||!allowedPath(item.path))throw error('허용하지 않은 저장 경로입니다.');
  if(paths.has(item.path))throw error('저장 경로가 중복되었습니다: '+item.path);paths.add(item.path);
  if(!/^Backup_\d{6}\.bin$/.test(item.file||'')||names.has(item.file))throw error('백업 항목 이름이 잘못되었거나 중복되었습니다.');names.add(item.file);
  const zip=entries.get(item.file.toLowerCase());if(!zip||!Number.isSafeInteger(item.size)||item.size<1||zip.size!==item.size||!/^[a-f0-9]{64}$/.test(item.sha256||''))throw error('백업 항목 크기 또는 무결성 정보가 올바르지 않습니다.');
  const found=XLSX.CFB.find(archive,item.file);if(!found)throw error('백업 항목을 찾을 수 없습니다: '+item.file);
  const bytes=Buffer.from(found.content);if(bytes.length!==item.size||sha(bytes)!==item.sha256)throw error('파일 무결성 검증에 실패했습니다: '+item.path);
  files.push({path:item.path,bytes});
 }
 if(!paths.has('current.json'))throw error('현재 저장본 위치가 없습니다.');
 return {manifest,files};
}
// The CLI path seeks within the ZIP instead of reading the complete annual
// backup into CFB. Stored entries use a fixed buffer; legacy deflated entries
// allocate only that one compressed/uncompressed entry at a time.
const COPY_CHUNK=1024*1024,MAX_MANIFEST=64*1024*1024;
const CRC_TABLE=Array.from({length:256},(_,value)=>{for(let bit=0;bit<8;bit++)value=value&1?0xedb88320^(value>>>1):value>>>1;return value>>>0;});
function crcUpdate(crc,bytes){for(let i=0;i<bytes.length;i++)crc=CRC_TABLE[(crc^bytes[i])&255]^(crc>>>8);return crc;}
function readAt(fd,position,length){
 const bytes=Buffer.allocUnsafe(length);let done=0;
 while(done<length){const count=fs.readSync(fd,bytes,done,length-done,position+done);if(!count)throw error('ZIP 파일이 예상보다 일찍 끝났습니다.');done+=count;}
 return bytes;
}
function writeAll(fd,bytes){let done=0;while(done<bytes.length){const count=fs.writeSync(fd,bytes,done,bytes.length-done);if(!count)throw error('복원 파일을 기록하지 못했습니다.');done+=count;}}
function diskZipEntries(fd,fileSize){
 if(!Number.isSafeInteger(fileSize)||fileSize<22)throw error('완전한 ZIP 파일이 아닙니다.');
 const tailOffset=Math.max(0,fileSize-65557),tail=readAt(fd,tailOffset,fileSize-tailOffset);let end=-1;
 for(let at=tail.length-22;at>=0;at--)if(tail.readUInt32LE(at)===0x06054b50&&at+22+tail.readUInt16LE(at+20)===tail.length){end=at;break;}
 if(end<0)throw error('완전한 ZIP 파일이 아닙니다.');
 const count=tail.readUInt16LE(end+10),directorySize=tail.readUInt32LE(end+12),directoryOffset=tail.readUInt32LE(end+16),directoryEnd=tailOffset+end;
 if(tail.readUInt16LE(end+4)||tail.readUInt16LE(end+6)||tail.readUInt16LE(end+8)!==count||count===65535||directorySize===0xffffffff||directoryOffset===0xffffffff||directoryOffset+directorySize!==directoryEnd)throw error('지원하지 않는 ZIP 형식입니다.');
 const entries=new Map(),ranges=[];let at=directoryOffset,totalSize=0;
 for(let i=0;i<count;i++){
  if(at+46>directoryEnd)throw error('ZIP 목록이 손상되었습니다.');
  const header=readAt(fd,at,46);if(header.readUInt32LE(0)!==0x02014b50)throw error('ZIP 목록이 손상되었습니다.');
  const flags=header.readUInt16LE(8),method=header.readUInt16LE(10),crc=header.readUInt32LE(16),compressedSize=header.readUInt32LE(20),size=header.readUInt32LE(24),nameLength=header.readUInt16LE(28),extraLength=header.readUInt16LE(30),commentLength=header.readUInt16LE(32),localOffset=header.readUInt32LE(42),next=at+46+nameLength+extraLength+commentLength;
  if(next>directoryEnd||flags&0x2041||![0,8].includes(method)||header.readUInt16LE(34)||[compressedSize,size,localOffset].includes(0xffffffff))throw error('손상되었거나 지원하지 않는 ZIP 항목입니다.');
  const nameBytes=readAt(fd,at+46,nameLength),name=nameBytes.toString('utf8');
  if(!/^(Server_Backup\.json|Backup_\d{6}\.bin)$/.test(name))throw error('예상하지 않은 ZIP 항목이 있습니다: '+name);
  if(entries.has(name.toLowerCase()))throw error('ZIP 파일명이 중복되었습니다: '+name);
  totalSize+=size;if(totalSize>=0xffffffff)throw error('ZIP 원본 크기가 지원 범위인 4 GB를 초과했습니다.');
  if(localOffset+30>directoryOffset)throw error('ZIP 항목 위치가 올바르지 않습니다.');
  const local=readAt(fd,localOffset,30),localNameLength=local.readUInt16LE(26),localExtraLength=local.readUInt16LE(28),dataOffset=localOffset+30+localNameLength+localExtraLength,dataEnd=dataOffset+compressedSize;
  if(local.readUInt32LE(0)!==0x04034b50||local.readUInt16LE(6)!==flags||local.readUInt16LE(8)!==method||dataOffset>directoryOffset||dataEnd>directoryOffset||!readAt(fd,localOffset+30,localNameLength).equals(nameBytes))throw error('ZIP 목록과 개별 파일 헤더가 일치하지 않습니다.');
  const localValues=[local.readUInt32LE(14),local.readUInt32LE(18),local.readUInt32LE(22)],values=[crc,compressedSize,size];
  if(localValues.some((value,index)=>value!==values[index]&&(!(flags&8)||value!==0))||method===0&&compressedSize!==size)throw error('ZIP 파일 크기 또는 검사값이 일치하지 않습니다.');
  let rangeEnd=dataEnd;
  if(flags&8){
   if(dataEnd+12>directoryOffset)throw error('ZIP 데이터 설명자가 없습니다.');
   const signed=readAt(fd,dataEnd,4).readUInt32LE(0)===0x08074b50,descriptorSize=signed?16:12;
   if(dataEnd+descriptorSize>directoryOffset)throw error('ZIP 데이터 설명자가 손상되었습니다.');
   const descriptor=readAt(fd,dataEnd,descriptorSize),start=signed?4:0;
   if(values.some((value,index)=>descriptor.readUInt32LE(start+index*4)!==value))throw error('ZIP 데이터 설명자가 일치하지 않습니다.');
   rangeEnd+=descriptorSize;
  }
  ranges.push({start:localOffset,end:rangeEnd});entries.set(name.toLowerCase(),{name,size,compressedSize,method,crc,dataOffset});at=next;
 }
 if(at!==directoryEnd||!entries.has('server_backup.json'))throw error('ZIP 목록 또는 백업 설명 파일이 없습니다.');
 ranges.sort((a,b)=>a.start-b.start);for(let i=1;i<ranges.length;i++)if(ranges[i].start<ranges[i-1].end)throw error('ZIP 파일 영역이 중복되었습니다.');
 return entries;
}
function consumeDiskEntry(fd,entry,accept){
 const hash=crypto.createHash('sha256');let crc=0xffffffff,total=0;
 const emit=bytes=>{total+=bytes.length;if(total>entry.size)throw error('압축 해제된 파일 크기가 올바르지 않습니다.');hash.update(bytes);crc=crcUpdate(crc,bytes);accept(bytes);};
 if(entry.method===0){
  const buffer=Buffer.allocUnsafe(Math.min(COPY_CHUNK,entry.size));let offset=0;
  while(offset<entry.size){const length=Math.min(buffer.length,entry.size-offset);let done=0;
   while(done<length){const count=fs.readSync(fd,buffer,done,length-done,entry.dataOffset+offset+done);if(!count)throw error('ZIP 파일이 예상보다 일찍 끝났습니다.');done+=count;}
   emit(buffer.subarray(0,length));offset+=length;
  }
 }else{
  let output;try{output=zlib.inflateRawSync(readAt(fd,entry.dataOffset,entry.compressedSize),{maxOutputLength:Math.max(1,entry.size)});}catch{throw error('ZIP 항목의 압축을 풀 수 없습니다: '+entry.name);}
  emit(output);
 }
 if(total!==entry.size||((crc^0xffffffff)>>>0)!==entry.crc)throw error('ZIP 파일 크기 또는 CRC 검증에 실패했습니다: '+entry.name);
 return hash.digest('hex');
}
function openDiskBackup(filename){
 const fd=fs.openSync(path.resolve(filename),'r');
 try{
  const stat=fs.fstatSync(fd);if(!stat.isFile())throw error('백업 경로는 일반 ZIP 파일이어야 합니다.');
  const entries=diskZipEntries(fd,stat.size),description=entries.get('server_backup.json');
  if(description.size>MAX_MANIFEST)throw error('백업 설명 파일이 허용 크기를 초과했습니다.');
  const chunks=[];consumeDiskEntry(fd,description,bytes=>chunks.push(Buffer.from(bytes)));
  let manifest;try{manifest=JSON.parse(Buffer.concat(chunks).toString('utf8'));}catch{throw error('백업 설명 파일을 읽을 수 없습니다.');}
  if(manifest.format!=='parts-monitor-server-backup'||manifest.version!==1||!Number.isSafeInteger(manifest.revision)||manifest.revision<0||!Array.isArray(manifest.files)||!manifest.files.length||manifest.files.length+1!==entries.size)throw error('백업 형식 또는 파일 개수가 올바르지 않습니다.');
  const paths=new Set(),names=new Set();
  for(const item of manifest.files){
   if(!item||!allowedPath(item.path))throw error('허용하지 않은 저장 경로입니다.');
   if(paths.has(item.path))throw error('저장 경로가 중복되었습니다: '+item.path);paths.add(item.path);
   if(!/^Backup_\d{6}\.bin$/.test(item.file||'')||names.has(item.file))throw error('백업 항목 이름이 잘못되었거나 중복되었습니다.');names.add(item.file);
   const zip=entries.get(item.file.toLowerCase());if(!zip||!Number.isSafeInteger(item.size)||item.size<1||zip.size!==item.size||!/^[a-f0-9]{64}$/.test(item.sha256||''))throw error('백업 항목 크기 또는 무결성 정보가 올바르지 않습니다.');
  }
  if(!paths.has('current.json'))throw error('현재 저장본 위치가 없습니다.');
  return {manifest,close(){fs.closeSync(fd);},extract(stage){
   for(const item of manifest.files){const dest=path.join(stage,item.path);fs.mkdirSync(path.dirname(dest),{recursive:true});const output=fs.openSync(dest,'wx',0o600);let hash;
    try{hash=consumeDiskEntry(fd,entries.get(item.file.toLowerCase()),bytes=>writeAll(output,bytes));}finally{fs.closeSync(output);}
    if(hash!==item.sha256)throw error('파일 무결성 검증에 실패했습니다: '+item.path);
   }
  }};
 }catch(problem){fs.closeSync(fd);throw problem;}
}
function validateStaged(directory,manifest){
 // Validate both pointer files explicitly so createStore cannot mask corruption
 // through its normal automatic previous-generation recovery behavior.
 for(const name of ['current.json','previous.json']){
  const location=path.join(directory,name);if(!fs.existsSync(location))continue;
  let pointer,envelope;try{
   pointer=JSON.parse(fs.readFileSync(location,'utf8'));
   if(pointer.format!==1||!Number.isSafeInteger(pointer.revision)||pointer.revision<0||!GENERATION.test(pointer.generation||'')||!/^[a-f0-9]{64}$/.test(pointer.sha256||''))throw Error();
   const bytes=fs.readFileSync(path.join(directory,'generations',pointer.generation));if(sha(bytes)!==pointer.sha256)throw Error();
   envelope=JSON.parse(zlib.gunzipSync(bytes));if(![1,2].includes(envelope.format)||envelope.revision!==pointer.revision)throw Error();
  }catch{throw error(name+'와 연결된 저장본이 올바르지 않습니다.');}
  if(name==='current.json'&&pointer.revision!==manifest.revision)throw error('현재 저장본과 백업 버전이 일치하지 않습니다.');
 }
 const store=createStore({dataDir:directory});try{
  const saved=store.compactManifest();if(saved.recoveryNotice||saved.revision!==manifest.revision)throw error('최신 저장본을 그대로 복원할 수 없습니다.');
  // Verify every committed historical source one at a time. Reading only the
  // latest report would miss a corrupt blob used exclusively by an older week.
  const checked=new Set();
  for(const commit of store.listCommits(10000)){
   if(!GENERATION.test(commit.generation||'')||!fs.existsSync(path.join(directory,'generations',commit.generation)))throw error('저장 이력의 파일이 없습니다.');
   let generation;try{generation=JSON.parse(zlib.gunzipSync(fs.readFileSync(path.join(directory,'generations',commit.generation))));if(![1,2].includes(generation.format)||generation.revision!==commit.revision)throw Error();}catch{throw error('저장 이력 파일이 손상되었습니다.');}
   if(generation.format===2){
    if(!Array.isArray(generation.sourceIndex))throw error('분석 원본 목록이 없습니다.');
    for(const descriptor of generation.sourceIndex){
     if(!/^[a-f0-9]{64}$/.test(descriptor?.hash||''))throw error('분석 원본 식별자가 올바르지 않습니다.');
     if(checked.has(descriptor.hash))continue;
     try{const raw=zlib.gunzipSync(fs.readFileSync(path.join(directory,'sources',descriptor.hash+'.json.gz')));if(sha(raw)!==descriptor.hash||!Array.isArray(JSON.parse(raw).rows))throw Error();}catch{throw error('분석 원본이 없거나 손상되었습니다: '+descriptor.hash);}
     checked.add(descriptor.hash);
    }
   }
  }
  for(const raw of store.listRaw())store.readRaw(raw.id);
  createAuth(directory);
  return {revision:saved.revision,reportCount:store.status().reportCount,rawCount:store.status().rawCount};
 }finally{store.close();}
}
function restoreBackup({backupPath,bytes,dataDir,fsOps=fs}={}){
 if(!dataDir||(!backupPath&&!bytes))throw error('--backup과 --data-dir을 지정하세요.');
 const target=path.resolve(dataDir),parent=path.dirname(target);
 if(target===parent)throw error('파일 시스템 루트에는 복원할 수 없습니다.');
 assertStopped(target);
 if(fs.existsSync(target)&&!fs.lstatSync(target).isDirectory())throw error('복원 위치는 일반 폴더여야 합니다.');
 const archive=bytes?(()=>{
  const decoded=decodeBackup(bytes);return {manifest:decoded.manifest,close(){},extract(stage){
   for(const entry of decoded.files){const dest=path.join(stage,entry.path);fs.mkdirSync(path.dirname(dest),{recursive:true});fs.writeFileSync(dest,entry.bytes,{flag:'wx',mode:0o600});}
  }};
 })():openDiskBackup(backupPath);
 let stage=null,preserved=null,targetReserved=false;
 const lockText=JSON.stringify({pid:process.pid,startedAt:new Date().toISOString(),operation:'restore'});
 const removeOwnLock=directory=>{const name=path.join(directory,'server.lock');try{if(JSON.parse(fs.readFileSync(name,'utf8')).pid===process.pid)fs.unlinkSync(name);}catch(e){if(e.code!=='ENOENT')throw e;}};
 try{
  fs.mkdirSync(parent,{recursive:true});stage=fs.mkdtempSync(path.join(parent,'.parts-restore-'));archive.extract(stage);
  const result=validateStaged(stage,archive.manifest);
  assertStopped(target);
  // Reserve the target and replacement with the same writer lock the server
  // uses, closing the window in which another launcher could start a writer.
  if(!fs.existsSync(target))fs.mkdirSync(target);
  const targetLock=path.join(target,'server.lock');if(fs.existsSync(targetLock))fs.unlinkSync(targetLock);
  fs.writeFileSync(targetLock,lockText,{flag:'wx',mode:0o600});targetReserved=true;
  fs.writeFileSync(path.join(stage,'server.lock'),lockText,{flag:'wx',mode:0o600});
  const existing=fs.readdirSync(target).filter(name=>name!=='server.lock');
  preserved=path.join(parent,path.basename(target)+'.before-restore-'+new Date().toISOString().replace(/[:.]/g,'-')+'-'+crypto.randomUUID().slice(0,8));
  fsOps.renameSync(target,preserved);
  try{fsOps.renameSync(stage,target);}catch(e){fsOps.renameSync(preserved,target);preserved=null;throw e;}
  removeOwnLock(target);targetReserved=false;removeOwnLock(preserved);
  if(!existing.length){fs.rmdirSync(preserved);preserved=null;}
  return {...result,dataDir:target,preservedDir:preserved};
 }catch(e){if(targetReserved&&fs.existsSync(target))removeOwnLock(target);throw e;}
 finally{archive.close();if(stage&&fs.existsSync(stage))fs.rmSync(stage,{recursive:true,force:true});}
}
function parseArgs(args){const out={};for(let i=0;i<args.length;i++){const key={'--backup':'backupPath','--data-dir':'dataDir'}[args[i]];if(!key||!args[i+1])throw error('사용법: node scripts/restore-server-backup.cjs --backup 백업.zip --data-dir 복원폴더');out[key]=args[++i];}return out;}
if(require.main===module){try{const result=restoreBackup(parseArgs(process.argv.slice(2)));console.log('복원 완료: '+result.dataDir+'\n저장 버전 '+result.revision+' / 주간 보고 '+result.reportCount+'개 / 원본 '+result.rawCount+'개'+(result.preservedDir?'\n기존 폴더 보관: '+result.preservedDir:''));}catch(e){console.error(e.message);process.exitCode=1;}}
module.exports={restoreBackup,decodeBackup,zipEntries,validateStaged,assertStopped};
