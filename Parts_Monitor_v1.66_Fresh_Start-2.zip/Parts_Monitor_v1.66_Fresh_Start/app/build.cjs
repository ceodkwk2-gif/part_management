const fs = require('fs');
const path = require('path');
const C = require('./src/core.js');
const appVersion = require('./package.json').version;
const args = process.argv.slice(2);
function option(name, fallback) {
  const index = args.indexOf(name);
  if (index < 0) return fallback;
  if (!args[index + 1] || args[index + 1].startsWith('--')) throw Error(name + ' requires a path');
  return args[index + 1];
}
const outDir = path.resolve(option('--out-dir', path.join(__dirname, 'dist')));
const seedPath = path.resolve(option('--seed', path.join(__dirname, 'dist', 'parts-data.json')));
const empty = args.includes('--empty');
if (args.includes('--seed') && !empty && !fs.existsSync(seedPath)) throw Error('Seed file not found: ' + seedPath);
const state = empty || !fs.existsSync(seedPath) ? C.empty() : JSON.parse(fs.readFileSync(seedPath, 'utf8'));
if (!Array.isArray(state.sources) || !state.settings) throw Error('Invalid seed state');
const safe = text => text.replace(/<\/(script|body|head)/gi, '<\\/$1');
const read = file => fs.readFileSync(path.join(__dirname, file), 'utf8');
const scriptFiles = [
  ['vendor', 'vendor/xlsx.full.min.js'],
  ['siel', 'src/siel.js'],
  ['core', 'src/core.js'],
  ['part-names', 'src/part-names.js'],
  ['reporting', 'src/reporting.js'],
  ['history', 'src/history.js'],
  ['risk', 'src/risk.js'],
  ['leadtime', 'src/leadtime.js'],
  ['actions', 'src/actions.js'],
  ['operations', 'src/operations.js'],
  ['pipeline', 'src/pipeline.js'],
  ['packaging', 'src/packaging.js'],
  ['wip-tat', 'src/wip-tat.js'],
  ['first-confirmed', 'src/first-confirmed.js'],
  ['wip-trace', 'src/wip-trace.js'],
  ['followups', 'src/followups.js'],
  ['i18n', 'src/i18n.js'],
  ['i18n-extra', 'src/i18n-extra.js'],
  ['share-tables', 'src/share-tables.js'],
  ['share-dialog', 'src/share-dialog.js'],
  ['share-i18n', 'src/share-i18n.js'],
  ['server-client', 'src/server-client.js'],
  ['summary-data', 'src/summary-data.js'],
  ['supply-stages', 'src/supply-stages.js'],
  ['stage-data', 'src/stage-data.js'],
  ['stage-dashboard', 'src/stage-dashboard.js'],
  ['action-requests', 'src/action-requests.js'],
  ['workflow','src/workflow.js'],
  ['summary-mail', 'src/summary-mail.js'],
  ['overdue-mail', 'src/overdue-mail.js'],
  ['chart-labels', 'src/chart-labels.js'],
  ['overview', 'src/overview.js'],
  ['part-trace','src/part-trace.js'],
  ['summary-downloads', 'src/summary-downloads.js'],
  ['report-export', 'src/report-export.js'],
  ['first-confirmed-panel', 'src/first-confirmed-panel.js'],
  ['first-confirmed-bulk','src/first-confirmed-bulk.js'],
  ['workflow-ui','src/workflow-ui.js'],
  ['archive-panel','src/archive-panel.js'],
  ['upload-board', 'src/upload-board.js'],
  ['upload-panel', 'src/upload-panel.js'],
  ['upload-flow', 'src/upload-flow.js'],
  ['app', 'src/app.js']
].filter(([,file]) => fs.existsSync(path.join(__dirname, file)))
 ;
const scriptsFor=mode=>scriptFiles.map(([id,file])=>`<script id="${id}">${safe(read(mode==='server'&&id==='app'?'src/server-app.js':file))}</script>`).join('');
const themeScript='<script id="theme">'+safe(read('src/theme.js'))+'</script>';
const css = read('src/style.css') + '\n' + read('src/share-dialog.css') + (fs.existsSync(path.join(__dirname,'src/server.css'))?'\n'+read('src/server.css'):'');
const extensionCss=['src/upload-board.css','src/stage-dashboard.css','src/overview.css','src/first-confirmed-panel.css','src/upload-panel.css','src/v144.css','src/v145.css','src/part-trace.css','src/workspace.css','src/workflow.css'].filter(file=>fs.existsSync(path.join(__dirname,file))).map(read).join('\n');
const seed = JSON.stringify(state).replace(/</g, '\\u003c');
fs.mkdirSync(outDir, {recursive: true});
for (const mode of ['admin', 'viewer', 'server']) {
  const display = mode === 'admin' ? '관리자' : '조회';
  const effectiveMode=mode==='server'?'viewer':mode;
  const file = mode==='server'?'server-template.html':`Parts_Monitor_${mode === 'admin' ? 'Admin' : 'Viewer'}.html`;
  const html = `<!doctype html><html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Parts Monitor v${appVersion} · ${display}</title><link rel="icon" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 40 40'%3E%3Crect width='40' height='40' rx='8' fill='%23155fc6'/%3E%3Ctext x='11' y='29' font-family='Arial' font-size='28' fill='white'%3EP%3C/text%3E%3C/svg%3E"><style>${css}\n${extensionCss}\n${read('src/theme.css')}</style>${themeScript}</head><body data-mode="${effectiveMode}"><div id="root"></div><script id="seed" type="application/json">${mode==='server'?JSON.stringify(C.empty()):seed}</script>${scriptsFor(mode)}</body></html>`;
  fs.writeFileSync(path.join(outDir, file), html);
}
console.log(`Built offline admin and viewer (${state.sources.length} source snapshots).`);
