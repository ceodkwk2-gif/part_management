'use strict';
const path=require('node:path'),crypto=require('node:crypto'),zlib=require('node:zlib');
const C=require('../src/core.js');
const HASH=/^[a-f0-9]{64}$/;
const digest=bytes=>crypto.createHash('sha256').update(bytes).digest('hex');
const refId=ref=>JSON.stringify([ref.key,ref.revision]);
const clone=value=>JSON.parse(JSON.stringify(value));
function failure(code,message){return Object.assign(new Error(message),{status:503,code});}
// Same reference identity as Reporting.normalizeSource, without changing the
// stored source object returned by the backwards-compatible read() API.
function reference(source){
 const data={...source,operator:C.canonicalOperator(source.center,source.operator,source.type)};data.id=C.sourceKey(data);delete data.reportingRevision;
 let a=2166136261,b=2246822519;const text=JSON.stringify(data);for(let i=0;i<text.length;i++){const c=text.charCodeAt(i);a=Math.imul(a^c,16777619);b=Math.imul(b^c,3266489917);}
 return {key:C.sourceKey(source),revision:(a>>>0).toString(16).padStart(8,'0')+(b>>>0).toString(16).padStart(8,'0')+'-'+text.length};
}
function metadata(source){
 const result={};for(const key of ['id','type','center','operator','date','assignedWeek','rawId','sourceDate','reportWeek','datePrecision','dateBasis','dateLabel','demo','demoAssignment','file','sheet','sheets','wipImportComplete','duplicates','total','holdDate','usageMonths','rawSha256','importedAt','revisedAt','importPath','relativePath','archiveName','sheetAudit','issues'])if(source[key]!==undefined)result[key]=source[key];
 result.rowCount=Array.isArray(source.rows)?source.rows.length:0;return result;
}
function createSourceBlobs({fs,dir,atomicWrite}){
 fs.mkdirSync(dir,{recursive:true});
 function filename(hash){if(!HASH.test(hash||''))throw failure('INVALID_SOURCE_HASH','저장 원본 식별자가 올바르지 않습니다.');return path.join(dir,hash+'.json.gz');}
 function read(hash){
  try{const bytes=zlib.gunzipSync(fs.readFileSync(filename(hash)));if(digest(bytes)!==hash)throw Error('checksum mismatch');const source=JSON.parse(bytes);if(!source||typeof source!=='object'||!Array.isArray(source.rows))throw Error('invalid source');return source;}
  catch(error){if(error.code==='INVALID_SOURCE_HASH')throw error;throw failure('SOURCE_INTEGRITY_ERROR','보관된 분석 원본의 무결성을 확인할 수 없습니다. 이전 백업을 확인하세요.');}
 }
 function write(source,ref=reference(source)){
  const bytes=Buffer.from(JSON.stringify(source)),hash=digest(bytes),target=filename(hash);
  if(fs.existsSync(target)){read(hash);}else atomicWrite(target,zlib.gzipSync(bytes,{level:6}));
  return {...ref,hash,meta:metadata(source)};
 }
 function validateDescriptor(value){
  if(!value||typeof value.key!=='string'||typeof value.revision!=='string'||!HASH.test(value.hash||'')||!value.meta||typeof value.meta!=='object'||!fs.existsSync(filename(value.hash)))throw failure('SOURCE_REFERENCE_MISSING','보고가 참조하는 분석 원본을 찾을 수 없습니다.');
 }
 function compact(state){
  const rest={...state};delete rest.sources;delete rest.reportingSourceArchive;
  const index=new Map(),put=(source,ref)=>{const item=write(source,ref),id=refId(item),old=index.get(id);if(old&&old.hash!==item.hash)throw failure('SOURCE_REFERENCE_CONFLICT','같은 원본 버전의 내용이 다릅니다.');index.set(id,item);return {key:item.key,revision:item.revision};};
  const currentSourceRefs=(state.sources||[]).map(source=>put(source,reference(source))),archiveSourceRefs={};
  for(const [key,source]of Object.entries(state.reportingSourceArchive||{})){let pair;try{pair=JSON.parse(key);}catch(_){throw failure('INVALID_SOURCE_REFERENCE','보관 원본 참조 형식이 올바르지 않습니다.');}if(!Array.isArray(pair)||pair.length!==2)throw failure('INVALID_SOURCE_REFERENCE','보관 원본 참조 형식이 올바르지 않습니다.');archiveSourceRefs[key]=put(source,{key:pair[0],revision:pair[1]});}
  return {state:clone(rest),sourceIndex:[...index.values()],currentSourceRefs,archiveSourceRefs};
 }
 function materialize(manifest){
  const index=new Map(manifest.sourceIndex.map(item=>[refId(item),item])),load=ref=>{const descriptor=index.get(refId(ref));if(!descriptor)throw failure('SOURCE_REFERENCE_MISSING','원본 버전을 찾을 수 없습니다.');return read(descriptor.hash);};
  return {...clone(manifest.state),sources:manifest.currentSourceRefs.map(load),reportingSourceArchive:Object.fromEntries(Object.entries(manifest.archiveSourceRefs).map(([key,ref])=>[key,load(ref)]))};
 }
 return {read,write,compact,materialize,validateDescriptor,filename};
}
module.exports={createSourceBlobs,reference,metadata,refId,HASH};
