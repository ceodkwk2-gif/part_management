'use strict';
// Updates operate on small report/source references. Only the selected week's
// full sources and the newly submitted sources are needed for import review.
const C=require('../src/core.js'),R=require('../src/reporting.js'),P=require('../src/pipeline.js'),Trace=require('../src/wip-trace.js'),First=require('../src/first-confirmed.js');
const Weekly=require('../src/weekly-policy.js');
const {reference,refId}=require('./source-blobs.cjs');
const clone=value=>JSON.parse(JSON.stringify(value));
const fail=(status,message,details)=>Object.assign(new Error(message),{status,...(details?{details}:{})});
function checkedSettings(value,current={}){
 if(!value||typeof value!=='object'||Array.isArray(value))throw fail(422,'설정을 확인하세요.');
 const settings={...C.empty().settings,lowUsageSixMonthMax:2,...current,...value};
 const constraints={months:[1,24],targetMonths:[.1,24],indiaMonths:[0,24],hqMonths:[0,24],lowUsageSixMonthMax:[1,1000]};
 for(const [k,[lo,hi]] of Object.entries(constraints))if(!Number.isFinite(settings[k])||settings[k]<lo||settings[k]>hi||['months','lowUsageSixMonthMax'].includes(k)&&!Number.isInteger(settings[k]))throw fail(422,'설정 범위를 확인하세요: '+k);
 return settings;
}
function metadataState(manifest){
 const index=new Map(manifest.sourceIndex.map(item=>[refId(item),item]));
 const source=ref=>{const item=index.get(refId(ref));if(!item)throw fail(422,'원본 참조를 찾을 수 없습니다.');return {...item.meta,id:item.key,reportingRevision:item.revision,__reportingMetadata:true,rows:[]};};
 return {...manifest.state,sources:manifest.currentSourceRefs.map(source),reportingSourceArchive:Object.fromEntries(Object.entries(manifest.archiveSourceRefs).map(([id,ref])=>[id,source(ref)]))};
}
function createUpdateService({store}){
 function current(){const manifest=store.compactManifest();return {manifest,state:metadataState(manifest)};}
 function checkRevision(body){if(!Number.isSafeInteger(body.baseRevision)||body.baseRevision!==store.status().revision)throw Object.assign(fail(409,'다른 화면에서 자료가 갱신됐습니다. 최신 결과를 불러온 뒤 다시 반영하세요.'),{code:'REVISION_CONFLICT'});}
 function validateIncoming(sources){
  if(!Array.isArray(sources)||sources.length>200)throw fail(400,'한 번에 반영할 자료 목록을 확인하세요.');
  for(const source of sources)if(!source||typeof source!=='object'||source.__reportingMetadata||!Array.isArray(source.rows)||!P.slotKey(source))throw fail(422,'원본 행·자료 종류·센터·사업자를 확인하세요.');
 }
 function review(body){
  validateIncoming(body.sources||[]);if(!R.validDate(body.reportDate))throw fail(400,'보고 기준일을 확인하세요.');
  const {state}=current(),list=R.reports(state),id=R.weekStart(body.reportDate),entry=list.find(report=>report.id===id)||list.filter(report=>report.reportDate<=body.reportDate).at(-1);
  const basis=entry?store.readReportState(entry.id):{...state,sources:[],reportingSourceArchive:{},reportingWeeks:[]};
  // Pipeline's duplicate/content comparison needs this week's real sources,
  // not the metadata placeholders. Earlier reports are irrelevant to review.
  const incoming=Weekly.bind(body.sources||[],body.reportDate);
  const plan=Weekly.enforce(P.evaluate(basis,incoming,body.reportDate,body.choices||{}),basis,incoming,body.reportDate);
  if(body.operation==='carry'&&(list.some(report=>report.id===id)||body.reportDate<=(list.at(-1)?.reportDate||''))){plan.canRecordExisting=false;plan.recordExistingReason='기존 자료 기록은 최신 보고 이후의 새 주에만 가능합니다. 저장된 주는 수정할 파일을 업로드하세요.';}
  return plan;
 }
 function publicReview(body){
  const plan=review(body),meta=source=>source?{id:source.id,type:source.type,center:source.center,operator:source.operator,file:source.file,sheet:source.sheet,importPath:source.importPath,date:source.date,assignedWeek:source.assignedWeek,sourceDate:source.sourceDate,reportWeek:source.reportWeek,datePrecision:source.datePrecision,demo:source.demo,demoAssignment:source.demoAssignment,rowCount:source.rows?.length||0,sheetAudit:source.sheetAudit||[]}:null;
  return {...plan,selectedSources:plan.selectedSources.map(meta),rows:plan.rows.map(row=>({...row,source:meta(row.source),existing:meta(row.existing),candidates:row.candidates.map(item=>({...item,source:meta(item.source)}))}))};
 }
 function saveState(next,manifest,{sources=[],...options}){
  const {sources:currentSources,reportingSourceArchive,...state}=next;
  const ref=source=>({key:C.sourceKey(source),revision:source.reportingRevision});
  return store.saveManifest({manifest:{...manifest,state,currentSourceRefs:currentSources.map(ref),archiveSourceRefs:Object.fromEntries(Object.entries(reportingSourceArchive||{}).map(([id,source])=>[id,ref(source)]))},sources,...options});
 }
 function update(body){
  if(!body||!['import','carry','remove','settings','notes','firstConfirmed','followup','quality','undoImport'].includes(body.operation))throw fail(400,'저장 종류를 확인하세요.');checkRevision(body);
  if(body.operation==='undoImport'){const {manifest,state}=current(),undo=state.lastImportUndo;if(!undo||undo.resultRevision!==body.baseRevision)throw fail(409,'이 실행 이후 다른 변경이 있습니다. 저장 이력에서 복원할 범위를 확인하세요.');const next={...undo.state,undoHistory:[...(state.undoHistory||[]),{at:new Date().toISOString(),reportDate:undo.reportDate,undoneRevision:body.baseRevision}]};store.saveManifest({manifest:{...manifest,state:next,currentSourceRefs:undo.currentSourceRefs,archiveSourceRefs:undo.archiveSourceRefs},sources:[],baseRevision:body.baseRevision,operation:'undoImport',reportDate:undo.reportDate});return store.status();}
  if(body.operation==='followup'){
   const W=require('../src/workflow.js'),{state}=current();
   if(typeof body.rowId!=='string'||body.rowId.length>500)throw fail(400,'부품·센터를 확인하세요.');
   const latest=R.reports(state).at(-1),basis=latest?store.readReportState(latest.id):null;
   if(!basis||!C.calculate(basis,latest.cutoff).allParts.some(r=>r.center+'|'+r.part===body.rowId))throw fail(404,'현재 보고의 부품·센터를 찾지 못했습니다.');
   let value;try{value=W.validateNote(body.value)}catch(e){throw fail(422,e.message)}
   const prior=state.partFollowups?.[body.rowId]||{},updatedAt=new Date().toISOString();
   store.saveMetadata({patch:{partFollowups:{...(state.partFollowups||{}),[body.rowId]:{...prior,...value,updatedAt}}},baseRevision:body.baseRevision,operation:'followup',actor:value.editor,reportDate:latest.reportDate});return store.status();
  }
  if(body.operation==='quality'){
   const {state}=current(),v=body.value;
   if(typeof body.issueId!=='string'||body.issueId.length>5000||!v||!['OPEN','CONFIRMED'].includes(v.status)||typeof v.owner!=='string'||!v.owner.trim()||v.owner.length>100||typeof v.note!=='string'||v.note.length>4000||v.status==='CONFIRMED'&&!v.note.trim())throw fail(422,'담당자·확인 상태·근거를 입력하세요.');
   store.saveMetadata({patch:{qualityReviews:{...(state.qualityReviews||{}),[body.issueId]:{status:v.status,owner:v.owner.trim(),note:v.note.trim(),updatedAt:new Date().toISOString()}}},baseRevision:body.baseRevision,operation:'quality',actor:v.owner});return store.status();
  }
  if(body.operation==='firstConfirmed'){
   if(!Array.isArray(body.changes)||!body.changes.length||body.changes.length>500)throw fail(400,'최초확인일을 저장할 제품·부품을 선택하세요.');
   const {manifest,state}=current(),latest=R.reports(state).at(-1),next={...(state.manualFirstConfirmed||{})},seen=new Set();
   const entries=latest?Trace.evaluate(store.readReportState(latest.id),{reportId:latest.id,asof:latest.cutoff}).byKey:{};
   for(const change of body.changes){
    if(!change||typeof change.key!=='string'||change.key.length>2500||seen.has(change.key)||Object.keys(change).some(key=>!['key','date','note'].includes(key)))throw fail(400,'최초확인일 변경 목록을 확인하세요.');seen.add(change.key);
    if(change.date===null){if(!Object.hasOwn(next,change.key)&&!entries[change.key])throw fail(404,'선택한 제품·부품 기록을 찾지 못했습니다.');delete next[change.key];continue;}
    let value;try{value=First.validateChange(entries[change.key],change);}catch(error){throw fail(422,error.message);}
    next[change.key]={...value,updatedAt:new Date().toISOString()};
   }
   store.saveMetadata({patch:{manualFirstConfirmed:next},baseRevision:body.baseRevision,operation:'firstConfirmed',actor:body.actor,reportDate:latest?.reportDate});return store.status();
  }
  if(body.operation==='settings'||body.operation==='notes'){
   const permitted=body.operation==='settings'?new Set(['settings','partLeadTimes','leadTimes']):new Set(['notes','partFollowups','summaryNotes','actionNotes']);
   if(!body.patch||Object.keys(body.patch).some(key=>!permitted.has(key)))throw fail(400,'저장할 설정·조치 기록을 확인하세요.');
   if(body.operation==='settings'&&Object.hasOwn(body.patch,'settings'))body={...body,patch:{...body.patch,settings:checkedSettings(body.patch.settings,current().state.settings)}};
   store.saveMetadata({patch:body.patch,baseRevision:body.baseRevision,operation:body.operation,actor:body.actor,reportDate:body.reportDate});return store.status();
  }
  if(!R.validDate(body.reportDate))throw fail(400,'보고 기준일을 확인하세요.');
  const {manifest,state}=current(),options={baseRevision:body.baseRevision,operation:body.operation,reportDate:body.reportDate,rawIds:body.rawIds||[]};
  let next,newSources=[];
  if(body.operation==='remove'){
   if(!Array.isArray(body.sourceIds)||!body.sourceIds.length)throw fail(400,'취소할 파일을 선택하세요.');next=state;
   for(const id of new Set(body.sourceIds)){const preview=R.previewRemoveSource(next,id,R.weekStart(body.reportDate));if(!preview.source)throw fail(404,'선택 주차에서 취소할 원본을 찾지 못했습니다.');next=R.removeSource(next,id,R.weekStart(body.reportDate));}
  }else{
   const plan=review(body);
   if(body.operation==='import'&&!plan.canApply)throw fail(422,plan.errors.join(' / ')||'반영할 새 자료가 없습니다.');
   if(body.operation==='carry'&&!plan.canRecordExisting)throw fail(422,plan.recordExistingReason||'기존 자료로 이 주를 기록할 수 없습니다.');
   next=R.applySources(state,body.operation==='import'?plan.selectedSources:[],body.reportDate);
   if(body.operation==='import'&&plan.excludedSlots?.length){
    const slots=plan.excludedSlots.map(key=>P.SLOTS.find(slot=>slot.key===key)).filter(Boolean).map(slot=>[slot.type,slot.center||'',slot.operator||''].join('|'));
    next=R.excludeSlots(next,slots,plan.weekId);
   }
   newSources=next.sources.filter(source=>source.__reportingMetadata!==true);
   if(body.operation==='carry')next.reportingWeeks=next.reportingWeeks.map(report=>report.id===plan.weekId?{...report,carriedForward:true}:report);
   const receipt={reportDate:body.reportDate,weekId:plan.weekId,at:new Date().toISOString(),carriedForward:body.operation==='carry',rows:plan.rows.map(row=>({key:row.key,label:row.label,status:row.status,date:row.source?.date||null,file:row.source?.file||null,choice:body.choices?.[row.key]||'auto',message:row.message})),exclusions:plan.excludedSlots||[]};
   next.lastImportReceipt=receipt;next.importReceipts={...(next.importReceipts||{}),[plan.weekId]:receipt};
   const diagnostics=next.importDiagnostics||{},weeks=[...(diagnostics.weeks||[])],existing=weeks.findIndex(week=>week.reportWeek===plan.weekId||week.week===plan.weekId||week.reportDate===body.reportDate),prior=existing>=0?weeks[existing]:{};
   const incomingIssues=(Array.isArray(body.importIssues)?body.importIssues:[]).slice(0,200).map(issue=>({file:String(issue.file||'').slice(0,500),message:String(issue.message||'').slice(0,2000),excluded:issue.excluded===true,status:'open'}));
   if(incomingIssues.some(issue=>!issue.excluded))throw fail(422,'읽지 못한 파일을 정정하거나 이번 반영에서 제외하세요.');
   const repaired=issue=>newSources.find(source=>source.file===issue.file||issue.type&&source.type===issue.type&&(!issue.center||source.center===issue.center)&&(!issue.operator||source.operator===issue.operator)&&R.weekStart(C.sourceSelectionDate(source))===plan.weekId);
   const resolved=(prior.excluded||[]).filter(repaired).map(issue=>({...issue,status:'resolved',resolution:'valid-source-uploaded',resolvedBy:repaired(issue).file,resolvedAt:receipt.at}));
   const excluded=[...(prior.excluded||[]).filter(issue=>!repaired(issue)),...incomingIssues];
   if(existing>=0||excluded.length||resolved.length){const entry={...prior,reportWeek:plan.weekId,reportDate:body.reportDate,excluded,resolved:[...(prior.resolved||[]),...resolved]};if(existing>=0)weeks[existing]=entry;else weeks.push(entry);next.importDiagnostics={...diagnostics,weeks};}
  }
  for(const id of next.lastReportingChange?.affectedReportIds||[R.weekStart(body.reportDate)]){try{Weekly.assertWipPreserved(next,id)}catch(e){throw fail(422,e.message)}}
  if(body.operation==='import'){const {lastImportUndo,...before}=manifest.state;next.lastImportUndo={state:before,currentSourceRefs:manifest.currentSourceRefs,archiveSourceRefs:manifest.archiveSourceRefs,resultRevision:body.baseRevision+1,reportDate:body.reportDate};next.reportingWeeks=next.reportingWeeks.map(r=>r.id===R.weekStart(body.reportDate)?{...r,uploadPolicy:'slots-v160'}:r);}
  saveState(next,manifest,{...options,sources:newSources});return {...store.status(),affectedReportIds:next.lastReportingChange?.affectedReportIds||[R.weekStart(body.reportDate)]};
 }
 function previewSettings(body){
  checkRevision(body);const {state}=current(),settings=checkedSettings(body.settings,state.settings);
  const O=require('../src/overview.js'),W=require('../src/workflow.js');
  const result=R.reports(state).map(report=>{const basis=store.readReportState(report.id),calc=s=>{const r=C.calculate({...basis,settings:s},report.cutoff);const data={rows:r.allParts};return {shortage:O.metrics(data,'ALL').SHORTAGE,additional:W.orderTotals(data).all};};return {week:report.id,before:calc(basis.settings),after:calc(settings)};});
  return {baseRevision:body.baseRevision,scope:'all-reports-current-policy',reports:result};
 }
 return {previewSettings,review:publicReview,update,manifest:()=>{const {state}=current();delete state.partNameIndex;state._metadataOnly=true;return {...store.status(),state,raw:store.listRaw()};}};
}
module.exports={createUpdateService,metadataState};
