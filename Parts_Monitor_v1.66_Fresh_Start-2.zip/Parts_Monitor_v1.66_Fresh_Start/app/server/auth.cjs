'use strict';
const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const fail=(status,message)=>Object.assign(new Error(message),{status});
const same=(a,b)=>{const x=Buffer.from(String(a||'')),y=Buffer.from(String(b||''));return x.length===y.length&&crypto.timingSafeEqual(x,y)};
function createAuth(dataDir,{now=()=>Date.now(),ttl=8*60*60*1000}={}){
 const file=path.join(dataDir,'admin-auth.json'),sessions=new Map(),failures=new Map();
 let credential=null;
 if(fs.existsSync(file)){credential=JSON.parse(fs.readFileSync(file,'utf8'));if(!/^[a-f0-9]{32}$/.test(credential.salt||'')||!/^[a-f0-9]{128}$/.test(credential.hash||''))throw Error('관리자 인증 파일을 읽을 수 없습니다. 백업 또는 지원 담당자에게 확인하세요.');}
 const passwordHash=(password,salt)=>crypto.scryptSync(password,salt,64).toString('hex');
 function prune(){const time=now();for(const [key,value]of sessions)if(value.expires<=time)sessions.delete(key);for(const[key,value]of failures)if(time-value.at>15*60*1000)failures.delete(key);}
 function login(password,ip='local'){prune();if(!credential)throw fail(409,'서버 PC에서 관리자 비밀번호를 먼저 설정하세요.');const prior=failures.get(ip);if(prior?.count>=5)throw fail(429,'로그인 시도가 반복되어 잠시 제한했습니다. 15분 후 다시 시도하세요.');if(typeof password!=='string'||Buffer.byteLength(password)>1024||!same(passwordHash(password,credential.salt),credential.hash)){failures.set(ip,{count:(prior?.count||0)+1,at:prior?.at||now()});throw fail(401,'비밀번호가 맞지 않습니다.');}failures.delete(ip);const id=crypto.randomBytes(32).toString('hex'),session={csrfToken:crypto.randomBytes(32).toString('hex'),expires:now()+ttl};sessions.set(id,session);return {id,...session};}
 function setup(password,ip){if(credential)throw fail(409,'관리자 설정이 이미 완료되어 있습니다.');if(typeof password!=='string'||password.length<8||Buffer.byteLength(password)>1024)throw fail(400,'관리자 비밀번호는 8자 이상으로 입력하세요.');const salt=crypto.randomBytes(16).toString('hex');const next={version:1,salt,hash:passwordHash(password,salt),createdAt:new Date(now()).toISOString()};fs.mkdirSync(dataDir,{recursive:true});const temp=file+'.'+crypto.randomUUID()+'.tmp';try{const fd=fs.openSync(temp,'wx',0o600);try{fs.writeFileSync(fd,JSON.stringify(next));fs.fsyncSync(fd)}finally{fs.closeSync(fd)}fs.renameSync(temp,file)}finally{if(fs.existsSync(temp))fs.unlinkSync(temp)}credential=next;return login(password,ip);}
 function get(cookie){prune();const id=String(cookie||'').split(';').map(s=>s.trim()).find(s=>s.startsWith('parts_session='))?.slice(14);const session=sessions.get(id);return session?{id,...session}:null;}
 return {setup,login,get,logout(id){sessions.delete(id)},isSetup:()=>!!credential,verifyCsrf(session,token){return !!session&&same(session.csrfToken,token)},file};
}
module.exports={createAuth};
