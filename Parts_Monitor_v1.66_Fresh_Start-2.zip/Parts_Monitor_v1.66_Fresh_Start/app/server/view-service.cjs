'use strict';
// Server-only projections. Never assembles the entire annual source state or
// sends source rows/status dictionaries to a browser. Source blobs remain the
// store's responsibility; this service reads one report/source at a time.
const crypto=require('node:crypto'),fs=require('node:fs'),path=require('node:path'),zlib=require('node:zlib');
const C=require('../src/core.js'),R=require('../src/reporting.js'),S=require('../src/summary-data.js'),T=require('../src/wip-tat.js'),Trace=require('../src/wip-trace.js'),I=require('../src/i18n.js');
require('../src/i18n-extra.js')(I);require('../src/share-i18n.js')(I);
const SCOPES=['전체','Flex','CTDI'],OUTPUT_CACHE_VERSION='1.54';
const refKey=ref=>JSON.stringify([ref.key,ref.revision]);
const hash=value=>crypto.createHash('sha256').update(JSON.stringify(value)).digest('hex');
const identity=row=>JSON.parse(Trace.rowKey(row,'1000-000000'))[0];
const sourceRow=(row,source)=>({...row,center:source.center,operator:source.operator,source:source.file,sheet:row.sheet||source.sheet,date:source.date});
const norm=value=>String(value??'').trim().toUpperCase();
const statusIdentity=key=>{const split=String(key).indexOf('|');return split<0?norm(key):norm(String(key).slice(0,split))+'|'+norm(String(key).slice(split+1));};
function createViewService({store,maxViews=2,cacheDir}={}){
 if(!store||typeof store.compactManifest!=='function'||typeof store.readSources!=='function'||typeof store.readReportState!=='function')throw Error('A compact source store is required.');
 const weekly=new Map(),views=new Map();let traced=null;
 const stats={weekBuilds:0,traceBuilds:0,viewBuilds:0,viewHits:0,sourceReads:0,diskHits:0,cacheWriteFailures:0};
 // Derived caches are disposable, separate from source/generation storage.
 // Fingerprint actual calculation modules so a code upgrade cannot reuse old
 // quantities merely because report refs/settings happened to stay the same.
 const fingerprint=hash({version:OUTPUT_CACHE_VERSION,modules:[__filename,path.join(__dirname,'store.cjs'),path.join(__dirname,'source-blobs.cjs'),...['siel','core','reporting','actions','operations','followups','wip-tat','first-confirmed','wip-trace','part-names','leadtime','summary-data','i18n','i18n-extra','share-i18n'].map(name=>path.join(__dirname,'../src',name+'.js'))].map(file=>fs.readFileSync(file,'utf8'))});
 let cacheRoot=null;if(cacheDir)try{cacheRoot=path.resolve(cacheDir);fs.mkdirSync(cacheRoot,{recursive:true});}catch(_){stats.cacheWriteFailures++;cacheRoot=null;}
 const cacheFile=name=>cacheRoot?path.join(cacheRoot,name+'.json.gz'):null;
 function readCache(name,key){
  const file=cacheFile(name);if(!file)return null;
  try{if(fs.statSync(file).size>32*1024*1024)return null;const value=JSON.parse(zlib.gunzipSync(fs.readFileSync(file),{maxOutputLength:64*1024*1024}));if(value.fingerprint!==fingerprint||value.key!==key)return null;stats.diskHits++;return value.value;}catch(_){return null;}
 }
 function writeCache(name,key,value){
  const file=cacheFile(name);if(!file)return;const temp=file+'.'+crypto.randomUUID()+'.tmp';
  try{fs.writeFileSync(temp,zlib.gzipSync(Buffer.from(JSON.stringify({fingerprint,key,value})),{level:3}));fs.renameSync(temp,file);}catch(_){stats.cacheWriteFailures++;}finally{try{fs.unlinkSync(temp);}catch(_){}}
 }
 function manifest(){return store.compactManifest();}
 function sourceIndex(m){return new Map((m.sourceIndex||[]).map(entry=>[refKey(entry),entry]));}
 function reportKey(report,state){return hash({report,settings:state.settings||{}});}
 function pointFor(report,m){
  const key=reportKey(report,m.state),old=weekly.get(report.id);if(old?.key===key)return old.point;
  const saved=readCache('week-'+report.id,key);if(saved){weekly.set(report.id,{key,point:saved});return saved;}
  const state=store.readReportState(report.id),point=S.weekMetrics({...state,reportingWeeks:m.state.reportingWeeks.map(item=>item.id===report.id?state.reportingWeeks[0]:item)},report);
  // Only identities and required part codes are needed to compare adjacent
  // observations; do not retain Core/Actions/source objects per historical week.
  point._products=point._products.map(product=>({productId:product.productId,center:product.center,partEntries:product.partEntries.map(part=>({part:part.part,quantity:part.quantity}))}));
  weekly.set(report.id,{key,point});writeCache('week-'+report.id,key,point);stats.weekBuilds++;return point;
 }
 function traceFor(selected,m,currentState){
  const reports=R.reports(m.state).filter(report=>report.id<=selected.id&&report.cutoff<=selected.cutoff),index=sourceIndex(m);
  const wantedRefs=new Map(),activeByReport=new Map();
  for(const report of reports){const excluded=new Set((report.excludedSourceRefs||[]).map(refKey)),slots=new Map();for(const ref of report.sourceRefs||[]){
   const entry=index.get(refKey(ref)),meta=entry?.meta;if(excluded.has(refKey(ref))||meta?.type!=='wip'||!R.validDate(meta.date)||C.sourceSelectionDate(meta)>report.cutoff)continue;
   const slot=JSON.stringify([norm(meta.center),norm(C.canonicalOperator(meta.center,meta.operator,'wip'))]),old=slots.get(slot);if(!old||meta.date>=old.date)slots.set(slot,{ref,date:meta.date});
  }const active=[...slots.values()].map(value=>value.ref);activeByReport.set(report.id,active);for(const ref of active)wantedRefs.set(refKey(ref),ref);}
  const key=hash({reports:reports.map(report=>({id:report.id,reportDate:report.reportDate,cutoff:report.cutoff,refs:activeByReport.get(report.id)})),selected:selected.id,manualFirstConfirmed:m.state.manualFirstConfirmed||{}});
  if(traced?.key===key)return traced.value;
  const saved=readCache('trace-latest',key);if(saved){traced={key,value:saved};return saved;}
  const wanted=new Set(),wantedStatuses=new Map();for(const source of currentState.sources||[])if(source.type==='wip')for(const row of source.rows||[]){
   const id=identity(sourceRow(row,source));wanted.add(id);const parts=JSON.parse(id),scope=parts[0];if(!wantedStatuses.has(scope))wantedStatuses.set(scope,new Set());
   if(parts[1]==='identity')wantedStatuses.get(scope).add(parts[2]+'|'+parts[3]);else if(parts[1]==='key')wantedStatuses.get(scope).add(parts[2]);
  }
  const projected=new Map();
  for(const [id,ref] of wantedRefs){
   const source=store.readSources([ref])[0];stats.sourceReads++;if(!source)continue;
   const rows=(source.rows||[]).filter(row=>wanted.has(identity(sourceRow(row,source)))),statuses={};
   // Iteration avoids Object.entries' large temporary array for all historical
   // nonwaiting products. Only current product identities enter Trace's Maps.
   const scope=JSON.parse(identity(sourceRow({key:'scope'},source)))[0],keys=wantedStatuses.get(scope);
   for(const rowKey in source.statuses||{})if(keys?.has(statusIdentity(rowKey)))statuses[rowKey]=source.statuses[rowKey];
   projected.set(id,{...source,rows,statuses,reportingRevision:ref.revision});
  }
  // Metadata placeholders satisfy all saved source refs, but only WIP sources
  // carry projected row data. Revision identifiers remain those of originals;
  // this disposable read model is never persisted or revision-hashed.
  const sources=(m.sourceIndex||[]).map(entry=>projected.get(refKey(entry))||{...entry.meta,id:entry.key,reportingRevision:entry.revision,rows:[],statuses:{}});
  const state={...m.state,sources,reportingSourceArchive:{},reportingWeeks:reports,selectedReportingWeek:selected.id};
  const value=Trace.evaluate(state,{asof:selected.cutoff,reportId:selected.id});traced={key,value};writeCache('trace-latest',key,value);stats.traceBuilds++;return value;
 }
 function attachTrend(output,reports,m){
  let previous=null;const trend=[];
  for(const report of reports){const point=pointFor(report,m),changes={};for(const scope of SCOPES){const change=S.waitingChanges(point._products,previous?._products,scope,point.availableByCenter[scope].wip,previous?.availableByCenter[scope].wip);change.previousReportWeek=previous?.week||null;change.reportGapDays=previous?T.ageAt(previous.week,point.week).age:null;change.consecutiveReportingWeeks=change.reportGapDays===7;if(previous&&!change.consecutiveReportingWeeks&&change.available)change.reason+=' · 저장된 두 보고 사이에 빈 주가 있어 연속 주차 관찰을 뜻하지 않음';changes[scope]=change;}
   const {_products,...publicPoint}=point;trend.push({...publicPoint,observedWaitingChanges:changes});previous=point;
  }
  output.trend=trend;output.availability=trend.at(-1)?.available||output.availability;output.availabilityByCenter=trend.at(-1)?.availableByCenter||output.availabilityByCenter;
  output.checks.weeklyEvidence={reportCount:trend.length,sourceDatesPreserved:true,staleWipTrendNull:trend.every(point=>SCOPES.every(scope=>point.availableByCenter[scope].wip||point.knownPartialCounts||point.metricsByCenter[scope].wip===null&&point.metricsByCenter[scope].over45===null)),overdueProducts:output.overdue.metricsByCenter['전체'].products,overduePartKinds:output.overdue.metricsByCenter['전체'].partKinds,overdueRequiredQty:output.overdue.metricsByCenter['전체'].requiredQty,poAllocationConfirmed:false};
 }
 function getView({reportId}={}){
  const m=manifest(),live={manualNotes:m.state.partFollowups||{},qualityReviews:m.state.qualityReviews||{},auditLog:m.state.auditLog||[]},all=R.reports(m.state),selected=reportId!=null?all.find(report=>report.id===reportId):all.at(-1);
  if(reportId!=null&&!selected)throw Error('저장된 주간 보고를 찾지 못했습니다.');
  if(!selected)return {...S.build({...m.state,sources:[],reportingSourceArchive:{}}),...live,revision:m.revision,updatedAt:m.updatedAt};
  const reports=all.filter(report=>report.id<=selected.id&&report.cutoff<=selected.cutoff);
  const key=hash({reports,settings:m.state.settings||{},partLeadTimes:m.state.partLeadTimes||{},supplierRecords:m.state.supplierRecords||[],supplierEvidenceStatus:m.state.supplierEvidenceStatus||{},importDiagnostics:m.state.importDiagnostics||{},manualFirstConfirmed:m.state.manualFirstConfirmed||{}});
  const cached=views.get(selected.id);if(cached?.key===key){stats.viewHits++;return {...cached.value,...live,revision:m.revision,updatedAt:m.updatedAt};}
  const cacheName=selected.id===all.at(-1).id?'view-latest':'view-historical',saved=readCache(cacheName,key);
  if(saved){views.delete(selected.id);views.set(selected.id,{key,value:saved});while(views.size>Math.max(1,maxViews))views.delete(views.keys().next().value);stats.viewHits++;return {...saved,...live,revision:m.revision,updatedAt:m.updatedAt};}
  const currentState=store.readReportState(selected.id),traceResult=traceFor(selected,m,currentState),output=S.build(currentState,{reportId:selected.id,traceResult});
  attachTrend(output,reports,m);stats.viewBuilds++;
  views.delete(selected.id);views.set(selected.id,{key,value:output});writeCache(cacheName,key,output);while(views.size>Math.max(1,maxViews))views.delete(views.keys().next().value);
  const validIds=new Set(all.map(report=>report.id));for(const id of weekly.keys())if(!validIds.has(id))weekly.delete(id);
  return {...output,...live,revision:m.revision,updatedAt:m.updatedAt};
 }
 function invalidate(change={}){
  // Content keys naturally detect changed source refs/settings. Notes-only saves
  // do not affect quantities, traces or follow-up tasks and retain all caches.
  // First-confirmed records participate in view/trace keys; weekly quantities do not.
  if(change.force){weekly.clear();views.clear();traced=null;if(cacheRoot)for(const file of fs.readdirSync(cacheRoot))if(/^(?:week-\d{4}-\d{2}-\d{2}|view-latest|view-historical|trace-latest)\.json\.gz$/.test(file))try{fs.unlinkSync(path.join(cacheRoot,file));}catch(_){}}
 }
 return {getView,getManifest:manifest,invalidate,diagnostics:()=>({...stats,cachedWeeks:weekly.size,cachedViews:views.size,traceCached:!!traced}),close(){weekly.clear();views.clear();traced=null;}};
}
module.exports={createViewService};
