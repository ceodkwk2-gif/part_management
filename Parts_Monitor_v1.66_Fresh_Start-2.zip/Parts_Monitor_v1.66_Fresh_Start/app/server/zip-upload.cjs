'use strict';
// Read uploaded archives entirely in memory. No ZIP entry ever becomes a disk
// path. Both ZIP headers and decompressed bytes are checked before any Excel
// file is returned to the ordinary staged-import flow.
const zlib=require('node:zlib');
const LIMITS=Object.freeze({maxArchiveBytes:128*1024*1024,maxEntryBytes:128*1024*1024,maxTotalBytes:256*1024*1024,maxEntries:500,maxExcelFiles:100,maxRatio:1000});
const fail=(message,status=400)=>Object.assign(new Error('ZIP 확인: '+message),{status});
const crcTable=Array.from({length:256},(_,i)=>{let n=i;for(let j=0;j<8;j++)n=(n&1)?0xedb88320^(n>>>1):n>>>1;return n>>>0;});
function crc32(bytes){let crc=0xffffffff;for(const value of bytes)crc=crcTable[(crc^value)&255]^(crc>>>8);return (crc^0xffffffff)>>>0;}
function utf8(bytes){try{return new TextDecoder('utf-8',{fatal:true}).decode(bytes);}catch{return null;}}
function decodeName(raw,extra,flags){
 let unicodeName=null;
 for(let at=0;at<extra.length;){
  if(at+4>extra.length)throw fail('추가 정보가 손상되었습니다.');
  const tag=extra.readUInt16LE(at),size=extra.readUInt16LE(at+2);at+=4;
  if(at+size>extra.length)throw fail('추가 정보의 길이가 맞지 않습니다.');
  if(tag===0x0001)throw fail('ZIP64는 지원하지 않습니다. Excel 파일을 직접 선택해 주세요.');
  if(tag===0x7075&&size>=5&&extra[at]===1&&extra.readUInt32LE(at+1)===crc32(raw))unicodeName=utf8(extra.subarray(at+5,at+size));
  at+=size;
 }
 if(flags&0x800){const value=utf8(raw);if(value===null)throw fail('UTF-8 파일 이름을 읽을 수 없습니다.');return value;}
 if(unicodeName!==null)return unicodeName;
 const value=utf8(raw);if(value!==null)return value;
 // Legacy Korean archives are common in the existing Excel handover flow.
 try{return new TextDecoder('euc-kr',{fatal:true}).decode(raw);}catch{throw fail('파일 이름 인코딩을 읽을 수 없습니다. ZIP을 풀고 Excel 파일을 직접 선택해 주세요.');}
}
function safePath(value){
 const name=value.replace(/\\/g,'/'),body=name.endsWith('/')?name.slice(0,-1):name;
 if(!body||name.length>1024||/^[\/]|[:\x00-\x1f\x7f]/.test(name)||body.split('/').some(segment=>segment==='..'||segment==='.'||segment==='')){
  throw fail('허용하지 않는 파일 경로가 있습니다.');
 }
 return name;
}
function expandZip(input,{archiveName='upload.zip',...overrides}={}){
 const limits={...LIMITS,...overrides},bytes=Buffer.from(input);
 if(typeof archiveName!=='string'||archiveName.length>240||!archiveName.toLowerCase().endsWith('.zip')||/[/\\\x00-\x1f]/.test(archiveName))throw fail('올바른 ZIP 파일 이름을 사용하세요.');
 if(bytes.length>limits.maxArchiveBytes)throw fail('압축 파일이 허용 크기를 초과했습니다.',413);
 let end=-1;
 for(let at=bytes.length-22;at>=Math.max(0,bytes.length-65557);at--)if(bytes.readUInt32LE(at)===0x06054b50&&at+22+bytes.readUInt16LE(at+20)===bytes.length){end=at;break;}
 if(end<0)throw fail('완전한 ZIP 파일이 아닙니다. 다시 내려받아 선택해 주세요.');
 const count=bytes.readUInt16LE(end+10),directorySize=bytes.readUInt32LE(end+12),directoryOffset=bytes.readUInt32LE(end+16);
 if(bytes.readUInt16LE(end+4)||bytes.readUInt16LE(end+6)||bytes.readUInt16LE(end+8)!==count||count===65535||directorySize===0xffffffff||directoryOffset===0xffffffff||directoryOffset+directorySize!==end)throw fail('분할 ZIP 또는 ZIP64는 지원하지 않습니다. Excel 파일을 직접 선택해 주세요.');
 if(!count)throw fail('압축 파일 안에 파일이 없습니다.');
 if(count>limits.maxEntries)throw fail('압축 파일 안의 항목이 너무 많습니다. 주차별로 나눠 주세요.',413);
 const entries=[],paths=new Set(),excelNames=new Set();let at=directoryOffset,totalBytes=0,excelCount=0;
 for(let i=0;i<count;i++){
  if(at+46>end||bytes.readUInt32LE(at)!==0x02014b50)throw fail('파일 목록이 손상되었습니다.');
  const flags=bytes.readUInt16LE(at+8),method=bytes.readUInt16LE(at+10),crc=bytes.readUInt32LE(at+16),compressed=bytes.readUInt32LE(at+20),size=bytes.readUInt32LE(at+24),nameLength=bytes.readUInt16LE(at+28),extraLength=bytes.readUInt16LE(at+30),commentLength=bytes.readUInt16LE(at+32),disk=bytes.readUInt16LE(at+34),attributes=bytes.readUInt32LE(at+38),offset=bytes.readUInt32LE(at+42),next=at+46+nameLength+extraLength+commentLength;
  if(next>end||!nameLength)throw fail('파일 목록의 길이가 맞지 않습니다.');
  if(flags&0x2041)throw fail('암호화된 ZIP은 읽을 수 없습니다. 암호를 해제한 Excel을 선택해 주세요.');
  if(flags&~0x080e||disk||![0,8].includes(method))throw fail('지원하지 않는 압축 방식입니다. ZIP을 풀고 Excel 파일을 선택해 주세요.');
  if([compressed,size,offset].includes(0xffffffff))throw fail('ZIP64는 지원하지 않습니다.');
  const mode=(attributes>>>16)&0xf000;if(mode&&mode!==0x8000&&mode!==0x4000)throw fail('일반 파일이 아닌 항목이 있습니다.');
  const rawName=bytes.subarray(at+46,at+46+nameLength),extra=bytes.subarray(at+46+nameLength,at+46+nameLength+extraLength),relativePath=safePath(decodeName(rawName,extra,flags)),directory=relativePath.endsWith('/'),name=relativePath.split('/').at(-1),isExcel=!directory&&/\.(xlsx|xls|xlsb)$/i.test(name)&&!name.startsWith('~$')&&!relativePath.startsWith('__MACOSX/');
  const key=relativePath.normalize('NFC').toLowerCase();if(paths.has(key))throw fail('같은 경로의 파일이 중복되어 있습니다: '+relativePath);paths.add(key);
  if(size>limits.maxEntryBytes||(compressed===0&&size>0)||(compressed>0&&size/compressed>limits.maxRatio))throw fail('압축 해제 크기가 허용 범위를 초과했습니다.',413);
  totalBytes+=size;if(totalBytes>limits.maxTotalBytes)throw fail('압축 해제 후 전체 크기가 너무 큽니다. 주차별로 나눠 주세요.',413);
  if(directory&&size)throw fail('폴더 항목에 잘못된 데이터가 있습니다.');
  if(isExcel){
   if(!size)throw fail('빈 Excel 파일이 있습니다: '+relativePath);
   if(name.length>240)throw fail('Excel 파일 이름이 너무 깁니다.');
   const baseKey=name.normalize('NFC').toLowerCase();if(excelNames.has(baseKey))throw fail('서로 다른 폴더에 같은 Excel 파일 이름이 있습니다: '+name+'. 이름을 구분한 뒤 선택해 주세요.');excelNames.add(baseKey);
   if(++excelCount>limits.maxExcelFiles)throw fail('Excel 파일 수가 너무 많습니다. 주차별로 나눠 주세요.',413);
  }
  entries.push({flags,method,crc,compressed,size,offset,rawName,relativePath,name,directory,isExcel});at=next;
 }
 if(at!==end)throw fail('파일 목록의 끝이 일치하지 않습니다.');
 const excelFiles=[],ignoredEntries=[],ranges=[];
 for(const entry of entries){
  const {offset,flags,method,crc,size,compressed,rawName,relativePath,name}=entry;
  if(offset+30>directoryOffset||bytes.readUInt32LE(offset)!==0x04034b50)throw fail('파일 본문을 찾을 수 없습니다: '+relativePath);
  const localFlags=bytes.readUInt16LE(offset+6),localMethod=bytes.readUInt16LE(offset+8),nameLength=bytes.readUInt16LE(offset+26),extraLength=bytes.readUInt16LE(offset+28),start=offset+30+nameLength+extraLength,finish=start+compressed;
  if(start>directoryOffset||finish>directoryOffset||localFlags!==flags||localMethod!==method||!bytes.subarray(offset+30,offset+30+nameLength).equals(rawName))throw fail('파일 목록과 본문 정보가 다릅니다: '+relativePath);
  if(!(flags&8)&&(bytes.readUInt32LE(offset+14)!==crc||bytes.readUInt32LE(offset+18)!==compressed||bytes.readUInt32LE(offset+22)!==size))throw fail('파일 크기 또는 검사값이 일치하지 않습니다: '+relativePath);
  let endOffset=finish;
  if(flags&8){let d=finish;if(d+4<=directoryOffset&&bytes.readUInt32LE(d)===0x08074b50)d+=4;if(d+12>directoryOffset||bytes.readUInt32LE(d)!==crc||bytes.readUInt32LE(d+4)!==compressed||bytes.readUInt32LE(d+8)!==size)throw fail('압축 파일의 끝 정보가 손상되었습니다: '+relativePath);endOffset=d+12;}
  ranges.push({start:offset,end:endOffset});
  let content;
  try{if(method===0)content=bytes.subarray(start,finish);else{const result=zlib.inflateRawSync(bytes.subarray(start,finish),{maxOutputLength:Math.max(1,size),info:true});if(result.engine.bytesWritten!==compressed)throw Error('Trailing compressed bytes');content=result.buffer;}}catch{throw fail('압축을 풀 수 없습니다: '+relativePath);}
  if(content.length!==size||crc32(content)!==crc)throw fail('파일 무결성 검사에 실패했습니다: '+relativePath);
  if(entry.isExcel)excelFiles.push({name,relativePath,archiveName,size,base64:content.toString('base64')});
  else ignoredEntries.push({name:relativePath,reason:entry.directory?'폴더':/\.zip$/i.test(name)?'내부 ZIP: 압축을 풀고 따로 선택해 주세요':name.startsWith('~$')?'Excel 임시 파일':'Excel이 아닌 파일'});
 }
 ranges.sort((a,b)=>a.start-b.start);for(let i=1;i<ranges.length;i++)if(ranges[i].start<ranges[i-1].end)throw fail('파일 영역이 서로 겹치는 잘못된 ZIP입니다.');
 if(!excelFiles.length)throw fail('읽을 Excel(.xlsx/.xls/.xlsb) 파일이 없습니다.');
 return {archiveName,excelFiles,ignoredEntries,fileCount:excelFiles.length,totalBytes:excelFiles.reduce((sum,file)=>sum+file.size,0)};
}
module.exports={expandZip,crc32,LIMITS};
