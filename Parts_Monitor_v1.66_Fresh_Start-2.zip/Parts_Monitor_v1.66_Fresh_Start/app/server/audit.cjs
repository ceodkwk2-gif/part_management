'use strict';
const same=(a,b)=>JSON.stringify(a??null)===JSON.stringify(b??null);
function changesFor(state,patch){
 const changes=[];
 for(const [section,value] of Object.entries(patch)){
  if(value&&typeof value==='object'&&!Array.isArray(value)){
   for(const key of new Set([...Object.keys(state[section]||{}),...Object.keys(value)])){
    const before=state[section]?.[key]??null,after=value[key]??null;
    if(!same(before,after))changes.push({section,key,before,after});
   }
  }else if(!same(state[section],value))changes.push({section,before:state[section]??null,after:value??null});
 }
 return changes;
}
function event(state,patch,{actor,operation,revision,at=new Date().toISOString()}={}){
 const changes=changesFor(state,patch);if(!changes.length)return null;
 return {revision,at,operation,actor:typeof actor==='string'?actor.trim().slice(0,100):'',changes};
}
module.exports={event,changesFor};
