'use strict';
const {Worker,isMainThread,parentPort,workerData}=require('node:worker_threads');
if(!isMainThread){
 const {createStore}=require('./store.cjs'),{createViewService}=require('./view-service.cjs');
 let store=createStore({dataDir:workerData.dataDir});
 const proxy={compactManifest:()=>store.compactManifest(),readSources:refs=>store.readSources(refs),readReportState:id=>store.readReportState(id)};
 const service=createViewService({store:proxy,cacheDir:require('node:path').join(workerData.dataDir,'view-cache')});
 parentPort.on('message',message=>{
  try{if(store.status().revision!==message.revision){store.close();store=createStore({dataDir:workerData.dataDir});}
   const data=service.getView({reportId:message.reportId});parentPort.postMessage({id:message.id,data,diagnostics:service.diagnostics()});
  }catch(error){parentPort.postMessage({id:message.id,error:{message:error.message,status:error.status,code:error.code}});}
 });
}else{
 function createViewWorker({dataDir}){
  let worker=null,nextId=0,closed=false;const pending=new Map(),inflight=new Map();let latestDiagnostics={};
  function rejectAll(error){for(const job of pending.values())job.reject(error);pending.clear();inflight.clear();}
  function start(){
   if(worker)return;worker=new Worker(__filename,{workerData:{dataDir}});
   worker.on('message',message=>{const job=pending.get(message.id);if(!job)return;pending.delete(message.id);inflight.delete(job.key);latestDiagnostics=message.diagnostics||latestDiagnostics;message.error?job.reject(Object.assign(new Error(message.error.message),message.error)):job.resolve(message.data);});
   worker.on('error',error=>{rejectAll(error);worker=null;});worker.on('exit',code=>{worker=null;if(pending.size)rejectAll(new Error('계산 작업이 종료되었습니다. 다시 불러오세요.'));});
  }
  function getView({revision,reportId}={}){
   if(closed)return Promise.reject(new Error('계산 서버가 종료되었습니다.'));const key=JSON.stringify([revision,reportId||null]);if(inflight.has(key))return inflight.get(key);start();
   const id=++nextId,promise=new Promise((resolve,reject)=>{pending.set(id,{key,resolve,reject});worker.postMessage({id,revision,reportId});});inflight.set(key,promise);return promise;
  }
  async function close(){closed=true;rejectAll(new Error('서버를 종료합니다.'));if(worker)await worker.terminate();worker=null;}
  return {getView,close,diagnostics:()=>({...latestDiagnostics})};
 }
 module.exports={createViewWorker};
}
