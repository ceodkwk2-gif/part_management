'use strict';
// One server process owns this directory. Format 2 generations hold metadata
// and immutable source references; large parsed sources live in shared blobs.
// Replacing current.json remains the only commit point. Format 1 still reads.
// Unreferenced generations/raw blobs are never selected or exposed as history.
const nativeFs=require('node:fs');
const path=require('node:path');
const crypto=require('node:crypto');
const zlib=require('node:zlib');
const P=require('../src/pipeline.js');
const R=require('../src/reporting.js');
const C=require('../src/core.js');
const First=require('../src/first-confirmed.js');
const {createSourceBlobs,reference,refId}=require('./source-blobs.cjs');
const clone=value=>JSON.parse(JSON.stringify(value));
const digest=bytes=>crypto.createHash('sha256').update(bytes).digest('hex');
const RAW_ID=/^raw_[a-f0-9]{64}$/;
const GENERATION=/^\d{12}-[a-f0-9-]{36}\.json\.gz$/;
function fail(status,code,message,details){const error=new Error(message);Object.assign(error,{status,code});if(details)error.details=details;return error;}
function safeName(name){
 if(typeof name!=='string'||!name||name==='.'||name==='..'||/[\\/\x00-\x1f\x7f]/.test(name)||name.length>500)throw fail(400,'INVALID_RAW_NAME','원본 파일 이름이 올바르지 않습니다.');
 return name;
}
function createStore(options={}){
 const fs=options.fs||nativeFs;
 if(!options.dataDir)throw new Error('dataDir is required');
 const dir=path.resolve(options.dataDir),generationDir=path.join(dir,'generations'),rawDir=path.join(dir,'raw'),sourceDir=path.join(dir,'sources');
 for(const target of [dir,generationDir,rawDir,sourceDir])fs.mkdirSync(target,{recursive:true});
 let current=null,pointer=null,recoveryNotice=null,cachedStatus=null;
 let compactCache=null,compactCacheOwner=null;
 const pendingRaw=new Map();
 const now=()=>new Date().toISOString();
 const pointerPath=path.join(dir,'current.json'),previousPath=path.join(dir,'previous.json');
 function syncDirectory(directory){
  let fd;try{fd=fs.openSync(directory,'r');fs.fsyncSync(fd);}catch(_){/* Windows and some network filesystems do not support directory fsync. */}finally{if(fd!==undefined)fs.closeSync(fd);}
 }
 function atomicWrite(target,bytes){
  const temporary=target+'.'+crypto.randomUUID()+'.tmp';let fd;
  try{fd=fs.openSync(temporary,'wx',0o600);fs.writeFileSync(fd,bytes);fs.fsyncSync(fd);fs.closeSync(fd);fd=undefined;fs.renameSync(temporary,target);syncDirectory(path.dirname(target));}
  finally{if(fd!==undefined)fs.closeSync(fd);try{fs.unlinkSync(temporary);}catch(error){if(error.code!=='ENOENT')throw error;}}
 }
 const blobs=createSourceBlobs({fs,dir:sourceDir,atomicWrite});
 function compactOf(envelope=current){
  if(envelope.format===2)return {state:envelope.state,sourceIndex:envelope.sourceIndex,currentSourceRefs:envelope.currentSourceRefs,archiveSourceRefs:envelope.archiveSourceRefs};
  if(compactCacheOwner!==envelope){compactCache=blobs.compact(envelope.state);compactCacheOwner=envelope;}
  return compactCache;
 }
 function checkManifest(manifest,allowEmpty=false){
  const state=manifest?.state;
  if(state&&!First.validMap(state.manualFirstConfirmed))throw fail(422,'INVALID_FIRST_CONFIRMED','최초확인일 기록 형식이 올바르지 않습니다.');
  if(!state||state.version!==1||!state.settings||typeof state.settings!=='object'||Array.isArray(state.settings)||'sources'in state||'reportingSourceArchive'in state||!Array.isArray(manifest.sourceIndex)||!Array.isArray(manifest.currentSourceRefs)||!manifest.archiveSourceRefs||typeof manifest.archiveSourceRefs!=='object')throw fail(422,'INVALID_STATE','작업 메타데이터 형식이 올바르지 않습니다.');
  if(!allowEmpty&&!manifest.currentSourceRefs.length&&!(state.reportingWeeks||[]).length)throw fail(422,'INVALID_STATE','기존 보고를 빈 상태로 덮어쓸 수 없습니다.');
  const index=new Map();for(const item of manifest.sourceIndex){blobs.validateDescriptor(item);if(index.has(refId(item)))throw fail(422,'INVALID_REPORT_HISTORY','중복된 원본 버전 참조입니다.');index.set(refId(item),item);if(!P.slotKey(item.meta)||item.meta.date&&!R.validDate(item.meta.date))throw fail(422,'INVALID_STATE','원본 종류 또는 실제 기준일이 올바르지 않습니다.');}
  const available=new Set();for(const ref of [...manifest.currentSourceRefs,...Object.values(manifest.archiveSourceRefs)]){if(!index.has(refId(ref)))throw fail(422,'INVALID_REPORT_HISTORY','원본 버전을 찾을 수 없습니다.');available.add(refId(ref));}
  const seen=new Set();for(const report of R.reports(state)){
   if(!R.validDate(report.reportDate)||!R.validDate(report.cutoff)||report.id!==R.weekStart(report.reportDate)||seen.has(report.id)||report.cutoff>report.reportDate||!Array.isArray(report.sourceRefs))throw fail(422,'INVALID_REPORT_HISTORY','주간 이력을 확인할 수 없습니다.');seen.add(report.id);
   const excluded=new Set((report.excludedSourceRefs||[]).map(refId));
   for(const ref of report.sourceRefs){if(excluded.has(refId(ref)))continue;const item=index.get(refId(ref));if(!item||!available.has(refId(ref))||C.sourceSelectionDate(item.meta)>report.cutoff)throw fail(422,'INVALID_REPORT_HISTORY','이전 원본 참조 또는 기준일을 확인할 수 없습니다.');}
  }
  if(state.selectedReportingWeek&&!seen.has(state.selectedReportingWeek))throw fail(422,'INVALID_REPORT_HISTORY','선택한 주간 보고가 저장 이력에 없습니다.');
 }
 function reportFromManifest(manifest,reportId){
  const reports=R.reports(manifest.state),entry=reportId?reports.find(report=>report.id===reportId):R.selectedReport(manifest.state);
  if(!entry){if(reportId)throw fail(404,'REPORT_NOT_FOUND','저장된 주간 보고를 찾을 수 없습니다.');return {...clone(manifest.state),sources:[],reportingSourceArchive:{},reportingWeeks:[]};}
  const index=new Map(manifest.sourceIndex.map(item=>[refId(item),item])),excluded=new Set((entry.excludedSourceRefs||[]).map(refId));
  // Older reports may contain all sources known by that week. Calculation only
  // uses the latest source for each operating slot. Choose using metadata first
  // so a one-week view never hydrates the entire accumulated source history.
  const eligible=entry.sourceRefs.filter(ref=>!excluded.has(refId(ref))),latest=new Map();
  for(const ref of eligible){const item=index.get(refId(ref));if(!item)throw fail(422,'INVALID_REPORT_HISTORY','원본 버전을 찾을 수 없습니다.');const slot=P.slotKey(item.meta),date=C.sourceSelectionDate(item.meta)||'',prior=latest.get(slot);if(date>entry.cutoff)continue;if(!prior||date>=prior.date)latest.set(slot,{ref,date});}
  const selected=new Set([...latest.values()].map(value=>refId(value.ref))),seen=new Set(),sourceRefs=eligible.filter(ref=>{const id=refId(ref);if(!selected.has(id)||seen.has(id))return false;seen.add(id);return true;});
  const sources=sourceRefs.map(ref=>blobs.read(index.get(refId(ref)).hash));
  return {...clone(manifest.state),sources,reportingSourceArchive:{},reportingWeeks:[{...clone(entry),sourceRefs:clone(sourceRefs)}],selectedReportingWeek:entry.id,activeReportingWeek:entry.id};
 }
 function publicManifest(){return {...clone(compactOf()),revision:current.revision,updatedAt:current.updatedAt,...(recoveryNotice?{recoveryNotice}:{})};}
 function checkState(state,allowEmpty=false){
  if(state&&!First.validMap(state.manualFirstConfirmed))throw fail(422,'INVALID_FIRST_CONFIRMED','최초확인일 기록 형식이 올바르지 않습니다.');
  if(!state||typeof state!=='object'||Array.isArray(state))throw fail(422,'INVALID_STATE','작업 데이터 형식이 올바르지 않습니다.');
  if(allowEmpty&&state.version===1&&Array.isArray(state.sources)&&!state.sources.length&&state.settings&&typeof state.settings==='object'&&(!state.reportingWeeks||!state.reportingWeeks.length))return;
  const result=P.validate(state);
  if(!result.ok)throw fail(422,'INVALID_STATE','저장 전 데이터 검증에 실패했습니다.',result.errors);
  // The ordinary validator checks the selected report. Persisted history must
  // also retain every source revision referenced by older report weeks.
  const normalized=R.normalizeState(state),seen=new Set();
  for(const report of R.reports(normalized)){
   if(!R.validDate(report.reportDate)||!R.validDate(report.cutoff)||report.id!==R.weekStart(report.reportDate)||seen.has(report.id)||report.cutoff>report.reportDate||R.reportWarnings(normalized,report.id).length)throw fail(422,'INVALID_REPORT_HISTORY','주간 이력 또는 이전 원본 참조를 확인할 수 없습니다.');
   seen.add(report.id);
  }
 }
 function readPointer(file){
  const value=JSON.parse(fs.readFileSync(file,'utf8'));
  if(value.format!==1||!Number.isSafeInteger(value.revision)||value.revision<0||!GENERATION.test(value.generation)||!/^[a-f0-9]{64}$/.test(value.sha256||''))throw new Error('Invalid generation pointer');
  const bytes=fs.readFileSync(path.join(generationDir,value.generation));
  if(digest(bytes)!==value.sha256)throw new Error('Generation checksum mismatch');
  const envelope=JSON.parse(zlib.gunzipSync(bytes).toString('utf8'));
  if(![1,2].includes(envelope.format)||envelope.revision!==value.revision||!Array.isArray(envelope.commits)||!envelope.raw||typeof envelope.raw!=='object'||Array.isArray(envelope.raw))throw new Error('Invalid stored envelope');
  if(envelope.format===1)checkState(envelope.state,true);else checkManifest(envelope,true);
  for(const [id,meta]of Object.entries(envelope.raw))if(!RAW_ID.test(id)||meta.id!==id||meta.sha256!==id.slice(4)||!Number.isSafeInteger(meta.size)||meta.size<0)throw new Error('Invalid raw manifest');
  return {pointer:value,envelope};
 }
 function load(){
  const hasCurrent=fs.existsSync(pointerPath),hasPrevious=fs.existsSync(previousPath);
  if(!hasCurrent&&!hasPrevious)return false;
  try{const saved=readPointer(pointerPath);pointer=saved.pointer;current=saved.envelope;cacheStatus();return true;}
  catch(primaryError){
   try{const saved=readPointer(previousPath);pointer=saved.pointer;current=saved.envelope;cacheStatus();recoveryNotice='최신 저장본을 읽지 못해 직전 정상 저장본을 복구했습니다. 최신 반영 자료를 확인해 주세요.';return true;}
   catch(_){throw fail(503,'STORE_RECOVERY_REQUIRED','저장된 현재·직전 데이터 모두 읽을 수 없습니다. 기존 파일을 덮어쓰지 않았습니다. 백업 복구가 필요합니다.');}
  }
 }
 function publish(envelope){
  const generation=String(envelope.revision).padStart(12,'0')+'-'+crypto.randomUUID()+'.json.gz';
  envelope.commits.at(-1).generation=generation;
  const bytes=zlib.gzipSync(Buffer.from(JSON.stringify(envelope)),{level:6});
  const nextPointer={format:1,revision:envelope.revision,generation,sha256:digest(bytes)};
  atomicWrite(path.join(generationDir,generation),bytes);
  if(pointer)atomicWrite(previousPath,Buffer.from(JSON.stringify(pointer)));
  atomicWrite(pointerPath,Buffer.from(JSON.stringify(nextPointer)));
  // No code that can fail belongs after this publication point.
  pointer=nextPointer;current=envelope;compactCache=null;compactCacheOwner=null;cacheStatus();
 }
 function publicEnvelope(){return {state:current.format===1?clone(current.state):blobs.materialize(compactOf()),revision:current.revision,updatedAt:current.updatedAt,...(recoveryNotice?{recoveryNotice}:{} )};}
 function reportInfo(state){const reports=R.reports(state),latest=reports.at(-1);return {reportDate:latest?.reportDate||null,reportCount:reports.length};}
 function cacheStatus(){cachedStatus={revision:current.revision,updatedAt:current.updatedAt,...reportInfo(current.state),rawCount:Object.keys(current.raw).length,storageFormat:current.format};}
 function checkRevision(baseRevision){
  try{const disk=JSON.parse(fs.readFileSync(pointerPath,'utf8'));if(disk.revision!==current.revision&&GENERATION.test(disk.generation||'')){const loaded=readPointer(pointerPath);pointer=loaded.pointer;current=loaded.envelope;compactCache=null;compactCacheOwner=null;cacheStatus();}}
  catch(error){if(!recoveryNotice)throw fail(503,'STORE_READ_FAILED','현재 저장본을 확인할 수 없습니다. 기존 데이터는 유지됩니다.');}
  if(!Number.isSafeInteger(baseRevision)||baseRevision!==current.revision)throw fail(409,'REVISION_CONFLICT','다른 화면에서 자료가 갱신됐습니다. 새로고침한 뒤 다시 반영해 주세요.',{currentRevision:current.revision});
 }
 function commitManifest(manifest,{baseRevision,rawIds=[],operation='update',reportDate}={}){
  checkRevision(baseRevision);
  if(!['import','carry','settings','notes','restore','remove','update','carry-forward','initialize','migrate','firstConfirmed','followup','quality','archive-recovered-originals','undoImport'].includes(operation))throw fail(400,'INVALID_OPERATION','저장 작업 종류가 올바르지 않습니다.');
  checkManifest(manifest,operation==='undoImport'||(current.format===1?!current.state.sources.length:!current.currentSourceRefs.length));
  const oldWeeks=new Set(R.reports(current.state).map(report=>report.id)),newWeeks=new Set(R.reports(manifest.state).map(report=>report.id));
  if(!['restore','undoImport'].includes(operation)&&[...oldWeeks].some(id=>!newWeeks.has(id)))throw fail(422,'HISTORY_REMOVAL_BLOCKED','이전 주간 이력이 빠져 있습니다. 기존 이력을 유지한 자료로 다시 반영해 주세요.');
  if(reportDate!=null&&!R.validDate(reportDate))throw fail(400,'INVALID_REPORT_DATE','보고일을 YYYY-MM-DD 형식으로 확인해 주세요.');
  reportDate=reportDate||R.selectedReport(manifest.state)?.reportDate||reportInfo(manifest.state).reportDate;
  const revision=current.revision+1,updatedAt=now(),raw=includeRaw(rawIds,revision,operation,reportDate,current.raw),commit={revision,updatedAt,operation,reportDate:reportDate||null,week:reportDate?R.weekStart(reportDate):null,rawIds:[...new Set(rawIds)]};
  publish({format:2,...manifest,revision,updatedAt,raw,commits:[...current.commits,commit]});for(const id of rawIds)pendingRaw.delete(id);return publicManifest();
 }
 function addRaw({name,bytes}={}){
  safeName(name);
  if(!Buffer.isBuffer(bytes)&&!(bytes instanceof Uint8Array))throw fail(400,'INVALID_RAW_BYTES','원본 파일을 읽을 수 없습니다.');
  bytes=Buffer.from(bytes);const sha256=digest(bytes),id='raw_'+sha256,target=path.join(rawDir,sha256+'.bin');
  if(fs.existsSync(target)){
   const existing=fs.readFileSync(target);if(existing.length!==bytes.length||digest(existing)!==sha256)throw fail(500,'RAW_INTEGRITY_ERROR','보관된 원본의 무결성을 확인할 수 없습니다.');
  }else atomicWrite(target,bytes);
  const existing=pendingRaw.get(id)||current?.raw[id],names=[...new Set([...(existing?.names||[]),...(existing?.name?[existing.name]:[]),name])];
  const meta={id,name,size:bytes.length,sha256,names,storedAt:existing?.storedAt||now()};pendingRaw.set(id,meta);
  return clone(meta);
 }
 function includeRaw(rawIds,revision,operation,reportDate,prior={}){
  if(!Array.isArray(rawIds))throw fail(400,'INVALID_RAW_IDS','원본 파일 목록이 올바르지 않습니다.');
  const raw=clone(prior),week=reportDate?R.weekStart(reportDate):null;
  for(const id of new Set(rawIds)){
   if(typeof id!=='string'||!RAW_ID.test(id))throw fail(400,'INVALID_RAW_ID','원본 파일 식별자가 올바르지 않습니다.');
   const meta=pendingRaw.get(id)||raw[id];if(!meta)throw fail(422,'RAW_NOT_STAGED','반영할 원본 파일이 보관되지 않았습니다. 다시 선택해 주세요.');
   const bytes=fs.readFileSync(path.join(rawDir,meta.sha256+'.bin'));
   if(bytes.length!==meta.size||digest(bytes)!==meta.sha256)throw fail(500,'RAW_INTEGRITY_ERROR','반영할 원본 파일의 무결성을 확인할 수 없습니다.');
   raw[id]={...meta,names:[...new Set([...(raw[id]?.names||[]),...(meta.names||[]),meta.name])],date:reportDate||null,week,
    uses:[...(raw[id]?.uses||[]),{revision,operation,reportDate:reportDate||null,week,name:meta.name}]};
  }
  return raw;
 }
 function backupFileEntries(){
  // A backup is a snapshot of immutable committed files. Hash one file at a
  // time, keeping at most a fixed read buffer and one parsed source in memory.
  const entries=[],generations=new Set(current.commits.map(commit=>commit.generation));generations.add(pointer.generation);
  let previous=null;try{previous=readPointer(previousPath).pointer;generations.add(previous.generation);}catch(_){}
  function fromFile(name,target,expected){
   const hasher=crypto.createHash('sha256'),buffer=Buffer.allocUnsafe(1024*1024);let size=0,fd;
   try{fd=fs.openSync(target,'r');for(;;){const length=fs.readSync(fd,buffer,0,buffer.length,null);if(!length)break;hasher.update(buffer.subarray(0,length));size+=length;}}finally{if(fd!==undefined)fs.closeSync(fd);}
   const sha256=hasher.digest('hex');if(expected&&(expected.size!==size||expected.sha256!==sha256))throw fail(500,'RAW_INTEGRITY_ERROR','보관된 원본의 무결성을 확인할 수 없습니다.');
   return {name,path:target,size,sha256};
  }
  const hashes=new Set();
  for(const generation of generations){
   if(!GENERATION.test(generation||''))throw fail(500,'BACKUP_HISTORY_INVALID','저장 이력을 백업할 수 없습니다.');
   const target=path.join(generationDir,generation),envelope=JSON.parse(zlib.gunzipSync(fs.readFileSync(target)));
   if(envelope.format===2)for(const item of envelope.sourceIndex)hashes.add(item.hash);
   entries.push(fromFile('generations/'+generation,target));
  }
  for(const hash of hashes){blobs.read(hash);entries.push(fromFile('sources/'+hash+'.json.gz',blobs.filename(hash)));}
  for(const meta of Object.values(current.raw))entries.push(fromFile('raw/'+meta.sha256+'.bin',path.join(rawDir,meta.sha256+'.bin'),meta));
  for(const [name,value]of [['current.json',pointer],['previous.json',previous]])if(value){const bytes=Buffer.from(JSON.stringify(value));entries.push({name,bytes,size:bytes.length,sha256:digest(bytes)});}
  return entries;
 }
 if(!load()){
  const state=clone(options.seedState||C.empty());checkState(state,true);
  const rawIds=[];
  if(options.initialRawDir&&fs.existsSync(options.initialRawDir)){
   function visit(directory){for(const entry of fs.readdirSync(directory,{withFileTypes:true}).sort((a,b)=>a.name.localeCompare(b.name))){const target=path.join(directory,entry.name);if(entry.isDirectory())visit(target);else if(entry.isFile()&&/\.(xlsx?|xlsb|csv)$/i.test(entry.name)&&!entry.name.startsWith('~$'))rawIds.push(addRaw({name:entry.name,bytes:fs.readFileSync(target)}).id);}}
   visit(path.resolve(options.initialRawDir));
  }
  const updatedAt=now(),info=reportInfo(state),commit={revision:0,updatedAt,operation:'initialize',reportDate:info.reportDate,week:info.reportDate?R.weekStart(info.reportDate):null,rawIds:[...new Set(rawIds)]};
  publish({format:2,...blobs.compact(state),revision:0,updatedAt,raw:includeRaw(rawIds,0,'initialize',info.reportDate),commits:[commit]});pendingRaw.clear();
 }
 return {
  read:publicEnvelope,
  compactManifest:publicManifest,
  readManifest:publicManifest,
  readReportState(reportId){return reportFromManifest(compactOf(),reportId);},
  readSources(refs){
   if(!Array.isArray(refs))throw fail(400,'INVALID_SOURCE_REFS','조회할 원본 목록이 올바르지 않습니다.');const manifest=compactOf(),index=new Map(manifest.sourceIndex.map(item=>[refId(item),item])),hashes=new Set(manifest.sourceIndex.map(item=>item.hash));
   return refs.map(ref=>{const item=ref?.hash?hashes.has(ref.hash)&&ref:index.get(refId(ref||{}));if(!item)throw fail(404,'SOURCE_NOT_FOUND','저장된 원본 버전을 찾을 수 없습니다.');return blobs.read(item.hash);});
  },
  migrate({baseRevision=current.revision}={}){checkRevision(baseRevision);if(current.format===2)return publicManifest();return commitManifest(compactOf(),{baseRevision,operation:'migrate'});},
  saveMetadata({patch,baseRevision,operation='notes',reportDate,actor}={}){
   checkRevision(baseRevision);const allowed=new Set(['notes','partFollowups','settings','leadTimes','partLeadTimes','summaryNotes','actionNotes','selectedReportingWeek','manualFirstConfirmed','qualityReviews']);
   if(!patch||typeof patch!=='object'||Array.isArray(patch)||Object.keys(patch).some(key=>!allowed.has(key)))throw fail(400,'INVALID_METADATA_PATCH','설정·조치 기록 이외의 데이터는 이 경로에서 바꿀 수 없습니다.');
   if('manualFirstConfirmed'in patch&&!First.validMap(patch.manualFirstConfirmed))throw fail(422,'INVALID_FIRST_CONFIRMED','최초확인일 기록 형식이 올바르지 않습니다.');
   const manifest=publicManifest(),audit=require('./audit.cjs').event(manifest.state,patch,{actor,operation,revision:current.revision+1});manifest.state={...manifest.state,...clone(patch),...(audit?{auditLog:[...(manifest.state.auditLog||[]),audit]}:{})};delete manifest.revision;delete manifest.updatedAt;delete manifest.recoveryNotice;
   if('settings'in patch||'leadTimes'in patch||'partLeadTimes'in patch){const state=reportFromManifest(manifest);if(state.reportingWeeks.length)checkState(state);}
   return commitManifest(manifest,{baseRevision,operation,reportDate});
  },
  saveManifest({manifest,sources=[],baseRevision,rawIds=[],operation='update',reportDate}={}){
   checkRevision(baseRevision);if(!manifest||!Array.isArray(sources))throw fail(400,'INVALID_MANIFEST','저장할 보고 메타데이터가 올바르지 않습니다.');
   const next=clone(manifest);delete next.revision;delete next.updatedAt;delete next.recoveryNotice;
   const known=new Map(compactOf().sourceIndex.map(item=>[refId(item),item]));for(const source of sources){const descriptor=blobs.write(source,reference(source));known.set(refId(descriptor),descriptor);}
   const incomingIndex=new Map((next.sourceIndex||[]).map(item=>[refId(item),item]));for(const source of sources){const ref=reference(source);incomingIndex.set(refId(ref),known.get(refId(ref)));}
   for(const [id,item]of incomingIndex){const saved=known.get(id);if(!saved||saved.hash!==item.hash||JSON.stringify(saved.meta)!==JSON.stringify(item.meta))throw fail(422,'INVALID_SOURCE_REFERENCE','보관되지 않은 원본 참조입니다. 새 원본을 함께 전달해 주세요.');}
   next.sourceIndex=[...incomingIndex.values()];checkManifest(next,operation==='undoImport'||(current.format===1?!current.state.sources.length:!current.currentSourceRefs.length));
   const previous=new Map(R.reports(current.state).map(report=>[report.id,report]));
   const settingsChanged=JSON.stringify(next.state.settings)!==JSON.stringify(current.state.settings)||JSON.stringify(next.state.partLeadTimes)!==JSON.stringify(current.state.partLeadTimes);
   const selected=R.selectedReport(next.state)?.id;
   for(const report of R.reports(next.state)){if(JSON.stringify(report)!==JSON.stringify(previous.get(report.id))||settingsChanged&&report.id===selected){checkState(reportFromManifest(next,report.id));}}
   return commitManifest(next,{baseRevision,rawIds,operation,reportDate});
  },
  status(){return {...cachedStatus,...(recoveryNotice?{recoveryNotice}:{})};},
  save({state,baseRevision,rawIds=[],operation='update',reportDate}={}){
   checkRevision(baseRevision);state=clone(state);checkState(state,current.format===1?!current.state.sources.length:!current.currentSourceRefs.length);
   commitManifest(blobs.compact(state),{baseRevision,rawIds,operation,reportDate});
   return publicEnvelope();
  },
  addRaw,
  listRaw(){return clone(Object.values(current.raw)).sort((a,b)=>(b.date||'').localeCompare(a.date||'')||a.name.localeCompare(b.name));},
  readRaw(id){
   if(typeof id!=='string'||!RAW_ID.test(id))throw fail(400,'INVALID_RAW_ID','원본 파일 식별자가 올바르지 않습니다.');
   const meta=current.raw[id];if(!meta)throw fail(404,'RAW_NOT_FOUND','반영 완료된 원본 파일을 찾지 못했습니다.');
   const bytes=fs.readFileSync(path.join(rawDir,meta.sha256+'.bin'));
   if(bytes.length!==meta.size||digest(bytes)!==meta.sha256)throw fail(500,'RAW_INTEGRITY_ERROR','보관된 원본의 무결성을 확인할 수 없습니다.');
   return {meta:clone(meta),bytes};
  },
  listCommits(limit=100){if(!Number.isInteger(limit)||limit<1||limit>10000)throw fail(400,'INVALID_LIMIT','이력 조회 개수를 확인해 주세요.');return clone(current.commits.slice(-limit).reverse());},
  backupFileEntries,
  backupEntries(){
   // Compatibility helper for existing callers and small test fixtures. The
   // HTTP download path uses backupFileEntries() and streams these files.
   return backupFileEntries().map(entry=>({name:entry.name,bytes:entry.bytes||fs.readFileSync(entry.path)}));
  },
  close(){}
 };
}
module.exports={createStore};
