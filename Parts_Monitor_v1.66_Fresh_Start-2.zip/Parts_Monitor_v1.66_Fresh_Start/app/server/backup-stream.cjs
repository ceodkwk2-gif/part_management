'use strict';
// The ZIP download holds one file chunk in memory, never the entire archive.
// Known sizes/CRC in local headers also support older offline restore readers.
const fs=require('node:fs'),crypto=require('node:crypto');
const crcTable=Array.from({length:256},(_,index)=>{let value=index;for(let i=0;i<8;i++)value=value&1?0xedb88320^(value>>>1):value>>>1;return value>>>0;});
function crcUpdate(crc,bytes){for(const value of bytes)crc=crcTable[(crc^value)&255]^(crc>>>8);return crc>>>0;}
const digest=bytes=>crypto.createHash('sha256').update(bytes).digest('hex');
function snapshot(store,version){
 const entries=store.backupFileEntries(),files=entries.map((entry,index)=>({path:entry.name,file:'Backup_'+String(index).padStart(6,'0')+'.bin',sha256:entry.sha256,size:entry.size}));
 const bytes=Buffer.from(JSON.stringify({format:'parts-monitor-server-backup',version:1,appVersion:version,createdAt:new Date().toISOString(),revision:store.status().revision,files}));
 const values=[{name:'Server_Backup.json',bytes,size:bytes.length,sha256:digest(bytes)},...entries.map((entry,index)=>({...entry,name:files[index].file}))];
 const total=values.reduce((sum,item)=>sum+item.size+Buffer.byteLength(item.name)*2+92,22);
 if(values.length>=65535||total>=0xffffffff)throw Object.assign(new Error('전체 백업이 ZIP 단일 파일 한도를 초과했습니다. 지원 담당자에게 data 폴더 백업을 요청하세요.'),{status:413});
 return values;
}
async function writeZip(output,entries){
 let offset=0;const central=[];
 const write=bytes=>new Promise((resolve,reject)=>{if(output.destroyed)return reject(Error('백업 다운로드 연결이 종료되었습니다.'));output.write(bytes,error=>error?reject(error):resolve());});
 for(const entry of entries){
  let expectedCrc=0xffffffff,expectedSize=0;const check=crypto.createHash('sha256');
  for await(const chunk of entry.bytes?[entry.bytes]:fs.createReadStream(entry.path,{highWaterMark:256*1024})){expectedSize+=chunk.length;expectedCrc=crcUpdate(expectedCrc,chunk);check.update(chunk);}
  if(expectedSize!==entry.size||check.digest('hex')!==entry.sha256)throw Error('백업 파일의 무결성을 확인하지 못했습니다.');expectedCrc=(expectedCrc^0xffffffff)>>>0;
  const name=Buffer.from(entry.name),start=offset,local=Buffer.alloc(30);local.writeUInt32LE(0x04034b50,0);local.writeUInt16LE(20,4);local.writeUInt16LE(0x0800,6);local.writeUInt32LE(expectedCrc,14);local.writeUInt32LE(entry.size,18);local.writeUInt32LE(entry.size,22);local.writeUInt16LE(name.length,26);
  await write(local);await write(name);offset+=local.length+name.length;
  let crc=0xffffffff,size=0;const sha=crypto.createHash('sha256'),stream=entry.bytes?[entry.bytes]:fs.createReadStream(entry.path,{highWaterMark:256*1024});
  for await(const chunk of stream){size+=chunk.length;if(size>entry.size)throw Error('백업 중 파일 크기가 변경되었습니다.');crc=crcUpdate(crc,chunk);sha.update(chunk);await write(chunk);offset+=chunk.length;}
  if(size!==entry.size||sha.digest('hex')!==entry.sha256)throw Error('백업 중 파일 무결성을 확인하지 못했습니다.');crc=(crc^0xffffffff)>>>0;
  if(crc!==expectedCrc)throw Error('백업 도중 파일 내용이 변경되었습니다.');
  const header=Buffer.alloc(46);header.writeUInt32LE(0x02014b50,0);header.writeUInt16LE(20,4);header.writeUInt16LE(20,6);header.writeUInt16LE(0x0800,8);header.writeUInt32LE(crc,16);header.writeUInt32LE(size,20);header.writeUInt32LE(size,24);header.writeUInt16LE(name.length,28);header.writeUInt32LE(start,42);central.push(header,name);
 }
 const directoryOffset=offset;for(const bytes of central){await write(bytes);offset+=bytes.length;}
 const end=Buffer.alloc(22);end.writeUInt32LE(0x06054b50,0);end.writeUInt16LE(entries.length,8);end.writeUInt16LE(entries.length,10);end.writeUInt32LE(offset-directoryOffset,12);end.writeUInt32LE(directoryOffset,16);await write(end);output.end();
}
module.exports={snapshot,writeZip,crcUpdate};
