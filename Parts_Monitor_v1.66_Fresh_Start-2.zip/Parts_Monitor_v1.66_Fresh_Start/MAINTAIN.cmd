@echo off
setlocal
cd /d "%~dp0"
set "PARTS_NODE=node"
if exist "app\runtime\node.exe" set "PARTS_NODE=app\runtime\node.exe"
"%PARTS_NODE%" app\scripts\maintain.cjs %*
if errorlevel 1 pause
