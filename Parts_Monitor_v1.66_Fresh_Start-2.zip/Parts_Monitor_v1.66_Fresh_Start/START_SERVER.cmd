@echo off
setlocal
chcp 65001 >nul
title Parts Monitor - Server 8510

cd /d "%~dp0app"
if errorlevel 1 goto folder_error

set "PARTS_NODE="
if exist "%CD%\runtime\node.exe" set "PARTS_NODE=%CD%\runtime\node.exe"
if not defined PARTS_NODE for /f "delims=" %%I in ('where node.exe 2^>nul') do if not defined PARTS_NODE set "PARTS_NODE=%%I"
if not defined PARTS_NODE goto node_missing

"%PARTS_NODE%" -e "process.exit(Number(process.versions.node.split('.')[0])>=18?0:1)"
if errorlevel 1 goto node_old

echo.
echo Parts Monitor를 시작합니다.
echo 이 창을 닫으면 팀원 접속도 종료됩니다. 운영하는 동안 열어 두세요.
echo 브라우저가 열리면 비밀번호 없이 바로 사용합니다. 자료 업로드에서 Excel 또는 ZIP을 반영하세요.
echo.
"%PARTS_NODE%" server.cjs --open
set "PARTS_EXIT=%ERRORLEVEL%"
if "%PARTS_EXIT%"=="0" goto finished
echo.
echo [시작 실패] 위 오류 내용을 확인하세요.
echo 자세한 안내: 상위 폴더의 START_HERE.html
pause
exit /b %PARTS_EXIT%

:node_missing
echo.
echo [처음 한 번 준비 필요] 이 PC에서 Node.js를 찾지 못했습니다.
echo 사내 승인된 Node.js 22 또는 24 설치를 지원 담당자에게 요청하세요.
echo 조회하는 팀원 PC에는 설치할 필요가 없습니다.
echo 승인된 휴대용 실행본은 app\runtime\node.exe 위치로 둘 수도 있습니다.
echo 자세한 안내: 상위 폴더의 START_HERE.html
pause
exit /b 1

:node_old
echo.
echo [버전 확인 필요] 실행에는 Node.js 18 이상이 필요합니다.
echo 새 설치는 사내 승인된 Node.js 22 또는 24를 사용하세요.
echo 조회하는 팀원 PC에는 설치할 필요가 없습니다.
pause
exit /b 1

:folder_error
echo.
echo [폴더 확인 필요] ZIP 전체를 서버 PC의 로컬 폴더에 압축 해제하세요.
echo START_SERVER.cmd 옆에 app 폴더가 있어야 합니다.
echo ZIP 안에서 바로 실행하거나 파일 하나만 옮겨 실행하지 마세요.
pause
exit /b 1

:finished
echo.
echo 서버가 종료되었습니다. 다시 사용할 때 이 파일을 실행하세요.
pause
exit /b 0
